<!---
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-aws-eks-bootstrap

Terraform module for Terragrunt layer: eks-bootstrap

## LINKS
#### [Additional documentation](./docs/README.md)
#### [CHANGELOG](CHANGELOG.md)

<!--- "./docs/header.md" content ends here.--->

<!--- "./README.md" file content bellow this comment is automticaly generated and replaced by terraform_docs and pre-commit hooks.
To make changes in anything below this comment, modify template file - ".terraform-docs.yaml".
Human managed content (abbove this comment) is automatically pulled in "./README.md" file from "./docs/header.md". --->

## Examples
```hcl
module "eks_bootstrap" {
  source = "../"

  aws_region       = "eu-central-1"
  aws_account_name = "devsecops"
  env              = "tst"

  tags = {
    creator  = "antoni.tomaszuk@luminorgroup.com"
    git_repo = "https://git.onelum.host/lds/Foundation/terragrunt-aws-eks-bootstrap"
  }

  layers = {
    network = data.terraform_remote_state.network.outputs
    eks     = data.terraform_remote_state.eks.outputs
  }
}
```
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.10.0 |
| <a name="provider_kubectl"></a> [kubectl](#provider\_kubectl) | 1.14.0 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | 2.22.0 |
| <a name="provider_time"></a> [time](#provider\_time) | 0.9.1 |
| <a name="provider_tls"></a> [tls](#provider\_tls) | 4.0.4 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_coreinfra_tags"></a> [coreinfra\_tags](#module\_coreinfra\_tags) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-coreinfra-tags.git | v3.0.5 |
| <a name="module_eks_addon_keda"></a> [eks\_addon\_keda](#module\_eks\_addon\_keda) | aws-ia/eks-blueprints-addon/aws | ~> 1.1 |
| <a name="module_eks_addon_linkerd"></a> [eks\_addon\_linkerd](#module\_eks\_addon\_linkerd) | aws-ia/eks-blueprints-addon/aws | ~> 1.1 |
| <a name="module_eks_addon_linkerd_crds"></a> [eks\_addon\_linkerd\_crds](#module\_eks\_addon\_linkerd\_crds) | aws-ia/eks-blueprints-addon/aws | ~> 1.1 |
| <a name="module_eks_addon_newrelic"></a> [eks\_addon\_newrelic](#module\_eks\_addon\_newrelic) | aws-ia/eks-blueprints-addon/aws | ~> 1.1 |
| <a name="module_eks_addon_wiz"></a> [eks\_addon\_wiz](#module\_eks\_addon\_wiz) | aws-ia/eks-blueprints-addon/aws | ~> 1.1 |
| <a name="module_eks_blueprints_addons"></a> [eks\_blueprints\_addons](#module\_eks\_blueprints\_addons) | aws-ia/eks-blueprints-addons/aws | ~> 1.9 |
| <a name="module_iam_irsa_newrelic_secret"></a> [iam\_irsa\_newrelic\_secret](#module\_iam\_irsa\_newrelic\_secret) | terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks | ~> 5.30 |
| <a name="module_iam_irsa_wiz_secret"></a> [iam\_irsa\_wiz\_secret](#module\_iam\_irsa\_wiz\_secret) | terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks | ~> 5.30 |
| <a name="module_irsa_ebs_csi_driver"></a> [irsa\_ebs\_csi\_driver](#module\_irsa\_ebs\_csi\_driver) | terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks | ~> 5.30 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_addon_aws_efs_csi_driver"></a> [addon\_aws\_efs\_csi\_driver](#input\_addon\_aws\_efs\_csi\_driver) | EFS CSI Driver add-on configuration values | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "aws-efs-csi-driver")<br>    namespace     = optional(string, "kube-system")<br>    chart_version = optional(string, "2.4.8")<br>    repository    = optional(string, "https://kubernetes-sigs.github.io/aws-efs-csi-driver/")<br>  })</pre> | <pre>{<br>  "enable": true<br>}</pre> | no |
| <a name="input_addon_aws_load_balancer_controller"></a> [addon\_aws\_load\_balancer\_controller](#input\_addon\_aws\_load\_balancer\_controller) | AWS Load Balancer Controller add-on configuration values | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "aws-load-balancer-controller")<br>    namespace     = optional(string, "kube-system")<br>    chart_version = optional(string, "1.6.0")<br>    repository    = optional(string, "https://aws.github.io/eks-charts")<br>  })</pre> | <pre>{<br>  "enable": true<br>}</pre> | no |
| <a name="input_addon_cert_manager"></a> [addon\_cert\_manager](#input\_addon\_cert\_manager) | cert-manager add-on configuration values | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "cert-manager")<br>    namespace     = optional(string, "cert-manager")<br>    chart_version = optional(string, "1.12.4")<br>    repository    = optional(string, "https://charts.jetstack.io")<br>  })</pre> | <pre>{<br>  "enable": true<br>}</pre> | no |
| <a name="input_addon_external_secrets"></a> [addon\_external\_secrets](#input\_addon\_external\_secrets) | External Secrets add-on configuration values | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "external-secrets")<br>    namespace     = optional(string, "external-secrets")<br>    chart_version = optional(string, "0.9.4")<br>    repository    = optional(string, "https://charts.external-secrets.io")<br>  })</pre> | <pre>{<br>  "enable": true<br>}</pre> | no |
| <a name="input_addon_ingress_nginx"></a> [addon\_ingress\_nginx](#input\_addon\_ingress\_nginx) | Ingress Nginx add-on configurations | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "ingress-nginx")<br>    namespace     = optional(string, "ingress-nginx")<br>    chart_version = optional(string, "4.7.1")<br>    repository    = optional(string, "https://kubernetes.github.io/ingress-nginx")<br>  })</pre> | <pre>{<br>  "enable": true<br>}</pre> | no |
| <a name="input_addon_karpenter"></a> [addon\_karpenter](#input\_addon\_karpenter) | Karpenter add-on configuration values | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "karpenter")<br>    namespace     = optional(string, "karpenter")<br>    chart_version = optional(string, "v0.30.0")<br>    repository    = optional(string, "internal")<br>  })</pre> | <pre>{<br>  "enable": true<br>}</pre> | no |
| <a name="input_addon_keda"></a> [addon\_keda](#input\_addon\_keda) | Keda add-on configurations | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "keda")<br>    namespace     = optional(string, "keda")<br>    chart_version = optional(string, "2.11.2")<br>    repository    = optional(string, "https://kedacore.github.io/charts")<br>  })</pre> | <pre>{<br>  "enable": true<br>}</pre> | no |
| <a name="input_addon_linkerd"></a> [addon\_linkerd](#input\_addon\_linkerd) | Linkerd add-on configurations | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "linkerd-control-plane")<br>    namespace     = optional(string, "linkerd")<br>    chart_version = optional(string, "1.15.0")<br>    repository    = optional(string, "https://helm.linkerd.io/stable")<br>    crds = object({<br>      name          = optional(string, "linkerd-crds")<br>      chart_version = optional(string, "1.8.0")<br>      repository    = optional(string, "https://helm.linkerd.io/stable")<br>    })<br>  })</pre> | <pre>{<br>  "crds": {},<br>  "enable": false<br>}</pre> | no |
| <a name="input_addon_newrelic"></a> [addon\_newrelic](#input\_addon\_newrelic) | New Relic add-on configurations | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "newrelic")<br>    namespace     = optional(string, "newrelic")<br>    chart_version = optional(string, "5.0.28")<br>    repository    = optional(string, "https://helm-charts.newrelic.com")<br>  })</pre> | <pre>{<br>  "enable": false<br>}</pre> | no |
| <a name="input_addon_wiz"></a> [addon\_wiz](#input\_addon\_wiz) | Wiz add-on configurations | <pre>object({<br>    enable        = bool<br>    name          = optional(string, "wiz")<br>    namespace     = optional(string, "wiz")<br>    chart_version = optional(string, "2.3.4")<br>    repository    = optional(string, "https://wiz-sec.github.io/charts")<br>  })</pre> | <pre>{<br>  "enable": false<br>}</pre> | no |
| <a name="input_aws_account_name"></a> [aws\_account\_name](#input\_aws\_account\_name) | User friendly name for AWS account | `string` | n/a | yes |
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | AWS region in which resources will be deployed | `string` | `"eu-central-1"` | no |
| <a name="input_env"></a> [env](#input\_env) | Environment type | `string` | n/a | yes |
| <a name="input_layers"></a> [layers](#input\_layers) | Infrastructure layers information | <pre>object({<br>    network = any<br>    eks     = any<br>  })</pre> | n/a | yes |
| <a name="input_private_nlb_cidr_hostnum"></a> [private\_nlb\_cidr\_hostnum](#input\_private\_nlb\_cidr\_hostnum) | Host number used to calculate IP address based on private subnet CIDR blocks | `number` | `15` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Map of tags to be configured for all resources of this deployment | <pre>object({<br>    service_area     = optional(string, "cloud")<br>    project_id       = optional(string, "Foundation")<br>    creator          = string<br>    owner            = optional(string, "guntis.smits@luminorgroup.com")<br>    git_repo         = string<br>    confidentiality  = optional(string, "shared-env")<br>    integrity        = optional(string, "shared-env")<br>    availability     = optional(string, "shared-env")<br>    personal_data    = optional(string, "shared-env")<br>    compliance       = optional(string, "shared-env")<br>    enable_backup    = optional(string, "on")<br>    backup_retention = optional(string, "1m")<br>    backup_rpo       = optional(string, "1d")<br>  })</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_private_nlb"></a> [private\_nlb](#output\_private\_nlb) | Private Network Load Balancer information |

