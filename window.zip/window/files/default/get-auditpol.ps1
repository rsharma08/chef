﻿<#
.SYNOPSIS

This script generates a comma delimited list of all Audit Policy settings into auditpol_settings.txt
 
#>

$log = "c:\chef\policy\auditpol_settings.txt"

if (Test-Path -path $log) {
  remove-item -path $log 
}

$subcats   = auditpol /list /subcategory:* /r | Where-Object { -not[String]::IsNullorEmpty($_)} | ConvertFrom-Csv
$categorys = auditpol /get /category:* /r | Where-Object { -not[String]::IsNullorEmpty($_)} | ConvertFrom-Csv

$success = ""
$failure = ""
$subcat_name = ""

foreach ($cat in $subcats) {
  $guid= $cat.GUID
  if ($guid -notlike  '{*-797A-11D9-BED3-505054503030}') { # only pull back subcategory names from the returned list (not category names)
    Clear-Variable -name success
    Clear-Variable -name failure
    Clear-Variable -name subcat_name
    $auditsetting = $categorys | Where-Object {$_.'Subcategory GUID' -eq $guid}
    $subcat_name = $auditsetting.Subcategory
    $subcat_success = $auditsetting.'Inclusion Setting'
    $subcat_failure = $auditsetting.'Exclusion Setting'
    # Capture no auditing enabled
    if ($subcat_success -eq "No Auditing") {
      $success= "disable"
      $failure= "disable"
    }
    else {
      if ($subcat_success -eq "Success and Failure") {
        # Capture both success & failure auditing enabled
        $success= "enable"
        $failure= "enable"
      }
      else {
        # Capture success only auditing
        if ($subcat_success -eq "Success" ) {
          $success= "enable"
          if (!$subcat_failure) {
            $failure= "disable"
          }
        }
        else {
          # Capture failure only auditing
          if ($subcat_success -eq "Failure" ) {
            $success= "disable"
            $failure = "enable"
          }
        }
      }
    }
    add-content -Path "$log" -value "$subcat_name,$success,$failure"
  
  }
}
return "DONE"
