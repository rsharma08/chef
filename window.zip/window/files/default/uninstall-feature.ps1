﻿<#
.SYNOPSIS

This script uninstalls a supplied Windows feature
 
#>

$feature = $args[0]

$cmd = Uninstall-WindowsFeature -name $feature
if ($? -eq "True") {
  return "SUCCESS"
}
else {
  return "FAILED"
}
