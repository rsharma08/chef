﻿<#
.SYNOPSIS

This script returns outputs a list of all installed Windows features into installed_features.txt
 
#>

$log = "c:\chef\policy\installed_features.txt"

if (Test-Path -path $log) {
  remove-item -path $log 
}

$installed = Get-WindowsFeature | where installed
foreach ($f in $installed) {
  $feature = $f.name
  add-content -Path "$log" -value "$feature"
}

return "DONE"
