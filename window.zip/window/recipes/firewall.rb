require "chef/mixin/powershell_exec" 

Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                                 F I R E W A L L                                    ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running firewall.rb')

directory 'c:\chef\policy' do
  action :create
end

node.default['window']['firewall_flag_file'] = 'c:\\chef\\policy\\fwprofile_settings.txt'

flag_file = node['window']['firewall_flag_file']

# Create script to confirm firewall settings

template 'C:\chef\policy\get-fwsettings.ps1' do
  source 'get-fwsettings.ps1.erb'
  notifies :run, 'ruby_block[CheckFW]', :immediately
end

#-------------------------------------------
# Main
#-------------------------------------------

# Ruby Block

ruby_block 'CheckFW' do
  action :nothing
  block do
    # Remove any existing policy list
    File.delete(flag_file) if File.exist?(flag_file)

    # Generate a full list of configured firewall profile settings in c:\chef\policy\fwprofile_settings.txt
    fwsettings = powershell_out('Powershell -f c:\\chef\\policy\\get-fwsettings.ps1').stdout.chop

    # Confirm all required audit policy settings are present - if they arent enforce required settings
    if File.exist?(flag_file) && fwsettings == 'DONE'
      node['window']['firewall'].each do |_name, values|
        prf_name     = values['profile']
        prf_state    = values['state']
        # Confirm the current firewall settings by checking fwprofile_settings.txt
        found = 0
        File.open('c:\\chef\\policy\\fwprofile_settings.txt').each_line do |line|
          next unless line =~ /^#{prf_name}\,(.*)$/i
          found = 1
          current_state = Regexp.last_match(1)
          Chef::Log.info("PROFILE:        #{prf_name}")
          Chef::Log.info("STATUS:         #{current_state} REQUIRED: #{prf_state}")
          if current_state == prf_state
            Chef::Log.info('DESIRED STATE:  COMPLIANT')
          else
            Chef::Log.info('DESIRED STATE:  NON-COMPLIANT')
            powershell_exec("Set-NetFirewallProfile -profile #{prf_name} -Enabled #{prf_state}")
          end
        end
        # If we havent found an entry in fwprofile_settings.txt for this profile enforce desired state
        next unless found == 0
        powershell_exec("Set-NetFirewallProfile -profile #{prf_name} -Enabled #{prf_state}")
      end
    else
      # Unable to determine current firewall settings so enforce all settings
      node['window']['firewall'].each do |_name, values|
        prf_name     = values['profile']
        prf_state    = values['state']
        powershell_exec("Set-NetFirewallProfile -profile #{prf_name} -Enabled #{prf_state}")
      end
    end
  end
end

ruby_block 'ApplyFWSettings' do
  action :run
  block do
    node['window']['firewall_settings'].each do |option, value|
      powershell_exec("Set-NetFirewallProfile -All #{option} #{value}")
    end
  end
end
