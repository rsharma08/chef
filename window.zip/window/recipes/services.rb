Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                             S E R V I C E S                                        ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running services.rb')

netbiosoptions = node['window']['netbiosoptions']

node['window']['services'].each do |svc_name, values|
  svc_stop     = values['svc_stop']
  svc_manage   = values['svc_manage']
  svc_startup  = values['svc_startup']

  # Ensure All Services required to be stopped are stopped
  if svc_stop == 'Yes'
    Chef::Log.info("Service Name: #{svc_name} Service State: Stop")
    windows_service svc_name do
      service_name svc_name
      action :stop
      only_if { ::Win32::Service.exists?(svc_name) }
    end
  end

  # Configure any required startup values
  next unless svc_manage == 'Yes'
  Chef::Log.info("Service Name: #{svc_name} Startup: #{svc_startup}")
  windows_service svc_name do
    service_name svc_name
    action :configure_startup
    startup_type values['svc_startup']
    only_if { ::Win32::Service.exists?(svc_name) }
  end
end

# End of amendment by Liam Ryan

