Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                           A U D I T     P O L I C Y                                ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running auditpolicy.rb')

directory 'c:\chef\policy' do
  action :create
end

node.default['window']['auditpol_flag_file'] = 'c:\\chef\\policy\\auditpol_settings.txt'

flag_file = node['window']['auditpol_flag_file']

# Script used to obtain a full list of configured audit policies

cookbook_file 'c:\chef\policy\get-auditpol.ps1' do
  source 'get-auditpol.ps1'
end

#-------------------------------------------
# Main
#-------------------------------------------

# Global Object Access Auditing

execute 'Global Object Access Auditing - File' do
  command 'auditpol /resourceSACL /type:File /clear'
end

# Remove any existing policy list

File.delete(flag_file) if File.exist?(flag_file)

# Generate a full list of configured audit policies in c:\chef\policy\auditpol_settings.txt

audit_policies = powershell_out('Powershell -f c:\\chef\\policy\\get-auditpol.ps1').stdout.chop

# Confirm all required audit policy settings are present - if they arent enforce required settings

if File.exist?(flag_file) && audit_policies == 'DONE'
  node['window']['auditpol'].each do |name, values|
    pol_name     = values['name']
    pol_success  = values['success']
    pol_failure  = values['failure']
    # Confirm the current auditpoly policy settings by checking auditpol_settings.txt
    found = 0
    File.open('c:\\chef\\policy\\auditpol_settings.txt').each_line do |line|
      next unless line =~ /^#{pol_name}\,(.*)\,(.*)$/i
      found = 1
      current_success = Regexp.last_match(1)
      current_failure = Regexp.last_match(2)
      Chef::Log.info("POLICY:  #{pol_name}")
      Chef::Log.info("SUCCESS: #{current_success} REQUIRED: #{pol_success}")
      Chef::Log.info("FAILURE: #{current_failure} REQUIRED: #{pol_failure}")
      if current_success == pol_success && current_failure == pol_failure
        Chef::Log.info('Status:  COMPLIANT')
      else
        Chef::Log.info('Status:  NON-COMPLIANT')

        # Enforce desired audit policy state if non-compliant
        execute 'set Audit Policy' do
          command %(auditpol /set /subcategory:"#{node['window']['auditpol'][name]['name']}" /success:#{node['window']['auditpol'][name]['success']} /failure:#{node['window']['auditpol'][name]['failure']})
        end
      end
    end
    # If we haven't found an entry for the policy in auditpol_settings.txt enforce the required state
    next unless found == 0
    execute 'set Audit Policy' do
      command %(auditpol /set /subcategory:"#{node['window']['auditpol'][name]['name']}" /success:#{node['window']['auditpol'][name]['success']} /failure:#{node['window']['auditpol'][name]['failure']})
    end
  end
else
  # If auditpol_settings.txt isnt present enforce desired state
  node['window']['auditpol'].each do |name, _values|
    execute 'set Audit Policy' do
      command %(auditpol /set /subcategory:"#{node['window']['auditpol'][name]['name']}" /success:#{node['window']['auditpol'][name]['success']} /failure:#{node['window']['auditpol'][name]['failure']})
    end
  end
end
