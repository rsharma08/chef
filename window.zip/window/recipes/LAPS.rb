Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                                   L A P S                                          ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running laps.rb')

node['window']['laps'].each do |name, regvalues|
  hive   = regvalues['hive']
  values = regvalues['values']
  Chef::Log.info("Key: #{name} Hive: #{hive}  Values: #{values}")
  registry_key hive do
    key hive
    values values
    action :create
    recursive true
  end
end
