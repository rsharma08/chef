Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                  A D M I N I S T R A T I V E   T E M P L A T E S                   ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running administrativetemplates.rb')

node['window']['admintemplates'].each do |name, regvalues|
  hive   = regvalues['hive']
  values = regvalues['values']
  Chef::Log.info("Key: #{name} Hive: #{hive}  Values: #{values}")
  registry_key hive do
    key hive
    values values
    action :create
    recursive true
  end
end

# The special characters in the below key name means they cannot be stored as attributes in a ruby hash
# therefore the following code manages these specfic keys

# Hardened UNC Paths
registry_key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths' do
  values [{
    name: '\\\\*\\SYSVOL',
    type: :string,
    data: node['window']['admintemplates_unc_sysvol'],
  }]
  action :create
  recursive true
end

# Hardened UNC Paths
registry_key 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths' do
  values [{
    name: '\\\\*\\NETLOGON',
    type: :string,
    data: node['window']['admintemplates_unc_netlogon'],
  }]
  action :create
  recursive true
end
