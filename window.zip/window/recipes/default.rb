Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                 B A S E   H A R D E N I N G   C O O K B O O K                      ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running default.rb')

# node_domain = node['domain'].split('.')[0].downcase
node_domain = 'lbg-base-2019'
node.default['window']['short_domain'] = node_domain

include_recipe 'window::RolesAndFeatures'

if ::Win32::Service.exists?('SQLBrowser')
  include_recipe 'window::sqlpolicy'
else
  include_recipe 'window::winpolicy'
end

include_recipe 'window::services'
include_recipe 'window::MSS'
include_recipe 'window::userpolicy'
include_recipe 'window::AdministrativeTemplates'
include_recipe 'window::LAPS'
include_recipe 'window::AuditPolicy'
