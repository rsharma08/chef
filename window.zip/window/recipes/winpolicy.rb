﻿Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                               W I N P O L I C Y                                    ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running winpolicy.rb')

azureadmins = node['window']['azure_admin']

if azureadmins == 'Yes'
  Chef::Log.info("Ensuring #{node['window']['short_domain']}\\#{node['window']['windows_srv_admins']} is added to the local admin group")
  powershell_script 'windows_srv_admins Group' do
    code <<-EOH
    Add-LocalGroupMember -Group "Administrators" -Member "#{node['window']['short_domain']}\\#{node['window']['windows_srv_admins']}" -ErrorAction SilentlyContinue
    EOH
    only_if <<-EOH
    ((gwmi win32_computersystem).partofdomain) -and ((Get-LocalGroupMember -Group "Administrators").Name -notcontains "#{node['window']['short_domain']}\\#{node['window']['windows_srv_admins']}")
    EOH
  end
end

directory 'c:\chef\policy' do
  action :create
end

# Create winpolicy.txt
cookbook_file 'C:\chef\policy\winpolicy.txt' do
  source 'winpolicy.txt'
  action :create
end

# Populate winpolicy.txt with winpolicy.erb
template 'C:\chef\policy\winpolicy.txt' do
  source 'winpolicy.txt.erb'
end

# Build the winpolicy.pol file
execute 'build winpolicy.pol' do
  command 'LGPO.exe /r c:\chef\policy\winpolicy.txt /w c:\chef\policy\winpolicy.pol'
  action :run
end

# Import settings from winpolicy.pol
execute 'import winpolicy.pol' do
  command 'LGPO.exe /m c:\chef\policy\winpolicy.pol /v'
  action :run
end

# copy userpolicy.inf and modify
execute 'apply user password' do
  command 'LGPO.exe /s c:\Users\Administrator\userpolicy.inf /v'
  action :run
end

cookbook_file 'C:\chef\policy\winpolicy.inf' do
  source 'winpolicy.inf'
  action :create
end

template 'C:\chef\policy\winpolicy.inf' do
  source 'winpolicy.inf.erb'
end

execute 'Local Policy Import' do
  command 'secedit /import /db C:\chef\policy\winpolicy.sdb /cfg C:\chef\policy\winpolicy.inf /log C:\Windows\security\logs\chef-secedit.log /overwrite /quiet'
end

execute 'Local Policy Configure' do
  command 'secedit /configure /db C:\chef\policy\winpolicy.sdb /cfg C:\chef\policy\winpolicy.inf /log C:\Windows\security\logs\chef-secedit.log /overwrite /quiet'
end

