Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                                      M S S                                         ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running mss.rb')

node['window']['mss'].each do |name, regvalues|
  hive   = regvalues['hive']
  values = regvalues['values']
  Chef::Log.info("Key: #{name} Hive: #{hive}  Values: #{values}")
  registry_key hive do
    key hive
    values values
    action :create
  end
end

# The special reservice character "." in the below key name means it cannot be stored as an attribute as a key in a ruby hash
# therefore the following code manages this specfic key

registry_key 'HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\LSASS.exe' do
  values [{
    name: 'AuditLevel',
    type: :dword,
    data: node['window']['MSS_AuditLevel'],
  }]
  action :create
end
