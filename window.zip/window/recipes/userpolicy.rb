# Ensure c:\chef\policy is present

directory 'c:\chef\policy' do
  action :create
end

# Create userpolicy.txt

cookbook_file 'C:\chef\policy\userpolicy.txt' do
  source 'userpolicy.txt'
  action :create
end

# Populate userpolicy.txt with userpolicy.erb

template 'C:\chef\policy\userpolicy.txt' do
  source 'userpolicy.txt.erb'
end

# Build the userpolicy.pol file

execute 'build user userpolicy.pol' do
  command 'LGPO.exe /r c:\chef\policy\userpolicy.txt /w c:\chef\policy\userpolicy.pol'
  action :run
end

# Import user settings from userpolicy.pol

execute 'import user registry.pol' do
  command 'LGPO.exe /u c:\chef\policy\userpolicy.pol /v'
  action :run
end


