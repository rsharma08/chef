﻿Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                      R O L E S     A N D     F E A T U R E S                       ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running rolesandfeatures.rb')

directory 'c:\chef\policy' do
  action :create
end

node.default['window']['randf_flag_file'] = 'c:\\chef\\policy\\installed_features.txt'

flag_file = node['window']['randf_flag_file']

# Script used to obtain a full list of roles & features

cookbook_file 'c:\chef\policy\get-features.ps1' do
  source 'get-features.ps1'
end

# Script used to remove a role/feature if required

cookbook_file 'c:\chef\policy\uninstall-feature.ps1' do
  source 'uninstall-feature.ps1'
end

#-------------------------------------------
# Main
#-------------------------------------------

# Remove any existing install list

File.delete(flag_file) if File.exist?(flag_file)

# Generate a full list of installed features in c:\chef\policy\installed_features.txt

installed_features = powershell_out('Powershell -f c:\\chef\\policy\\get-features.ps1').stdout.chop

# Confirm none of the specified roles/features are present - remove them if they are installed

if File.exist?(flag_file) && installed_features == 'DONE'
  node['window']['absent_features'].each do |feature|
    # Confirm if the feature is installed by checking installed_features.txt
    found = 0
    File.open('c:\\chef\\policy\\installed_features.txt').each_line do |line|
      if line.match(/^#{feature}$/)
        found = 1
      end
    end
    if found == 1
      # Uninstall the feature if its installed
      Chef::Log.info("Removing Feature: #{feature}")
      powershell_out("Powershell -f c:\\chef\\policy\\uninstall-feature.ps1 #{feature}").stdout.chop
    else
      Chef::Log.info("Feature: #{feature} is not installed")
    end
  end
else

  # We havent been able to confirm the current installed features so proceed with removal of each
  # feature defined in ['window']['absent_features']

  node['window']['absent_features'].each do |feature|
    Chef::Log.info("Removing Feature: #{feature}")
    powershell_out("Powershell -f c:\\chef\\policy\\uninstall-feature.ps1 #{feature}").stdout.chop
  end
end
