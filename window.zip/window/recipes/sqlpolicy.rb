Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('                               S Q L P O L I C Y                                    ')
Chef::Log.info('------------------------------------------------------------------------------------')
Chef::Log.info('Running sqlpolicy.rb')

azureadmins = node['window']['azure_admin']

if azureadmins == 'Yes'
  Chef::Log.info("Ensuring #{node['window']['short_domain']}\\#{node['window']['windows_srv_admins']} is added to the local admin group")
  powershell_script 'LG_SQL_SERVICES Group' do
    code <<-EOH
    $lg_sql_autotest_group="SRVSQLDAUTOTEST01"
    if("#{node['window']['short_domain']}" -eq "TEST01GLOBAL"){
      $lg_sql_autotest_group="SRVSQLTAUTOTEST01"
    }
    if("#{node['window']['short_domain']}" -eq "GLOBAL"){
      $lg_sql_autotest_group="SRVSQLLAUTOTEST01"
    }
    Add-LocalGroupMember -Group "Administrators" -Member "#{node['window']['short_domain']}\\#{node['window']['windows_srv_admins']}" -ErrorAction SilentlyContinue
    $lg_sql_group = Get-LocalGroup -Name "#{node['window']['local_sqlservice_group']}" -ErrorAction SilentlyContinue
    if($lg_sql_group -eq $null){
      $sql_localgroup = New-LocalGroup -Name "#{node['window']['local_sqlservice_group']}"
      Add-LocalGroupMember -Group $sql_localgroup.Name -Member "#{node['window']['short_domain']}\\$lg_sql_autotest_group"
    }
    $lg_tivoli_group = Get-LocalGroup -Name "#{node['window']['local_sqltivoli_group']}" -ErrorAction SilentlyContinue
    if($lg_tivoli_group -eq $null){
      $sql_tivoli_group = New-LocalGroup -Name "#{node['window']['local_sqltivoli_group']}"
      Add-LocalGroupMember -Group $sql_tivoli_group.Name -Member "#{node['window']['short_domain']}\\$lg_sql_autotest_group"
    }
    $lg_tme_group = Get-LocalGroup -Name "#{node['window']['local_tme_group']}" -ErrorAction SilentlyContinue
    if($lg_tme_group -eq $null){
      $sql_tme_group = New-LocalGroup -Name "#{node['window']['local_tme_group']}"
      Add-LocalGroupMember -Group $sql_tme_group.Name -Member "#{node['window']['short_domain']}\\$lg_sql_autotest_group"
    }
    EOH
    only_if <<-EOH
      ((gwmi win32_computersystem).partofdomain) -and ((Get-LocalGroupMember -Group "#{node['window']['local_sqlservice_group']}").Name -notcontains "#{node['window']['short_domain']}\\$lg_sql_autotest_group")
    EOH
    powershell_script 'LG_CD_USERS Group' do
      code <<-EOH
      $sql_localgroup = New-LocalGroup -Name "#{node['window']['local_cdusers_group']}" -ErrorAction SilentlyContinue
      EOH
      only_if <<-EOH
        ((gwmi win32_computersystem).partofdomain) -and ((Get-LocalGroup -Name "#{node['window']['local_cdusers_group']}").Name -notcontains "#{node['window']['local_cdusers_group']}")
      EOH
    end
  end
end

# End of amendment by Liam Ryan

directory 'c:\chef\policy' do
  action :create
end

cookbook_file 'C:\chef\policy\sqlpolicy.inf' do
  source 'sqlpolicy.inf'
  action :create
end

template 'C:\chef\policy\sqlpolicy.inf' do
  source 'sqlpolicy.inf.erb'
end

execute 'Local Policy Import' do
  command 'secedit /import /db C:\chef\policy\sqlpolicy.sdb /cfg C:\chef\policy\sqlpolicy.inf /log C:\Windows\security\logs\chef-secedit.log /overwrite /quiet'
end

execute 'Local Policy Configure' do
  command 'secedit /configure /db C:\chef\policy\sqlpolicy.sdb /cfg C:\chef\policy\sqlpolicy.inf /log C:\Windows\security\logs\chef-secedit.log /overwrite /quiet'
  notifies :run, 'powershell_script[TidyLog]', :immediately
end

# Housekeep secedit logs
powershell_script 'TidyLog' do
  action :nothing
  code <<-EOF
    $log = "C:\\Windows\\security\\logs\\chef-secedit.log"
    $logpath = 'C:\\Windows\\security\\logs'
    $timestamp = get-date -F 'dd-MM-yy-HHmmss'
    $seceditlog  = "$timestamp" + "-chef-secedit.log"
    if (Test-Path -Path $log) {rename-item -path $log -NewName $seceditlog -Force}
    Get-ChildItem -path $logpath | where {$_.Name -ilike "*-chef-secedit.log"} | Where-Object {$_.LastWriteTime -lt (get-date).Addhours(-10)}| remove-item
  EOF
end
