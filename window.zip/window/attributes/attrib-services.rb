######################################################################################################################################################################
#
#  Author:       Liam Ryan GCIO Enterprise Toolsets & Automation
#
#  Description:  Contains service attributes consumed & enforced by services.rb
#
#  Syntax:
#
#  <svc_name>  => {' => 'svc_stop' => <svc_stop_value>, 'svc_manage' => <svc_startup_mgmt>, 'svc_manage' => <svc_startup_value> },
#
#  Where:
#
#  <svc_name>           - The name of the service  requiring setting enforcement
#
#  <svc_stop_value>     - Defines whether the desired service state is "stopped", two possible values:
#                         - 'svc_stop' => 'Yes' -  Defines the required service status should be stopped
#                         - 'svc_stop' => 'No'  -  Defines the required service status should NOT be stopped (i.e. status no enforcement)
#
#  <svc_startup_mgmt>   - Defines whether service startup enforcement is required,  two possible values:
#                         - 'svc_manage' => 'Yes' - Defines service startup enforcement is required
#                         - 'svc_manage' => 'No'  - Defines service startup enforcement is NOT required
#
#  <svc_startup_value>  - Defines the desired service startup state, three possible values:
#                         - 'svc_startup' => 'automatic'  - "Automatic" service startup type required
#                         - 'svc_startup' => 'disabled'   - "Disabled" service startup type required
#                         - 'svc_startup' => 'manual'     - "Manual" service startup type required
#
#                         NOTE: <svc_startup_mgmt> MUST be set to "Yes" for <svc_startup_value> to be enforced
# --------------------------------------------------------------------------------------------------------------------------------
#
#  Examples
#  ---------
#
#  The following statement describes the desired service startup for the "Spooler" service is "Manual".  A service "stop" is not required.
#
#  'Spooler'                  => { 'svc_stop' => 'No', 'svc_manage' => 'Yes', 'svc_startup' => 'manual' },
#
#  The following statement describes the desired running state for the "certpropsvc" service is "stopped":
#
#  'certpropsvc'              => { 'svc_stop' => 'Yes', 'svc_manage' => 'No' },
#
#  The following statement describes the desired running state for the "DPS" service is "stopped" and startup set to "disabled":
#
#  'DPS'                      => { 'svc_stop' => 'Yes', 'svc_manage' => 'Yes', 'svc_startup' => 'disabled' },
#
#
#  Attribute Overrides
#  ----------------------
#
#  Any of the default values listed below can be overriden via a wrapper cookbook
#
#  For example, the following statement could be used in a wrapper cookbook to set the default startup setting for the "Spooler" service to "Automatic"
#
#  node.override['lbg']['gen']['hardenedwin_base']['services'] ['Spooler']['svc_startup'] = 'automatic'
#
######################################################################################################################################################################
#

default['window']['services'] = {
  'AJRouter'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'ALG'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'AppIDSvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'Appinfo'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'AppMgmt'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'AppVClient'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'AppXSvc'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'AudioEndpointBuilder'                     => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'Audiosrv'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'BFE'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'BITS'                                     => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'BrokerInfrastructure'                     => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'bthserv'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'CDPSvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'certpropsvc'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'COMSysApp'                                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'CryptSvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'DcomLaunch'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'defragsvc'                                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'DeviceAssociationService'                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'DeviceInstall'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'DevQueryBroker'                           => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'Dhcp'                                     => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'diagnosticshub.standardcollector.service' => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'DiagTrack'                                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'dmwappushservice'                         => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'Dnscache'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'dot3svc'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'DPS'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'DsmSvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'Eaphost'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'EFS'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'EventLog'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'EventSystem'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'fdPHost'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'FDResPub'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'FontCache'                                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'FrameServer'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'gpsvc'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'hidserv'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'HvHost'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'icssvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'IEEtwCollectorService'                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'IKEEXT'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'iphlpsvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'KeyIso'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'KPSSVC'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'LanmanServer'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'LanmanWorkstation'                        => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'lfsvc'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'LicenseManager'                           => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'lltdsvc'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'lmhosts'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'LSM'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'MapsBroker'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'MMCSS'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'MpsSvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'MSiSCSI'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'msiserver'                                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'NcaSvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'Netlogon'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'Netman'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'netprofm'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'NetSetupSvc'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'NetTcpPortSharing'                        => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'NlaSvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'nsi'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'PerfHost'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'PcaSvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'PhoneSvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'pla'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'PlugPlay'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'PolicyAgent'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'Power'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'PrintNotify'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'ProfSvc'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'QWAVE'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'RasAuto'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'RasMan'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'RemoteAccess'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'RemoteRegistry'                           => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'RmSvc'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'RpcEptMapper'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'RpcLocator'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'RpcSs'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'RSoPProv'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'sacsvr'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'SamSs'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'SCardSvr'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'ScDeviceEnum'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'Schedule'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'SCPolicySvc'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'seclogon'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'SENS'                                     => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'SessionEnv'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'SharedAccess'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'ShellHWDetection'                         => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'smphost'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'SNMPTRAP'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'Spooler'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'SSDPSRV'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'SstpSvc'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'stisvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'StorSvc'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'svsvc'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'swprv'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'SysMain'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'SystemEventsBroker'                       => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'TapiSrv'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'TermService'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'Themes'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'TieringEngineService'                     => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'TrkWks'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'TrustedInstaller'                         => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'umrdpservice'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'upnphost'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'VaultSvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'vds'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'vmicguestinterface'                       => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'vmicheartbeat'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'vmickvpexchange'                          => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'vmicrdv'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'vmicshutdown'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'vmictimesync'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'vmicvmsession'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'vmicvss'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'VSS'                                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'W32Time'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'WalletService'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'WbioSrvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'Wcmsvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'WdiServiceHost'                           => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'WdiSystemHost'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'Wecsvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'WEPHOSTSVC'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'wercplsupport'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'WerSvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'WiaRpc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'WinHttpAutoProxySvc'                      => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'Winmgmt'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'WinRM'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'wisvc'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'wlidsvc'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'wmiApSrv'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'WPDBusEnum'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'wuauserv'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'wudfsvc'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'XblAuthManager'                           => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'XblGameSave'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'AppReadiness'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'AxInstSV'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'BthAvctpSvc'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'tzautoupdate'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'BDESVC'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'BTAGService'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'camsvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'CaptureService_83a7e'                     => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'CertPropSvc'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'ClipSVC'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'cbdhsvc_83a7e'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'CDPUserSvc_83a7e'                         => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'ConsentUxUserSvc_83a7e'                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'PimIndexMaintenanceSvc_83a7e'             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'CoreMessagingRegistrar'                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'DsSvc'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'DoSvc'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'DmEnrollmentSvc'                          => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'DevicePickerUserSvc_83a7e'                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'DevicesFlowUserSvc_83a7e'                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'MSDTC'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'EntAppSvc'                                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'GraphicsPerfSvc'                          => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'KtmRm'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'InstallService'                           => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'NcbService'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'CscService'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'ssh-agent'                                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'SEMgrSvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'PrintWorkflowUserSvc_83a7e'               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'RdAgent'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'UmRdpService'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'SensorDataService'                        => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'SensrSvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'SensorService'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'shpamsvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'StateRepository'                          => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'SgrmBroker'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'tapisrv'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'TimeBrokerSvc'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'TabletInputService'                       => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'UsoSvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'UALSVC'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'UserDataSvc_83a7e'                        => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'UnistoreSvc_83a7e'                        => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'UevAgentService'                          => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'UserManager'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'WarpJITSvc'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'TokenBroker'                              => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'WindowsAzureGuestAgent'                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'WindowsAzureTelemetryService'             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'Sense'                                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'WdNisSvc'                                 => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'WinDefend'                                => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'mpssvc'                                   => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'WpnService'                               => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'automatic' },
  'WpnUserService_83a7e'                     => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'PushToInstall'                            => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'WSearch'                                  => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'disabled'  },
  'SecurityHealthService'                    => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
  'WaaSMedicSvc'                             => { 'svc_stop' => 'No',  'svc_manage' => 'Yes', 'svc_startup' => 'manual'    },
}

# Attribute used to control NIC NetBios setting in services.rb

default['window']['netbiosoptions'] = '2'
