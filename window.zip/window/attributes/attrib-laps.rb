﻿######################################################################################################################################################################
#
#  Author:       Liam Ryan GCIO Enterprise Toolsets & Automation
#
#  Description:  Registry key attributes consumed & enforced by laps.rb
#
#  Syntax:
#
#  <attribute_name>  => {' => '<reg_hive>','values' => [{ name: '<reg_key_name>', type: '<reg_key_type>', data:'<reg_key_value>' }] },
#
#  Where:
#
#  <attribute_name> - The chef attribute name which is used to control desired state for the specified registry setting (Note: This is typically the reg key name, However in cases where multiple keys exist with the same name a unique attribute name is used)
#  <reg_hive>       - The registry hive
#  <reg_key_name>   - The registry key name
#  <reg_key_type>   - The registry key type [ binary|string|multi_string|expand_string|dword|dword_big_endian|qword] (see chef registry_key resource documentation for supported types
#  <reg_key_value>  - The desired registry key value
#
#   NOTE: Any "data:" values specified for a string: data type MUST be enclosed in single quotes (see ScreenSaverGracePeriod)
#
#  Examples
#  ---------
#
#  The below attribute string defines the followng desired registry key settings
#
#   Hive:      HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Messenger\Client
#   Key Name:  CEIP
#   Key Type:  dword
#   Key Value: 2
#
#  'CEIP' => { 'hive' => 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Messenger\Client', 'values' => [{ name: 'CEIP', type: :dword,  data: 2 }] },
#
#  Attribute Overrides
#  ----------------------
#
#  Any of the default values listed below can be overriden via a wrapper cookbook
#
#  For example, the following statement could be used in a wrapper cookbook to set the reg key value for the "AllowDomainPINLogon" key to "1"
#
#  node.override['lbg']['gen']['hardenedwin_base']['admintemplates'] ['AllowDomainPINLogon']['values'] = [{ name: 'AllowDomainPINLogon', type: :dword,  data: 1}]
#
######################################################################################################################################################################
#

default['window']['laps'] = {
    'AdmPwdEnabled' => { 'hive' => 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft Services', 'values' => [{ name: 'AdmPwdEnabled', type: :dword, data: 0 }] },
  }

