﻿######################################################################################################################################################################
#
#  Author:       Liam Ryan GCIO Enterprise Toolsets & Automation
#
#  Description:  Windows features attributes consumed & enforced by RolesandFeatures.rb
#
######################################################################################################################################################################
#

default['window']['absent_features'] = %w(
  Hyper-V
  Print-Internet
  Remote-Assistance
  RPC-over-HTTP-Proxy
  PNRP SMTP-Server
  Telnet-Client
  TFTP-Client
  WindowsPowerShellWebAccess
)

