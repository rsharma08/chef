﻿
######################################################################################################################################################################
#
#  Author:       Liam Ryan GCIO Enterprise Toolsets & Automation
#
#  Description:  Audit Policy attributes consumed & enforced by AuditPolicy.rb
#
#  Syntax:
#
#  <attribute_name>  => { 'name'  => '<audit_policy_name>' ,'success' => '<success_auditing_value>', 'failure' => '<failure_auditing_value>' },
#
#  Where:
#
#  <attribute_name>         - The chef attribute name which is used to control desired statce for the specified audit policy
#                             (NOTE: This ['lbg']['gen']['hardenedwin_base']['auditpol'] attribute name needs to be unique and should not contain white space or special characters)
#
#  <audit_policy_name>      - The actual audit policy subcategory name required by the "auditpol" oommand to enforce changes to this policy
#  <success_auditing_value> - Specifies the required success auditing behaviour  [ possible values: 'enable' or 'disable' ]
#  <failure_auditing_value> - Specifies the required failure auditing behaviour  [ possible values: 'enable' or 'disable' ]
#
#  Examples
#  ---------
#
#  The below string defines:
#
#  Attribute Name:         ['lbg']['gen']['hardenedwin_base']['auditpol']['AccountLockout']
#  Audit Policy Name       "Account Lockout"
#  Success Auduting Value: "enable"
#  Failure Auduting Value: "enable"
#
#
#  'AccountLockout'   => { 'name' => 'Account Lockout'  ,  'success' => 'enable'  , 'failure' => 'enable'   },
#
#
#  Attribute Overrides
#  ----------------------
#
#  Any of the default values listed below can be overriden via a wrapper cookbook (subject to approval by Security)
#
#  For example, the following statement could be used in a wrapper cookbook to set the success auditing value for the "Account Lockout" audit policy to be "disable"
#
#  node.override['lbg']['gen']['hardenedwin_base']['auditpol'] ['AccountLockout']['success'] = 'disable'
#
######################################################################################################################################################################
#

default['window']['auditpol'] = {
  'AccountLockout'                        => { 'name' => 'Account Lockout', 'success' => 'enable', 'failure' => 'enable' },
  'ApplicationGenerated'                  => { 'name' => 'Application Generated', 'success' => 'disable', 'failure' => 'disable' },
  'ApplicationGroupManagement'            => { 'name' => 'Application Group Management', 'success' => 'enable', 'failure' => 'enable' },
  'AuditPolicyChange'                     => { 'name' => 'Audit Policy Change', 'success' => 'enable', 'failure' => 'enable' },
  'AuthenticationPolicyChange'            => { 'name' => 'Authentication Policy Change', 'success' => 'enable', 'failure' => 'disable' },
  'AuthorizationPolicyChange'             => { 'name' => 'Authorization Policy Change', 'success' => 'enable', 'failure' => 'disable' },
  'CentralPolicyStaging'                  => { 'name' => 'Central Policy Staging',  'success' => 'disable', 'failure' => 'disable'  },
  'CertificationServices'                 => { 'name' => 'Certification Services',  'success' => 'disable', 'failure' => 'enable'   },
  'ComputerAccountManagement'             => { 'name' => 'Computer Account Management', 'success' => 'enable', 'failure' => 'enable' },
  'CredentialValidation'                  => { 'name' => 'Credential Validation', 'success' => 'enable', 'failure' => 'enable' },
  'DetailedDirectoryServiceReplication'   => { 'name' => 'Detailed Directory Service Replication', 'success' => 'disable', 'failure' => 'disable' },
  'DetailedFileShare'                     => { 'name' => 'Detailed File Share', 'success' => 'disable', 'failure' => 'enable' },
  'DirectoryServiceAccess'                => { 'name' => 'Directory Service Access', 'success' => 'enable', 'failure' => 'enable' },
  'DirectoryServiceChanges'               => { 'name' => 'Directory Service Changes',  'success' => 'enable', 'failure' => 'enable' },
  'DirectoryServiceReplication'           => { 'name' => 'Directory Service Replication',  'success' => 'disable', 'failure' => 'disable' },
  'DistributionGroupManagement'           => { 'name' => 'Distribution Group Management',  'success' => 'enable', 'failure' => 'enable' },
  'DPAPIActivity'                         => { 'name' => 'DPAPI Activity', 'success' => 'disable', 'failure' => 'disable' },
  'FileShare'                             => { 'name' => 'File Share',  'success' => 'enable', 'failure' => 'enable' },
  'FileSystem'                            => { 'name' => 'File System', 'success' => 'enable', 'failure' => 'enable' },
  'FilteringPlatformConnection'           => { 'name' => 'Filtering Platform Connection', 'success' => 'disable', 'failure' => 'enable' },
  'FilteringPlatformPacketDrop'           => { 'name' => 'Filtering Platform Packet Drop', 'success' => 'disable', 'failure' => 'enable' },
  'FilteringPlatformPolicyChange'         => { 'name' => 'Filtering Platform Policy Change', 'success' => 'disable', 'failure' => 'disable' },
  'GroupMembership'                       => { 'name' => 'Group Membership', 'success' => 'enable', 'failure' => 'disable' },
  'HandleManipulation'                    => { 'name' => 'Handle Manipulation', 'success' => 'disable', 'failure' => 'disable' },
  'IPSecDriver'                           => { 'name' => 'IPSec Driver', 'success' => 'enable', 'failure' => 'enable' },
  'IPsecExtendedMode'                     => { 'name' => 'IPsec Extended Mode', 'success' => 'disable', 'failure' => 'disable' },
  'IPsecMainMode'                         => { 'name' => 'IPsec Main Mode',  'success' => 'disable', 'failure' => 'disable' },
  'IPsecQuickMode'                        => { 'name' => 'IPsec Quick Mode', 'success' => 'disable', 'failure' => 'disable' },
  'KerberosAuthenticationService'         => { 'name' => 'Kerberos Authentication Service', 'success' => 'disable', 'failure' => 'disable' },
  'KerberosServiceTicketOperations'       => { 'name' => 'Kerberos Service Ticket Operations',  'success' => 'disable', 'failure' => 'disable' },
  'KernelObject'                          => { 'name' => 'Kernel Object',  'success' => 'disable', 'failure' => 'disable' },
  'Logoff'                                => { 'name' => 'Logoff', 'success' => 'enable', 'failure' => 'disable' },
  'Logon'                                 => { 'name' => 'Logon', 'success' => 'enable', 'failure' => 'enable' },
  'MPSSVCRuleLevelPolicyChange'           => { 'name' => 'MPSSVC Rule-Level Policy Change',  'success' => 'enable', 'failure' => 'enable' },
  'NetworkPolicyServer'                   => { 'name' => 'Network Policy Server',  'success' => 'disable', 'failure' => 'disable' },
  'NonSensitivePrivilegeUse'              => { 'name' => 'Non Sensitive Privilege Use', 'success' => 'disable', 'failure' => 'enable' },
  'OtherAccountLogonEvents'               => { 'name' => 'Other Account Logon Events', 'success' => 'disable', 'failure' => 'disable' },
  'OtherAccountManagementEvents'          => { 'name' => 'Other Account Management Events', 'success' => 'enable', 'failure' => 'enable' },
  'OtherLogonLogoffEvents'                => { 'name' => 'Other Logon/Logoff Events', 'success' => 'enable', 'failure' => 'enable' },
  'OtherObjectAccessEvents'               => { 'name' => 'Other Object Access Events',  'success' => 'enable', 'failure' => 'enable'  },
  'OtherPolicyChangeEvents'               => { 'name' => 'Other Policy Change Events',  'success' => 'disable', 'failure' => 'enable'  },
  'OtherPrivilegeUseEvents'               => { 'name' => 'Other Privilege Use Events',  'success' => 'disable', 'failure' => 'disable'  },
  'OtherSystemEvents'                     => { 'name' => 'Other System Events', 'success' => 'enable', 'failure' => 'enable' },
  'PlugandPlayEvents'                     => { 'name' => 'Plug and Play Events', 'success' => 'enable', 'failure' => 'disable' },
 # 'PNPActivity'                           => { 'name' => 'PNP Activity', 'success' => 'enable', 'failure' => 'disable' },
  'ProcessCreation'                       => { 'name' => 'Process Creation',  'success' => 'enable', 'failure' => 'disable' },
  'ProcessTermination'                    => { 'name' => 'Process Termination', 'success' => 'disable', 'failure' => 'disable' },
  'Registry'                              => { 'name' => 'Registry', 'success' => 'disable', 'failure' => 'disable'  },
  'RemovableStorage'                      => { 'name' => 'Removable Storage', 'success' => 'enable', 'failure' => 'enable' },
  'RPCEvents'                             => { 'name' => 'RPC Events', 'success' => 'disable', 'failure' => 'disable' },
  'SAM'                                   => { 'name' => 'SAM', 'success' => 'disable', 'failure' => 'disable' },
  'SecurityGroupManagement'               => { 'name' => 'Security Group Management', 'success' => 'enable', 'failure' => 'enable' },
  'SecurityStateChange'                   => { 'name' => 'Security State Change',  'success' => 'enable', 'failure' => 'disable' },
  'SecuritySystemExtension'               => { 'name' => 'Security System Extension', 'success' => 'enable', 'failure' => 'enable' },
  'SensitivePrivilegeUse'                 => { 'name' => 'Sensitive Privilege Use', 'success' => 'enable', 'failure' => 'enable' },
  'SpecialLogon'                          => { 'name' => 'Special Logon', 'success' => 'enable', 'failure' => 'disable' },
  'SystemIntegrity'                       => { 'name' => 'System Integrity', 'success' => 'enable', 'failure' => 'enable' },
  'TokenRightAdjustedEvents'              => { 'name' => 'Token Right Adjusted Events', 'success' => 'disable', 'failure' => 'disable' },
  'UserAccountManagement'                 => { 'name' => 'User Account Management',  'success' => 'enable', 'failure' => 'enable' },
  'UserDeviceClaims'                      => { 'name' => 'User / Device Claims', 'success' => 'enable', 'failure' => 'enable' },
 }

