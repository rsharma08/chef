﻿######################################################################################################################################################################
#
#  Author:       Liam Ryan GCIO Enterprise Toolsets & Automation
#
#  Description:  MSS registry key attributes consumed & enforced by mss.rb
#
#  Syntax:
#
#  <attribute_name>  => {' => '<reg_hive>','values' => [{ name: '<reg_key_name>', type: '<reg_key_type>', data:'<reg_key_value>' }] },
#
#  Where:
#
#  <attribute_name> - The chef attribute name which is used to control desired state for the specified registry setting
#  <reg_hive>       - The registry hive
#  <reg_key_name>   - The registry key name
#  <reg_key_type>   - The registry key type [ binary|string|multi_string|expand_string|dword|dword_big_endian|qword] (see chef registry_key resource documentation for supported types
#  <reg_key_value>  - The desired registry key value
#
#   NOTE: Any "data:" values specified for a string: data type MUST be enclosed in single quotes (see ScreenSaverGracePeriod)
#
#  Examples
#  ---------
#
#  The below attribute string defines the followng desired registry key settings
#
#   Hive:      HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon
#   Key Name:  AutoAdminLogon
#   Key Type:  dword
#   Key Value: 0
#
#  'AutoAdminLogon' => { 'hive' => 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon', 'values' => [{ name: 'AutoAdminLogon', type: egis:dword, data: 0}] },
#
#  Attribute Overrides
#  ----------------------
#
#  Any of the default values listed below can be overriden via a wrapper cookbook
#
#  For example, the following statement could be used in a wrapper cookbook to set the reg key value for the "AutoAdminLogon" key to "1"
#
#  node.override['lbg']['gen']['hardenedwin_base']['mss'] ['AutoAdminLogon']['values'] = [{ name: 'AutoAdminLogon', type: :dword,  data: 1}]
#
######################################################################################################################################################################
#

default['window']['mss'] = {
  'AutoAdminLogon'                      => { 'hive' => 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon',            'values' => [{ name: 'AutoAdminLogon',                      type: :dword,  data: 0        }] },
  'ScreenSaverGracePeriod'              => { 'hive' => 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon',            'values' => [{ name: 'ScreenSaverGracePeriod',              type: :string, data: '0'      }] },
  'AutoReboot'                          => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\CrashControl',                    'values' => [{ name: 'AutoReboot',                          type: :dword,  data: 1        }] },
  'AutoShareWks'                        => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters',        'values' => [{ name: 'AutoShareWks',                        type: :dword,  data: 0        }] },
  'AutoShareServer'                     => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters',        'values' => [{ name: 'AutoShareServer',                     type: :dword,  data: 1        }] },
  'DisableIPSourceRouting'              => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',               'values' => [{ name: 'DisableIPSourceRouting',              type: :dword,  data: 2        }] },
  'DisableIPSourceRoutingip6'           => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters',              'values' => [{ name: 'DisableIPSourceRouting',              type: :dword,  data: 2        }] },
  'DisableSavePassword'                 => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RasMan\Parameters',              'values' => [{ name: 'DisableSavePassword',                 type: :dword,  data: 1        }] },
  'EnableDeadGWDetect'                  => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',               'values' => [{ name: 'EnableDeadGWDetect',                  type: :dword,  data: 0        }] },
  'SynAttackProtect'                    => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',               'values' => [{ name: 'SynAttackProtect',                    type: :dword,  data: 1        }] },
  'EnableICMPRedirect'                  => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',               'values' => [{ name: 'EnableICMPRedirect',                  type: :dword,  data: 0        }] },
  'Hidden'                              => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters',        'values' => [{ name: 'Hidden',                              type: :dword,  data: 0        }] },
  'KeepAliveTime'                       => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',               'values' => [{ name: 'KeepAliveTime',                       type: :dword,  data: 300000   }] },
  'TcpMaxDataRetransmissions'           => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',               'values' => [{ name: 'TcpMaxDataRetransmissions',           type: :dword,  data: 3        }] },
  'TcpMaxDataRetransmissionsip6'        => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters',              'values' => [{ name: 'TcpMaxDataRetransmissions',           type: :dword,  data: 3        }] },
  'DisabledComponents'                  => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters',              'values' => [{ name: 'DisabledComponents',                  type: :dword,  data: 0xFF     }] },
  'NoDefaultExempt'                     => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\IPSEC',                          'values' => [{ name: 'NoDefaultExempt',                     type: :dword,  data: 3        }] },
  'NoNameReleaseOnDemand'               => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Netbt\Parameters',               'values' => [{ name: 'NoNameReleaseOnDemand',               type: :dword,  data: 1        }] },
  'NtfsDisable8dot3NameCreation'        => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem',                      'values' => [{ name: 'NtfsDisable8dot3NameCreation',        type: :dword,  data: 1        }] },
  'PerformRouterDiscovery'              => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',               'values' => [{ name: 'PerformRouterDiscovery',              type: :dword,  data: 0        }] },
  'SafeDllSearchMode'                   => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager',                 'values' => [{ name: 'SafeDllSearchMode',                   type: :dword,  data: 1        }] },
  'WarningLevel'                        => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Eventlog\Security',              'values' => [{ name: 'WarningLevel',                        type: :dword,  data: 80       }] },
  'RunAsPPL'                            => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa',                             'values' => [{ name: 'RunAsPPL',                            type: :dword,  data: 00000001 }] },
  'UseLogonCredential'                  => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest',       'values' => [{ name: 'UseLogonCredential',                  type: :dword,  data: 0        }] },
  'TcpMaxConectResponseRetransmissions' => { 'hive' => 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',               'values' => [{ name: 'TcpMaxConectResponseRetransmissions', type: :dword,  data: 2        }] },
}

# The following attributes manage regisry settings containing special characters which cannot be supported in the above Ruby hash

default['lbg']['gen']['hardenedwin_base']['MSS_AuditLevel'] = '00000008'

