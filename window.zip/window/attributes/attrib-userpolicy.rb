﻿######################################################################################################################################################################
#
#  Author:       Liam Ryan GCIO Enterprise Toolsets & Automation
#
#  Description:  User Policy attributes consumed & enforced by UserPolicy.rb
#
######################################################################################################################################################################
#

default['window']['lgpo_binary'] = 'C:\Windows\System32\LGPO.exe'
default['window']['lgpo_repo_location'] = 'LGPO/LGPO.exe'
default['window']['Explorer_NoRecycleFiles'] = 1
default['window']['Explorer_NoPublishingWizard'] = 1
default['window']['Explorer_NoWebServices'] = 1
default['window']['Explorer_HideSCAHealth'] = 1
default['window']['Explorer_NoDrives'] = 3
default['window']['Explorer_NoViewOnDrive'] = 3
default['window']['Explorer_NoInplaceSharing'] = 1
default['window']['IE_ControlPanel_FormSuggest_Passwords'] = 1
default['window']['IE_FormSuggest'] = 1
default['window']['IE_Certificates'] = 1
default['window']['IE_FormSuggest_PW_Ask'] = 'no'
default['window']['IE_Main_FormSuggest_Passwords'] = 'no'
default['window']['IE_Main_Use_FormSuggest'] = 'no'
default['window']['ControlPanel_ScreenSaverIsSecure'] = 1
default['window']['ControlPanel_ScreenSaveActive'] = 1
default['window']['ControlPanel_SCRNSAVE.EXE'] = 'scmsave.scr'
default['window']['ControlPanel_ScreenSaveTimeOut'] = 900
default['window']['ControlPanel_NoToastApplicationNotificationOnLockScreen'] = 1
default['window']['Assistance_NoImplicitFeedback'] = 1
default['window']['Attachments_SaveZoneInformation'] = 2
default['window']['Attachments_ScanWithAntiVirus'] = 3
default['window']['CloudContent_ConfigureWindowsSpotlight'] = 2
default['window']['CloudContent_DisableThirdPartySuggestions'] = 1
default['window']['CloudContent_DisableWindowsSpotlightFeatures'] = 1
default['window']['MicrosoftEdge_AllowDeveloperTools'] = 0
default['window']['MicrosoftEdge_ExtensionsEnabled'] = 0
default['window']['MicrosoftEdge_AllowInPrivate'] = 0
default['window']['MicrosoftEdge_AllowWebContentOnNewTabPage'] = 1
default['window']['MicrosoftEdge_Use_FormSuggest'] = 'no'
default['window']['MicrosoftEdge_Cookies'] = 1
default['window']['MicrosoftEdge_FormSuggest_Passwords'] = 'no'
default['window']['MicrosoftEdge_AllowPopups'] = 'no'
default['window']['MicrosoftEdge_ShowSearchSuggestionsGlobal'] = 0
default['window']['MicrosoftEdge_EnabledV9'] = 1
default['window']['MicrosoftEdge_PreventAccessToAboutFlagsInMicrosoftEdge'] = 1
default['window']['MicrosoftEdge_PreventOverrideAppRepUknown'] = 1
default['window']['MicrosoftEdge_PreventOverride'] = 1
default['window']['MicrosoftEdge_HideLocalHostIP'] = 1
default['window']['Messenger_CEIP'] = 2
default['window']['Installer_AlwaysInstallElevated'] = 0
default['window']['WindowsMediaPlayer_PreventCodecDownload'] = 1
# newly added MSEdge Attributes (nos.36)
default['window']['MicrosoftEdge_UseSharedFolderForBooks'] = 1
default['window']['MicrosoftEdge_ShowOneBox'] = 1
default['window']['MicrosoftEdge_FlashPlayerEnabled'] = 1
default['window']['MicrosoftEdge_ClearBrowsingHistoryOnExit'] = 1
default['window']['MicrosoftEdge_AllowConfigurationUpdateForBooksLibrary'] = 1
default['window']['MicrosoftEdge_EnableExtendedBooksTelemetry'] = 1
default['window']['MicrosoftEdge_AllowFullScreenMode'] = 1
default['window']['MicrosoftEdge_MSCompatibilityMode'] = 1
default['window']['MicrosoftEdge_AllowPrelaunch'] = 1
default['window']['MicrosoftEdge_AllowTabPreloading'] = 0
default['window']['MicrosoftEdge_AllowPrinting'] = 1
default['window']['MicrosoftEdge_AllowSavingHistory'] = 1
default['window']['MicrosoftEdge_AllowSearchEngineCustomization'] = 1
default['window']['MicrosoftEdge_AllowSideloadingOfExtensions'] = 1
default['window']['MicrosoftEdge_AlwaysEnableBooksLibrary'] = 1
default['window']['MicrosoftEdge_ConfigureAdditionalSearchEngines'] = 1
default['window']['MicrosoftEdge_DoNotTrack'] = 0
default['window']['MicrosoftEdge_ProvisionedFavorites'] = 1
default['window']['MicrosoftEdge_ConfigureFavoritesBar'] = 1
default['window']['MicrosoftEdge_ConfigureHomeButton'] = 1
default['window']['MicrosoftEdge_ConfigureKioskMode'] = 0
default['window']['MicrosoftEdge_ConfigureKioskResetAfterIdleTimeout'] = 0
default['window']['MicrosoftEdge_ConfigureOpenMicrosoftEdgeWith'] = 0
default['window']['MicrosoftEdge_ProvisionedHomePages'] = 1
default['window']['MicrosoftEdge_FlashClickToRunMode'] = 1
default['window']['MicrosoftEdge_SiteList'] = 1
default['window']['MicrosoftEdge_DisableLockdownOfStartPages'] = 0
default['window']['MicrosoftEdge_SyncFavoritesBetweenIEAndMicrosoftEdge'] = 1
default['window']['MicrosoftEdge_PreventOverrideAppRepUnknown'] = 1
default['window']['MicrosoftEdge_PreventOverride'] = 0
default['window']['MicrosoftEdge_PreventCertErrorOverrides'] = 0
default['window']['MicrosoftEdge_LockdownFavorites'] = 1
default['window']['MicrosoftEdge_PreventLiveTileDataCollection'] = 0
default['window']['MicrosoftEdge_PreventFirstRunPage'] = 0
default['window']['MicrosoftEdge_PreventTurningOffRequiredExtensions'] = 0
default['window']['MicrosoftEdge_ConfiguredFavorites'] = 1
default['window']['MicrosoftEdge_SendIntranetTraffictoInternetExplorer'] = 0
default['window']['MicrosoftEdge_SetDefaultSearchEngine'] = 1
default['window']['MicrosoftEdge_HomeButtonURL'] = 1
default['window']['MicrosoftEdge_NewTabPageURL'] = 0
default['window']['MicrosoftEdge_ShowMessageWhenOpeningSitesInInternetExplorer'] = 1
default['window']['MicrosoftEdge_UnlockHomeButton'] = 1
