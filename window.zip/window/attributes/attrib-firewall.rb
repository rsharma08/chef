﻿
######################################################################################################################################################################
#
#  Author:       Liam Ryan GCIO Enterprise Toolsets & Automation
#
#  Description:  Firewall profile attributes consumed & enforced by firewall.rb
#
#  Syntax:
#
#  <attribute_name>  => { 'profile'  => '<profile_name>' ,'state' => '<profile_state>' },
#
#  Where:
#
#  <attribute_name>         - The chef attribute name which is used to control desired statce for the specified firewall profile
#
#  <profile_name>           - The actual firewall profile name required by the Set-NetFirewall cmdlet to enforce changes to this policy
#  <profile_state>          - The required firewall profile state  [ possible values: 'True', 'False'. 'NotConfigured' ]
#
#  Examples
#  ---------
#
#  The below string defines:
#
#  Attribute Name:         ['lbg']['gen']['hardenedwin_base']['firewall']['Public']
#  Firewall Profile Name:  "Public"
#  Firewall Profile State: "False"
#
#  'Public'   => { 'profile' => 'Public'  ,  'state' => 'False'  },
#
#
#  Attribute Overrides
#  ----------------------
#
#  Any of the default values listed below can be overriden via a wrapper cookbook (subject to approval by Security)
#
#  For example, the following statement could be used in a wrapper cookbook to enable the "Public" Firewall profile
#
#  node.override['lbg']['gen']['hardenedwin_base']['firewall'] ['Public']['state'] = 'True'
#
######################################################################################################################################################################
#

default['window']['firewall'] = {
  'Domain'      => { 'profile' => 'Domain', 'state' => 'True' },
  'Private'     => { 'profile' => 'Private', 'state' => 'True' },
  'Public'      => { 'profile' => 'Public', 'state' => 'True' },
}

default['window']['firewall_settings'] = {
  '-DefaultInboundAction'                 => 'Block',
  '-DefaultOutboundAction'                => 'Allow',
  '-NotifyOnListen'                       => 'False',
  '-AllowUnicastResponseToMulticast'      => 'False',
  '-AllowLocalFirewallRules'              => 'True',
  '-AllowConnectionSecurityRules'         => 'True',
  '-LogAllowed'                           => 'True',
  '-LogBlocked'                           => 'True',
  '-LogFileName'                          => '%windir%\system32\logfiles\firewall\ServerFirewall.Log',
  '-LogMaxSizeKilobytes'                  => '16384'
}
