<!---
"./docs/header.md" content starts here ...
This content is automatically included  from "./docs/header.md" in "/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md".
--->

# terraform-aws-bootstrap

This repo is used as template to create other terraform repos and automatically populate repo with min required file structure

## LINKS

**[Additional documentation](/docs/README.md)**

**[CHANGELOG](/CHANGELOG.md)**

**[CONTRIBUTING](/docs/CONTRIBUTING.md)**

<!--- "./docs/header.md" content ends here.--->

<!--- "./README.md" file content bellow this comment is automatically generated and replaced by terraform_docs and pre-commit hooks.
To make changes in anything below this comment, modify template file - ".terraform-docs.yaml".
Human managed content (above this comment) is automatically pulled in "./README.md" file from "./docs/header.md". --->

## Examples

```hcl
module "this" {
  source = "../"

  aws_account_name                       = "devops"
  env                                    = "snb"
  iac_deployer_devops_trusted_role_arns  = []
  iac_deployer_network_trusted_role_arns = []

  iam_user = {
    enable = false
  }

  backend = {
    enable = true
  }

  keypair = {
    enable                  = false
    recovery_window_in_days = 0 # 0 used only for testing module, for prod use 30 or remove variable to use default value
  }

  tags = {
    creator  = "antoni.tomaszuk@luminorgroup.com"
    git_repo = "https://git.onelum.host/lds/Foundation/terragrunt-aws-coreinfra/-/tree/master/modules/iam"
  }
}
```

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.0 |
| <a name="provider_wiz"></a> [wiz](#provider\_wiz) | ~> 1.1 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_backend"></a> [backend](#module\_backend) | ./modules/backend | n/a |
| <a name="module_coreinfra_tags"></a> [coreinfra\_tags](#module\_coreinfra\_tags) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-coreinfra-tags.git | v3.0.5 |
| <a name="module_iac_deployer_devops"></a> [iac\_deployer\_devops](#module\_iac\_deployer\_devops) | terraform-aws-modules/iam/aws//modules/iam-assumable-role | ~> 5.0 |
| <a name="module_iac_deployer_network"></a> [iac\_deployer\_network](#module\_iac\_deployer\_network) | terraform-aws-modules/iam/aws//modules/iam-assumable-role | ~> 5.0 |
| <a name="module_iam_wiz"></a> [iam\_wiz](#module\_iam\_wiz) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-iam-wiz.git | 0.2.1 |
| <a name="module_key_pair"></a> [key\_pair](#module\_key\_pair) | terraform-aws-modules/key-pair/aws | ~> v2.0 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_account_name"></a> [aws\_account\_name](#input\_aws\_account\_name) | User frendly name for AWS account | `string` | n/a | yes |
| <a name="input_backend"></a> [backend](#input\_backend) | Backend configuration | <pre>object({<br>    enable                 = bool<br>    enable_dynamodb_stream = optional(bool, false)<br>    dynamodb_stream_view = optional(map(any), {<br>      true  = "NEW_AND_OLD_IMAGES"<br>      false = null<br>    })<br>    dynamodb_read_capacity  = optional(number, 1)<br>    dynamodb_write_capacity = optional(number, 1)<br>    remote_account_id       = optional(string)<br>    remote_bucket_arn       = optional(string)<br>    remote_table_arn        = optional(string)<br>  })</pre> | <pre>{<br>  "enable": false<br>}</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | Environment type | `string` | n/a | yes |
| <a name="input_iac_deployer_devops_trusted_role_arns"></a> [iac\_deployer\_devops\_trusted\_role\_arns](#input\_iac\_deployer\_devops\_trusted\_role\_arns) | List of Role ARNs which will be alloved to assume account specific IaC Deployer DevOps Role | `list(string)` | n/a | yes |
| <a name="input_iac_deployer_network_trusted_role_arns"></a> [iac\_deployer\_network\_trusted\_role\_arns](#input\_iac\_deployer\_network\_trusted\_role\_arns) | List of Role ARNs which will be alloved to assume account specific IaC Deployer Network Role | `list(string)` | n/a | yes |
| <a name="input_iam_user"></a> [iam\_user](#input\_iam\_user) | Set to true to create the IAM user, false otherwise. | <pre>object({<br>    enable = bool<br>  })</pre> | <pre>{<br>  "enable": false<br>}</pre> | no |
| <a name="input_keypair"></a> [keypair](#input\_keypair) | AWS keypair configuration | <pre>object({<br>    enable                  = bool<br>    recovery_window_in_days = optional(number, 30)<br>  })</pre> | <pre>{<br>  "enable": true<br>}</pre> | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Map of tags to be configured for all resources of this deployment | <pre>object({<br>    service_area     = optional(string, "cloud")<br>    project_id       = optional(string, "Foundation")<br>    creator          = string<br>    owner            = optional(string, "guntis.smits@luminorgroup.com")<br>    git_repo         = string<br>    confidentiality  = optional(string, "shared-env")<br>    integrity        = optional(string, "shared-env")<br>    availability     = optional(string, "shared-env")<br>    personal_data    = optional(string, "shared-env")<br>    compliance       = optional(string, "shared-env")<br>    enable_backup    = optional(string, "on")<br>    backup_retention = optional(string, "1m")<br>    backup_rpo       = optional(string, "1d")<br>  })</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_backend"></a> [backend](#output\_backend) | Configuration of S3 for storing Terraform statefiles |
| <a name="output_keypair_name"></a> [keypair\_name](#output\_keypair\_name) | Name of common Key Pair to be used in all EC2 deployed on account |
| <a name="output_role_iac_deployer_devops_arn"></a> [role\_iac\_deployer\_devops\_arn](#output\_role\_iac\_deployer\_devops\_arn) | ARN of IaC Deployer role |
| <a name="output_role_iac_deployer_network_arn"></a> [role\_iac\_deployer\_network\_arn](#output\_role\_iac\_deployer\_network\_arn) | ARN of IaC Deployer role |
| <a name="output_wiz_role_arn"></a> [wiz\_role\_arn](#output\_wiz\_role\_arn) | ARN of AWS Role granting Wiz access to account configuration |

<!---
"./docs/CONTRIBUTING.md" content starts here ...
This content is automatically included  from "./docs/CONTRIBUTING.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/CONTRIBUTING.md". --->

# Contributing

## Prerequisites

[Workstation Setup](/docs/workstation-setup.md)

## How to Contribute

You can contribute by creating a feature branch and opening a MR on Gitlab. Before creating MR, test your code using
example directory.

Your commits must fallow [conventional commits](https://www.conventionalcommits.org/en/v1.0.0/#summary) standards. If you are not familiar with conventional commits standard, you can use use `cz commit` instead of `git commit` command. Commitizen will guide you through series of prompts to automatically template commit message according to standard.
Remember, **commit messages** should be meanigfull, they are going to **apear in changelog.**

Changelog is automatically generated from commit messages by commitizen tool. Use 'cz bump -at' command to generate new [semantic version](https://semver.org/) of terraform module, automatically generate changelog and git tag.

### Module Testing

To test the terraform code, use the cheapest AWS sizing option possible - use smallest instance sizes available, use spot instances when possible.
Assin minimal resources required with k8s requests and limits. Module testing is for infra tests, not application functional tests.

#### Generic, Reusable Terraform Modules
<!--- Generic, reusable AWS module testing process description starts here-->
Generic atomic Terraform module like s3, rds, eks, vpc, must use aws-devops-snb account for module testing.
Module must deploy new ephemoral infrastructure, which is destoyed imediatly after the test is compleated.
Testing must do both - `terraform apply` and `terraform destroy`.

#### Application Specific Terraform Modules
<!--- Application's infra module testing process description starts here-->
Terraform modules for application specific infra, like "jenkins", like "ccc" must use aws account for the lowest environment to test the code. Module must deploy new ephemoral infrastructure, paralel to the existing environment.
e.g. jenkins uses aws-devsecops-tst account. Because jenkins does not have a dev environment, it's lowest available environment is TST.
e.g. ccc uses aws-main-dev account. Because ccc lowest available environment for CCC is DEV.
Testing must do both - `terraform apply` and `terraform destroy`.

#### Testing Process

1. Clone or pull latest changes from Gitlab master/main branch with `git clone $link_to_repo_here` or `git pull`
2. Run `pre-commit install` to setup precommit for this repository (one time action per repository)
3. After you finished writing your code on feature branch, run `cd /example` to switch to example directory.
4. Run `terraform validate` to validate code syntax
5. Run `terraform apply` to deploy infrastructure
6. Run `terraform destroy`to destroy infrastructure.

N.B. If terraform fails in the middle of creating/destoying resources, you are responsible for cleaning up the leftowers.

#### Creating a Merge Request

1. Run `pre-commit run -a` to validate all pre-commit hooks and auto generate documentation.
2. Stage files for git commit `git add .`
3. Run `cz commit` to generate commit messages. Use commitizen to add as many commits as you need. Once the code is ready to be merged fallow next steps.
4. Run `cz bump -at` to bump up module version. This generates change log and new git annotated tag.
5. Run `git push --follow-tags` to push changes to remote repository.
6. Go to Gitlab and open MR and assign one of the codeowners as a reviewer.
7. Merge the code.

#### Going for Extra Mile

If you are already modifying the code in this repo, there are fallowing low effort things you can do to keep code updated:

* Update pre-commit hook versions. Run command `pre-commit autoupdate` to populate .pre-commit-config.yaml file with latest versions
* Update Terraform provider versions.
* Update Terraform version.

#### Additional Reading

More detailed Terraform code guidelines are available [here](https://git.onelum.host/lds/ways-of-working/-/blob/master/01-terraform-code-guidelines.md)

<!---
#### Future Improvements for CI pipeline

Tag is added to feature branch not the merge commit on master branch.
TODO: test how to tag main branch and merge commit using `VER=$(cz version -p)` command instead of tagging feature branch. To achieve this, it might be required to modify .cz.toml file to use `version_provider = "commitizen"` instead of `version_provider = "scm"`.
TODO: design a CD pipeline to distribute the preconfigured files from template repo to rest of the users.
-->
<!--- "./docs/CONTRIBUTING.md" content ends here.--->