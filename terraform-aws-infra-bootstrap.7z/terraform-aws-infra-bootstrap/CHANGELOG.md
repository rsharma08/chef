## v0.5.0 (2023-12-12)

### Feat

- **store-smtp-secret-newly-created-secret-manager**: store smtp secret into secret manager and modify user creation flag to standardise as per rest of the code
- **add-toggle-to-control-SMTP-user-creation**: add toggle to example to control SMTP user creation
- **enable-bootstrap-of-sandbox-env**: enable bootstrap of sandbox enviornment with wiz configuration
- **enable-feature-flag-for-user-creation**: feature flag configure to create IAM user, deafult set to false
- **setup-ses-user**: provision ses user to send email for gitlab setup

## v0.3.2 (2023-11-27)

### Fix

- **wiz**: Service Account needs to have unique name

## v0.3.1 (2023-11-16)

### Fix

- **tags**: updated configuration of resource tags

## v0.3.0 (2023-08-30)

## v0.2.0 (2023-08-30)

## v0.1.0 (2023-08-10)
