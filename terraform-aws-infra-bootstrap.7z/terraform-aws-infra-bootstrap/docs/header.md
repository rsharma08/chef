<!--- 
"./docs/header.md" content starts here ...
This content is automatically included  from "./docs/header.md" in "/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". 
--->

# terraform-aws-bootstrap

This repo is used as template to create other terraform repos and automatically populate repo with min required file structure

## LINKS

**[Additional documentation](/docs/README.md)**

**[CHANGELOG](/CHANGELOG.md)**

**[CONTRIBUTING](/docs/CONTRIBUTING.md)**

<!--- "./docs/header.md" content ends here.--->