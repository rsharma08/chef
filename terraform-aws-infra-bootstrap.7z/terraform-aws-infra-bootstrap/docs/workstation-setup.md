# Workstation Setup

Fallowing tools must be installd on workstation.
For MS Windows, most of the tools are available from "company portal app" as self service installations.
For MacOS users, you must have admin permissions on your workstation. Most of these tools are available as homebrew packages.

## Tools

### Generric Tools for All DevOps Engineers

* [VPN client](https://nubis.luminorgroup.com/)
* [aws cli](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)
* [AWS SSM plugin](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager-working-with-install-plugin.html)
* [jfrog cli](https://jfrog.com/help/r/jfrog-cli/download-and-installation)
* [git](https://git-scm.com/downloads)
* [pre-commit](https://pre-commit.com/#intro) installed on your workstation
* [commitizen](https://commitizen-tools.github.io/commitizen/) installed on your workstation
* [tfswitch](https://tfswitch.warrensbox.com/Install/) to manage installing/switching between Terraform versions.
* IDE - [InteliJ CE](https://www.jetbrains.com/idea/download/) or [Visual Studio Code](https://code.visualstudio.com/download) with plugins for Git, Terraform, Jenkins.
* [granted](https://docs.commonfate.io/granted/getting-started/)
* (required only for Win) [Windows Subsystem for Linux](https://learn.microsoft.com/en-us/windows/wsl/install)
* (optional) [Localstack](https://docs.localstack.cloud/getting-started/) for mocking AWS APIs and trully offline Terraform module testing

### (optional) For Local K8s Testing on Minikube

* [colima](https://github.com/abiosoft/colima)
* [virtualbox](https://www.virtualbox.org/wiki/Downloads)
* [minikube](https://minikube.sigs.k8s.io/docs/start/)
* IDE plugins for Artifactory, k8s

### For Working with EKS on AWS

* [kubectl](https://kubernetes.io/docs/tasks/tools/)
* [kubens](https://webinstall.dev/kubens/)
* [kubectx](https://webinstall.dev/kubectx/)
* [helm](https://helm.sh/docs/intro/install/)
* IDE plugins for Artifactory, k8s, Sonarqube.

### For Working with EC2s and Chef

* [Chef Workstation](https://docs.chef.io/workstation/install_workstation/)
* [Vagrant](https://developer.hashicorp.com/vagrant/downloads)
* IDE Plugins for Ruby language, Artifactory.

## AWS CLI Configuration

Human access to AWS is granted via AWS IAM Identity center deployed from aws-master-prd account. You must have at least one AWS account access group assigned to you before you can configure CLI.

1. When you configure aws cli for the first time run `aws configure sso` and configure one profile.
It does not mater which on you choose.
2. Go to Gitlab, select directory (SSO access role) from [repo](https://git.onelum.host/lds/terraform-aws-coreinfra/aws-master/-/tree/master/z-aws-sso). Typicaly, if you are devops engineer, it would be [devops](https://git.onelum.host/lds/terraform-aws-coreinfra/aws-master/-/blob/master/z-aws-sso/devops/) role.
3. Copy  config file contents from repo and replace your local ~/.aws/config file.
4. Verify access by running commands:

    ```shell
    aws sso login
    aws sts get-caller-identity --profile $UseSomeProfileNameHere
    ```

5. If you do not have access to all profiles configured in config file, you can safely delete ones you do not need from local config file.

### AWS CLI Login for Terraform

Before you can use terraform you must login to AWS using CLI credentials.

1. Run `assume $UseSomeProfileNameHere` to get temporary credentials to AWS.
2. For the first time login, you will have to configure default browser and will have to restart your terminal.

## Git CLI Config

1. Before you can configure git cli, you must log in to Gitlab at least once from UI.
2. Create personal access [token](https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html)
3. Run command `git config` and fallow on screen prompts. When you are asked for password, enter access token value instead.

## Jfrog CLI Config

1. Before you can configure jfrog cli, you must log in to Artifactory at least once from UI.
2. Create [access token](https://jfrog.com/help/r/jfrog-cli/authenticating-with-username-and-password/api-key).
3. Run `jf c add` command and fallow onscreen prompts.
4. Verify access by running command `jf rt ping`
