<!---
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-aws-app-gitlab

Repository offering organized and versioned Terraform/Terragrunt configurations designed to deploy and maintain Gitlab application which will be used on DevSecOps Platform on AWS

## LINKS
#### [Additional documentation](./docs/README.md)
#### [CHANGELOG](CHANGELOG.md)

<!--- "./docs/header.md" content ends here.--->

<!--- "./README.md" file content bellow this comment is automticaly generated and replaced by terraform_docs and pre-commit hooks.
To make changes in anything below this comment, modify template file - ".terraform-docs.yaml".
Human managed content (abbove this comment) is automatically pulled in "./README.md" file from "./docs/header.md". --->

## Examples
```hcl
module "gitlab" {
  source = "../"

  # 03-eks
  # eks = data.terraform_remote_state.eks.outputs.eks
  aws_account_name = "devsecops"
  env              = "tst"
  creator          = "ghazi.nisar@luminorgroup.com"
  git_repo         = "https://git.onelum.host/lds/Foundation/terraform-aws-app-gitlab"

  public_domain = "tst-onelum.run"
}

```
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.10.0 |
| <a name="provider_helm"></a> [helm](#provider\_helm) | 2.10.1 |
| <a name="provider_http"></a> [http](#provider\_http) | 3.4.0 |
| <a name="provider_kubectl"></a> [kubectl](#provider\_kubectl) | ~> 1.14.0 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | 2.22.0 |
| <a name="provider_random"></a> [random](#provider\_random) | 3.5.1 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_coreinfra_tags"></a> [coreinfra\_tags](#module\_coreinfra\_tags) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-coreinfra-tags.git | v3.0.5 |
| <a name="module_elasticache_redis"></a> [elasticache\_redis](#module\_elasticache\_redis) | cloudposse/elasticache-redis/aws | ~> 0.53.0 |
| <a name="module_iam_irsa_gitlab"></a> [iam\_irsa\_gitlab](#module\_iam\_irsa\_gitlab) | terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks | ~> 5.30 |
| <a name="module_rds_postgres"></a> [rds\_postgres](#module\_rds\_postgres) | terraform-aws-modules/rds/aws | ~> 6.1.0 |
| <a name="module_security_group_gitlab_efs"></a> [security\_group\_gitlab\_efs](#module\_security\_group\_gitlab\_efs) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |
| <a name="module_security_group_rds_postgres"></a> [security\_group\_rds\_postgres](#module\_security\_group\_rds\_postgres) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |
| <a name="module_security_group_redis"></a> [security\_group\_redis](#module\_security\_group\_redis) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | Name of application | `string` | `"gitlab"` | no |
| <a name="input_aws_account_name"></a> [aws\_account\_name](#input\_aws\_account\_name) | User frendly name for AWS account | `string` | n/a | yes |
| <a name="input_creator"></a> [creator](#input\_creator) | Email address of person deploying this module | `string` | n/a | yes |
| <a name="input_efs_storage"></a> [efs\_storage](#input\_efs\_storage) | Storage size for EFS volume | `string` | `"50Gi"` | no |
| <a name="input_env"></a> [env](#input\_env) | Environment tst or prd | `string` | `"tst"` | no |
| <a name="input_git_repo"></a> [git\_repo](#input\_git\_repo) | Link to Terraform module repository | `string` | n/a | yes |
| <a name="input_public_domain"></a> [public\_domain](#input\_public\_domain) | Public DNS Domain used to connect to service from outside of local Luminor network | `string` | n/a | yes |
| <a name="input_rds_allocated_storage"></a> [rds\_allocated\_storage](#input\_rds\_allocated\_storage) | RDS Allocated Storage | `number` | `20` | no |
| <a name="input_rds_backup_retention_period"></a> [rds\_backup\_retention\_period](#input\_rds\_backup\_retention\_period) | RDS Backup Retention Period | `number` | `1` | no |
| <a name="input_rds_backup_window"></a> [rds\_backup\_window](#input\_rds\_backup\_window) | RDS backup window | `string` | `"03:00-06:00"` | no |
| <a name="input_rds_engine_version"></a> [rds\_engine\_version](#input\_rds\_engine\_version) | RDS postgres engine version | `string` | `"15.4"` | no |
| <a name="input_rds_instance_class"></a> [rds\_instance\_class](#input\_rds\_instance\_class) | RDS Instance Class | `string` | `"db.t4g.micro"` | no |
| <a name="input_rds_maintenance_window"></a> [rds\_maintenance\_window](#input\_rds\_maintenance\_window) | RDS Maintenance Window | `string` | `"Mon:00:00-Mon:03:00"` | no |
| <a name="input_rds_max_allocated_storage"></a> [rds\_max\_allocated\_storage](#input\_rds\_max\_allocated\_storage) | RDS Allocated Storage | `number` | `100` | no |
| <a name="input_rds_skip_final_snapshot"></a> [rds\_skip\_final\_snapshot](#input\_rds\_skip\_final\_snapshot) | RDS Skip final snapshot | `bool` | `true` | no |
| <a name="input_redis_cluster_size"></a> [redis\_cluster\_size](#input\_redis\_cluster\_size) | Number of nodes in cluster. Ignored when cluster\_mode\_enabled == true | `number` | `1` | no |
| <a name="input_redis_engine_version"></a> [redis\_engine\_version](#input\_redis\_engine\_version) | Redis engine version | `string` | `"7.0"` | no |
| <a name="input_redis_family"></a> [redis\_family](#input\_redis\_family) | Redis family | `string` | `"redis7"` | no |
| <a name="input_redis_instance_type"></a> [redis\_instance\_type](#input\_redis\_instance\_type) | Elastic cache instance type | `string` | `"cache.t4g.micro"` | no |

## Outputs

No outputs.

