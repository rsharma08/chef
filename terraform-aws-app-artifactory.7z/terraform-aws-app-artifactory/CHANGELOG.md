# CHANGELOG

## Improvements for Future Releases
- add terraform_validate hook to pre-commit
- add terraform_tflint hook to pre-commit

## v0.1.0 (2023-09-29)
### Features
- adding diagram to docs directory
- adding changelog
- adding precommit config