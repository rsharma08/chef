# CHANGELOG

## Improvements for Future Releases
- add terraform_validate hook to pre-commit
- add terraform_tflint hook to pre-commit

## v0.3.0 (2023-12-15)

### Feat

- **add-lifecycle-to-S3-bucket**: add lifecycle rule on tst environment to delete 90 days old file
- **enable-smtp,-log-rotation-and-update-AS-IS-daigram**: enable smtp, log rotation and update  Daigram for AS IS and TO Be

### Refactor

- **align-providers-version-declaration**: align provider version declaration as per rest of terraform repositories

## v0.2.0 (2023-11-30)

### Refactor

- **update-data-certificate-to-adopt-variable**: update data certificate to adopt best practice using variable within url

## v0.1.3 (2023-11-23)

### Fix

- **tags**: Updated Luminor tags

## v0.1.2 (2023-10-27)

## v0.1.1 (2023-10-26)

## v0.1.0 (2023-09-29)
### Features
- adding diagram to docs directory
- adding changelog
- adding precommit config