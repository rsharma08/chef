<!---
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-aws-app-gitlab

Repository offering organized and versioned Terraform/Terragrunt configurations designed to deploy and maintain Gitlab application which will be used on DevSecOps Platform on AWS

## LINKS
#### [Additional documentation](./docs/README.md)
#### [CHANGELOG](CHANGELOG.md)

<!--- "./docs/header.md" content ends here.--->

<!--- "./README.md" file content bellow this comment is automticaly generated and replaced by terraform_docs and pre-commit hooks.
To make changes in anything below this comment, modify template file - ".terraform-docs.yaml".
Human managed content (abbove this comment) is automatically pulled in "./README.md" file from "./docs/header.md". --->

## Examples
```hcl
resource "random_string" "suffix" {
  length  = 6
  lower   = true
  upper   = false
  special = false
}

module "gitlab" {
  source = "../"

  aws_account_name = "devsecops"
  env              = "tst"

  application_name = "gitlab-${random_string.suffix.result}"

  public_domain = "tst-onelum.run"

  tags = {
    creator  = "ghazi.nisar@luminorgroup.com"
    git_repo = "https://git.onelum.host/lds/Foundation/terraform-aws-app-gitlab"
  }
}
```
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.10 |
| <a name="provider_helm"></a> [helm](#provider\_helm) | ~> 2.10 |
| <a name="provider_http"></a> [http](#provider\_http) | ~> 3.4 |
| <a name="provider_kubectl"></a> [kubectl](#provider\_kubectl) | ~> 1.14 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | ~> 2.22 |
| <a name="provider_random"></a> [random](#provider\_random) | ~> 3.5 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_coreinfra_tags"></a> [coreinfra\_tags](#module\_coreinfra\_tags) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-coreinfra-tags.git | v3.0.5 |
| <a name="module_elasticache_redis"></a> [elasticache\_redis](#module\_elasticache\_redis) | cloudposse/elasticache-redis/aws | ~> 0.53.0 |
| <a name="module_iam_irsa_gitlab"></a> [iam\_irsa\_gitlab](#module\_iam\_irsa\_gitlab) | terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks | ~> 5.30 |
| <a name="module_rds_postgres"></a> [rds\_postgres](#module\_rds\_postgres) | terraform-aws-modules/rds/aws | ~> 6.1.0 |
| <a name="module_s3_gitlab"></a> [s3\_gitlab](#module\_s3\_gitlab) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-s3-bucket.git | v1.0.6 |
| <a name="module_security_group_gitlab_efs"></a> [security\_group\_gitlab\_efs](#module\_security\_group\_gitlab\_efs) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |
| <a name="module_security_group_rds_postgres"></a> [security\_group\_rds\_postgres](#module\_security\_group\_rds\_postgres) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |
| <a name="module_security_group_redis"></a> [security\_group\_redis](#module\_security\_group\_redis) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |
| <a name="module_sso"></a> [sso](#module\_sso) | ./modules/aruzead_sso | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | Name of application | `string` | `"gitlab"` | no |
| <a name="input_aws_account_name"></a> [aws\_account\_name](#input\_aws\_account\_name) | User frendly name for AWS account | `string` | n/a | yes |
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | AWS Region | `string` | `"eu-central-1"` | no |
| <a name="input_efs_storage"></a> [efs\_storage](#input\_efs\_storage) | Storage size for EFS volume | `string` | `"50Gi"` | no |
| <a name="input_env"></a> [env](#input\_env) | Environment type | `string` | n/a | yes |
| <a name="input_gitlab_webservice"></a> [gitlab\_webservice](#input\_gitlab\_webservice) | Gitlab webservice container configuration | <pre>object({<br>    request_memory = string<br>    request_cpu    = string<br>    limit_memory   = string<br>    limit_cpu      = string<br>  })</pre> | <pre>{<br>  "limit_cpu": "1000m",<br>  "limit_memory": "2Gi",<br>  "request_cpu": "1000m",<br>  "request_memory": "2Gi"<br>}</pre> | no |
| <a name="input_public_domain"></a> [public\_domain](#input\_public\_domain) | Public DNS Domain used to connect to service from outside of local Luminor network | `string` | n/a | yes |
| <a name="input_rds_allocated_storage"></a> [rds\_allocated\_storage](#input\_rds\_allocated\_storage) | RDS Allocated Storage | `number` | `20` | no |
| <a name="input_rds_backup_retention_period"></a> [rds\_backup\_retention\_period](#input\_rds\_backup\_retention\_period) | RDS Backup Retention Period | `number` | `1` | no |
| <a name="input_rds_backup_window"></a> [rds\_backup\_window](#input\_rds\_backup\_window) | RDS backup window | `string` | `"03:00-06:00"` | no |
| <a name="input_rds_engine_version"></a> [rds\_engine\_version](#input\_rds\_engine\_version) | RDS postgres engine version | `string` | `"15.4"` | no |
| <a name="input_rds_instance_class"></a> [rds\_instance\_class](#input\_rds\_instance\_class) | RDS Instance Class | `string` | `"db.t4g.micro"` | no |
| <a name="input_rds_maintenance_window"></a> [rds\_maintenance\_window](#input\_rds\_maintenance\_window) | RDS Maintenance Window | `string` | `"Mon:00:00-Mon:03:00"` | no |
| <a name="input_rds_max_allocated_storage"></a> [rds\_max\_allocated\_storage](#input\_rds\_max\_allocated\_storage) | RDS Allocated Storage | `number` | `100` | no |
| <a name="input_rds_skip_final_snapshot"></a> [rds\_skip\_final\_snapshot](#input\_rds\_skip\_final\_snapshot) | RDS Skip final snapshot | `bool` | `true` | no |
| <a name="input_redis_cluster_size"></a> [redis\_cluster\_size](#input\_redis\_cluster\_size) | Number of nodes in cluster. Ignored when cluster\_mode\_enabled == true | `number` | `1` | no |
| <a name="input_redis_engine_version"></a> [redis\_engine\_version](#input\_redis\_engine\_version) | Redis engine version | `string` | `"7.0"` | no |
| <a name="input_redis_family"></a> [redis\_family](#input\_redis\_family) | Redis family | `string` | `"redis7"` | no |
| <a name="input_redis_instance_type"></a> [redis\_instance\_type](#input\_redis\_instance\_type) | Elastic cache instance type | `string` | `"cache.t4g.micro"` | no |
| <a name="input_sso_roles"></a> [sso\_roles](#input\_sso\_roles) | Additional custom SSO role definitions | <pre>map(object({<br>    description = string<br>    group_names = list(string) # List of AzureAD Group names to be assign to role<br>  }))</pre> | `{}` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Map of tags to be configured for all resources of this deployment | <pre>object({<br>    service_area     = optional(string, "cloud")<br>    project_id       = optional(string, "stab")<br>    application      = optional(string, "lum1133") # Gitlab code<br>    creator          = string<br>    owner            = optional(string, "guntis.smits@luminorgroup.com")<br>    git_repo         = string<br>    confidentiality  = optional(string, "c1")<br>    integrity        = optional(string, "i1")<br>    availability     = optional(string, "a1")<br>    personal_data    = optional(string, "pii") # Employee email addresses<br>    compliance       = optional(string, "na")<br>    enable_backup    = optional(string, "on")<br>    backup_retention = optional(string, "1m")<br>    backup_rpo       = optional(string, "1d")<br>  })</pre> | n/a | yes |

## Outputs

No outputs.

<!---
"./docs/CONTRIBUTING.md" content starts here ...
This content is automatically included  from "./docs/CONTRIBUTING.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/CONTRIBUTING.md". --->

# Contributing

## Prerequisites

[Workstation Setup](/docs/workstation-setup.md)

## How to Contribute

You can contribute by creating a feature branch and opening a MR on Gitlab. Before creating MR, test your code using
example directory.

Your commits must fallow [conventional commits](https://www.conventionalcommits.org/en/v1.0.0/#summary) standards. If you are not familiar with conventional commits standard, you can use use `cz commit` instead of `git commit` command. Commitizen will guide you through series of prompts to automatically template commit message according to standard.
Remember, **commit messages** should be meanigfull, they are going to **apear in changelog.**

Changelog is automatically generated from commit messages by commitizen tool. Use 'cz bump -at' command to generate new [semantic version](https://semver.org/) of terraform module, automatically generate changelog and git tag.

### Module Testing

To test the terraform code, use the cheapest AWS sizing option possible - use smallest instance sizes available, use spot instances when possible.
Assin minimal resources required with k8s requests and limits. Module testing is for infra tests, not application functional tests.

#### Generic, Reusable Terraform Modules
<!--- Generic, reusable AWS module testing process description starts here-->
Generic atomic Terraform module like s3, rds, eks, vpc, must use aws-devops-snb account for module testing.
Module must deploy new ephemeral infrastructure, which is destroyed immediately after the test is completed.
Testing must do both - `terraform apply` and `terraform destroy`.

#### Application Specific Terraform Modules
<!--- Application's infra module testing process description starts here-->
Terraform modules for application specific infra, like "jenkins", like "ccc" must use aws account for the lowest environment to test the code. Module must deploy new ephemoral infrastructure, paralel to the existing environment.
e.g. jenkins uses aws-devsecops-tst account. Because jenkins does not have a dev environment, it's lowest available environment is TST.
e.g. ccc uses aws-main-dev account. Because ccc lowest available environment for CCC is DEV.
Testing must do both - `terraform apply` and `terraform destroy`.

#### Testing Process

1. Clone or pull latest changes from Gitlab master/main branch with `git clone $link_to_repo_here` or `git pull`
2. Run `pre-commit install` to setup pre-commit for this repository (one time action per repository)
3. After you finished writing your code on feature branch, run `cd /example` to switch to example directory.
If you are writing new Terraform module, update `/example/backend.tf` file to use unique TF state file according to naming pattern.
4. Run `terraform validate` to validate code syntax
5. Run `terraform apply` to deploy infrastructure
6. Run `terraform destroy`to destroy infrastructure.

N.B. If terraform fails in the middle of creating/destoying resources, you are responsible for cleaning up the leftowers.

#### Creating a Merge Request

1. Run `pre-commit run -a` to validate all pre-commit hooks and auto generate documentation.
2. Stage files for git commit `git add .`
3. Run `cz commit` to generate commit messages. Use commitizen to add as many commits as you need. Once the code is ready to be merged fallow next steps.
4. Run `cz bump -at` to bump up module version. This generates change log and new git annotated tag.
5. Run `git push --follow-tags` to push changes to remote repository.
6. Go to Gitlab and open MR and assign one of the codeowners as a reviewer.
7. Merge the code.

#### Going for Extra Mile

If you are already modifying the code in this repo, there are fallowing low effort things you can do to keep code updated:

* Update pre-commit hook versions. Run command `pre-commit autoupdate` to populate .pre-commit-config.yaml file with latest versions
* Update Terraform provider versions.
* Update Terraform version.

#### Additional Reading

More detailed Terraform code guidelines are available [here](https://git.onelum.host/lds/ways-of-working/-/blob/master/01-terraform-code-guidelines.md)

<!---
#### Future Improvements for CI pipeline

Tag is added to feature branch not the merge commit on master branch.
TODO: test how to tag main branch and merge commit using `VER=$(cz version -p)` command instead of tagging feature branch. To achieve this, it might be required to modify .cz.toml file to use `version_provider = "commitizen"` instead of `version_provider = "scm"`.
TODO: design a CD pipeline to distribute the preconfigured files from template repo to rest of the users.
-->
<!--- "./docs/CONTRIBUTING.md" content ends here.--->