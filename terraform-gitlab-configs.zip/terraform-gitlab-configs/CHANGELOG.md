## v0.2.1 (2024-01-12)

### Fix

- **groups**: Fixed permission to create projects under technology groups

## v0.2.0 (2023-12-22)

### Feat

- **Gitlab-configuration**: gitlab configuration

## v0.1.0 (2023-12-22)

### Feat

- **Gitlab-configuration**: gitlab configuration
- **GitLab-config-without-iamExtraGroups**: gitlab confiuration of groups, projects and settings without iamextragroups
- **GitLab-config-without-iamExtraGroups**: gitlab confiuration of groups, projects and settings without iamextragroups
