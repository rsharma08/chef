<!---
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-gitlab-configs

Repository offering organized and versioned Terraform/Terragrunt configurations designed to configure Gitlab application which will be used on DevSecOps Platform on AWS

## LINKS

**[Additional documentation](/docs/README.md)**

**[CHANGELOG](/CHANGELOG.md)**

**[CONTRIBUTING](/docs/CONTRIBUTING.md)**

<!--- "./docs/header.md" content ends here.--->

<!--- "./README.md" file content bellow this comment is automticaly generated and replaced by terraform_docs and pre-commit hooks.
To make changes in anything below this comment, modify template file - ".terraform-docs.yaml".
Human managed content (abbove this comment) is automatically pulled in "./README.md" file from "./docs/header.md". --->

## Examples
```hcl
# Note: Ensure the variable var.application_name matches exactly the application name deployed using terraform-aws-app-artifactory
module "gitlab_configs" {
  source = "../"

  # aws_account_name = "devsecops"
  env = "tst"

  application_name = "gitlab"
  public_domain    = "tst-onelum.run"

  product_team_configs = local.config_list

}
```
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.10 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_gitlab_config"></a> [gitlab\_config](#module\_gitlab\_config) | ./modules/gitlab-config | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | Gitlab Application name | `string` | `"gitlab"` | no |
| <a name="input_env"></a> [env](#input\_env) | Environment type | `string` | n/a | yes |
| <a name="input_product_team_configs"></a> [product\_team\_configs](#input\_product\_team\_configs) | Yamldecoded Configuration | `any` | n/a | yes |
| <a name="input_public_domain"></a> [public\_domain](#input\_public\_domain) | Public DNS Domain used to connect to service from outside of local Luminor network | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_gitlab_project_ids"></a> [gitlab\_project\_ids](#output\_gitlab\_project\_ids) | Map of existing Gitlab Projects and their IDs |

