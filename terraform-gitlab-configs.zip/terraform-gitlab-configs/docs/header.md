<!--- 
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-gitlab-configs

Repository offering organized and versioned Terraform/Terragrunt configurations designed to configure Gitlab application which will be used on DevSecOps Platform on AWS

## LINKS

**[Additional documentation](/docs/README.md)**

**[CHANGELOG](/CHANGELOG.md)**

**[CONTRIBUTING](/docs/CONTRIBUTING.md)**

<!--- "./docs/header.md" content ends here.--->