<!---
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-aws-app-gitlab-admin

Repository offering organized and versioned Terraform/Terragrunt configurations designed to deploy and maintain Gitlab application admin configurations which will be used on DevSecOps Platform on AWS

## Pre-requisite to start using this repo.
For Gitlab admin automation setup (Global Configuration, Group Configuration and Project configuration), an access token is needed and this can be generated from Gitlab admin page.

1. Login to Gitlab admin page using url: `https://${var.application_name}.${var.public_domain}`.

2. Login user must be part of administrator Group.

3. Click on Edit Profile on Right hand corner, Go to `Access Tokens`.

4. Click `Add new Token` Enter requested details: name, expiry and Scope of Token [api, admin-mode]. Click on `Create Personal access Token`.

5. Copy the Token and  then manually paste the tokens to existing application secret manager `a-${var.env}-asm-${var.application_name}-credentials` with secret keys as `access_token`.

8. Proceed to run the `terraform-aws-app-gitlab-admin` repo to setup admin configurations.

## LINKS
#### [CHANGELOG](CHANGELOG.md)

<!--- "./docs/header.md" content ends here.--->

<!--- "./README.md" file content bellow this comment is automticaly generated and replaced by terraform_docs and pre-commit hooks.
To make changes in anything below this comment, modify template file - ".terraform-docs.yaml".
Human managed content (abbove this comment) is automatically pulled in "./README.md" file from "./docs/header.md". --->

## Examples
```hcl
# Note: Ensure the variable var.application_name matches exactly the application name deployed using terraform-aws-app-artifactory
module "gitlab" {
  source = "../"

  aws_account_name = "devsecops"
  env              = "tst"

  application_name = "gitlab"
  public_domain    = "tst-onelum.run"

  tags = {
    creator  = "raman.sharma@luminorgroup.com"
    git_repo = "https://git.onelum.host/lds/Foundation/terraform-aws-app-gitlab-admin"
  }

}
```
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.10 |
| <a name="provider_gitlab"></a> [gitlab](#provider\_gitlab) | ~> 16.6 |
| <a name="provider_restapi"></a> [restapi](#provider\_restapi) | ~> 1.18 |
| <a name="provider_time"></a> [time](#provider\_time) | 0.10.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_coreinfra_tags"></a> [coreinfra\_tags](#module\_coreinfra\_tags) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-coreinfra-tags.git | v3.0.5 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_allow_account_deletion"></a> [allow\_account\_deletion](#input\_allow\_account\_deletion) | Configure user to allow account\_deletion | `string` | `"true"` | no |
| <a name="input_allow_local_requests_from_system_hooks"></a> [allow\_local\_requests\_from\_system\_hooks](#input\_allow\_local\_requests\_from\_system\_hooks) | Configure requests from system hooks | `string` | `"true"` | no |
| <a name="input_allow_local_requests_from_web_hooks_and_services"></a> [allow\_local\_requests\_from\_web\_hooks\_and\_services](#input\_allow\_local\_requests\_from\_web\_hooks\_and\_services) | Configure requests from web\_hooks and services | `string` | `"true"` | no |
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | Gitlab Application name | `string` | n/a | yes |
| <a name="input_aws_account_name"></a> [aws\_account\_name](#input\_aws\_account\_name) | User friendly name for AWS account | `string` | n/a | yes |
| <a name="input_default_branch_protection"></a> [default\_branch\_protection](#input\_default\_branch\_protection) | Configure  Branch Protection | `number` | `4` | no |
| <a name="input_default_group_visibility"></a> [default\_group\_visibility](#input\_default\_group\_visibility) | Default group visibilty level | `string` | `"internal"` | no |
| <a name="input_default_project_creation"></a> [default\_project\_creation](#input\_default\_project\_creation) | Configure Default project creation protection, maintainer, Developer or no one | `number` | `0` | no |
| <a name="input_default_project_deletion_protection"></a> [default\_project\_deletion\_protection](#input\_default\_project\_deletion\_protection) | Configure project deletion protection | `string` | `"false"` | no |
| <a name="input_default_project_visibility"></a> [default\_project\_visibility](#input\_default\_project\_visibility) | Default project visibilty level | `string` | `"internal"` | no |
| <a name="input_default_snippet_visibility"></a> [default\_snippet\_visibility](#input\_default\_snippet\_visibility) | Default snippet visibilty level | `string` | `"private"` | no |
| <a name="input_deletion_adjourned_period"></a> [deletion\_adjourned\_period](#input\_deletion\_adjourned\_period) | Configure project deletion protection | `number` | `30` | no |
| <a name="input_diff_max_files"></a> [diff\_max\_files](#input\_diff\_max\_files) | Configure  Max diff files | `number` | `1000` | no |
| <a name="input_diff_max_lines"></a> [diff\_max\_lines](#input\_diff\_max\_lines) | Configure  Max diff files | `number` | `50000` | no |
| <a name="input_diff_max_patch_bytes"></a> [diff\_max\_patch\_bytes](#input\_diff\_max\_patch\_bytes) | Configure  Max diff limit size | `number` | `512000` | no |
| <a name="input_dns_rebinding_protection_enabled"></a> [dns\_rebinding\_protection\_enabled](#input\_dns\_rebinding\_protection\_enabled) | Configure dns rebinding protection | `string` | `"true"` | no |
| <a name="input_dsa_key_restriction"></a> [dsa\_key\_restriction](#input\_dsa\_key\_restriction) | Configure dsa key restriction | `number` | `0` | no |
| <a name="input_ecdsa_key_restriction"></a> [ecdsa\_key\_restriction](#input\_ecdsa\_key\_restriction) | Configure ecdsa key restriction | `number` | `0` | no |
| <a name="input_ecdsa_sk_key_restriction"></a> [ecdsa\_sk\_key\_restriction](#input\_ecdsa\_sk\_key\_restriction) | Configure ecdsa\_sk key restriction | `number` | `0` | no |
| <a name="input_ed25519_key_restriction"></a> [ed25519\_key\_restriction](#input\_ed25519\_key\_restriction) | Configure ecdsa key restriction | `number` | `0` | no |
| <a name="input_ed25519_sk_key_restriction"></a> [ed25519\_sk\_key\_restriction](#input\_ed25519\_sk\_key\_restriction) | Configure ecdsa\_sk key restriction | `number` | `0` | no |
| <a name="input_email_confirmation_setting"></a> [email\_confirmation\_setting](#input\_email\_confirmation\_setting) | configure email\_confirmation\_setting | `string` | `"hard"` | no |
| <a name="input_enabled_git_access_protocol"></a> [enabled\_git\_access\_protocol](#input\_enabled\_git\_access\_protocol) | Enable git access protocol, options are Http, ssh, or both | `string` | `"http"` | no |
| <a name="input_env"></a> [env](#input\_env) | Environment type | `string` | n/a | yes |
| <a name="input_gitaly_timeout_default"></a> [gitaly\_timeout\_default](#input\_gitaly\_timeout\_default) | Configure default gitlay timeout | `number` | `55` | no |
| <a name="input_gitaly_timeout_fast"></a> [gitaly\_timeout\_fast](#input\_gitaly\_timeout\_fast) | Configure default gitlay timeout | `number` | `10` | no |
| <a name="input_gitaly_timeout_medium"></a> [gitaly\_timeout\_medium](#input\_gitaly\_timeout\_medium) | Configure default gitlay timeout | `number` | `30` | no |
| <a name="input_group_download_export_limit"></a> [group\_download\_export\_limit](#input\_group\_download\_export\_limit) | Configure group import/export setting | `number` | `1` | no |
| <a name="input_group_export_limit"></a> [group\_export\_limit](#input\_group\_export\_limit) | Configure group import/export setting | `number` | `6` | no |
| <a name="input_group_import_limit"></a> [group\_import\_limit](#input\_group\_import\_limit) | Configure group import/export setting | `number` | `6` | no |
| <a name="input_hide_third_party_offers"></a> [hide\_third\_party\_offers](#input\_hide\_third\_party\_offers) | Configure third party offers | `string` | `"true"` | no |
| <a name="input_import_sources"></a> [import\_sources](#input\_import\_sources) | Default list of import sources | `list(string)` | <pre>[<br>  "gitlab_project"<br>]</pre> | no |
| <a name="input_maintenance_mode"></a> [maintenance\_mode](#input\_maintenance\_mode) | Configure maintainance mode | `string` | `"false"` | no |
| <a name="input_maintenance_mode_message"></a> [maintenance\_mode\_message](#input\_maintenance\_mode\_message) | Configure maintainance mode | `string` | `"Gitlab is undergoing maintenance, please Try again later."` | no |
| <a name="input_max_artifacts_size"></a> [max\_artifacts\_size](#input\_max\_artifacts\_size) | Configure max artifacts size | `number` | `10` | no |
| <a name="input_max_attachment_size"></a> [max\_attachment\_size](#input\_max\_attachment\_size) | Configure max attachment size | `number` | `10` | no |
| <a name="input_max_import_size"></a> [max\_import\_size](#input\_max\_import\_size) | Configure max import size | `number` | `50` | no |
| <a name="input_minimum_password_length"></a> [minimum\_password\_length](#input\_minimum\_password\_length) | Configure minimum\_password\_length | `number` | `20` | no |
| <a name="input_mirror_available"></a> [mirror\_available](#input\_mirror\_available) | Configure repository Mirror | `string` | `"true"` | no |
| <a name="input_project_deletion_level"></a> [project\_deletion\_level](#input\_project\_deletion\_level) | Configure project import/export setting | `number` | `3` | no |
| <a name="input_project_download_export_limit"></a> [project\_download\_export\_limit](#input\_project\_download\_export\_limit) | Configure project import/export setting | `number` | `1` | no |
| <a name="input_project_export_limit"></a> [project\_export\_limit](#input\_project\_export\_limit) | Configure project import/export setting | `number` | `6` | no |
| <a name="input_project_import_limit"></a> [project\_import\_limit](#input\_project\_import\_limit) | Configure project import/export setting | `number` | `6` | no |
| <a name="input_public_domain"></a> [public\_domain](#input\_public\_domain) | Public DNS Domain used to connect to service from outside of local Luminor network | `string` | n/a | yes |
| <a name="input_remember_me_enabled"></a> [remember\_me\_enabled](#input\_remember\_me\_enabled) | Allow User to extend there session | `string` | `"false,"` | no |
| <a name="input_repository_access_git"></a> [repository\_access\_git](#input\_repository\_access\_git) | Configure Repository settings | `string` | `"true"` | no |
| <a name="input_repository_access_http"></a> [repository\_access\_http](#input\_repository\_access\_http) | Configure Repository settings | `string` | `"true"` | no |
| <a name="input_repository_access_pages"></a> [repository\_access\_pages](#input\_repository\_access\_pages) | Configure Repository settings | `string` | `"true"` | no |
| <a name="input_repository_access_ssh"></a> [repository\_access\_ssh](#input\_repository\_access\_ssh) | Configure Repository settings | `string` | `"true"` | no |
| <a name="input_restricted_visibility_levels"></a> [restricted\_visibility\_levels](#input\_restricted\_visibility\_levels) | Default visibilty level restriction | `list(string)` | <pre>[<br>  "public"<br>]</pre> | no |
| <a name="input_rsa_key_restriction"></a> [rsa\_key\_restriction](#input\_rsa\_key\_restriction) | Configure rsa key restriction | `number` | `0` | no |
| <a name="input_session_expire_delay"></a> [session\_expire\_delay](#input\_session\_expire\_delay) | Configure  session expire delay | `number` | `960` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Map of tags to be configured for all resources of this deployment | <pre>object({<br>    service_area     = optional(string, "cloud")<br>    project_id       = optional(string, "stab")<br>    application      = optional(string, "lum1130")<br>    creator          = string<br>    owner            = optional(string, "guntis.smits@luminorgroup.com")<br>    git_repo         = string<br>    confidentiality  = optional(string, "c1")<br>    integrity        = optional(string, "i1")<br>    availability     = optional(string, "a1")<br>    personal_data    = optional(string, "pii") # Employee email addresses<br>    compliance       = optional(string, "na")<br>    enable_backup    = optional(string, "on")<br>    backup_retention = optional(string, "1m")<br>    backup_rpo       = optional(string, "1d")<br>  })</pre> | n/a | yes |
| <a name="input_user_deactivation_emails_enabled"></a> [user\_deactivation\_emails\_enabled](#input\_user\_deactivation\_emails\_enabled) | Configure user permission for email | `string` | `"true"` | no |
| <a name="input_user_oauth_applications"></a> [user\_oauth\_applications](#input\_user\_oauth\_applications) | Configure application oauth | `string` | `"false"` | no |
| <a name="input_whats_new_variant"></a> [whats\_new\_variant](#input\_whats\_new\_variant) | Configure marketing prefernce | `string` | `"all_tiers"` | no |

## Outputs

No outputs.

