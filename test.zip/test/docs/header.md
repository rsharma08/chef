<!--- 
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-aws-app-gitlab-admin

Repository offering organized and versioned Terraform/Terragrunt configurations designed to deploy and maintain Gitlab application admin configurations which will be used on DevSecOps Platform on AWS

## Pre-requisite to start using this repo.
For Gitlab admin automation setup (Global Configuration, Group Configuration and Project configuration), an access token is needed and this can be generated from Gitlab admin page.

1. Login to Gitlab admin page using url: `https://${var.application_name}.${var.public_domain}`.

2. Login user must be part of administrator Group.

3. Click on Edit Profile on Right hand corner, Go to `Access Tokens`.

4. Click `Add new Token` Enter requested details: name, expiry and Scope of Token [api, admin-mode]. Click on `Create Personal access Token`.

5. Copy the Token and  then manually paste the tokens to existing application secret manager `a-${var.env}-asm-${var.application_name}-credentials` with secret keys as `access_token`.

8. Proceed to run the `terraform-aws-app-gitlab-admin` repo to setup admin configurations.

## LINKS
#### [CHANGELOG](CHANGELOG.md)

<!--- "./docs/header.md" content ends here.--->