# frozen_string_literal: true

#! /usr/bin/env python

# Copyright:: Kyndryl 2022

import pwd
import grp
import os
import stat
import sys
import warnings
import shutil
import subprocess
import shlex  # Simple lexical analysis for Unix shell-like languages.
import re
import time
from global_consts import *
from stat import *

##############################################################################
#                   Users and Groups management functions                    #
##############################################################################


def initdirs():

    for dr in (LOG_DIR, BKP_DIR):
        if not os.path.isdir(dr):
            try:
                os.mkdir(dr)
            except:
                dr = os.path.dirname(os.path.abspath(sys.argv[0]))


def name2uid(name):
    return pwd.getpwnam(name).pw_uid


def uid2name(uid):
    return pwd.getpwuid(uid).pw_name


def name2gid(name):
    return grp.getgrnam(name).gr_gid


def gid2name(gid):
    return grp.getgrgid(gid).gr_name


def loadfile2dict(thefile, byfieldno, delim=':'):

    fh = open(thefile)

    all_lines = {}
    for ln in fh:
        key = ln.split(delim)[byfieldno - 1]
        # Python is not Perl, so we can't append to the dict value directly...
        # first, we need to tell it it's a list...
        # ...but first, test it hasn't been already initialized :D
        if key not in all_lines.keys():
            all_lines[key] = []

        all_lines[key].append(ln)

    fh.close()

    return all_lines


def duplicates_in(thefile, fieldno, delim=':'):
    '''
        Looks in the tabular file 'thefile' to find duplicate lines (i.e lines
        which have the same value for the field indicated by 'fieldno'). Fields
        are separated by 'delim'.
        It returns a dictionary of the form of:
        {
         'onedupvalue_for_fieldno'  : ['line_x', 'line_y' ],
         'otherdupval_for_fieldno'  : ['line_m', 'line_n']
        }
    '''

    file_content = loadfile2dict(thefile, fieldno, delim)
    # now, get only those dict entries which have as value a list longer than 2

    # return dict((key, listval) for (key, listval) in file_content.iteritems()
    #            if len(listval) > 1)

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict((key, listval) for (key, listval) in file_content.items()
                if len(listval) > 1)

def write_multi_lines_infile(target, lines=[], mode='append'):
    '''
        Takes a list of lines (specified by "lines") and writes them to the
        file designated by "target" one by one, as dictated by "mode"
            - append: adds the lines at the end of the file
    '''
    if mode == 'append':
        orig_fh = open(target, "a")
        for line in lines:
            orig_fh.writelines(line+"\n")
        orig_fh.close()
        return 1

def writelines_infile(target, lines=[], mode='append'):
    '''
        Takes a list of lines (specified by "lines") and writes them to the
        file designated by "target", as dictated by "mode"
            - append: adds the lines at the end of the file
            - rewrite: replaces the old content by the new one
    '''

    if mode == 'append':
        orig_fh = open(target, "a")
        orig_fh.writelines(lines)
        orig_fh.close()
        return 1

    if mode == 'rewrite':
        tempname = "/tmp/hardening_" + str(os.getpid())
        tempobj = open(tempname, "w")
        tempobj.writelines(lines)
        tempobj.close()

        # backup the original file
        # shutil.copyfile(target, target + '_bkp')
        if os.path.isfile(target):
            shutil.copyfile(target,
                            os.path.join(BKP_DIR,
                                         os.path.basename(target) + TSTAMP))
        # ovewrwrite the original file with the new content
        # shutil.move(tempname, target)
        if os.path.isfile(target):
            os.remove(target)
        shutil.copyfile(tempname, target)

        return 1

def search_line_and_add_newline_before(target, directives, newline, commentchr, uniq_occur=None, case='sensitive', replace_full_line=True):
        
    fh = open(target, "r")
    new_content = []
    refernce_auth_line = ""
    for line in fh:
        if directives[0] in line and directives[1] in line:
            refernce_auth_line = line
            break  
    fh.close()
    return search_file_replace_line(target, regex=refernce_auth_line, newline=newline+"\n"+refernce_auth_line,commentchr="#",uniq_occur=None, case='sensitive', replace_full_line=True)


def search_file_replace_line(target, regex, newline, commentchr,
                             uniq_occur=None, case='sensitive',
                             replace_full_line=True):

    if replace_full_line:
        regex = r'^.*' + regex + r'.*$'
        # regex = r'^(.*)' + regex + r'(.*)$'

    # python 2.6 way to deal with case sensitivity in re.sub ...
    if case == 'insensitive':
        regex = re.compile(regex, re.I)

    fh = open(target, "r")
    new_content = []
    for line in fh:
        # if the file supports comments and the crt line is commented,
        # save the line unchanged to the data structure
        if commentchr and line.strip().startswith(commentchr):
            new_content.append(line)
            continue

        new_val = re.sub(regex, newline, line)

        new_content.append(new_val)

    fh.close()

    if uniq_occur:
        new_content = uniq(rgx=regex, lines=new_content, commentchr=commentchr)

    return writelines_infile(target=target, lines=new_content, mode='rewrite')


def comment_lines_infile(target, regex, commentchr, case='sensitive'):

    regex = r'^(.*' + regex + r'.*)$'

    # python 2.6 way to deal with case sensitivity in re.sub ...
    if case == 'insensitive':
        regex = re.compile(regex, re.I)

    fh = open(target, "r")
    new_content = []
    for line in fh:
        # if the file supports comments and the crt line is commented,
        # save the line unchanged to the data structure
        if commentchr and line.strip().startswith(commentchr):
            new_content.append(line)
            continue

        new_val = re.sub(regex, commentchr + r' \1', line)
        new_content.append(new_val)

    fh.close()

    writelines_infile(target=target, lines=new_content, mode='rewrite')


def search_file_replace_field(target, fieldno, agreedvalue, except_regex=None,
                              delim=':', commentchr=None, case='sensitive'):

    if except_regex and case == 'insensitive':
        except_regex = re.compile(except_regex, re.I)

    fh = open(target, "r")
    new_content = []
    for line in fh:
        # skip the excepted lines
        if except_regex and re.search(except_regex, line):
            new_content.append(line)
            continue
        # if the file supports comments and the crt line is commented,
        # save the line unchanged to the data structure
        if commentchr and line.strip().startswith(commentchr):
            new_content.append(line)
            continue

        fields = line.split(delim)
        # if we are replacing the last element, add the newline !!!
        if len(fields) == int(fieldno):
            agreedvalue += '\n'
        fields[int(fieldno) - 1] = agreedvalue
        new_val = delim.join(fields)
        new_content.append(new_val)

    fh.close()

    writelines_infile(target=target, lines=new_content, mode='rewrite')


def uniq(rgx, lines=[], commentchr=None):
    '''
        Looks in <thefile> for all the lines containing <rgx>
        and keeps only the first of them
    '''

    new_content = []
    already_found = 0

    for ln in lines:
        if commentchr and ln.strip().startswith(commentchr):
            new_content.append(ln)
            continue
        if not re.search(rgx, ln):
            new_content.append(ln)
            continue

        # else...crt line matches regex
        if not already_found:
            new_content.append(ln)
            # print already_found, ln, new_content
            already_found = 1

    return new_content


def lookline_in_file(afile="", thevalues="", commentchr='#', case="sensitive",
                     by_regex=None, delim=None):
    '''
        Looks in the specified file for a line with the fields specified by
        the supplied values list
        Returns the found lines
    '''

    with open(afile) as f:
        lines = f.readlines()

    validlines = [ln for ln in lines if not ln.strip().startswith(commentchr)]

    if not thevalues and not by_regex:
        return validlines

    if case == 'sensitive':
        if not by_regex:
            foundlines = [ln for ln in validlines if
                          not set(thevalues.split(delim)).difference(
                              set(ln.split(delim)))]
        else:
            foundlines = [ln for ln in validlines if re.search(by_regex, ln)]
    else:
        if not by_regex:
            foundlines = [ln for ln in validlines
                          if not set(thevalues.upper().split(delim)).
                          difference(set(ln.upper().split(delim)))]
        else:
            foundlines = [ln for ln in validlines if re.search(by_regex, ln,
                                                               re.I)]
    f.close()
    return foundlines


def checkfield_in_file(afile, fieldno, refval=None, delim=':',
                       except_regex=None, case='sensitive', valregex=None):
    '''
        Checks to see if all the lines in 'afile' have the field specified
        by 'fieldno' equal to the 'refval'
    '''

    if except_regex and case == 'insensitive':
        except_regex = re.compile(except_regex, re.I)

    violations = {}

    with open(afile) as f:
        for num, line in enumerate(f, 1):
            # do nothing for the excepted lines
            if except_regex and re.search(except_regex, line):
                continue
            vals = line.strip().split(delim)

            # test for out of range
            if len(vals) < int(fieldno):  # index out of range
                crtval = ''
            else:
                crtval = vals[int(fieldno) - 1]

            # if vals and vals[int(fieldno)-1] != str(refval):
            if not valregex:  # test for equality
                if refval != crtval:
                    violations["line " + str(num)] = line
            else:  # test by regex, ignore refval
                if not re.match(valregex, crtval):
                    violations["line " + str(num)] = line

    f.close()
    return violations


def getfields_from_file(afile, retfieldnos, keyfieldno, keyval=None,
                        delim=':', except_regex=None, case='sensitive'):
    '''
        Given the field number 'keyfieldno' and its reference value 'keyval',
        returns the value of the fields specified by 'retfieldnos'. Since there
        can be several matching lines, the return value is an array of values
    '''

    if except_regex and case == 'insensitive':
        except_regex = re.compile(except_regex, re.I)

    ret = []
    with open(afile) as f:
        for line in f:
            # do nothing for the excepted lines
            if except_regex and re.search(except_regex, line):
                continue

            fields = line.strip().split(delim)
            if fields and fields[int(keyfieldno) - 1] != keyval:
                continue

            # for fld in retfieldnos:
            #     fields[int(fld)-1]

            ret.append(tuple(fields[idx - 1] for idx in retfieldnos))

    f.close()
    return ret


def search_multiple_strings_in_file(filename, search_strings = None, search_mode="includes", comment_char=None,
                                    case="sensitive"):
    '''
        Search for multiple lines in file and returns a dictionary with details - if file is missing, missing lines
        which are required and lines which are not allowed but present
    '''

    matched_lines = set()

    result = {
        "file_missing": False,
        "missing_required_lines": [],
        "disallowed_lines": []
    }

    if not os.path.exists(filename):
        result["file_missing"] = True
        result["missing_required_lines"] = search_strings
        return result

    if case == "insensitive":
        search_strings = set([search_string.lower() for search_string in search_strings])
    else:
        search_strings = set(search_strings)

    with open(filename, "r") as fh:
        for line in fh:
            line = line.strip()
            if comment_char and line.startswith(comment_char):
                continue
            else:
                if case == "insensitive":
                    line = line.lower()

                if line in search_strings:
                    if line not in matched_lines:
                        matched_lines.add(line)
                else:
                    if search_mode == "only":
                        result["disallowed_lines"].append(line)

                if search_strings == matched_lines:
                    if search_mode == "includes":
                        break

        if search_strings != matched_lines:
            result["missing_required_lines"] = search_strings.difference(matched_lines)

    return result


def oct2bits(perms, len=MAX_LEN):
    '''
        - gets an octal string - "perms" (eg: '0755')
        - converts it to binary
        - chops the '0b' from the head of the string and fills with zero's
        up to "len" positions
    '''

    return bin(int(perms, 8))[2:].zfill(len)


def enforce_perm(refperm, crtperm, mode='max', category='all'):
    '''
            mode :      { exact, max }
            category:   { all, owner, group, others }
        Receives 2 strings (refperm & crtperm), a mode and a category:
        Category:
        - all : all permission bits are being checked
        - other: only the last 3
        - group: the ones for the group
        - owner: the bits for the owner
        Mode:
        - max - permissions lower than refperm are accepted
        - exact - refperm and crtperm should match

        For the bits in the range dictated by "category", the function
        returns the minimum of the two args
        Outside the range, it preserves the bits of crtperm
        Example:
            refperm: '1722' -> '1 111 010 010'
            crtperm: '1455' -> '1 100 101 101'
            category: group, mode: max

            returns: '1405' <- '1 100 000 101' in OCTAL representation
    '''
    # refperm: '0700'
    # crtperm: '0755'
    mask = BITRANGE[category]
    refpermbits = oct2bits(refperm)
    crtpermbits = oct2bits(crtperm)
    # print "refpermbits: ", refpermbits
    # print "crtpermbits: ", crtpermbits
    # print "mask:", mask
    minrange = mask[0]
    maxrange = mask[-1]
    goodbits = ''

    for idx in range(0, MAX_LEN):
        if minrange <= idx <= maxrange:
            # inside the range, get the minimum of the 2 bit strings
            if mode == 'max':
                goodbits += min(refpermbits[idx], crtpermbits[idx])
            else:  # mode == 'exact'
                goodbits += refpermbits[idx]
        else:
            # idx < minrange or maxrange < idx:
            # outside the range of interest, keep crtperm bits
            goodbits += crtpermbits[idx]

    return oct(int(goodbits, 2))  # '0700'


def perm_violation(obj, refperms, mode='exact', category='all'):
    '''
        mode : { exact, max }
    '''
    # we assume the file exists, to simplify the return value
    # rng=range(0, MAX_LEN)
    minindex = BITRANGE[category][0]
    maxindex = BITRANGE[category][-1]
    rng = range(minindex, maxindex)

    crtperms = oct(stat.S_IMODE(os.stat(obj).st_mode))  # '0733'
    crtperms_bits = oct2bits(crtperms)
    refperms_bits = oct2bits(refperms)

    if mode == "exact":
        if category == 'all':
            if crtperms == refperms:
                return 0
            return crtperms
        else:
            for idx in rng:
                if crtperms_bits[idx] != refperms_bits[idx]:
                    return crtperms

    # print crtperms_bits
    # print refperms_bits
    # print rng
    for idx in rng:
        if crtperms_bits[idx] > refperms_bits[idx]:  # FAIL !!!
            return crtperms
    return 0


def create_osr(osr, res_type='dir', perms=None, ownerid=None,
               ownername=None, category='all'):

    if os.path.exists(osr):
        log_enforce(descr='\n' +
                    " *** WARNING *** OSR %s already existing. Skipping..."
                    % osr)
        return

    if ownerid is None:
        if ownername:
            ownerid = name2uid(ownername)
        else:
            ownerid = 0

    if res_type == 'dir':
        os.mkdir(osr)
        if perms:
            os.chmod(osr, int(perms, 8))
        # print '=================== chown =================='
        os.chown(osr, ownerid, -1)
    elif res_type == 'file':
        open(osr, 'a').close()
        if perms:
            os.chmod(osr, int(perms, 8))


# def pam_tally2_used():
#
#     '''
#         Looks in all the /etc/pam.d files to determine
#            if pam_tally2.so is used
#     '''
#     pamdir = '/etc/pam.d'
#     pamfiles = [os.path.join(pamdir, f) for f in os.listdir(pamdir)]
#
#     for pamfl in pamfiles:
#         if lookline_in_file(afile=pamfl, thevalues="pam_tally2.so"):
#             return 1

def pam_tally2_used():
    '''
        Looks in LIBPATH for pam_tally2.so
    '''

    tally2file = 'pam_tally2.so'
    for dr in LIBPATH:

        if not os.path.isdir(dr):
            continue

        for root, dirs, files in os.walk(dr, followlinks=True):
            if tally2file in files:
                return os.path.join(root, tally2file)


def is_exe(prog):

    return os.path.isfile(prog) and os.access(prog, os.EX_OK)


# def which_py(prog, check_exe=True):
#
#     filepath, fname = os.path.split(prog)
#     if filepath:
#         if is_exe(prog):
#             return prog
#     else:
#         for path in os.environ["PATH"].split(os.pathsep):
#             path = path.strip('"')
#             fullpath = os.path.join(path, prog)
#             if is_exe(fullpath):
#                 return fullpath
#
#     return None


def which_py(prog, check_exe=True):

    filepath, fname = os.path.split(prog)
    if filepath:
        if check_exe:
            if is_exe(prog):
                return prog
        else:
            if os.path.isfile(prog):
                return prog
    else:
        for path in os.environ["PATH"].split(os.pathsep):
            path = path.strip('"')
            fullpath = os.path.join(path, prog)
            if check_exe:
                if is_exe(fullpath):
                    return fullpath
            else:
                if os.path.isfile(fullpath):
                    return fullpath

    return None


def get_exec_entries(thefile, delim=':|\s', commentchr='#', filter_regex='.*',
                     case='sensitive'):

    if filter_regex and case == 'insensitive':
        filter_regex = re.compile(filter_regex, re.I)

    ret = set([])
    if not os.path.isfile(thefile):
        return ret

    fh = open(thefile)

    all_execs = []
    for ln in fh:
        if ln.startswith(commentchr) or not re.match(filter_regex, ln):
            continue
        # words = ln.split(delim)
        words = re.split(delim, ln)
        # all_execs.update(set(wrd for wrd in words if which_py(wrd)))
        all_execs.extend(which_py(wrd) for wrd in words if which_py(wrd))

    fh.close()

    for entry in all_execs:
        if os.path.islink(entry):
            # ret.add(os.path.abspath(os.readlink(entry)))
            # ret.add(os.readlink(entry))
            ret.add(os.path.join(os.path.dirname(entry), os.readlink(entry)))
        else:
            # ret.add(os.path.abspath(entry))
            ret.add(entry)

    return ret


def get_dir_exec_entries(dr, recurse=False):

    ret = set([])
    if not os.path.isdir(dr):
        return ret

    if not recurse:
        for fl in os.listdir(dr):
            fullpath = os.path.join(dr, fl)
            ret.update(get_exec_entries(fullpath))

        return ret


# def list_files_in(dr, boolfunc, osr, cond):
def list_files_in(drs, cond='os.access(%, os.EX_OK)'):
    '''
        Returns all the files in the directory list <drs>, which conform to the
        condition specified by <cond>
        <cond> should be specified  using the '%' special character in lieu
        of the file name
    '''

    ret = set([])
    inodes = []

    for dr in drs:
        if not os.path.isdir(dr):
            continue

        for root, dirs, files in os.walk(dr):
            for fl in files:
                fullpath = os.path.join(root, fl)
                if os.path.islink(fullpath):  # read the link
                    fullpath = os.path.join(os.path.dirname(fullpath),
                                            os.readlink(fullpath))

                # code to avoid duplicate files, introduced by symlinks
                if os.stat(fullpath).st_ino in inodes:
                    continue
                else:
                    inodes.append(os.stat(fullpath).st_ino)

                cond = cond.replace('%', 'fullpath')
                # if eval(cond % fullpath):
                if eval(cond):
                    ret.add(fullpath)

    return ret


def grpmembers(grpname):

    if not grpname or grpname not in [struct.gr_name
                                      for struct in grp.getgrall()]:
        return set([])
    else:
        usersfrompwd = [s.pw_name for s in pwd.getpwall()
                        if s.pw_gid == grp.getgrnam(grpname).gr_gid]
        usersfromgrp = grp.getgrnam(grpname).gr_mem
        return set(usersfrompwd + usersfromgrp)


def is_valid(usr):
    '''
        - checks if the supplied user has a valid password and shell
    '''

    pwd_file = '/etc/passwd'
    shd_file = '/etc/shadow'
    valid_shells = ('sh', 'bash', 'ksh', 'zsh', 'dash', 'heirloomsh', 'mksh',
                    'csh', 'fish', 'yash', 'tcsh', 'posh', 'pdksh', 'lush')

    # print "\nvalid_shells: ", valid_shells
    pwd = getfields_from_file(shd_file, retfieldnos=[2], keyfieldno=1,
                              keyval=usr, delim=':', except_regex=None,
                              case='sensitive')
    shll = getfields_from_file(pwd_file, retfieldnos=[7], keyfieldno=1,
                               keyval=usr, delim=':', except_regex=None,
                               case='sensitive')

    if not pwd or not shll:  # user not found
        return False

    pwd = pwd[0][0]    # [('!!',)]  -> '!!'
    shll = shll[0][0]  # [('/bin/bash',)]  -> '/bin/bash'

    # print "\nusr, pwd, shll: ", usr, pwd, shll

    if pwd in ('*', '!', '!!', ''):  # pwd not set
        return False

    shell_OK = bool(is_exe(shll) and
                    os.path.basename(shll) in valid_shells)
    if not shell_OK:
        # user not found or invalid shell
        return False

    return True


def insertlines_infile_after_line(target, lines, searchline):
    '''
        Takes a list of lines (specified by "lines") and writes them to the
        file designated by "target", next line after "searchline" is found

    '''
    if os.path.isfile(target):
        with open(target, 'r+') as fd:
            contents = fd.readlines()

            for index, line in enumerate(contents):
                if searchline in line and lines not in contents[index + 1]:
                    contents.insert(index + 1, lines)
                    break
            fd.seek(0)

            fd.writelines(contents)

            fd.close()

        return 1


def list_files_in_dir_with_extension(drs, extension=''):
    '''
        Returns all the files in the directory list <drs>, which conform to the
        extension specified by <extension>
    '''

    ret = set([])

    for file in os.listdir(drs):
        if file.endswith(extension):
            fl = (os.path.join(drs, file))
            ret.add(fl)

    return ret


def execute_command(cmd,  shell=False):
    '''
        Returns all the command execution stdout, stderr and return code
        for input command passed
    '''
    ret = {}

    args = shlex.split(cmd)
    out = subprocess.Popen(args, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, shell=shell)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode

    if cmd_ret == 0:
        cmd_err = None

    ret = ({'cmd_out': cmd_out, 'cmd_err': cmd_err, 'cmd_ret': cmd_ret})

    return ret


def check_date_field_in_file(afile, fieldno, refval=None, delim=':',
                       except_regex=None, case='sensitive'):

    '''
        Checks to see if all the lines in 'afile' have the field specified
        by 'fieldno' lesser than 'refval'
    '''

    if except_regex and case == 'insensitive':
        except_regex = re.compile(except_regex, re.I)

    violations = {}

    with open(afile) as f:
        for num, line in enumerate(f, 1):
            # do nothing for the excepted lines
            if except_regex and re.search(except_regex, line):
                continue
            vals = line.strip().split(delim)

            # test for out of range
            if len(vals) < int(fieldno):  # index out of range
                crtval = ''
            else:
                crtval = vals[int(fieldno)-1]

            if crtval == '':
                violations["line " + str(num)] = line
            elif int(crtval) > int(refval) :
                violations["line " + str(num)] = line

    f.close()
    return violations


def check_null_field_in_file(afile, fieldno, delim=':',
                       except_regex=None, case='sensitive'):

    '''
        Checks to see if all the lines in 'afile' have the field specified
        by 'fieldno' as not null
    '''

    if except_regex and case == 'insensitive':
        except_regex = re.compile(except_regex, re.I)

    violations = {}

    with open(afile) as f:
        for num, line in enumerate(f, 1):
            # do nothing for the excepted lines
            if except_regex and re.search(except_regex, line):
                continue
            vals = line.strip().split(delim)

            # test for out of range
            if len(vals) < int(fieldno):  # index out of range
                crtval = ''
            else:
                crtval = vals[int(fieldno)-1]

            if crtval == '':
                violations["line " + str(num)] = line

    f.close()
    return violations

def get_list_of_field_value(afile, fieldno, delim=':'):
    '''
        Returns a list of values from a particular field no
    '''
    field_values = []

    with open(afile) as f:
        for num, line in enumerate(f, 1):
            vals = line.strip().split(delim)

            # test for out of range
            if len(vals) < int(fieldno):  # index out of range
                crtval = ''
            else:
                crtval = vals[int(fieldno) - 1]
            # log_audit(str(crtval), "CurrentVal")
            field_values.append(crtval)

    f.close()
    unique_field_values = set(field_values)

    return unique_field_values


def generic_check_if_service_enabled(service_name):
    '''
        Check status of services and return results based on the same

        :param service_name: str: Name of the service to check
        :return: boolean: Indicating whether service is enabled
    '''

    status_results = []
    command = "systemctl is-enabled {}".format(service_name)

    result = execute_command(command)

    if result['cmd_ret'] == 0:
        return True

    return False


def generic_check_if_package_installed(package_name):
    '''
        Check if package is installed

        :param package_name: str: Name of the package to check
        :return: boolean: Indicating if package is installed
    '''

    command = "rpm -q {}".format(package_name)

    result = execute_command(command)

    if result['cmd_ret'] == 0:
        return True
    else:
        return False


def list_osr(osr_dir, exception_dir, osr_list=None):
    '''
       recursively descend the directory tree rooted at osr_dir,
       skipping exception dir
       calling the callback function for non block, pipe or socket
     '''

    if osr_list == None:
        osr_list = []

    for f in os.listdir(osr_dir):
        pathname = os.path.join(osr_dir, f)
        if exception_dir not in pathname:  # skip /usr/local dir
            # here files with missing links are filtered, they are not handled
            if os.path.exists(pathname):
                mode = os.stat(pathname)[ST_MODE]
                if S_ISDIR(mode):
                    # It's a directory, recurse into it
                    #print(pathname)
                    if check_not_filesystem(osr_dir, pathname):
                        osr_list.append(pathname)
                        list_osr(pathname, exception_dir, osr_list)
                    else:
                        continue
                if S_ISREG(mode):
                    # It's a regular file, append the path to list
                    osr_list.append(pathname)
                else:
                    # file type of block ,char device , pipe or socket and symlinks need to skip
                    continue
    return osr_list



def check_not_filesystem(osr_dir, pathname):
    '''
      Check if given osr_dir is filesystem (hard links or 'bounded mounts' to /proc)
    '''
    not_fs = True
    #print("check dir " + pathname)
    list_fs =  subprocess.getoutput("cat /proc/mounts | awk '{print $2}' | grep " + osr_dir )
    if list_fs:
        for line in list_fs.splitlines():
            if pathname == line:
                #print("skipped path " + pathname)
                not_fs = False
                break

    return not_fs


# A.D.5.0.2, AD.5.0.3
def check_previledged_uid(uid):
    '''
     -  A userid with a UID which is less than or equal to SYS_UID_MAX is
        considered privileged.
        If SYS_UID_MAX is not set, then a userid with a UID which is
        less than UID_MIN.
        Note: It is not valid for an OSR to be owned by a UID which
        does not have a userid defined to it with in /etc/passwd.
    '''

    login_defs_file = "/etc/login.defs"
    priviledged = False
    # check gid which does not have a group defined to it with in /etc/group
    try:
        user_name = pwd.getpwuid(uid).pw_name
        gid = pwd.getpwuid(uid).pw_gid
    except KeyError:
        return priviledged
    # get the SYS_UID_MAX, if not set get UID_MIN
    search_key = "SYS_UID_MAX"
    result = lookline_in_file(afile=login_defs_file, thevalues=search_key,
                              commentchr='#', case="sensitive")
    if result:
        for line in result:
            sys_uid_max = line.split()[1]
            if uid <= int(sys_uid_max):
                priviledged = True
    else:
        search_key = "UID_MIN"
        result = lookline_in_file(afile=login_defs_file, thevalues=search_key,
                                  commentchr='#', case="sensitive")
        if result:
            for line in result:
                uid_min = line.split()[1]
                if uid > int(uid_min):
                    priviledged = True
    if check_previledged_gid(gid):
        return priviledged
    else:
        return False


# A.D.5.0.4
def check_previledged_gid(gid):
    '''
      -  A userid with a UID which is less than or equal to SYS_UID_MAX is
         considered privileged.
         If SYS_UID_MAX is not set, then a userid with a UID which is
         less than UID_MIN.
         Note: It is not valid for an OSR to be owned by a UID which
         does not have a userid defined to it with in /etc/passwd.
    '''

    login_defs_file = "/etc/login.defs"
    priviledged = False

    # The group 'users' will have a GID of 100, and is not a group permitted to own an OSR.
    if gid == 100:
        return priviledged
    # check gid which does not have a group defined to it with in /etc/group
    try:
        group_name = grp.getgrgid(gid).gr_name
    except KeyError:
        return priviledged
    # get the SYS_GID_MAX, if not set get GID_MIN
    search_key = "SYS_GID_MAX"
    result = lookline_in_file(afile=login_defs_file, thevalues=search_key,
                              commentchr='#', case="sensitive")
    if result:
        for line in result:
            sys_gid_max = line.split()[1]
            if gid <= int(sys_gid_max):
                priviledged = True
    else:
        search_key = "GID_MIN"
        result = lookline_in_file(afile=login_defs_file, thevalues=search_key,
                                  commentchr='#', case="sensitive")
        if result:
            for line in result:
                gid_min = line.split()[1]
                if gid > int(gid_min):
                    priviledged = True
    return priviledged

def check_field_in_file(afile, fieldno, delim=':'):

    '''
        Checks to see if all the lines in 'afile' have the field specified
        by 'fieldno' as null
    '''

    violations = {}

    with open(afile) as f:
        for num, line in enumerate(f, 1):

            vals = line.strip().split(delim)

            # test for out of range
            if len(vals) < int(fieldno):  # index out of range
                crtval = ''
            else:
                crtval = vals[int(fieldno)-1]
            #log_audit(str(crtval), "CurrentVal")
            if crtval != '':
                violations["line " + str(num)] = line

    f.close()
    return violations


def default_group_check(gid):
    '''
      -   compare gid with /etc/default/useradd GROUP attribute
    '''
    ret = False
    osrname =  "/etc/default/useradd"
    search_key = "GROUP"


    result = lookline_in_file(afile=osrname, thevalues=search_key,
                              commentchr='#', case="sensitive",
                              by_regex=search_key)

    group_id = None

    if result:
        for line in result:
            group_id = line.split('=')[1]


    if gid == int(group_id):
        ret = True


    return ret


def get_position_of_line_in_file(osrname, search_key):
    '''
      -  finds the position of line in given osrname which contains search_key
    '''
    ret = 0
    result = lookline_in_file(afile=osrname, thevalues=search_key, commentchr='#', case="sensitive")
    if result:

        file_pos = 0
        with open(osrname, "r+") as f:
            for ln in f:
                file_pos += len(ln)

                if ln == result[0]:
                    ret = file_pos

    return ret


def deleteline_infile(target, line_to_del):
    '''
        deletes "line" from file designated by "target"
    '''
    if os.path.isfile(target):
        with open(target, 'r+') as fd:
            contents = fd.readlines()
            fd.seek(0)
            for line in contents:
                if line_to_del not in line:
                    fd.writelines(line)
            fd.truncate()

        return 1 
###############################################################################
#                           Log functions                                     #
###############################################################################


def format_nicely(name):

    indent = (MAX_CHECKNAME_LEN - len(name)) / 2
    allignr = indent + len(name)
    fmt = '%' + '%ds' % allignr

    return '[' + fmt % name + ' ' * int((MAX_CHECKNAME_LEN - allignr)) + '] '


def log_audit(descr='', result='', details={}):

    suppl_msg = '\n'
    if details:
        suppl_msg = "\n" + " " * (3 + MAX_CHECKNAME_LEN) +\
                    "Violations: " + str(details) + "\n"

    with open(LOG_AUDIT, "a+") as f:
        f.write("\n" + descr + " : " + result + suppl_msg)
    f.close()

    print("\n" + descr + " : " + result)


def log_enforce(descr='', ):

    with open(LOG_AUDIT, "a+") as f:
        f.write(descr)
    f.close()

    sys.stdout.write(descr)

    # if descr == 'DONE\n':
    #     sys.stdout.write('\n')
