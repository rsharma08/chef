if [ $UID -gt 199 ]; then
	umask 077
fi
TMOUT=1800
export TMOUT
