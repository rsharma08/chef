# frozen_string_literal: true

#! /usr/bin/env python

# Copyright:: Kyndryl 2022

import helper_funcs
import os
import sys
from helper_funcs import *
import inspect
import json
import subprocess
import glob
import time
import shlex
from os import path
import pwd
from stat import *

# IZ.1.1.8.2
def USERIDS_UID(osrname='/etc/passwd'):
    '''
        ----------------
            REQ_ID: 1
        ----------------

        UID:     Each UID must only be used once.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking for duplicate UID's in %s"\
        % (osrname)
    # print descr
    # sys.stdout.write(descr)

    violations = duplicates_in(thefile=osrname, fieldno=3, delim=':')

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.8.3.1


def USERIDS_GID(osrname='/etc/group'):
    '''
        ----------------
            REQ_ID: 2
        ----------------

        GID: Each GID must only be used once.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking for duplicate GID's in %s"\
        % (osrname)
    # print descr

    violations = duplicates_in(thefile=osrname, fieldno=3, delim=':')

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# NOT PRESENT


def AUTH_COMMAUTH(directive,
                  pamfiles=['/etc/pam.d/login', '/etc/pam.d/passwd',
                            '/etc/pam.d/sshd', '/etc/pam.d/su']):
    '''
        -----------------------
            REQ_ID:
                - 3_1 (RHEL)
                - 4_1 (SLES)
        -----------------------

        Directive:
            RHEL:   auth include system-auth
            SLES:   auth include common-auth
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Looking for directive '%s'" % (directive) + " in the pam files"

    violations = []
    ret = {}
    for fl in pamfiles:
        if not os.path.isfile(fl):
            violations.append('%s: file MISSING' % (fl))
            ret = {'FILE_NOT_FOUND': fl}
        else:
            # 1st and 3rd element
            search_key = ' '.join(directive.split()[0:3:2])
            result = lookline_in_file(
                afile=fl,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                if 'MISSING_DIRECTIVES' not in ret.keys():
                    ret['MISSING_DIRECTIVES'] = []

                violations.append("Directive MISSING in file: %s" % (fl))
                ret['MISSING_DIRECTIVES'].append(fl)
            else:  # found the directive
                if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                    ret['BAD_PARAM_DIRECTIVES'] = []
                violations.append("BAD_PARAM_DIRECTIVES in file: %s" % (fl))
                ret['BAD_PARAM_DIRECTIVES'].append(fl)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret

# NOT PRESENT


def AUTH_COMMACC(directive,
                 pamfiles=['/etc/pam.d/login', '/etc/pam.d/passwd',
                           '/etc/pam.d/sshd', '/etc/pam.d/su']):
    '''
        -----------------------
            REQ_ID:
                - 3_2 (RHEL)
                - 4_2 (SLES)
        -----------------------

        Directive:
            RHEL:   account include system-auth
            SLES:   account include common-account
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Looking for directive '%s'" % (directive) + " in the pam files"

    violations = []
    ret = {}
    for fl in pamfiles:
        if not os.path.isfile(fl):
            violations.append('%s: file MISSING' % (fl))
            ret = {'FILE_NOT_FOUND': fl}
        else:
            # 1st and 3rd element
            search_key = ' '.join(directive.split()[0:3:2])
            result = lookline_in_file(
                afile=fl,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                if 'MISSING_DIRECTIVES' not in ret.keys():
                    ret['MISSING_DIRECTIVES'] = []

                violations.append("Directive MISSING in file: %s" % (fl))
                ret['MISSING_DIRECTIVES'].append(fl)
            else:  # found the directive
                if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                    ret['BAD_PARAM_DIRECTIVES'] = []
                violations.append("BAD_PARAM_DIRECTIVES in file: %s" % (fl))
                ret['BAD_PARAM_DIRECTIVES'].append(fl)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret

# NOT PRESENT


def AUTH_COMMPASS(directive,
                  pamfiles=['/etc/pam.d/login', '/etc/pam.d/passwd',
                            '/etc/pam.d/sshd', '/etc/pam.d/su']):
    '''
        -----------------------
            REQ_ID:
                - 3_3 (RHEL)
                - 4_3 (SLES)
        -----------------------

        Directive:
            RHEL:   password include system-auth
            SLES:   password include common-password

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Looking for directive '%s'" % (directive) + " in the pam files"

    violations = []
    ret = {}
    for fl in pamfiles:
        if not os.path.isfile(fl):
            violations.append('%s: file MISSING' % (fl))
            ret = {'FILE_NOT_FOUND': fl}
        else:
            # 1st and 3rd element
            search_key = ' '.join(directive.split()[0:3:2])
            result = lookline_in_file(
                afile=fl,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                if 'MISSING_DIRECTIVES' not in ret.keys():
                    ret['MISSING_DIRECTIVES'] = []

                violations.append("Directive MISSING in file: %s" % (fl))
                ret['MISSING_DIRECTIVES'].append(fl)
            else:  # found the directive
                if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                    ret['BAD_PARAM_DIRECTIVES'] = []
                violations.append("BAD_PARAM_DIRECTIVES in file: %s" % (fl))
                ret['BAD_PARAM_DIRECTIVES'].append(fl)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret

# IZ.1.1.1.1


def AUTH_MAXDAYS(osrname='/etc/login.defs',
                 directive="PASS_MAX_DAYS",
                 agreedvalue="60",
                 expirepassword="true"):
    '''
        ----------------
            REQ_ID: 5
        ----------------

        /etc/login.defs - must include this line: PASS_MAX_DAYS 60
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in %s" \
        % (directive + ' ' + agreedvalue, osrname)

    violations = []

    result = lookline_in_file(afile=osrname, thevalues=directive)
    if not result:
        result = violations = ["Directive MISSING"]
    else:  # found the directive
        if len(result) > 1:
            violations = ["Directive found multiple times"]
        else:
            crtval = result[0].split()[1]
            if crtval != agreedvalue:
                violations = ["%s set to %s" % (directive, crtval)]
            else:  # all OK, return boolean "false"
                result = []

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return result

# IZ.1.1.3.1


def AUTH_MINDAYS(osrname='/etc/login.defs',
                 directive="PASS_MIN_DAYS",
                 agreedvalue="15"):
    '''
        ----------------
            REQ_ID: 8
        ----------------

        /etc/login.defs - must include this line: PASS_MIN_DAYS 15
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in %s" \
        % (directive + ' ' + agreedvalue, osrname)

    violations = []

    result = lookline_in_file(afile=osrname, thevalues=directive)
    if not result:
        violations = ["Directive MISSING"]
    else:  # found the directive
        if len(result) > 1:
            violations = ["Directive found multiple times"]
        else:
            crtval = result[0].split()[1]
            if crtval != agreedvalue:
                violations = ["%s set to %s" % (directive, crtval)]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.1.2


def AUTH_SHADOWF5(osrname='/etc/shadow',
                  fieldno=5,
                  agreedvalue="60",
                  except_regex=r'^[^:]+:(!!|!|\*|):'):
    '''
        ----------------
            REQ_ID: 6
        ----------------

        /etc/shadow
            - Field 5 must be "60"
            - This setting in is not required on userids without a password,
            nor is it required for locked accounts
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking field no %s in %s to be %s" \
        % (fieldno, osrname, agreedvalue)

    violations = checkfield_in_file(afile=osrname, fieldno=fieldno,
                                    refval=agreedvalue, delim=':',
                                    except_regex=except_regex)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.3.2


def AUTH_SHADOWF4(osrname='/etc/shadow',
                  fieldno=4,
                  agreedvalue="15",
                  except_regex=r'^[^:]+:(!!|!|\*|):'):
    '''
        ----------------
            REQ_ID: 9
        ----------------

        /etc/shadow
            - Field 4 must be "15" - for all userids with a password assigned
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking field no %s in %s to be %s" \
        % (fieldno, osrname, agreedvalue)

    violations = checkfield_in_file(afile=osrname, fieldno=fieldno,
                                    refval=agreedvalue, delim=':',
                                    except_regex=except_regex)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.2.0.1.0


def AUTH_BUN(files=['/etc/motd', '/etc/issue'],
             text=''):
    '''
        ----------------
            REQ_ID: 17
        ----------------

        /etc/motd
            - 	Exists and should contain notification text
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking the Business Use Notice in %s \
             " % (" or ".join(files))

    violations = []
    ret = {}

    for fl in files:
        if os.path.isfile(fl) and os.stat(fl).st_size:
            fh = open(fl)
            content = fh.read()
            fh.close()
            if content.strip().split() == text.strip().split():
                violations = []
            if content.strip().split() != text.strip().split():
                violations.append("File doesn't have notification text %s" % (fl))
                ret[fl] = []
                ret[fl].append({'problem': 'missing'})
                #break

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.9.1.2.1 and IZ.1.9.1.2
def AUTH_UMASK(osrnames=['/etc/login.defs', '/etc/bashrc'],
               directive="UMASK",
               agreedvalue="0777"):
    '''
        ----------------
            REQ_ID: 19
        ----------------

        /etc/login.defs:
            - Must include this line:   UMASK 077
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in: " \
            % (directive + ' ' + agreedvalue) + str(osrnames)

    violations = []
    ret = {}
    for osrname in osrnames:
        if not os.path.isfile(osrname):  # file missing, no problem. Move on
            continue
        result = lookline_in_file(afile=osrname, thevalues='umask', commentchr='#', case="", by_regex=None, delim=None)
        ret[osrname] = []
        if not result:
            violations.append(osrname)
            ret[osrname] = "Directive MISSING"

        else:  # found the directive
            if len(result) > 1:
                violations.append(osrname)
                ret[osrname] = "Directive found multiple times"
            else:
                crtval = result[0].split()[1]
                if crtval != agreedvalue:
                    violations.append("%s set to %s in file %s" % (directive, crtval, osrname))
                    ret[osrname] = "Update UMASK value"

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return dict(entry for entry in ret.items() if len(entry[1]))

def AUTH_HOMES(agreedperms='0700', mode='exact', category='all', mustexist=False):
    '''
        ----------------
            REQ_ID: 18
        ----------------

        $HOME: permissions of 700 at creation time
    '''
    # agreedperms='0700'
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "$HOME directories should have permissions %s" % (agreedperms)

    violations = []
    ret = {}

    # ------------ get UID_MIN
    uid_min_line_arr = lookline_in_file(afile='/etc/login.defs',
                                        thevalues="UID_MIN",
                                        commentchr='#')
    if not uid_min_line_arr:
        uid_min = 1000
    else:
        uid_min = int(uid_min_line_arr[0].split()[1])

    # --------------get UID_MAX
    uid_max_line_arr = lookline_in_file(afile='/etc/login.defs',
                                        thevalues="UID_MAX",
                                        commentchr='#')
    if not uid_max_line_arr:
        uid_max = 60000
    else:
        uid_max = int(uid_max_line_arr[0].split()[1])

    user_homes = set([(entr.pw_uid, entr.pw_dir) for entr in pwd.getpwall()
                      if uid_min < entr.pw_uid < uid_max])

    for (agreeduid, dr) in user_homes:   # dr -> fl
        if not os.path.isdir(dr):
            if mustexist:
                violations.append("FS object %s not found" % (dr))
                ret[dr] = []
                ret[dr].append({'problem': 'missing',
                                'rightful_ownerid': agreeduid})
            else:
                pass
        else:
            ret[dr] = []
            # check ownership first
            # if agreeduser:  # -> this part differs from the other functions
            # because we do not know the agreed user in advance
            agreeduser = pwd.getpwuid(agreeduid).pw_name
            owner_id = os.stat(dr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name

            if owner_id != agreeduid:
                ret[dr].append({'problem': 'ownership',
                                'rightful_owner': agreeduser,
                                'wrong_owner': owner_name})
                violations.append("Dir %s owned not by %s, but by %s"
                                  % (dr, agreeduser, owner_name))

            # now check permissions
            # else:
            permfailed = perm_violation(obj=dr, refperms=agreedperms,
                                        mode=mode)
            if permfailed:
                ret[dr].append({'problem': 'permissions',
                                'perms': permfailed})
                violations.append("Dir %s permissions: %s"
                                  % (dr, permfailed))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean

    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.2.1


def OSR_RHOSTS(osrname=os.path.join(os.path.expanduser("~root"), '.rhosts'),
               agreedperms='0600',
               mode='exact',
               category='all',
               mustexist=False,
               agreeduser='root'):
    '''
        ----------------
          REQ_ID: 29_1
        ----------------

        ~root/.rhosts : If exists, only read and write by root
    '''

    osr = os.path.expanduser(osrname)
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s:" % (osr) + \
        " if present, should only be read and write by %s" % (agreeduser)

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # check ownership first !!!
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("File owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("File permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.2.2 & IZ.C.6.2.13


def OSR_NETRC(osrname=os.path.join(os.path.expanduser("~root"), '.netrc'),
              agreedperms='0600',
              mode="exact",
              category="all",
              mustexist=False,
              agreeduser='root'):
    '''
        ----------------
          REQ_ID: 29_2
        ----------------

        ~root/.netrc : If exists, only read and write by root
    '''

    osr = os.path.expanduser(osrname)
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s:" % (osr) + \
        " if present, should only be read and write by %s" % (agreeduser)

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # check ownership first !!!
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("File owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("File permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

     # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.3.1


def OSR_FSROOT(osrname='/',
               agreedperms='0005',
               mode='max',
               category='others',
               mustexist=True,
               agreeduser='root'):
    '''
        ----------------
            REQ_ID: 30
        ----------------

        / : Setting for other r-x or more restrictive
    '''

    osr = osrname
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions for 'others' should be r-x or more restrictive"

    violations = []
    ret = {}

    if not os.path.isdir(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # check ownership first
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})

        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode="max", category=category)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.3.2.1


def OSR_USR(osrname='/usr',
            agreedperms='0005',
            mode='max',
            category='others',
            mustexist=True,
            agreeduser='root'):
    '''
        ----------------
            REQ_ID: 31
        ----------------

        /usr : Setting for other r-x or more restrictive
    '''

    osr = osrname
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions for 'others' should be r-x or more restrictive"

    violations = []
    ret = {}

    if not os.path.isdir(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})

        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode, category=category)
        #                             mode="max", rng=range(7, 10))
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.3.3


def OSR_ETC(osrname='/etc',
            agreedperms='0005',
            mode='max',
            category='others',
            mustexist=True,
            agreeduser='root'):
    '''
        ----------------
           REQ_ID: 32
        ----------------

        /etc : Setting for other r-x or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions for 'others' should be r-x or more restrictive"

    violations = []
    ret = {}

    if not os.path.isdir(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode, category=category)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.4.1


def OSR_ETCSECOPASSWD(osrname='/etc/security/opasswd',
                      agreedperms='0600',
                      mode='max',
                      category='all',
                      mustexist=True,
                      agreeduser='root'):
    '''
        ----------------
           REQ_ID: 33
        ----------------

        /etc/security/opasswd : Must exist.
        Setting  rw- --- --- or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions should be rw- --- ---  or more restrictive"

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.4.2.1


def OSR_ETCSHADOW(osrname='/etc/shadow',
                  agreedperms='0600',
                  mode='max',
                  category='all',
                  mustexist=True,
                  agreeduser='root'):
    '''
        ----------------
           REQ_ID: 34
        ----------------

        /etc/shadow : Must exist.
        Setting  rw- --- --- or more restrictive
    '''

    osr = osrname
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions should be rw- --- ---  or more restrictive"

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})
    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.5.1


def OSR_VAR(osrname='/var',
            agreedperms='0005',
            mode='max',
            category='others',
            mustexist=True,
            agreeduser='root'):
    '''
        ----------------
           REQ_ID: 35
        ----------------

        /var : Setting for other r-x or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions for 'others' should be r-x or more restrictive"

    violations = []
    ret = {}

    if not os.path.isdir(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode, category=category)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.11


def OSR_VARTMP(osrname='/var/tmp',
               agreedperms='01777',
               mode='exact',
               category='all',
               mustexist=True,
               agreeduser=False):
    '''
        ----------------
           REQ_ID: 36
        ----------------

        /var/tmp : Settings must be rwxrwxrwt(1777)
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions must be rwxrwxrwt (01777) "

    violations = []
    ret = {}

    if not os.path.isdir(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode, category=category)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

    #    # owner_id = os.stat(osr).st_uid
    #    # if owner_id != 0:
    #    #     violations = "FS object owned not by root, but by %s" \
    #    #                   % (pwd.getpwuid(owner_id).pw_name)
    #    # else:
    #         ret = perm_violation(obj=osr, refperms=agreedperms,
    #                              mode="exact")
    #         if ret:
    #             violations = "FS object permissions: %s" % (ret)
    #
    # if violations:
    #     log_audit(descr, "FAILED", details=violations)
    # else:
    #     log_audit(descr, "PASS")
    #
    # return ret

# IZ.1.8.5.2


def OSR_VARLOG(osrname='/var/log',
               agreedperms='0005',
               mode='max',
               category='others',
               mustexist=True,
               agreeduser='root'):
    '''
        ----------------
           REQ_ID: 37
        ----------------

        /var/log : Settings for other must be r-x or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions for 'others' should be r-x or more restrictive"

    violations = []
    ret = {}

    if not os.path.isdir(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode, category=category)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# AD.1.8.6.1


def OSR_FAILLOG(osrname='/var/log/faillog',
                agreedperms='0600',
                mode="exact",
                category="all",
                mustexist=True,
                agreeduser='root'):
    '''
        ----------------
          REQ_ID: 39_1
        ----------------

        /var/log/faillog :
          - must be set to rw- --- --- for all systems not using pam_tally2.so
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions must be set to rw- --- --- " + \
        "for all systems not using pam_tally2.so"

    if pam_tally2_used():  # check N/A
        log_audit(descr, "N/A")
        return

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.6.2


def OSR_TALLYLOG(osrname='/var/log/tallylog',
                 agreedperms='0600',
                 mode="exact",
                 category="all",
                 mustexist=True,
                 agreeduser='root'):
    '''
        ----------------
          REQ_ID: 39_2
        ----------------

        /var/log/tallylog :
          - must be set to rw- --- --- for all systems using pam_tally2.so
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions must be set to rw- --- --- " + \
        "for all systems using pam_tally2.so"

    if not pam_tally2_used():  # check N/A
        log_audit(descr, "N/A")
        return

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.7.1


def OSR_VARLOGMESSAGES(osrname='/var/log/messages',
                       agreedperms='0744',
                       mode='max',
                       category='all',
                       mustexist=True,
                       agreeduser='root'):
    '''
        ----------------
           REQ_ID: 40
        ----------------

        /var/log/messages : must be set rwx r-- r-- or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions should be rwx r-x r-x or more restrictive"

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        # This cod eis wrriten to add pemrission 744 to /var/log/mmessages file explicitly as requested. Becasue in template its 700 permssions.
        os.chmod(osrname, int("744", 8))

        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})
    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.7.2


def OSR_VARLOGWTMP(osrname='/var/log/wtmp',
                   agreedperms='0764',
                   mode='max',
                   category='all',
                   mustexist=True,
                   agreeduser='root'):
    '''
        ----------------
           REQ_ID: 42
        ----------------

        /var/log/wtmp : must be set rwx rw- r-- or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions should be rwx r-x r-x or more restrictive"

    violations = []
    ret = {}
    agreedgroup = "root"
    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        if agreedgroup:
            agreedgid = grp.getgrnam(agreedgroup).gr_gid
            group_id = os.stat(osr).st_gid
            group_name = grp.getgrgid(group_id).gr_name
            if group_id != agreedgid:
                violations.append("FS object owned not by group %s, but by %s"
                                  % (agreedgroup, group_name))
                ret[osr].append({'problem': 'groupownership',
                                 'rightful_group': agreedgroup,
                                 'wrong_group': group_name})

        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})
    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.8


def OSR_VARLOGSECURE(osrname='/var/log/secure',
                     agreedperms='0740',
                     mode='max',
                     category='all',
                     mustexist=True,
                     agreeduser='root'):
    '''
        ----------------
           REQ_ID: 43
        ----------------

        /var/log/secure : must be set rwx r-- --- or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions should be rwx r-x --- or more restrictive"

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.9


def OSR_TMP(osrname='/tmp',
            agreedperms='01777',
            mode='exact',
            category='all',
            mustexist=True,
            agreeduser=False):
    '''
        ----------------
           REQ_ID: 45
        ----------------

        /tmp : Settings must be rwxrwxrwt(1777)
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions must be rwxrwxrwt (01777) "

    violations = []
    ret = {}

    if not os.path.isdir(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode, category=category)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.10


def OSR_SNMPDCONF(osrname='/etc/snmp/snmpd.conf',
                  agreedperms='0540',
                  mode='max',
                  category='all',
                  mustexist=False,
                  agreeduser='root'):
    '''
        ----------------
          REQ_ID: 46_1
        ----------------

        /etc/snmp/snmpd.conf: if exists, r-x r-- --- or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "if exists, perms should be r-x r-- --- or more restrictive"

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        if mustexist:
            violations.append("FS object %s not found" % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            pass
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# NOT PRESENT


def OSR_INITTAB(osrname='/etc/inittab',
                agreedperms='0744',
                mode='max',
                category='all',
                mustexist=False,
                agreeduser='root'):
    '''
        ----------------
          REQ_ID: 47_1
        ----------------

        Files executed via entries in /etc/inittab
            - no write by general users (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in %s: " % (osrname) + \
        "should have no write by general users (744 or more restrictive)"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#'):
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object %s owned not by %s, but by %s"
                                  % (osr, agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object %s permissions: %s"
                              % (osr, permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.14.2


def OSR_CRONROOT(osrname='/var/spool/cron/root',
                         agreedperms='0745',
                         mode='max',
                         category='all',
                         mustexist=False,
                         agreeduser='root'):
    '''
        ----------------
          REQ_ID: 47_2
        ----------------

        Files executed via entries in /var/spool/cron/root
            - no write by general users (745 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in %s: " % (osrname) + \
        "should have no write by general users (745 or more restrictive)"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#'):
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object %s owned not by %s, but by %s"
                                  % (osr, agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object %s permissions: %s"
                              % (osr, permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# NOT PRESENT


def OSR_CRONTABSROOT(osrname='/var/spool/cron/tabs/root',
                     agreedperms='0744',
                     mode='max',
                     category='all',
                     mustexist=False,
                     agreeduser='root'):
    '''
        ----------------
          REQ_ID: 47_3
        ----------------

        Files executed via entries in /var/spool/cron/tabs/root
            - no write by general users (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in %s: " % (osrname) + \
        "should have no write by general users (744 or more restrictive)"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#'):
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object %s owned not by %s, but by %s"
                                  % (osr, agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object %s permissions: %s"
                              % (osr, permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.15.2
def OSR_ETCCRONTAB(osrname='/etc/crontab',
                   agreedperms='0744',
                   mode='max',
                   category='all',
                   mustexist=False,
                   agreeduser='root'):
    '''
        ----------------
          REQ_ID: 47_4
        ----------------

        Files executed via entries in /etc/crontab
            - no write by general users (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in %s: " % (osrname) + \
        "should have no write by general users (744 or more restrictive)"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#'):
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object %s owned not by %s, but by %s"
                                  % (osr, agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object %s permissions: %s"
                              % (osr, permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# AD.1.8.20.2
# IZ.1.8.20.3

def OSR_ETCCRONDALL(osrname='/etc/cron.d',
                    agreedperms='0744',
                    mode='max',
                    category='all',
                    mustexist=False,
                    agreeduser='root'):
    '''
        ----------------
          REQ_ID: 47_6
        ----------------

        Files executed via entries in files located in /etc/cron.d/*
            - no write by general users (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in %s: " % (osrname) + \
        "should have no write by general users (744 or more restrictive)"

    violations = []
    ret = {}

    if not os.path.isdir(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    allexecs = get_dir_exec_entries(osrname)

    # for osr in get_exec_entries(thefile=osrname,delim=':|\s',commentchr='#'):
    for osr in allexecs:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object %s owned not by %s, but by %s"
                                  % (osr, agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object %s permissions: %s"
                              % (osr, permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# NOT PRESENT


def OSR_ETCXINETDCONF(osrname='/etc/xinetd.conf',
                      agreedperms='0744',
                      mode='max',
                      category='all',
                      mustexist=False,
                      agreeduser='root'):
    '''
        ----------------
          REQ_ID: 47_5
        ----------------

        Files executed via entries in /etc/xinetd.conf
            - no write by general users (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in %s: " % (osrname) + \
        "should have no write by general users (744 or more restrictive)"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#',
                                filter_regex='.*\s*server\s*='):
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object %s owned not by %s, but by %s"
                                  % (osr, agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        # else: << removed >>
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode)
        if permfailed:
            violations.append("FS object %s permissions: %s"
                              % (osr, permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# NOT PRESENT


def OSR_INITD_RCD(osrname=['/etc/init.d/', '/etc/rc.d/'],
                  agreedperms='0744',
                  mode='max',
                  category='all',
                  mustexist=False,
                  agreeduser='root'):
    '''
        ----------------
          REQ_ID: 47_7
        ----------------

        Files executed via files or links contained in /etc/init.d/ or
        /etc/rc.d/:
            - should have no write by general users (744 or more restrictive)
    '''

    # osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Files executed via files or links " + \
        "contained in %s: " % (' or '.join(osrname)) + \
        "should have no write by general users (744 or more restrictive)"

    violations = []
    ret = {}

    for osr in list_files_in(drs=osrname, cond='os.access(%, os.X_OK)'):
        if not os.path.isfile(osr):
            if mustexist:
                violations.append("FS object %s not found" % (osr))
                ret[osr] = []
                ret[osr].append({'problem': 'missing'})
            else:
                pass
        else:
            ret[osr] = []
            # first, check ownership
            if agreeduser:
                agreeduid = pwd.getpwnam(agreeduser).pw_uid
                owner_id = os.stat(osr).st_uid
                owner_name = pwd.getpwuid(owner_id).pw_name
                if owner_id != agreeduid:
                    violations.append("FS object owned not by %s, but by %s"
                                      % (agreeduser, owner_name))
                    ret[osr].append({'problem': 'ownership',
                                     'rightful_owner': agreeduser,
                                     'wrong_owner': owner_name})
            # else: << removed >>
            # now check permissions
            permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                        mode=mode)
            if permfailed:
                violations.append("FS object %s permissions: %s" %
                                  (osr, permfailed))
                ret[osr].append({'problem': 'permissions',
                                 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# AD.1.8.18.2


def OSR_INITD_RCD_ALL(osrname=["/etc/init.d/rc0.d", "/etc/init.d/rc1.d",
                               "/etc/init.d/rc2.d", "/etc/init.d/rc3.d",
                               "/etc/init.d/rc4.d", "/etc/init.d/rc5.d",
                               "/etc/init.d/rc6.d", "/etc/init.d/rcS.d",
                               "/etc/rc.d/rc0.d", "/etc/rc.d/rc1.d",
                               "/etc/rc.d/rc2.d", "/etc/rc.d/rc3.d",
                               "/etc/rc.d/rc4.d", "/etc/rc.d/rc5.d",
                               "/etc/rc.d/rc6.d", "/etc/rc.d/rcS.d"],
                      agreedperms='0744',
                      mode='max',
                      category='all',
                      mustexist=False,
                      agreeduser='root'):
    '''
        ----------------
          REQ_ID: 47_*
        ----------------

        Files executed via files or links contained in
        /etc/init.d/rc0.d, /etc/init.d/rc1.d, /etc/init.d/rc2.d,
        /etc/init.d/rc3.d, /etc/init.d/rc4.d, /etc/init.d/rc5.d,
        /etc/init.d/rc6.d, /etc/init.d/rcS.d directories
            -or-
        /etc/rc.d/rc0.d, /etc/rc.d/rc1.d, /etc/rc.d/rc2.d, /etc/rc.d/rc3.d,
        /etc/rc.d/rc4.d, /etc/rc.d/rc5.d, /etc/rc.d/rc6.d, /etc/rc.d/rcS.d
                - should have no write by general users
                (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Files executed via files or links " + \
        "contained in %s: " % (' or '.join(osrname)) + \
        "should have no write by general users (744 or more restrictive)"

    violations = []
    ret = {}

    for osr in list_files_in(drs=osrname, cond='os.access(%, os.X_OK)'):
        if not os.path.isfile(osr):
            if mustexist:
                violations.append("FS object %s not found" % (osr))
                ret[osr] = []
                ret[osr].append({'problem': 'missing'})
            else:
                pass
        else:
            ret[osr] = []
            # first, check ownership
            if agreeduser:
                agreeduid = pwd.getpwnam(agreeduser).pw_uid
                owner_id = os.stat(osr).st_uid
                owner_name = pwd.getpwuid(owner_id).pw_name
                if owner_id != agreeduid:
                    violations.append("FS object owned not by %s, but by %s"
                                      % (agreeduser, owner_name))
                    ret[osr].append({'problem': 'ownership',
                                     'rightful_owner': agreeduser,
                                     'wrong_owner': owner_name})
            # else: << removed >>
            # now check permissions
            permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                        mode=mode)
            if permfailed:
                violations.append("FS object %s permissions: %s" %
                                  (osr, permfailed))
                ret[osr].append({'problem': 'permissions',
                                 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.5.9.20.1


def NET_SYNCOOKIES(osrname='/etc/sysctl.conf',
                   directive="net.ipv4.tcp_syncookies",
                   agreedvalue="1",
                   delim='='):
    '''
        -----------------------
            REQ_ID:  72_1
        -----------------------

        /etc/sysctl.conf:
            - should contain net.ipv4.tcp_syncookies = 1
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in %s" \
        % (directive + ' = ' + agreedvalue, osrname)

    violations = []
    # delim = '='

    result = lookline_in_file(afile=osrname, thevalues=directive)
    if not result:
        violations = ["Directive MISSING"]
    else:  # found the directive
        if len(result) > 1:
            violations = ["Directive found multiple times"]
        else:
            crtval = result[0].split(delim)[-1].strip()  # diff approach here
            if crtval != agreedvalue:
                violations = ["%s set to %s" % (directive, crtval)]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.5.9.20.2


def NET_BROADCASTS(osrname='/etc/sysctl.conf',
                   directive="net.ipv4.icmp_echo_ignore_broadcasts",
                   agreedvalue="1",
                   delim='='):
    '''
        -----------------------
            REQ_ID:  72_2
        -----------------------

        /etc/sysctl.conf:
            - should contain net.ipv4.icmp_echo_ignore_broadcasts = 1
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in %s" \
        % (directive + ' = ' + agreedvalue, osrname)

    violations = []
    # delim = '='

    result = lookline_in_file(afile=osrname, thevalues=directive)
    if not result:
        violations = ["Directive MISSING"]
    else:  # found the directive
        if len(result) > 1:
            violations = ["Directive found multiple times"]
        else:
            crtval = result[0].split(delim)[-1].strip()  # diff approach here
            if crtval != agreedvalue:
                violations = ["%s set to %s" % (directive, crtval)]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.5.9.20.3


def NET_REDIRECTS(osrname='/etc/sysctl.conf',
                  directive="net.ipv4.conf.all.accept_redirects",
                  agreedvalue="0",
                  delim='='):
    '''
        -----------------------
            REQ_ID:  72_3
        -----------------------

        /etc/sysctl.conf:
            - should contain net.ipv4.conf.all.accept_redirects = 0
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in %s" \
        % (directive + ' = ' + agreedvalue, osrname)

    violations = []
    # delim = '='

    result = lookline_in_file(afile=osrname, thevalues=directive)
    if not result:
        violations = ["Directive MISSING"]
    else:  # found the directive
        if len(result) > 1:
            violations = ["Directive found multiple times"]
        else:
            crtval = result[0].split(delim)[-1].strip()  # diff approach here
            if crtval != agreedvalue:
                violations = ["%s set to %s" % (directive, crtval)]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.5.9.18.3
# IZ.1.5.9.18.2


def NET_SNMPSERVICE(osrname='/etc/snmp/snmpd.conf',
                    communities=['public', 'private']):
    '''
        -----------------------
            REQ_ID:  71
        -----------------------

        /etc/snmp/snmpd.conf:
            - Community name of 'public' and 'private' are not permitted
            (if files exists, comment the uncommened lines that contain
            "public" or "private")
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Directives %s are not permitted in %s"\
        % (' and '.join(communities), osrname)

    violations = []
    # delim = '='

    if os.path.isfile(osrname):
        for directive in communities:
            violations.extend(lookline_in_file(afile=osrname,
                                               thevalues=directive))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.4.6


def SSAA_PAMD_OTH_AUTH(directive,
                       pamfiles=['/etc/pam.d/other']):
    '''
        -----------------------
            REQ_ID:  52_1
        -----------------------

        /etc/pam.d/other:
            - auth required pam_deny.so

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Looking for directive '%s'" % (directive) + \
        " in  %s" % (', '.join(pamfiles))

    violations = []

    for fl in pamfiles:
        if not lookline_in_file(afile=fl, thevalues=directive):
            violations.append(fl)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.4.1


def SSAA_PAMD_OTH_ACC(directive,
                      pamfiles=['/etc/pam.d/other']):
    '''
        -----------------------
            REQ_ID:  52_2
        -----------------------

        /etc/pam.d/other:
            - account required pam_deny.so

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Looking for directive '%s'" % (directive) + \
        " in  %s" % (', '.join(pamfiles))

    violations = []

    for fl in pamfiles:
        if not lookline_in_file(afile=fl, thevalues=directive):
            violations.append(fl)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.6.0


def SLA_PASSWORD_AUTH(directives,
                      pamfiles=['/etc/pam.d/password-auth']):
    '''
        ------------------
          REQ_ID: 56_3_4
        ------------------

        RHEL: /etc/pam.d/password-auth
            - auth required pam_tally.so deny=5
            - account required pam_tally.so

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Looking for directives '%s'" % (' and '.join(directives)) + \
        " in  %s" % (', '.join(pamfiles))

    if pam_tally2_used():  # check N/A
        log_audit(descr, "N/A")
        return

    violations = []
    ret = {}

    for fl in pamfiles:
        ret[fl] = []
        for directive in directives:
            if not lookline_in_file(afile=fl, thevalues=directive):
                violations.append('File %s - missing directive %s' %
                                  (fl, directive))
                ret[fl].append(directive)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # return violations
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# NOT PRESENT


def SLA_PASSWORD_AUTH2(directives,
                       pamfiles=['/etc/pam.d/password-auth']):
    '''
        ------------------
          REQ_ID: 56_1_2
        ------------------

        RHEL - /etc/pam.d/password-auth:
            - auth required pam_tally.so deny=3
            - account required pam_tally.so

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Looking for directives '%s'" % (' and '.join(directives)) + \
        " in  %s" % (', '.join(pamfiles))

    #if not pam_tally2_used():  # check N/A
    #    log_audit(descr, "N/A")
    #    return

    violations = []
    ret = {}

    for fl in pamfiles:
        ret[fl] = []
        for directive in directives:
            if not lookline_in_file(afile=fl, thevalues=directive):
                violations.append('File %s - missing directive %s' %
                                  (fl, directive))
                ret[fl].append(directive)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # return violations
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.1.7.1


def SSAA_ROOTPWD(agreeduser, maxage):
    '''
        ----------------
          REQ_ID: 76
        ----------------

        root user:
            - if password is set, must expire
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "User %s : if password is set, it must expire" % (agreeduser)

    violations = []

    pwd_age_arr = getfields_from_file(afile='/etc/shadow', retfieldnos=[2, 5],
                                      keyfieldno=1, keyval=agreeduser,
                                      delim=':', except_regex=None)
    # print pwd_age_arr

    (pwd, age) = pwd_age_arr[0]  # should be only one entry in /etc/shadow

    if pwd not in ('*', '!', '!!', ''):  # pwd is set
        if not age or age != maxage:  # empty it means it never expires
            violations.append('User %s has a password set and it never expires'
                              % (agreeduser))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# NOT PRESENT


def SSAA_ROOT_CONSOLE(osrname='/etc/ssh/sshd_config',
                      directive='PermitRootLogin',
                      agreedvalue='no'):
    '''
        -------------------
            REQ_ID:  49
        -------------------

        root user:
            - login restricted to system console - PermitRootLogin no
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in %s" \
        % (directive + ' ' + agreedvalue, osrname)

    violations = []

    result = lookline_in_file(afile=osrname, thevalues=directive,
                              case='insensitive')
    if not result:
        violations = ["Directive MISSING"]
    else:  # found the directive
        if len(result) > 1:
            violations = ["Directive found multiple times"]
        else:
            crtval = result[0].split()[1]
            if crtval != agreedvalue:
                violations = ["%s set to %s" % (directive, crtval)]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations



# IZ.1.5.10.1
def NET_YPPASSWDD(status_cmd, update_cmd, cfgfile='/etc/init.d/yppasswdd',
                  service='yppasswdd'):
    '''
        -------------------
            REQ_ID:  73
        -------------------

        - yppasswd daemon - disabled:
            - /etc/init.d/yppasswdd - if file exists, disable yppasswdd service
                = RHEL, SLES:
                    = status_cmd: chkconfig --list yppasswdd
                    = update_cmd: chkconfig yppasswdd off
                = Debian:
                    =
                    = update-rc.d yppasswdd disable
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "'%s' daemon should be dsabled"\
        % (service)

    violations = []
    status_cmd = re.sub('%', service, status_cmd)
    update_cmd = re.sub('%', service, update_cmd)

    if os.path.isfile(cfgfile):

        x = subprocess.Popen(status_cmd.split(), stdout=subprocess.PIPE)
        (cmd_out, cmd_err) = x.communicate()
        cmd_ret = x.returncode
        statuses = cmd_out.split()[1:]
        # ['0:off', '1:off', '2:on', '3:on', '4:on', '5:on', '6:off']
        ons = [entry for entry in statuses if entry.endswith('on')]

        if cmd_ret == 0 and ons:  # violation
            violations.append(service + '      ' + ' '.join(statuses))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# def AUTH_PWD_COMPLEX(osrname,
#                      directives=['password required pam_cracklib.so retry=3 \
#                                   minlen=8 dcredit=-1 ucredit=0 lcredit=-1 \
#                                   ocredit=0 type= reject_username',
#                                  'password required pam_passwdqc.so \
#                                   min=disabled,8,8,8,8 passphrase=0 \
#                                   random=0 enforce=everyone']):
#
#     '''
#         One of these two options must be implemented:
#             - Parameters of "retry=3 minlen=8 dcredit=-1 ucredit=0 lcredit=-1
#                 ocredit=0 type= reject_username" to the
#                 "password required pam_cracklib.so ..." stanza
#             - parameters of "min=disabled,8,8,8,8 passphrase=0 random=0
#                 enforce=everyone" to the
#                 "password required pam_passwdqc.so" stanza
#         The "type=" parameter to pam_crackllib.so may be omitted
#         if it causes problems.
#
#         RHEL -> '/etc/pam.d/system-auth'
#         SLES -> '/etc/pam.d/common-auth'
#     '''
#
#     checkname = inspect.stack()[0][3]
#     descr = format_nicely(checkname) + 'One of the following directives ' + \
#         'should be implemented in %s: "%s" ' % (osrname,
#                                                 '" or "'.join(directives))
#
#     violations = {}
#     ret = {}
#     found_one = 0
#
#     for directive in directives:
#         first_and_third = ' '.join(directive.split()[0:3:2])
#         # violations[first_and_third] = []
#         # look only after 'password pam_cracklib.so'
#         result = lookline_in_file(
#                         afile=osrname,
#                         thevalues=first_and_third,
#                         commentchr='#', case="sensitive")
#
#         if not result:
#             violations[first_and_third] = "MISSING"
#             ret[directive] = "MISSING"
#             continue
#
#         # found the directive
#         if len(result) > 1:
#             violations[first_and_third] = "MULTIPLE occurences"
#             ret[directive] = "MULTIPLE occurences"
#         else:
#             if set(result[0].split()) != set(directive.split()):  # bad parms
#                 violations[first_and_third] = "WRONG parms: %s" % (result[0])
#                 ret[directive] = "WRONG params: %s" % (result[0])
#             else:  # found a good directive
#                 found_one = 1
#
#     if found_one:
#         violations = {}
#         ret = {}
#
#     if violations:
#         log_audit(descr, "FAILED", details=violations)
#     else:
#         log_audit(descr, "PASS")
#
#     return ret

# AD 1.1.2.0
def AUTH_PWD_COMPLEX(osrnames,
                     directives=['password requisite pam_pwquality.so retry=3 \
                                  minlen=15 dcredit=-1 ucredit=0 lcredit=-1 \
                                  ocredit=0 type= reject_username']):

    '''
        -----------------------
            REQ_ID:
                -  7 (RHEL)
                - 75 (SLES)
        -----------------------

        One of these two options must be implemented:
            - Parameters of "retry=3 minlen=8 dcredit=-1 ucredit=0 lcredit=-1
                ocredit=0 type= reject_username" to the
                "password required pam_pwquality.so ..." stanza


        RHEL -> '/etc/pam.d/system-auth', /etc/pam.d/password-auth
        SLES -> '/etc/pam.d/common-auth'
    '''

    checkname = inspect.stack()[0][3]
    #opts = [' and '.join(directives) for directive in directives]
    descr = format_nicely(checkname) + 'The following directive ' + \
        'should be implemented in %s: %s ' % (' and '.join(osrnames), ' or '.join(directives))

    violations = []
    ret = {}

    for osrname in osrnames:
        if not os.path.isfile(osrname):
            violations.append('%s: file MISSING' % (osrname))
            ret = {'FILE_NOT_FOUND': osrname}
            directives = []  # for skipping the loop

        for directive in directives:

           # optional_directive_failed = 0

            #for directive in directives:
            search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd elem

            result = lookline_in_file(
                afile=osrname,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                if 'MISSING_DIRECTIVES' not in ret.keys():
                    ret['MISSING_DIRECTIVES'] = []

                violations.append("Directive MISSING: %s in %s" % (directive, osrname) )
                ret['MISSING_DIRECTIVES'].append(osrname)
             #   optional_directive_failed = 1
            else:  # found the directive
                for crtline in result:
                    should_be_values = directive.split()
                    crt_values = crtline.split()
                    missing = set(should_be_values).difference(set(crt_values))
                    # params in the directive, but not in the current config
                    # print missing
                    if missing:
                       # optional_directive_failed = 1
                        if osrname not in ret.keys():
                            ret[osrname] = {}
                        violations.append("Bad and/or missing parameters for" +
                                          " the" + " '%s' " % (search_key) +
                                          " directive: %s" % (crtline))
                        # determine what needs to be overwritten
                        # and what needs to be added
                        pam_flag = directive.split()[1]
                        if pam_flag in missing:  # needs to be overwritten
                            # overwrite the pam_flag
                            crt_values[1] = pam_flag
                            missing.remove(pam_flag)
                            # eg: password required pam_unix.so

                        # check the remember, or other argum which contains '='
                        for argum in missing:
                            if '=' not in argum:
                                crt_values.append(argum)
                            else:  # check if the '=' arg is missing,or bad val
                                param, rightval = argum.split('=')
                                if param in crtline:  # param present, bad val
                                    crt_values = [re.sub(param + r'=\S+',
                                                         argum, elem)
                                                  for elem in crt_values]
                                    # we are really modifying just 1 element...
                                else:
                                    crt_values.append(argum)

                        ret[osrname][crtline] = \
                            ' '.join(crt_values)
                        # wrong line --> right line
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")


    return ret



# IZ.1.1.2.0
def AUTH_PWD_MINLEN(osrnames=['/etc/pam.d/system-auth', '/etc/pam.d/password-auth'],
                    directive=['password requisite pam_pwquality.so'],
                    argum='minlen=17'):
    '''
        Password minimum length:   17
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The following directive ' + \
        'should be implemented in %s: %s ' % (' and '.join(osrnames), ' '.join(directive) + ' ' + argum)

    violations = []
    ret = {}
    # first_and_third = ' '.join(directive.split()[0:3:2])
    for osrname in osrnames:
        for d in directive:
            search_key = ' '.join(d.split()[0:3:2])  # 1st and 3rd elem

            result = lookline_in_file(
                afile=osrname,
                thevalues=search_key,
                commentchr='#', case="sensitive")

            if not result:
                if 'MISSING_DIRECTIVES' not in ret.keys():
                    ret['MISSING_DIRECTIVES'] = []

                violations.append("Directive MISSING: %s in %s" % (directive, osrname) )
                ret['MISSING_DIRECTIVES'].append(osrname)
            else:
                 if argum not in result[0].split():
                     violations = ["Password minimum length not set to the agreed" +
                                   " value. Current config - %s" % (result[0])]
                     if osrname not in ret.keys():
                         ret[osrname] = []
                     ret[osrname] = result

    if violations:

        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret

# NOT PRESENT

def SSAA_SUDO_SU(osrname='/etc/sudoers', addsudoers=[]):
    '''
        ----------------------
            REQ_ID:  50, 51
        ----------------------

        su verifications:
            - rename it to /bin/suDISABLED
            - remove x right for owner, group and others
        sudo:
            - at least one active users or group with and active user,
            allowed to login (login shell or password not disabled)
            should have an active (uncommented) entry in /etc/sudoers
            for all commands (last word is ALL)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'root user should be accessed by sudo, not su'

    violations = []
    ret = {}

    # su verifications
    supath = which_py('su', check_exe=False)

    if supath:  # found the su file in $PATH not good
        violations.append("Found su file in $PATH: %s" % (supath))
        ret['supath'] = supath
        if is_exe(supath):  # it gets worse :)...it's also executable
            violations.append("su file %s is also executable" % (supath))
            ret['su_executable'] = True

    # sudo verifications

    lines = lookline_in_file(afile='/etc/sudoers', by_regex=r'ALL\s*$',
                             commentchr='#', case="sensitive")

    normal_sudoer_lines = [ln for ln in lines if not re.search(r'^root', ln)]

    # print lines
    # print normal_sudoer_lines

    if not normal_sudoer_lines:
        violations.append('No normal user found in %s' % (osrname))
        ret['no_sudoers'] = True
    else:
        users = []
        for ln in normal_sudoer_lines:
            matchobj = re.search(r'^\s*(.*?)\s+', ln)
            if matchobj:
                usr_grp = matchobj.groups()[0]
                if usr_grp.startswith('%'):  # entry for a group
                    usr_grp = usr_grp[1:]
                    users.extend(grpmembers(usr_grp))
                else:  # entry for a user
                    users.append(usr_grp)
                # usersorgroups.append(usr_grp)

        # print "All sudo users: ", users
        validsudoers = [usr for usr in users if is_valid(usr)]
        # print "validsudoers: ", validsudoers
        if not validsudoers:
            violations.append('Sudo users found, but none is valid')
            ret['invalid_sudoers'] = [usr for usr in users
                                      if not is_valid(usr)]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret


# IZ.1.1.4.1
def AUTH_REUSE_RHEL(osrnames,
                    directives):
    '''
        ----------------
            REQ_ID: 11
        ----------------

        RHEL:
            - /etc/pam.d/password-auth, /etc/pam.d/system-auth:
                password required pam_unix.so remember=8 use_authtok md5 shadow
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The following directive ' + \
        'should be implemented in %s: %s ' % (' and '.join(osrnames), ', '.join(directives))

    violations = []
    ret = {}
    for osrname in osrnames:
        if not os.path.isfile(osrname):
            violations.append('%s: file MISSING' % (osrname))
            ret = {'FILE_NOT_FOUND': osrname}
            directives = []  # for skipping the loop

        for directive in directives:
            search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd element
            # password pam_unix.so
            result = lookline_in_file(
                afile=osrname,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                if 'MISSING_DIRECTIVES' not in ret.keys():
                    ret['MISSING_DIRECTIVES'] = []

                violations.append("Directive MISSING: %s" % (directive))
                ret['MISSING_DIRECTIVES'].append(osrname)
            else:  # found the directive
                for crtline in result:
                    should_be_values = directive.split()
                    crt_values = crtline.split()
                    missing = set(should_be_values).difference(set(crt_values))
                    # params in the directive, but not in the current config
                    # print missing
                    if missing:
                        if osrname not in ret.keys():
                            ret[osrname] = {}
                        violations.append("Bad and/or missing parameters for the" +
                                          " '%s' " % (search_key) +
                                          " directive: %s" % (crtline))
                        # determine what needs to be overwritten
                        # and what needs to be added
                        pam_flag = directive.split()[1]
                        if pam_flag in missing:  # needs to be overwritten
                            # overwrite the pam_flag
                            crt_values[1] = pam_flag
                            missing.remove(pam_flag)
                            # eg: password required pam_unix.so

                        # check the remember, or other argum which contains '='
                        for argum in missing:
                            if '=' not in argum:
                                crt_values.append(argum)
                            else:  # check if the '=' arg is missing, or wrong val
                                param, rightval = argum.split('=')  # eg 'remember'
                                if param in crtline:  # param present with wbad val
                                    crt_values = [re.sub(param + r'=\S+',
                                                         argum, elem)
                                                  for elem in crt_values]
                                    # we are really modifying just 1 element...
                                else:
                                    crt_values.append(argum)

                        ret[osrname][crtline] = ' '.join(crt_values)
                    # wrong line --> right line

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret

##############################################################################
#                            SUSE Linux only                                 #
##############################################################################


def SLA_COMMON_AUTH(osrname,
                    directives):
    '''
        -------------------
            REQ_ID: 57_2
        -------------------

        SLES - /etc/pam.d/common-auth (for pam_tally.so use):
           - auth required pam_tally.so deny=5 onerr=fail per_user no_lock_time

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The following directive(s) ' + \
        'should be implemented in %s: %s ' % (osrname, ', '.join(directives))

    if pam_tally2_used():  # check N/A
        log_audit(descr, "N/A")
        return

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
        ret = {'FILE_NOT_FOUND': osrname}
        directives = []  # for skipping the loop

    for directive in directives:
        search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd element
        # password pam_unix.so
        result = lookline_in_file(
            afile=osrname,
            thevalues=search_key,
            commentchr='#', case="sensitive")
        if not result:
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []

            violations.append("Directive MISSING: %s" % (directive))
            ret['MISSING_DIRECTIVES'].append(directive)
        else:  # found the directive
            # print result
            # if len(result) > 1:
            #     violations = ["Directive found multiple times"]
            #     ret = dict(zip(range(len(result)), result))
            # eg: { 0: "error_line", 1: "another error_line"}
            # else:  # found the directive, now check the params
            for crtline in result:
                should_be_values = directive.split()
                crt_values = crtline.split()
                missing = set(should_be_values).difference(set(crt_values))
                # params in the directive, but not in the current config
                # print missing
                if missing:
                    if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                        ret['BAD_PARAM_DIRECTIVES'] = {}
                    violations.append("Bad and/or missing parameters for the" +
                                      " '%s' " % (search_key) +
                                      " directive: %s" % (crtline))
                    # determine what needs to be overwritten
                    # and what needs to be added
                    pam_flag = directive.split()[1]
                    if pam_flag in missing:  # needs to be overwritten
                        # overwrite the pam_flag
                        crt_values[1] = pam_flag
                        missing.remove(pam_flag)
                        # eg: password required pam_unix.so

                    # check the remember, or other argum which contains '='
                    for argum in missing:
                        if '=' not in argum:
                            crt_values.append(argum)
                        else:  # check if the '=' arg is missing, or wrong val
                            param, rightval = argum.split('=')  # eg 'remember'
                            if param in crtline:  # param present with wbad val
                                crt_values = [re.sub(param + r'=\S+',
                                                     argum, elem)
                                              for elem in crt_values]
                                # we are really modifying just 1 element...
                            else:
                                crt_values.append(argum)

                    ret['BAD_PARAM_DIRECTIVES'][crtline] = ' '.join(crt_values)
                # wrong line --> right line

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret


def SLA_COMMON_AUTH2(osrname,
                     directives):
    '''
        -------------------
            REQ_ID: 57_1
        -------------------

        SLES - /etc/pam.d/common-auth (for pam_tally2.so use)
           -auth required pam_tally2.so deny=5 onerr=fail per_user no_lock_time

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The following directive(s) ' + \
        'should be implemented in %s: %s ' % (osrname, ', '.join(directives))

    if not pam_tally2_used():  # check N/A
        log_audit(descr, "N/A")
        return

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
        ret = {'FILE_NOT_FOUND': osrname}
        directives = []  # for skipping the loop

    for directive in directives:
        search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd element
        # password pam_unix.so
        result = lookline_in_file(
            afile=osrname,
            thevalues=search_key,
            commentchr='#', case="sensitive")
        if not result:
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []

            violations.append("Directive MISSING: %s" % (directive))
            ret['MISSING_DIRECTIVES'].append(directive)
        else:  # found the directive
            # print result
            # if len(result) > 1:
            #     violations = ["Directive found multiple times"]
            #     ret = dict(zip(range(len(result)), result))
            # eg: { 0: "error_line", 1: "another error_line"}
            # else:  # found the directive, now check the params
            for crtline in result:
                should_be_values = directive.split()
                crt_values = crtline.split()
                missing = set(should_be_values).difference(set(crt_values))
                # params in the directive, but not in the current config
                # print missing
                if missing:
                    if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                        ret['BAD_PARAM_DIRECTIVES'] = {}
                    violations.append("Bad and/or missing parameters for the" +
                                      " '%s' " % (search_key) +
                                      " directive: %s" % (crtline))
                    # determine what needs to be overwritten
                    # and what needs to be added
                    pam_flag = directive.split()[1]
                    if pam_flag in missing:  # needs to be overwritten
                        # overwrite the pam_flag
                        crt_values[1] = pam_flag
                        missing.remove(pam_flag)
                        # eg: password required pam_unix.so

                    # check the remember, or other argum which contains '='
                    for argum in missing:
                        if '=' not in argum:
                            crt_values.append(argum)
                        else:  # check if the '=' arg is missing, or wrong val
                            param, rightval = argum.split('=')  # eg 'remember'
                            if param in crtline:  # param present with wbad val
                                crt_values = [re.sub(param + r'=\S+',
                                                     argum, elem)
                                              for elem in crt_values]
                                # we are really modifying just 1 element...
                            else:
                                crt_values.append(argum)

                    ret['BAD_PARAM_DIRECTIVES'][crtline] = ' '.join(crt_values)
                # wrong line --> right line

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret

#


def SLA_COMMON_ACC(osrname,
                   directives):
    '''
        -------------------
            REQ_ID: 58_???
        -------------------

        /etc/pam.d/common-account (for pam_tally.so use)
           - account required pam_tally.so
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The following directive(s) ' + \
        'should be implemented in %s: %s ' % (osrname, ', '.join(directives))

    if pam_tally2_used():  # check N/A
        log_audit(descr, "N/A")
        return

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
        ret = {'FILE_NOT_FOUND': osrname}
        directives = []  # for skipping the loop

    for directive in directives:
        search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd element
        # password pam_unix.so
        result = lookline_in_file(
            afile=osrname,
            thevalues=search_key,
            commentchr='#', case="sensitive")
        if not result:
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []

            violations.append("Directive MISSING: %s" % (directive))
            ret['MISSING_DIRECTIVES'].append(directive)
        else:  # found the directive
            # print result
            # if len(result) > 1:
            #     violations = ["Directive found multiple times"]
            #     ret = dict(zip(range(len(result)), result))
            # eg: { 0: "error_line", 1: "another error_line"}
            # else:  # found the directive, now check the params
            for crtline in result:
                should_be_values = directive.split()
                crt_values = crtline.split()
                missing = set(should_be_values).difference(set(crt_values))
                # params in the directive, but not in the current config
                # print missing
                if missing:
                    if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                        ret['BAD_PARAM_DIRECTIVES'] = {}
                    violations.append("Bad and/or missing parameters for the" +
                                      " '%s' " % (search_key) +
                                      " directive: %s" % (crtline))
                    # determine what needs to be overwritten
                    # and what needs to be added
                    pam_flag = directive.split()[1]
                    if pam_flag in missing:  # needs to be overwritten
                        # overwrite the pam_flag
                        crt_values[1] = pam_flag
                        missing.remove(pam_flag)
                        # eg: password required pam_unix.so

                    # check the remember, or other argum which contains '='
                    for argum in missing:
                        if '=' not in argum:
                            crt_values.append(argum)
                        else:  # check if the '=' arg is missing, or wrong val
                            param, rightval = argum.split('=')  # eg 'remember'
                            if param in crtline:  # param present with wbad val
                                crt_values = [re.sub(param + r'=\S+',
                                                     argum, elem)
                                              for elem in crt_values]
                                # we are really modifying just 1 element...
                            else:
                                crt_values.append(argum)

                    ret['BAD_PARAM_DIRECTIVES'][crtline] = ' '.join(crt_values)
                # wrong line --> right line

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret


def SLA_COMMON_ACC2(osrname,
                    directives):
    '''
        -------------------
            REQ_ID: 58_1
        -------------------

        /etc/pam.d/common-account (for pam_tally2.so use)
           - account required pam_tally2.so
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The following directive(s) ' + \
        'should be implemented in %s: %s ' % (osrname, ', '.join(directives))

    if not pam_tally2_used():  # check N/A
        log_audit(descr, "N/A")
        return

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
        ret = {'FILE_NOT_FOUND': osrname}
        directives = []  # for skipping the loop

    for directive in directives:
        search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd element
        # password pam_unix.so
        result = lookline_in_file(
            afile=osrname,
            thevalues=search_key,
            commentchr='#', case="sensitive")
        if not result:
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []

            violations.append("Directive MISSING: %s" % (directive))
            ret['MISSING_DIRECTIVES'].append(directive)
        else:  # found the directive
            # print result
            # if len(result) > 1:
            #     violations = ["Directive found multiple times"]
            #     ret = dict(zip(range(len(result)), result))
            # eg: { 0: "error_line", 1: "another error_line"}
            # else:  # found the directive, now check the params
            for crtline in result:
                should_be_values = directive.split()
                crt_values = crtline.split()
                missing = set(should_be_values).difference(set(crt_values))
                # params in the directive, but not in the current config
                # print missing
                if missing:
                    if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                        ret['BAD_PARAM_DIRECTIVES'] = {}
                    violations.append("Bad and/or missing parameters for the" +
                                      " '%s' " % (search_key) +
                                      " directive: %s" % (crtline))
                    # determine what needs to be overwritten
                    # and what needs to be added
                    pam_flag = directive.split()[1]
                    if pam_flag in missing:  # needs to be overwritten
                        # overwrite the pam_flag
                        crt_values[1] = pam_flag
                        missing.remove(pam_flag)
                        # eg: password required pam_unix.so

                    # check the remember, or other argum which contains '='
                    for argum in missing:
                        if '=' not in argum:
                            crt_values.append(argum)
                        else:  # check if the '=' arg is missing, or wrong val
                            param, rightval = argum.split('=')  # eg 'remember'
                            if param in crtline:  # param present with wbad val
                                crt_values = [re.sub(param + r'=\S+',
                                                     argum, elem)
                                              for elem in crt_values]
                                # we are really modifying just 1 element...
                            else:
                                crt_values.append(argum)

                    ret['BAD_PARAM_DIRECTIVES'][crtline] = ' '.join(crt_values)
                # wrong line --> right line

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret


def AUTH_REUSE_PWCHECK(osrname="/etc/security/pam_pwcheck.conf",
                       directives=["password: md5 remember=8"]):
    '''
        ----------------
            REQ_ID: 13
        ----------------

        SLES: /etc/security/pam_pwcheck.conf
            - password: md5 remember=8
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The following directive ' + \
        'should be implemented in %s: %s ' % (osrname, ', '.join(directives))

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
        ret = {'FILE_NOT_FOUND': osrname}
        directives = []  # for skipping the loop

    for directive in directives:
        # search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd elem
        # password pam_unix.so
        search_key = directive.split()[0]  # password:
        result = lookline_in_file(
            afile=osrname,
            thevalues=search_key,
            commentchr='#', case="sensitive")
        if not result:
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []

            violations.append("Directive MISSING: %s" % (directive))
            ret['MISSING_DIRECTIVES'].append(directive)
        else:  # found the directive
            # print result
            # if len(result) > 1:
            #     violations = ["Directive found multiple times"]
            #     ret = dict(zip(range(len(result)), result))
            # eg: { 0: "error_line", 1: "another error_line"}
            # else:  # found the directive, now check the params
            for crtline in result:
                should_be_values = directive.split()
                crt_values = crtline.split()
                missing = set(should_be_values).difference(set(crt_values))
                # params in the directive, but not in the current config
                # print missing
                if missing:
                    if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                        ret['BAD_PARAM_DIRECTIVES'] = {}
                    violations.append("Bad and/or missing parameters for the" +
                                      " '%s' " % (search_key) +
                                      " directive: %s" % (crtline))
                    # determine what needs to be overwritten
                    # and what needs to be added
                    # ........ not necessary here .......
                    # -------------- REMOVED ---------- #
                    # pam_flag = directive.split()[1]
                    # if pam_flag in missing:  # needs to be overwritten
                    #     # overwrite the pam_flag
                    #     crt_values[1] = pam_flag
                    #     missing.remove(pam_flag)
                    #     # eg: password required pam_unix.so
                    # -------------- REMOVED ----------- #

                    # check the remember, or other argum which contains '='
                    for argum in missing:
                        if '=' not in argum:
                            crt_values.append(argum)
                        else:  # check if the '=' arg is missing, or wrong val
                            param, rightval = argum.split('=')  # eg 'remember'
                            if param in crtline:  # param present with wbad val
                                crt_values = [re.sub(param + r'=\S+',
                                                     argum, elem)
                                              for elem in crt_values]
                                # we are really modifying just 1 element...
                            else:
                                crt_values.append(argum)

                    ret['BAD_PARAM_DIRECTIVES'][crtline] = ' '.join(crt_values)
                # wrong line --> right line

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret


def AUTH_REUSE_SLES(osrname,
                    options):
    '''
        ----------------
            REQ_ID: 12
        ----------------

        SLES:	/etc/pam.d/common-password
            - file must exist and include these one of these two settings:
                - Option 1 (include both):
                    = password required pam_unix2.so md5
                    = password required pam_pwcheck.so remember=8
                - Option 2:
                    = password required pam_unix_passwd.so remember=7
                    use_authtok md5 shadow
    '''

    checkname = inspect.stack()[0][3]
    opts = [' and '.join(option) for option in options]
    descr = format_nicely(checkname) + 'The following directive ' + \
        'should be implemented in %s: %s ' % (osrname, ' or '.join(opts))

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
        ret = {'FILE_NOT_FOUND': osrname}
        options = []  # for skipping the loop

    for directives in options:

        optional_directive_failed = 0

        for directive in directives:
            search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd elem
            # password pam_unix.so
            result = lookline_in_file(
                afile=osrname,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                if 'MISSING_DIRECTIVES' not in ret.keys():
                    ret['MISSING_DIRECTIVES'] = []

                violations.append("Directive MISSING: %s" % (directive))
                ret['MISSING_DIRECTIVES'].append(directive)
                optional_directive_failed = 1
            else:  # found the directive
                # print result
                # if len(result) > 1:
                #     violations = ["Directive found multiple times"]
                #     ret = dict(zip(range(len(result)), result))
                # eg: { 0: "error_line", 1: "another error_line"}
                # else:  # found the directive, now check the params
                for crtline in result:
                    should_be_values = directive.split()
                    crt_values = crtline.split()
                    missing = set(should_be_values).difference(set(crt_values))
                    # params in the directive, but not in the current config
                    # print missing
                    if missing:
                        optional_directive_failed = 1
                        if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                            ret['BAD_PARAM_DIRECTIVES'] = {}
                        violations.append("Bad and/or missing parameters for" +
                                          " the" + " '%s' " % (search_key) +
                                          " directive: %s" % (crtline))
                        # determine what needs to be overwritten
                        # and what needs to be added
                        pam_flag = directive.split()[1]
                        if pam_flag in missing:  # needs to be overwritten
                            # overwrite the pam_flag
                            crt_values[1] = pam_flag
                            missing.remove(pam_flag)
                            # eg: password required pam_unix.so

                        # check the remember, or other argum which contains '='
                        for argum in missing:
                            if '=' not in argum:
                                crt_values.append(argum)
                            else:  # check if the '=' arg is missing,or bad val
                                param, rightval = argum.split('=')
                                if param in crtline:  # param present, bad val
                                    crt_values = [re.sub(param + r'=\S+',
                                                         argum, elem)
                                                  for elem in crt_values]
                                    # we are really modifying just 1 element...
                                else:
                                    crt_values.append(argum)

                        ret['BAD_PARAM_DIRECTIVES'][crtline] = \
                            ' '.join(crt_values)
                        # wrong line --> right line

        if not optional_directive_failed:  # => found a good option => break
            violations = []
            ret = {}
            break
        # else:  option failed, move on to try the other ones

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret


# --------------- 3rd iteration ------------ #

def AUTH_PAMUNIX2CONF(osrname="/etc/security/pam_unix2.conf",
                      directives=["password: md5 shadow"],
                      exact_match=True):
    '''
        ----------------
            REQ_ID: 14
        ----------------

        SLES: /etc/security/pam_unix2.conf
            - password: md5 shadow
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The following directive ' + \
        'should be implemented in %s: %s ' % (osrname, ', '.join(directives))

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
        ret = {'FILE_NOT_FOUND': osrname}
        directives = []  # for skipping the loop

    for directive in directives:
        # search_key = ' '.join(directive.split()[0:3:2])  # 1st and 3rd elem
        # password pam_unix.so
        search_key = directive.split()[0]  # password:
        result = lookline_in_file(
            afile=osrname,
            thevalues=search_key,
            commentchr='#', case="sensitive")
        if not result:
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []

            violations.append("Directive MISSING: %s" % (directive))
            ret['MISSING_DIRECTIVES'].append(directive)
        else:  # found the directive
            # print result
            # if len(result) > 1:
            #     violations = ["Directive found multiple times"]
            #     ret = dict(zip(range(len(result)), result))
            # eg: { 0: "error_line", 1: "another error_line"}
            # else:  # found the directive, now check the params
            for crtline in result:

                should_be_values = directive.split()
                crt_values = crtline.split()
                # ============= branch if the match must be exact or not
                if not exact_match:
                    missing = set(should_be_values).difference(set(crt_values))
                    # params in the directive, but not in the current config
                    # print missing
                    if missing:
                        if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                            ret['BAD_PARAM_DIRECTIVES'] = {}
                        violations.append("Bad and/or missing parameters" +
                                          " for the '%s' " % (search_key) +
                                          " directive: %s" % (crtline))
                        # determine what needs to be overwritten
                        # and what needs to be added
                        # ........ not necessary here .......
                        # -------------- REMOVED ---------- #
                        # pam_flag = directive.split()[1]
                        # if pam_flag in missing:  # needs to be overwritten
                        #     # overwrite the pam_flag
                        #     crt_values[1] = pam_flag
                        #     missing.remove(pam_flag)
                        #     # eg: password required pam_unix.so
                        # -------------- REMOVED ----------- #

                        # check the remember, or other argum which contains '='
                        for argum in missing:
                            if '=' not in argum:
                                crt_values.append(argum)
                            else:  # check if the '=' arg is missing,or bad val
                                param, rightval = argum.split('=')  # argname
                                if param in crtline:  # param with bad val
                                    crt_values = [re.sub(param + r'=\S+',
                                                         argum, elem)
                                                  for elem in crt_values]
                                    # we are really modifying just 1 element...
                                else:
                                    crt_values.append(argum)

                        ret['BAD_PARAM_DIRECTIVES'][crtline] = ' '.join(
                            crt_values)
                        # wrong line --> right line
                else:  # the match must be exact
                    if crt_values != should_be_values:

                        if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                            ret['BAD_PARAM_DIRECTIVES'] = {}

                        ret['BAD_PARAM_DIRECTIVES'][crtline] = directive
                        violations.append("Bad and/or missing parameters" +
                                          " for the '%s' " % (search_key) +
                                          " directive: %s" % (crtline))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # print ret
    return ret

# IZ.1.4.6.5
def AUTO_SKEL(osrnames=['/etc/skel/.cshrc', '/etc/skel/.login',
                        '/etc/skel/.profile', '/etc/skel/.bashrc',
                        '/etc/skel/.bash_profile', '/etc/skel/.bash_login',
                        '/etc/skel/.tcshrc'],
              directive="TMOUT",
              acceptedvalue="1800"):
    '''
        ----------------
            REQ_ID: 30.0.1.5
        ----------------

        - /etc/skel/.cshrc, /etc/skel/.login, /etc/skel/.profile,
        /etc/skel/.bashrc, /etc/skel/.bash_profile, /etc/skel/.bash_login,
        /etc/skel/.tcshrc
        - if the files exist, look for TMOUT parameter and set it to 1800 if found
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in: " \
        % (directive + ' ' + acceptedvalue) + str(osrnames)

    violations = []
    ret = []

    for osrname in osrnames:
        if not os.path.isfile(osrname):  # file missing, no problem. Move on
            continue
        result = lookline_in_file(afile=osrname, thevalues=directive, by_regex='TMOUT*', delim=None)
        if not result:  # no problem
            continue
        else:  # found the directive
             crtval = result[0].split("=")[1]
             if crtval.strip() != acceptedvalue:
               violations.append("%s set to %s: " % (directive, crtval))
               ret.append((osrname, result))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")


    return ret

# IZ.1.4.6.6
def CHECK_ALLOWED_SHELL():

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure Symbolic link is present from /bin/sh -> /bin/bash'
    violations = []
    cmd = "find -L /bin -samefile /bin/sh"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_ret'] != 0 and 'No such file or directory' in str(cmd_exec['cmd_err']):
        cmd1 = "cat /etc/shells"
        cmd1_exec = execute_command(cmd1)
        if cmd1_exec['cmd_ret'] == 0 and '/bin/sh' in str(cmd1_exec['cmd_out']):
            violations.append("Shell found,Symbolic link to be created")

    elif cmd_exec['cmd_ret'] == 0 and '/bin/bash\n/bin/sh\n' in str(cmd_exec['cmd_out']):
        violations.append("Symbolic Link not present from bin/bash to bin/sh")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.9.1.7
def AUTH_SKEL(osrnames=['/etc/skel/.cshrc', '/etc/skel/.login',
                        '/etc/skel/.profile', '/etc/skel/.bashrc',
                        '/etc/skel/.bash_profile', '/etc/skel/.bash_login',
                        '/etc/skel/.tcshrc'],
              directive="UMASK",
              acceptedvalue="077"):
    '''
        ----------------
            REQ_ID: 22
        ----------------

        - /etc/skel/.cshrc, /etc/skel/.login, /etc/skel/.profile,
        /etc/skel/.bashrc, /etc/skel/.bash_profile, /etc/skel/.bash_login,
        /etc/skel/.tcshrc
        - if the files exist, they do not override the umask 077
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in: " \
        % (directive + ' ' + acceptedvalue) + str(osrnames)

    violations = []
    ret = []

    for osrname in osrnames:

        if not os.path.isfile(osrname):  # file missing, no problem. Move on
            continue

        result = lookline_in_file(afile=osrname, thevalues=directive)
        if not result:  # no problem
            continue
        else:  # found the directive
            badlines = [ln for ln in result if ln.split()[1] != acceptedvalue]
            if badlines:
                violations.append("%s: " % osrname + str(badlines))
                ret.append((osrname, badlines))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret

# IZ.1.4.6.1
def AUTH_ETCPROFILE(osrnames=['/etc/profile'],
                    directive="UMASK",
                    acceptedvalue="077",
                    mustexist=True):
    '''
        ----------------
            REQ_ID: 20
        ----------------

        - /etc/profile
            - File must exist and does not set/reset umask after that
            invocation.
            Some systems will have /etc/profile invoke /etc/profile.local
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in: " \
        % (directive + ' ' + acceptedvalue) + str(osrnames)

    violations = []
    ret = []

    for osrname in osrnames:

        if not os.path.isfile(osrname):
            if mustexist:
                violations.append('%s: file MISSING' % (osrname))
                ret.append((osrname, [], 'MISSING'))  # badlines = []

            continue

        result = lookline_in_file(afile=osrname, thevalues=directive, case='sensitive')
        if not result:  # no problem
            continue
        else:  # found the directive
            badlines = [ln for ln in result if ln.split()[1] != acceptedvalue]
            if badlines:
                violations.append("%s: " % osrname + str(badlines))
                ret.append((osrname, badlines, None))  # MISSING = None

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret

# IZ.1.4.6.2
def AUTH_CSHLOGIN(osrnames=['/etc/csh.login'],
                  directive="UMASK",
                  acceptedvalue="077",
                  mustexist=True):
    '''
        ----------------
            REQ_ID: 21
        ----------------

        - /etc/csh.login
            - File must exist and does not set/reset umask after that
            invocation.
            Some systems will have /etc/csh.login invoke /etc/csh.login.local
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in: " \
        % (directive + ' ' + acceptedvalue) + str(osrnames)

    violations = []
    ret = []

    for osrname in osrnames:

        if not os.path.isfile(osrname):
            if mustexist:
                violations.append('%s: file MISSING' % (osrname))
                ret.append((osrname, [], 'MISSING'))  # badlines = []

            continue

        result = lookline_in_file(afile=osrname, thevalues=directive)
        if not result:  # no problem
            continue
        else:  # found the directive
            badlines = [ln for ln in result if ln.split()[1] != acceptedvalue]
            if badlines:
                violations.append("%s: " % osrname + str(badlines))
                ret.append((osrname, badlines, None))  # MISSING = None

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret


def IPC_MD5SHADOW(pamfiles=["/etc/pam.d/passwd", "/etc/pam.d/system-auth",
                            "/etc/pam.d/password-auth"],
                  mustexist=True,
                  options=["md5", "shadow"]):
    '''
        ----------------
            REQ_ID: 25
        ----------------

        /etc/pam.d/passwd, /etc/pam.d/system-auth, /etc/pam.d/password-auth
        and any file in /etc/pam.d containing
        "password required|sufficient (lib/security/$ISA)/pam_unix.so"
            - should include options: md5 shadow
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "/etc/pam.d/passwd, " + \
        "/etc/pam.d/system-auth, /etc/pam.d/password-auth and any file" + \
        " in /etc/pam.d containing 'password required|sufficient" + \
        " (lib/security/$ISA)/pam_unix.so'" + \
        " should include options: %s" % (str(options))

    violations = []
    ret = []
    badlines = []

    additionals = list_files_in(['/etc/pam.d'], cond="lookline_in_file(afile=%,\
                         by_regex='password\s+(required|sufficient)' + \
                         '\s+((((/)?lib/security/)?(\$ISA/)?))?pam_unix.so')")

    allfiles = set(pamfiles).union(additionals)

    for fl in allfiles:

        if not os.path.isfile(fl):
            if mustexist:
                violations.append('%s: file MISSING' % (fl))
                ret.append((fl, 'MISSING', []))

            continue

        all_lines = lookline_in_file(afile=fl,
                                     by_regex='password\s+' +
                                     '(required|sufficient)' +
                                     '\s+((((/)?lib/security/)?(\$ISA/)?))?' +
                                     'pam_unix.so')

        for ln in all_lines:
            missingopts = [opt for opt in options if opt not in ln]
            if missingopts:
                ret.append((fl, ln, missingopts))
                badlines.append(ln)

        # badlines = [ln for ln in all_lines
        #             if [opt for opt in options if opt not in ln]]
        # the sublist contains the options MISSING from the crt line
        # --> if the sublist is emtpy...OK ! it means all the options are there
        # --> so we DON'T included in the big list
        # + '.*' + '(md5.*shadow|shadow.*md5)')
        if badlines:
            violations.append("File %s bad lines found: %s"
                              % (fl, str(badlines)))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret


def IPC_ETCDEFPASSWD(osrnames=['/etc/default/passwd'],
                     directive='CRYPT_FILES',
                     mustexist=True,
                     agreedvalue='md5',
                     delim='='):
    '''
        ----------------
            REQ_ID: 27
        ----------------

        SLES: /etc/default/passwd
                - CRYPT_FILES=md5
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Looking for directive '%s' in %s" \
        % (directive + delim + agreedvalue, ','.join(osrnames))

    violations = []
    ret = []

    for osrname in osrnames:

        if not os.path.isfile(osrname):
            if mustexist:
                violations.append('%s: file MISSING' % (osrname))
                ret.append((osrname, ['MISSING']))

            continue

        foundlines = lookline_in_file(afile=osrname, thevalues=directive,
                                      case='sensitive', delim=delim)

        if not foundlines:
            violations.append('%s: Directive [%s] - MISSING'
                              % (osrname, directive))
            ret.append((osrname, ['DIRECTIVE_MISSING']))
        else:
            badlines = [ln for ln in foundlines
                        if ln.strip().split(delim)[1] != agreedvalue]
            if badlines:
                violations.append('%s: Bad Directive value(s): %s'
                                  % (osrname, str(badlines)))
                ret.append((osrname, badlines))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret


def IPC_PRIVKEYS(agreedperms='0600',
                 mode='exact',
                 category='all',
                 mustexist=False):
    '''
        ----------------
            REQ_ID: 28
        ----------------

        all users $HOME/.ssh/ all files containing "PRIVATE KEY-----"
            - permissions 600
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "$HOME/.ssh/ - all files containing <PRIVATE KEY----->" + \
        " should have permissions %s" % (agreedperms)

    violations = []
    ret = {}

    all_sshdirs = glob.glob("/home/*/.ssh")
    allfiles = list_files_in(all_sshdirs, cond="lookline_in_file(afile=%,\
                             by_regex='PRIVATE KEY-----')")
    # print allfiles
    # from /etc/passwd, get a mapping of (homedir : user), to know who shuld
    # own a certain home dir
    homedirs_users = dict((entr.pw_dir, entr.pw_uid)
                          for entr in pwd.getpwall())

    for dr in allfiles:   # dr -> fl
        # get the owner uid for the current file: $HOME/.ssh/<file_name>
        agreeduid = homedirs_users[os.path.dirname(os.path.dirname(dr))]
        if not os.path.isfile(dr):
            if mustexist:
                violations.append("FS object %s not found" % (dr))
                ret[dr] = []
                ret[dr].append({'problem': 'missing',
                                'rightful_ownerid': agreeduid})
            else:
                pass
        else:
            ret[dr] = []
            # check ownership first
            # if agreeduser:  # -> this part differs from the other functions
            # because we do not know the agreed user in advance
            agreeduser = pwd.getpwuid(agreeduid).pw_name
            owner_id = os.stat(dr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name

            if owner_id != agreeduid:
                ret[dr].append({'problem': 'ownership',
                                'rightful_owner': agreeduser,
                                'wrong_owner': owner_name})
                violations.append("Dir %s owned not by %s, but by %s"
                                  % (dr, agreeduser, owner_name))

            # now check permissions
            # else:
            permfailed = perm_violation(obj=dr, refperms=agreedperms,
                                        mode=mode)
            if permfailed:
                ret[dr].append({'problem': 'permissions',
                                'perms': permfailed})
                violations.append("Dir %s permissions: %s"
                                  % (dr, permfailed))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean

    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.4.2.1

def SSAA_FTPUSERS(osrname='/etc/vsftpd/ftpusers', contains="root"):
    '''
        ----------------
            REQ_ID: 53
        ----------------

        /etc/ftpusers (or /etc/vsftpd.ftpusers for vsftpd)
            - if file exists, root ID must exist in file

    '''

    checkname = inspect.stack()[0][3]

    violations = []
    ret = {}

    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "That is contains the user root, to block FTP access"
    if os.path.isfile(osrname):
        result = lookline_in_file(
            afile=osrname,
            thevalues=contains,
            commentchr='#', case="sensitive")
        if not result:
            violations.append('Directive MISSING')
            ret[osrname] = []
            ret[osrname].append(
                "FS object %s does not contain the search strings" % (osrname))
            ret[osrname].append(
                {'problem': 'File Contents must contain root, so user is blocked from ftp access'})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    return violations

# IZ.1.5.4.2
def NWSET_RLOGIN(osrnames=['/etc/pam.d/rlogin', '/etc/pam.d/rsh'],
                 searchstrings="auth      sufficient  /lib/security/pam_rhosts_auth.so no_hosts_equiv"):
    '''
        ----------------
            REQ_ID: 70
        ----------------

        /etc/pam.d/rlogin, /etc/pam.d/rsh
            If the files exist contain a /lib/security/pam_rhosts_auth.so line,
            the line should also contain "no_hosts_equiv" parameter
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "For pam_rhost_auth.so and no_hosts_equiv strings"
    violations = []
    ret = {}
    for osr in osrnames:
        descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
            "For pam_rhost_auth.so and no_hosts_equiv strings"
        if os.path.isfile(osr):
            # for directive in searchstrings:
            #    print "Searching ...." + directive
            search_key = searchstrings
            result = lookline_in_file(
                afile=osr,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                violations.append(osr)
                ret[osr] = []
                ret[osr].append(
                    "FS object %s does not contain the search strings" % (osr))
                ret[osr].append(
                    {'problem': 'File Contents must contain pam_rhost_auth.so and no_hosts_equiv strings'})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.5.4.1
def NWSET_HOSTS_EQUIV(osrname='/etc/hosts.equiv', mustexist=False):
    '''
        -------------------
            REQ_ID: 69
        -------------------

        /etc/hosts.equiv - Should either not exist or it should be empty
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "Should NOT Exist on the system"

    violations = []
    ret = {}
    if os.path.isfile(osrname):
        if os.path.getsize(osrname) > 0:
            violations.append(
                "FS object %s has a length greater than zero" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'File Contents should be empty'})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.2.2
def AUDIT_EXIST_WTMP(osrname='/var/log/wtmp', mustexist=True):
    '''
        -------------------
            REQ_ID: 66
        -------------------

        /var/log/wtmp - must exist
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "Should Exist on the system"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.2.1.4.2
def AUDIT_SYSLOG(osrname='/etc/rsyslog.conf',
                 audits=['*.info;mail.none;authpriv.none;cron.none                /var/log/messages',
                         'authpriv.*                                              /var/log/secure'],
                 by_regex=''):
    '''
        -------------------
            REQ_ID: 62
        -------------------

        /etc/syslog.conf:
            - Ensure audit controls in place with strings
            - audits=['*.info;mail.none;authpriv.none;cron.none /var/log/messages', 'authpriv.* /var/log/secure']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Directives %s are within  %s"\
        % (' and '.join(audits), osrname)

    violations = []
    if os.path.isfile(osrname):
        for directive in audits:
            check_for_line = lookline_in_file(
                afile=osrname, thevalues=directive)
            if not check_for_line:
                violations.append(directive)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.2.5

def AUDIT_EXIST_SECURE(osrname='/var/log/secure', mustexist=True):
    '''
        -------------------
            REQ_ID: 64_2
        -------------------

        /var/log/secure - must exist
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "Should Exist on the system"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.2.3.1

def AUDIT_EXIST_MSG(osrname='/var/log/messages', mustexist=True):
    '''
        -------------------
            REQ_ID: 64_1
        -------------------

        /var/log/messages - must exist
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "Should Exist on the system"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))


def AUDIT_EXIST_FAILLOG(osrname='/var/log/faillog', mustexist=True):
    '''
        -------------------
            REQ_ID: 67
        -------------------

        /var/log/faillog - 	Must exist for all systems NOT using pam_tally2.so
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "Should Exist on the system, if pam_tally2 not enabled"

    violations = []
    ret = {}
    bb = pam_tally2_used()
    if not pam_tally2_used():  # check N/A
        if not os.path.isfile(osrname):
            if mustexist:
                violations.append("FS object %s not found" % (osrname))
                ret[osrname] = []
                ret[osrname].append({'problem': 'missing'})
    else:
        log_audit(descr, "SKIP",
                  details="PAM_TALLY2 Enabled, failog skipping ....")
        return violations

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.2.4.2

def AUDIT_EXIST_TALLYLOG(osrname='/var/log/tallylog', mustexist=True):
    '''
        -------------------
            REQ_ID: 68
        -------------------

        /var/log/tallylog -	Must exist for all systems NOT using pam_tally2.so
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "Should Exist on the system"

    violations = []
    ret = {}
    bb = pam_tally2_used()
    if pam_tally2_used():  # check N/A
        if not os.path.isfile(osrname):
            if mustexist:
                violations.append("FS object %s not found" % (osrname))
                ret[osrname] = []
                ret[osrname].append({'problem': 'missing'})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.8.14.1/ IZ.1.8.15.1

def OSR_CRON_CMD(osrnames=['/var/spool/cron/root', '/var/spool/cron/tabs/root', '/etc/crontab'],
                 mustexist=False):
    '''
        -------------------
         REQ_ID: 48_2_3_4
        -------------------

        Entries in /var/spool/cron/root, /var/spool/cron/tabs/root, /etc/crontab
            - should start with a / to show fully qualified path
    '''

    checkname = inspect.stack()[0][3]
    violations = []
    ret = {}
    descr = format_nicely(
        checkname) + "Entries in /var/spool/cron/root, /var/spool/cron/tabs/root, /etc/crontab should start with /"
    for osrname in osrnames:
        if os.path.isfile(osrname):
            descr = format_nicely(checkname) + \
                "Entries in %s: " % (osrname) + "should start with /"

            with open(osrname) as f:
                lines = f.readlines()
            validlines = [ln for ln in lines if len(
                ln.strip().split(' ')) > 4 and not ln.strip().startswith('#')]

            for line in validlines:
                first_char_command = line.split()[-1]
                print(first_char_command)
                if first_char_command != '/':
                    violations.append("FS object %s has commands not starting with /"
                                      % (osrname))
                    ret[osrname] = []
                    ret[osrname].append('INVALID COMMAND IN ' + osrname)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))


def OSR_CRON_D_CMD(osrdir='/etc/cron.d'):
    '''
        ----------------
          REQ_ID: 48_5
        ----------------

        Files in /etc/cron.d should have commands
            - should start with a / to show fully qualified path
    '''

    checkname = inspect.stack()[0][3]
    violations = []
    ret = {}

    descr = format_nicely(checkname) + \
        "Entries in %s: " % (osrdir) + "should start with /"
    onlyfiles = [f for f in os.listdir(
        osrdir) if os.path.isfile(os.path.join(osrdir, f))]

    for filename in onlyfiles:
        full_path = os.path.join(osrdir, filename)
        with open(full_path) as f:
            lines = f.readlines()

        validlines = [ln for ln in lines if len(
            ln.strip().split(' ')) > 4 and not ln.strip().startswith('#')]
        for line in validlines:
            array_char_command = line.split()[-1]
            first_char_command = array_char_command[0]

            if first_char_command != '/':
                violations.append("FS object %s has commands not starting with /"
                                  % (full_path))
                ret[full_path] = []
                ret[full_path].append('INVALID COMMAND IN ' + full_path)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

     # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))


def OSR_INITTAB_CMD(osrname='/etc/inittab'):
    '''
        ----------------
          REQ_ID: 48_1
        ----------------

        Entries in /etc/inittab
            - should start with a / to show fully qualified path
    '''

    checkname = inspect.stack()[0][3]
    violations = []
    ret = {}
    descr = format_nicely(checkname) + \
        "Entries in %s: " % (osrname) + "should start with /"

    if os.path.isfile(osrname):
        descr = format_nicely(checkname) + \
            "Entries in %s: " % (osrname) + "should start with /"
        with open(osrname) as f:
            lines = f.readlines()
        validlines = [ln for ln in lines if len(
            ln.strip().split(':')) > 4 and not ln.strip().startswith('#')]

        for line in validlines:
            first_char_command = line.split()[-1]
            print(first_char_command)
            if first_char_command != '/':
                violations.append("FS object %s has commands not starting with /"
                                  % (osrname))
                ret[full_path] = []
                ret[full_path].append('INVALID COMMAND IN ' + full_path)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))


def OSR_XINETD_D_CMD(osrdir='/etc/xinetd.d'):
    '''
        ----------------
            REQ_ID: ???
        ----------------

        Files in /etc/xinetd.d should have commands
            - should start with a / to show fully qualified path
    '''

    checkname = inspect.stack()[0][3]
    violations = []
    ret = {}

    descr = format_nicely(checkname) + \
        "Entries in %s: " % (osrdir) + "should start with /"
    onlyfiles = [f for f in os.listdir(
        osrdir) if os.path.isfile(os.path.join(osrdir, f))]
    for filename in onlyfiles:
        full_path = os.path.join(osrdir, filename)

        with open(full_path) as f:
            lines = f.readlines()

        validlines = [ln.strip()
                      for ln in lines if not ln.strip().startswith('#')]
        for line in validlines:
            # print "evaluating line " + line
            if "server " in line:
                server_cmd = line.strip().split("=")
                first_char_command = server_cmd[1][1].lstrip()

                if first_char_command != '/':
                    violations.append("FS object %s has commands not starting with /"
                                      % (full_path))
                    ret[full_path] = []
                    ret[full_path].append('INVALID COMMAND IN ' + full_path)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))


def OSR_XINETD_CMD(osrname='/etc/xinetd.conf'):
    '''
        ----------------
          REQ_ID: 48_6
        ----------------

        Entries in /etc/xinetd.conf
            - should start with a / to show fully qualified path
    '''

    checkname = inspect.stack()[0][3]
    violations = []
    ret = {}
    descr = format_nicely(checkname) + \
        "Entries in %s: " % (osrname) + "should start with /"
    if os.path.isfile(osrname):
        descr = format_nicely(checkname) + \
            "Entries in %s: " % (osrname) + "should start with /"
        with open(osrname) as f:
            lines = f.readlines()
        validlines = [ln for ln in lines if not ln.strip().startswith('#')]

        for line in validlines:
            if "server" in line:
                server_cmd = line.split("=")
                first_char_command = server_cmd[1][1].lstrip()
                if first_char_command != '/':
                    violations.append("FS object %s has commands not starting with /"
                                      % (full_path))
                    ret[full_path] = []
                    ret[full_path].append('INVALID COMMAND IN ' + full_path)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))


# IZ.1.1.4.5
def AUTH_NO_NULL_PASS(osrnames=['/etc/pam.d/system-auth','/etc/pam.d/password-auth'],
                      directives=['auth pam_unix.so nullok',
                                  'password pam_unix.so nullok']):
    '''
        RHEL:
            - /etc/pam.d/system-auth:
                - auth pam_unix.so nullok
                - password pam_unix.so nullok
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'The nullok should be removed from' + \
        ' /etc/pam.d/system-auth and /etc/pam.d/password-auth from password and auth lines '

    violations = []
    ret = {}
    for osrname in osrnames:
        if not os.path.isfile(osrname):
            violations.append('%s: file MISSING' % (osrname))
            ret = {'FILE_NOT_FOUND': osrname}
            directives = []  # for skipping the loop

        else:
            for directive in directives:
                # 1st and 2nd element
                search_key = ' '.join(directive.split()[0:2:1])
                result = lookline_in_file(
                    afile=osrname,
                    thevalues=search_key,
                    commentchr='#', case="sensitive")
                if not result:
                    if 'MISSING_DIRECTIVES' not in ret.keys():
                        ret['MISSING_DIRECTIVES'] = []

                    violations.append("Directive MISSING: %s" % (directive))
                    ret['MISSING_DIRECTIVES'].append(search_key)
                else:  # found the directive
                    for crtline in result:
                        directive_list = directive.split()
                        crt_values = crtline.split()
                        # missing will contain value nullok, if not present in current line
                        missing = set(directive_list).difference(set(crt_values))
                        pam_flag_not_needed = directive.split()[2]
                        if not missing:
                            # pam_flag_not_needed(nullok) in the current line, remove it
                            if pam_flag_not_needed not in missing:
                                # remove  the nullok from currentline
                                crt_values.remove(pam_flag_not_needed)
                                # join back the values post removal
                                new_line = ' '.join(crt_values)
                                if 'BAD_PARAM_DIRECTIVES' not in ret.keys():
                                    ret['BAD_PARAM_DIRECTIVES'] = []
                                violations.append("BAD_PARAM_DIRECTIVES: with %s" % (
                                    crtline + ":" + new_line))
                                ret['BAD_PARAM_DIRECTIVES'].append(
                                    crtline + ":" + new_line)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret


# IZ.1.2.1.4.1
def AUDIT_RSYSLOG(agreedvalue='rsyslog'):
    '''
            - Ensure agreedvalue is installed and enabled (rsyslog or  syslog-ng)
            - agreedvalue='rsyslog'
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'Ensure %s is installed and enabled' % (agreedvalue)

    violations = []

    cmd = "rpm -q " + agreedvalue
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %
                          (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        violations.append("Agreed to values not installed")
    else:
        cmd = "systemctl is-enabled " + agreedvalue
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %
                          (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        violations.append("Agreed to values not enabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.2.1.4.3
def AUDIT_RSYSLOG_SECURE(osrnames=[
                         '/etc/rsyslog.conf',
                         '/etc/rsyslog.d/'],
                         searchstrings="FileCreateMode"):
    '''
            In /etc/rsyslog.conf', '/etc/rsyslog.d/*.conf'
            - Ensure that log files have the correct permissions to ensure \
            that sensitive data is archived and protected
            - searchstrings='$FileCreateMode' is 0640 or more restrictive
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Search strings %s are within  %s"\
        % (searchstrings, ' and '.join(osrnames))

    violations = []
    new_osrnames = []

    osr_names = list_files_in_dir_with_extension(
        osrnames[1], extension='.conf')
    if osr_names:
        for osr_name in osr_names:
            new_osrnames.append(osr_name)
    new_osrnames.append(osrnames[0])

    for osr in new_osrnames:
        descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
            "$FileCreateMode is 0640 or more restrictive"
        if os.path.isfile(osr):
            search_key = searchstrings
            result = lookline_in_file(
                afile=osr,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                violations.append('Line not found in file %s' % (osr))
            else:
                for crtline in result:
                    crt_value = crtline.split()[1]
                    if crt_value != '0640':
                        permissions = [x for x in crt_value]
                        if permissions[1] > 6 or permissions[2] > 4 or permissions[3] > 0:
                            violations.append(
                                '$FileCreateMode is set to %s in file %s' % (crt_value, osr))
        else:
            violations.append('%s: file MISSING' % (osr))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.1.13.4
def AUTH_PASS_USE_PAM(osrname='/etc/ssh/sshd_config',
                      searchstrings='UsePAM'):
    '''
            In /etc/ssh/sshd_config
            - Prevent ssh login from bypassing pam by setting "UsePAM yes"
            - searchstrings="UsePAM"
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Search strings %s are within  %s"\
        % (searchstrings, osrname)

    violations = []

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
    else:
        descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
            "for UsePAM yes"
        search_key = searchstrings
        result = lookline_in_file(
            afile=osrname,
            thevalues=search_key,
            commentchr='#', case="sensitive")
        if not result:
            violations.append('Line not found in file %s' % (osrname))
        else:
            for crtline in result:
                crt_value = crtline.split()[1]
                if crt_value != 'yes':
                    violations.append(
                        'UsePAM is set to %s in file %s' % (crt_value, osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#  AD.1.2.6
def AUDIT_SYSLOG_ROTATE(osrname='/etc/logrotate.d/syslog',
                        searchstrings=['monthly', 'daily',
                                       'hourly', 'weekly', 'yearly'],
                        logrotatevalue='rotate 30',
                        searchline='sharedscripts'):
    '''
            In /etc/logrotate.d/syslog
            - Log record rotation time frame should be set to 3 months, and replace if any other
            - searchstrings= ['monthly', 'daily', 'hourly', 'weekly', 'yearly'],
            - logrotatevalue= 'rotate 30'
            - searcline='sharedscripts' (line after which rotation values are added)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Log record retention is set to %s %s are within  %s"\
        % (searchstrings[0], logrotatevalue, osrname)

    violations = []
    present = []

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
    else:
        descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
            "for %s and %s" % (searchstrings[0], logrotatevalue)
        for search_string in searchstrings:
            result = lookline_in_file(afile=osrname,
                                      thevalues=search_string,
                                      commentchr='#', case="sensitive")
            if result:
                present.append(search_string)

        if len(present) == 0:
            violations.append('Line not found in file %s' % (osrname))

        else:
            for logrotate_type in present:
                if searchstrings[0] in logrotate_type:
                    # check rotate 30 else add rotate 30 or if any other rotate replace rotate 30
                    search_key = logrotatevalue.split()[0]
                    result = lookline_in_file(afile=osrname,
                                              thevalues=search_key,
                                              commentchr='#', case="sensitive")
                    if not result:
                        violations.append(
                            'Rotate Missing in file %s' % (osrname))
                    else:
                        for entry in result:
                            if logrotatevalue not in entry:
                                violations.append(
                                    'Replace Rotate 30 to %s' % (entry))

                else:
                    # override search string with monthly and  # check rotate 30 else add rotate 30 or if any other rotate replace rotate 30
                    search_key = logrotatevalue.split()[0]
                    result = lookline_in_file(afile=osrname,
                                              thevalues=search_key,
                                              commentchr='#', case="sensitive")

                    if not result:
                        violations.append('Monthly and Rotate not found in file %s replace %s' % (
                            osrname, logrotate_type))
                    else:
                        for entry in result:
                            if logrotatevalue not in entry:
                                violations.append(
                                    'Replace Monthly Rotate replace %s and %s' % (logrotate_type, entry))
                            else:
                                violations.append(
                                    'Replace Monthly Only replace %s' % (logrotate_type))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.2.7.1
def AUDIT_SYNC_CLOCK():
    '''
    - Ensure ntpd or chronyd must be running.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure clock synchronization is active'

    violations = []
     
    cmd_out =  subprocess.getoutput("systemctl status ntpd | grep active")
    print(cmd_out)
    if "Active: active (running)" not in cmd_out:
      cmd_out =  subprocess.getoutput("systemctl status chronyd | grep active")
      print(cmd_out)
      if "Active: active (running)" not in cmd_out:
          violations.append("No clock synchronization is active")
    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# Workaround for  IZ.1.2.7.1
def AUDIT_SYNC_CLOCK_WORKAROUND():
    '''
    - Ensure ntpd or chronyd must be running.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure clock synchronization is active'

    violations = []
    cmd = "systemctl start chronyd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Unable to execute command to restart chronyd service")
    else:
        print("Restarted chronyd service")
    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.2.7.2
def AUDIT_CHRONY_SERVER(osrname='/etc/chrony.conf',
                        searchstrings=['server', 'pool']):
    '''
        In /etc/chrony.conf
        -  ensure it has minimum required configuration:
            At least one pool or server is specified.
        - searchstrings=['server', 'pool']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure at least one pool or server is specified"\
        " within  %s" % (osrname)

    violations = []
    present = []

    cmd = "systemctl status chronyd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %
                          (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        violations.append("CHRONYD is not active")

    elif not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
    else:
        descr = format_nicely(checkname) + "Ensure at least one pool or server is specified"\
            " within  %s" % (osrname)
        for searchstring in searchstrings:
            result = lookline_in_file(afile=osrname,
                                      thevalues=searchstring,
                                      commentchr='#', case="sensitive")
            if result:
                present.append(searchstring)

        if len(present) == 0:
            violations.append('Line not found in file %s' % (osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.2.7.3
def AUDIT_CHRONY_NOEXCESSPRIV():
    '''
    - Ensure chrony has least privilege configuration
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'Ensure chrony has least privilege configuration'

    violations = []

    cmd = "systemctl status chronyd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %
                          (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        violations.append("CHRONYD is not active")

    else:
        cmd = "ps -u chrony"
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" % (
                str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] == b'' or 'chronyd' not in str(cmd_exec['cmd_out']):
            violations.append("No task is running as chrony id")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.2.7.4
def AUDIT_NTPD_SECURE(osrname='/etc/ntp.conf',
                      directives=['restrict -4 default kod nomodify notrap nopeer noquery',
                                  'restrict -6 default kod nomodify notrap nopeer noquery']):
    '''
        In /etc/ntp.conf
        - set key defaults for both ip4 and ip6 to:
          nomodify notrap nopeer noquery
        - directives ['restrict -4 default kod nomodify notrap nopeer noquery',
                      'restrict -6 default kod nomodify notrap nopeer noquery']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Key defaults for both ipv4 and ipv6 are"\
        " within  %s" % (osrname)

    violations = []

    cmd = "systemctl status ntpd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %
                          (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        violations.append("NTPD is not active")

    elif not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
    else:
        descr = format_nicely(checkname) + "Key defaults for both ipv4 and ipv6 are"\
            " within  %s" % (osrname)
        for directive in directives:
            search_key = ' '.join(directive.split()[0:2:1])
            result = lookline_in_file(afile=osrname,
                                      thevalues=search_key,
                                      commentchr='#', case="sensitive")
            if result:
                for crtline in result:
                    search_key = ' '.join(directive.split()[2:8:1])
                    if search_key not in crtline:

                        violations.append(
                            'key default missing, override the line %s' % (crtline))

            else:
                violations.append('%s line not found in file %s' %
                                  (directive, osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.2.7.5

def AUDIT_NTPD_SERVER(osrname='/etc/ntp.conf',
                      searchstrings=['server', 'pool']):
    '''
        In /etc/ntp.conf
        -  ensure it has minimum required configuration:
            At least one pool or server is specified.
        - searchstrings=['server', 'pool']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure at least one pool or server is specified"\
        " within  %s" % (osrname)

    violations = []
    present = []

    cmd = "systemctl status ntpd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %
                          (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        violations.append("NTPD is not active")

    elif not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
    else:
        descr = format_nicely(checkname) + "Ensure at least one pool or server is specified"\
            " within  %s" % (osrname)
        for searchstring in searchstrings:
            result = lookline_in_file(afile=osrname,
                                      thevalues=searchstring,
                                      commentchr='#', case="sensitive")
            if result:
                present.append(searchstring)

        if len(present) == 0:
            violations.append('Line not found in file %s' % (osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations



#IZ.1.1.1.3
def AUTH_SHADOWF3(osrname='/etc/shadow',
                  fieldno=3):

    '''

        /etc/shadow
            - Field 3 must be a date in the past
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking if field no %s in %s indicates a date from the past" \
            % (fieldno, osrname)

    #Get the time in seconds and number of days since the epoch
    seconds_since_epoch = time.time()
    days_since_epoch = seconds_since_epoch/86400

    #check if all the days mentioned in file are less than the current number of days
    violations = check_date_field_in_file(afile=osrname, fieldno=fieldno,
                                    refval=days_since_epoch, delim=':')

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.2.1
def AUTH_SHADOWF2(osrname='/etc/shadow',
                  fieldno=2):

    '''

        /etc/shadow
            - Field 2 must not be null
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking if field no %s in %s is null" \
            % (fieldno, osrname)

    violations = check_null_field_in_file(afile=osrname, fieldno=fieldno, delim=':')

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.2.2
def AUTH_PASSWDF2(osrname='/etc/passwd',
                  fieldno=2):

    '''

        /etc/passwd
            - Field 2 must not be null
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking if field no %s in %s is null" \
            % (fieldno, osrname)

    violations = check_null_field_in_file(afile=osrname, fieldno=fieldno, delim=':')

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.8.3.2
def AUTH_PASSWD_GROUP(osrnames = ['/etc/passwd', '/etc/group'], fieldno=4):

    '''

        All the GIDs from /etc/passwd should be present in /etc/group
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking if all GIDs from /etc/passwd are present in /etc/group."

    #Get a list of GIDs from the /etc/passwd file
    passwd_file_groups = get_list_of_field_value(afile=osrnames[0], fieldno=fieldno, delim=':')

    violations = []

    for i in passwd_file_groups:
        cmd = 'grep -q -P "^.*?:[^:]*:' + i + ':" ' + osrnames[1]
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %
                              (str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_ret'] == 0:
            continue;
        elif cmd_exec['cmd_ret'] != 0:
            violations.append("The GID:" + i + " is present in /etc/passwd but not in /etc/group.")


    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.10.1
def AUTH_PASSWD_NON_LOGIN(osrname='/etc/passwd',  fieldno=7):

    '''
        Login shell attribute in /etc/passwd should be set to /bin/false or /sbin/nologin,
    for the accounts that are not being used by regular users
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking if login shell attribute in /etc/passwd is set to /bin/false or /sbin/nologin, for the accounts that are not being used by regular users"
    delim = ':'
    violations = {}

    with open(osrname) as f:
        for num, line in enumerate(f, 1):

            vals = line.strip().split(delim)

            if(vals[0] != 'root' and int(vals[2]) < 1000 and vals[6] != '/sbin/nologin' and vals[6] != '/bin/false' ):
                violations["line " + str(num)] = line

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.39
def SAMBA_SERVICE():
    '''
        Ensure that the SAMBA(smb) service is disabled
    '''

    service_name = "smb"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.40
def RSH_CLIENT():
    '''
        Ensure that RSH Client is not installed
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that the rsh client is not installed"

    violations = []

    if generic_check_if_package_installed("rsh"):
        violations.append("rsh client is installed")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.41
def TALK_CLIENT():
    '''
        Ensure that talk Client is not installed
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that the talk client is not installed"

    violations = []

    if generic_check_if_package_installed("talk"):
        violations.append("talk client is installed")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#   IZ.1.5.11.1
def RLOGIN_SERVICE():
    '''
        Ensure that rlogin service is disabled
    '''

    service_name = "rlogin.socket"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#   IZ.1.5.11.2
def RSH_SERVICE():
    '''
        Ensure that rsh service is disabled
    '''

    service_name = "rsh.socket"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#   IZ.1.5.11.3
def REXEC_SERVICE():
    '''
        Ensure that rexec service is disabled
    '''

    service_name = "rexec.socket"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations



# IZ.1.5.9.34
def RSYNC_SERVICE():
    '''
        Ensure that the RSYNC(rsyncd) service is disabled
    '''

    service_name = "rsyncd"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.35
def CUPS_SERVICE():
    '''
        Ensure that the CUPS(cups) service is disabled
    '''

    service_name = "cups"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.36
def DHCP_SERVICE():
    '''
        Ensure that the DHCP(dhcpd) service is disabled
    '''

    service_name = "dhcpd"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.37
def DNS_SERVICE():
    '''
        Ensure that the DNS(named) service is disabled
    '''

    service_name = "named"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.38
def HTTP_SERVICE():
    '''
        Ensure that the HTTP(httpd) service is disabled
    '''

    service_name = "httpd"
    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that the {} service is disabled".format(format_nicely(checkname), service_name)

    violations = []

    if generic_check_if_service_enabled(service_name):
        violations.append("Service {} is enabled".format(service_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.13.1
def NET_COREDUMPS(osrnames=['/etc/security/limits.conf', '/etc/security/limits.d/', '/etc/sysctl.conf'],
                  searchstrings=['* hard core 0', 'fs.suid_dumpable = 0']):
    '''
            - Ensure core dumps are restricted
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'Ensure core dumps are restricted'

    violations = []
    new_osrnames = []

    if os.path.isfile(osrnames[0]):
        search_key = searchstrings[0]
        result = lookline_in_file(afile=osrnames[0],
                                  thevalues=search_key,
                                  commentchr='#', case="sensitive")
        if not result:
            violations.append('Line not found in limits file %s' % (osrnames[0]))
        else:
            osr_names = list_files_in_dir_with_extension(
                osrnames[1], extension='')
            if osr_names:
                for osr_name in osr_names:
                    new_osrnames.append(osr_name)
                for osr in new_osrnames:
                    if os.path.isfile(osr):
                        search_key = "core"
                        result = lookline_in_file(afile=osr,
                                                  thevalues=search_key,
                                                  commentchr='#', case="sensitive")
                        if result:
                            result = lookline_in_file(afile=osr,
                                                      thevalues=searchstrings[0],
                                                      commentchr='#', case="sensitive")
                            if not result:
                                violations.append('Line not found in limits file %s' % (osr))
    else:
        violations.append('%s: file MISSING' % (osrnames[0]))

    cmd = "sysctl fs.suid_dumpable"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" % (
            str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] == 'fs.suid_dumpable = 0' not in str(cmd_exec['cmd_out']):
        violations.append("Core dumps are not restricted")

    if os.path.isfile(osrnames[2]):
        search_key = searchstrings[1]
        result = lookline_in_file(afile=osrnames[2],
                                  thevalues=search_key,
                                  commentchr='#', case="sensitive")
        if not result:
            violations.append('Line not found in sysctl file %s' % (osrnames[2]))
    else:
        violations.append('%s: file MISSING' % (osrnames[2]))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.13.2
def NET_ASLR(osrname='/etc/sysctl.conf',
             searchstring='kernel.randomize_va_space = 2'):
    '''
            - Ensure address space layout randomization (ASLR) is enabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'Ensure address space layout randomization (ASLR) is enabled'

    violations = []

    cmd = "sysctl kernel.randomize_va_space"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" % (
            str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] == 'kernel.randomize_va_space = 2' not in str(cmd_exec['cmd_out']):
        violations.append("ASLR is not enabled")

    if os.path.isfile(osrname):
        result = lookline_in_file(afile=osrname,
                                  thevalues=searchstring,
                                  commentchr='#', case="sensitive")
        if not result:
            violations.append('Line not found in file %s' % (osrname))
    else:
        violations.append('%s: file MISSING' % (osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.3.4
def OSR_BOOTLOADER_BOOT(osrname='/boot',
                        agreedperms='0555',
                        mode='exact',
                        category='all',
                        agreeduser='root',
                        agreedgroup='root'):
    '''
            - /boot: Settings must be dr-xr-xr-x or more restrictive
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions for '/boot' should be dr-xr-xr-x or or more restrictive"

    violations = []
    ret = {}

    if not os.path.isdir(osr):
        violations.append("FS object %s not found" % (osr))
        ret[osr] = []
        ret[osr].append({'problem': 'missing'})
    else:
        ret[osr] = []
        # first, check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object owned not by %s, but by %s"
                                  % (agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership',
                                 'rightful_owner': agreeduser,
                                 'wrong_owner': owner_name})
        if agreedgroup:
            agreedgid = grp.getgrnam(agreedgroup).gr_gid
            group_id = os.stat(osr).st_gid
            group_name = grp.getgrgid(group_id).gr_name
            if group_id != agreedgid:
                violations.append("FS object owned not by group %s, but by %s"
                                  % (agreedgroup, group_name))
                ret[osr].append({'problem': 'groupownership',
                                 'rightful_group': agreedgroup,
                                 'wrong_group': group_name})
        # now check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode, category=category)
        if permfailed:
            violations.append("FS object permissions: %s" % (permfailed))
            ret[osr].append({'problem': 'permissions',
                             'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))


# IZ.1.8.3.5
def OSR_BOOTLOADER_GRUB(osrnames=['/boot/grub2/grub.cfg', '/boot/grub2/user.cfg'],
                        agreedperms='0600',
                        mode='exact',
                        category='all',
                        agreeduser='root',
                        agreedgroup='root'):
    '''
            - Ensure permissions on bootloader config are configured
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'Ensure permissions on bootloader config are configured'

    violations = []
    ret = {}

    for osr in osrnames:
        if not os.path.isfile(osr):
            log_audit('%s: file MISSING' % (osr))
        else:
            ret[osr] = []
            # first, check ownership
            if agreeduser:
                agreeduid = pwd.getpwnam(agreeduser).pw_uid
                owner_id = os.stat(osr).st_uid
                owner_name = pwd.getpwuid(owner_id).pw_name
                if owner_id != agreeduid:
                    violations.append("File owned not by %s, but by %s"
                                      % (agreeduser, owner_name))
                    ret[osr].append({'problem': 'ownership',
                                     'rightful_owner': agreeduser,
                                     'wrong_owner': owner_name})
            if agreedgroup:
                agreedgid = grp.getgrnam(agreedgroup).gr_gid
                group_id = os.stat(osr).st_gid
                group_name = grp.getgrgid(group_id).gr_name
                if group_id != agreedgid:
                    violations.append("File owned not by group %s, but by %s"
                                      % (agreedgroup, group_name))
                    ret[osr].append({'problem': 'groupownership',
                                     'rightful_group': agreedgroup,
                                     'wrong_group': group_name})
            # now check permissions
            permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                        mode=mode, category=category)
            if permfailed:
                violations.append("File permissions: %s" % (permfailed))
                ret[osr].append({'problem': 'permissions',
                                 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))


# iz.1.5.5
def NET_DISABLE_REXD():
    '''
     - Ensure rexd is disabled.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure rexd is disabled'

    violations = []

    cmd = "chkconfig --list --type xinetd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for line in cmd_exec['cmd_out'].splitlines():
            if 'rexd' in str(line):
                violations.append("rexd present in chkconfig, need to be disabled")

    cmd = "rpcinfo"
    cmd_exec = execute_command(cmd, shell=True)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for line in cmd_exec['cmd_out'].splitlines():
            if 'rexd' in str(line):
                violations.append("rexd present in chkconfig, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.7
def NET_DISABLE_XWIN():
    '''
    - Ensure X Windows is not installed using xorg-x11.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'Ensure X Windows is not installed using xorg-x11'

    violations = []

    cmd = "rpm -qa xorg-x11*"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        violations.append("xorg-x11* is installed, remove it")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.1
def NET_DISABLE_ECHO(directives=['echo-dgram: off', 'echo-stream: off']):
    '''
        -  Ensure if xinetd is enabled directives are present in off state
        - directives=['echo-dgram: off', 'echo-stream: off']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "If xinetd is enabled, ensure %s are"\
        " present chkconfig --list " % (' '.join(directives))

    violations = []
    present = []

    cmd = "chkconfig --list --type xinetd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for directive in directives:
            for line in cmd_exec['cmd_out'].splitlines():
                if directive.split()[0] in str(line) and directive.split()[1] in str(line):
                    present.append(directive)

        if len(present) == 0:
            violations.append("Both directives MISSING %s" % (directives))
        elif len(present) == 1:
            violations.append("Only single directive present %s" % (present))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.2
def NET_DISABLE_CHARGEN(directives=['chargen-dgram: off', 'chargen-stream: off']):
    '''
        -  Ensure if xinetd is enabled directives are present in off state
        - directives=['chargen-dgram: off', 'chargen-stream: off']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "If xinetd is enabled, ensure %s are"\
        " present chkconfig --list " % (' '.join(directives))

    violations = []
    present = []

    cmd = "chkconfig --list --type xinetd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for directive in directives:
            for line in cmd_exec['cmd_out'].splitlines():
                if directive.split()[0] in str(line) and directive.split()[1] in str(line):
                    present.append(directive)

        if len(present) == 0:
            violations.append("Both directives MISSING %s" % (directives))
        elif len(present) == 1:
            violations.append("Only single directive present %s" % (present))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.3
def NET_RSTATD_DISABLE():
    '''
            - Ensure rstatd is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure rstatd is disabled'

    violations = []

    cmd = "systemctl is-enabled rstatd.service"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("rusersd is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.3.3
def NFS_CONFIGURATION_NO_ROOT_SQUASH(osrname="/etc/exports", searchstrings="no_root_squash"):
    '''
        Check if NFS Configuration file contains no_root_squash
    '''

    checkname = inspect.stack()[0][3]
    descr = "{} Ensure that no NFS filesystem is being exported with '{}' " \
            "option via {} file".format(format_nicely(checkname),
                                        searchstrings,
                                        osrname)

    violations = []
    lines = []

    extra_check = ",{0,1}"

    # Checking if NFS exports file exists
    if os.path.isfile(osrname):
        lines = lookline_in_file(afile=osrname, by_regex="{}{}".format(extra_check, searchstrings))

        if lines:
            violations.append("One or more Filesystems are being exported with '{}' option".format(searchstrings))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return lines


# IZ.1.5.9.24.3
def VSFTPD_SERVICE_CONFIGURATION_FOR_ANON_FTP(osrnames=["/etc/vsftpd/vsftpd.conf", "/etc/vsftpd/user_list"],
                                              directives=None):
    '''
        Ensure VSFTPD service is properly configured (when anonymous ftp is enabled)
    '''

    checkname = inspect.stack()[0][3]
    descr = "{} Ensure VSFTPD service is properly configured with required " \
            "restrictions".format(format_nicely(checkname))

    violations = []
    all_results = {"error": None,
                   "file_details": {}
                   }

    # Checking if vsftpd service is enabled
    if generic_check_if_package_installed("vsftpd"):
        # Checking if configuration file exists
        if not os.path.exists("/etc/vsftpd/vsftpd.conf"):
            # Configuration file not found for vsftpd
            error_msg = "Configuration file not found for vsftpd at /etc/vsftpd/vsftpd.conf"
            violations.append(error_msg)
            all_results["error"] = error_msg

        else:
            # Check if anonymous FTP enabled.
            if lookline_in_file(afile="/etc/vsftpd/vsftpd.conf", thevalues="anonymous_enable=YES",
                                    case="insensitive", commentchr="#"):

                iterate_through = zip(osrnames, directives)

                for osrname, directive in iterate_through:
                    result = search_multiple_strings_in_file(filename=osrname,
                                                             search_strings = directive[1],
                                                             search_mode = directive[0],
                                                             comment_char = "#")

                    if result["missing_required_lines"]:
                        violations.append("Not all required lines are present in '{}'".format(osrname))

                    if result["disallowed_lines"]:
                        violations.append("Disallowed lines are present in '{}'".format(osrname))

                    all_results["file_details"][osrname] = result

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, all_results
    else:
        log_audit(descr, "PASS")
        return True, all_results


# IZ.1.5.9.4
def NET_DISABLE_TFTP(osrname='/etc/xinetd.d/tftp', directives=['tftp: off']):
    '''
        -  Ensure if xinetd is enabled directives are present in off state
        - directives=['tftp: off']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "If xinetd is enabled, ensure %s are"\
        " present chkconfig --list " % (' '.join(directives))

    violations = []
    present = []

    cmd = "chkconfig --list --type xinetd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for directive in directives:
            for line in cmd_exec['cmd_out'].splitlines():
                if directive.split()[0] in str(line) and directive.split()[1] in str(line):
                    present.append(directive)

        if len(present) == 0:
            violations.append("Directive MISSING %s" % (directives))
        #elif len(present) == 1:
        #    violations.append("Only single directive present %s" % (present))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.6
def NET_RUSERSD_DISABLE():
    '''
            - Ensure rusers is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure rusers is disabled'

    violations = []

    cmd = "systemctl is-enabled rusersd.service"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("rusersd is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.7
def NET_DISABLE_DISCARD(directives=['discard-dgram: off', 'discard-stream: off']):
    '''
        -  Ensure if xinetd is enabled directives are present in off state
        - directives=['discard-dgram: off', 'discard-stream: off']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "If xinetd is enabled, ensure %s are"\
        " present chkconfig --list " % (' '.join(directives))

    violations = []
    present = []

    cmd = "chkconfig --list --type xinetd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for directive in directives:
            for line in cmd_exec['cmd_out'].splitlines():
                if directive.split()[0] in str(line) and directive.split()[1] in str(line):
                    present.append(directive)

        if len(present) == 0:
            violations.append("Both directives MISSING %s" % (directives))
        elif len(present) == 1:
            violations.append("Only single directive present %s" % (present))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.8
def NET_DISABLE_DAYTIME(directives=['daytime-dgram: off', 'daytime-stream: off']):
    '''
        -  Ensure if xinetd is enabled directives are present in off state
        - directives=['daytime-dgram: off', 'daytime-stream: off']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "If xinetd is enabled, ensure %s are"\
        " present chkconfig --list " % (' '.join(directives))

    violations = []
    present = []

    cmd = "chkconfig --list --type xinetd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for directive in directives:
            for line in cmd_exec['cmd_out'].splitlines():
                if directive.split()[0] in str(line) and directive.split()[1] in str(line):
                    present.append(directive)

        if len(present) == 0:
            violations.append("Both directives MISSING %s" % (directives))
        elif len(present) == 1:
            violations.append("Only single directive present %s" % (present))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.9
def NET_BOOTPS_DISABLE():
    '''
            - Ensure bootps is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure bootps is disabled'

    violations = []

    cmd = "systemctl is-enabled dhcpd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("dhcpd is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#IZ.1.5.1.2
def NET_FTP_PERMS(osrnames= ['/var/ftp', '/etc/vsftpd/vsftpd.conf'],
                  directives = ['anonymous_enable=YES', 'anon_root = *']):
    '''
        - If anonymous ftp is enabled, then ftp home directory must be owned by root and only the owner should have write access.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'If anonymous ftp is enabled, then ftp home directory must be owned by root and only the owner should have write access.'

    violations = []

    cmd = 'systemctl is-enabled vsftpd'
    cmd_exec = execute_command(cmd)

    home_dir = osrnames[0]

    if cmd_exec['cmd_err']:
        violations.append("Unable to check the status for vsftpd")
    if cmd_exec['cmd_ret'] == 0:
        linefound = lookline_in_file(afile=osrnames[1], thevalues=directives[0], commentchr='#', case="sensitive")
        if (linefound):
            dirfound = lookline_in_file(afile=osrnames[1], by_regex=r'anon_root\s*=\s*.*$',
                                        commentchr='#', case="sensitive")
            if(dirfound):
                dir_split = dirfound[0].split("=")
                dir = dir_split[1]
                home_dir = dir.rstrip("\n")

        if (os.path.exists(home_dir) and os.path.isdir(home_dir)):
            mode = oct(os.stat(home_dir)[ST_MODE])[-3:]
            dir_perm = str(mode)
            if (path.exists(home_dir) and path.isdir(home_dir)):
                if (pwd.getpwuid(os.stat(home_dir).st_uid).pw_name != 'root'):
                    violations.append("%s directory owner is not root"  % (home_dir))
                if(dir_perm[1] == '2' or dir_perm[1] == '3' or dir_perm[1] == '6' or dir_perm[1] == '7'):
                    violations.append("%s directory group has write permission"  % (home_dir))
                if (dir_perm[2] == '2' or dir_perm[2] == '3' or dir_perm[2] == '6' or dir_perm[2] == '7'):
                    violations.append("%s directory other users have write permission"  % (home_dir))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#IZ.1.5.1.3
def NET_FTP_BIN_PERMS(osrnames= ['/var/ftp/bin', '/etc/vsftpd/vsftpd.conf'],
                  directives = ['anonymous_enable=YES', 'anon_root = *'], agreedperms='0111'):
    '''
        - If anonymous ftp is enabled, then bin subdirectory in ftp home directory must be owned by root and only the owner
           should have write access and the files present in bin directory should have '0111' permissions.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'If anonymous ftp is enabled, then ftp home directory must be owned by root and only the owner should have write access.'

    violations = []

    cmd = 'systemctl is-enabled vsftpd'
    cmd_exec = execute_command(cmd)

    bin_dir = osrnames[0]

    if cmd_exec['cmd_err']:
        violations.append("Unable to check the status for vsftpd")
    if cmd_exec['cmd_ret'] == 0:
        linefound = lookline_in_file(afile=osrnames[1], thevalues=directives[0], commentchr='#', case="sensitive")
        if (linefound):
            dirfound = lookline_in_file(afile=osrnames[1], by_regex=r'anon_root\s*=\s*.*$',
                                        commentchr='#', case="sensitive")
            if (dirfound):
                dir_split = dirfound[0].split("=")
                dir = dir_split[1]
                bin_dir = dir.rstrip("\n")
                bin_dir = bin_dir + '/bin'

        if(os.path.exists(bin_dir) and os.path.isdir(bin_dir)):
            mode = oct(os.stat(bin_dir)[ST_MODE])[-3:]
            dir_perm = str(mode)
            if (path.exists(bin_dir) and path.isdir(bin_dir)):
                if (pwd.getpwuid(os.stat(bin_dir).st_uid).pw_name != 'root'):
                    violations.append("%s directory owner is not root"  % (bin_dir))
                if(dir_perm[1] == '2' or dir_perm[1] == '3' or dir_perm[1] == '6' or dir_perm[1] == '7'):
                    violations.append("%s directory group has write permission"  % (bin_dir))
                if (dir_perm[2] == '2' or dir_perm[2] == '3' or dir_perm[2] == '6' or dir_perm[2] == '7'):
                    violations.append("%s directory other users have write permission"  % (bin_dir))

            drs = []
            drs.append(bin_dir)
            #permfailed = false
            files = list_files_in(drs, cond='os.access(%, os.F_OK)')
            if(files):
                for file in files:
                    permfailed = perm_violation(obj=file, refperms=agreedperms,
                                                mode='exact', category = 'all')
                    if permfailed:
                        violations.append("%s directory files do not have permissions %s" % (bin_dir, agreedperms))
                        break;


    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.28
def NET_DISABLE_XINETD():
    '''
        -  Ensure xinetd is disabled if no service is active under it
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure xinetd is disabled if no service is active under it"

    violations = []
    service_active = []
    ret = {}

    cmd = "chkconfig --list --type xinetd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        if 'CMD_ERR' not in ret.keys():
            ret['CMD_ERR'] = []
            ret['CMD_ERR'].append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] !=  b'':
        for line in cmd_exec['cmd_out'].splitlines():
            if 'on' in str(line):
                service_active.append(str(line.split()[0][:-1], 'utf-8'))


        if len(service_active) == 0:
            violations.append("xinetd is enabled, need to be disabled")
            if 'XINETD_ENABLED' not in ret.keys():
                ret['XINETD_ENABLED'] = []
                ret['XINETD_ENABLED'].append("xinetd is enabled, need to be disabled")


        if len(service_active) > 0:
            if 'SERVICES_ENABLED' not in ret.keys():
                ret['SERVICES_ENABLED'] = []
                ret['SERVICES_ENABLED'] = service_active.copy()
            violations.append("Services still active: %s, needs to be disabled" %(service_active))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret


# IZ.1.5.10.2
def AUDIT_NIS_MAPS(osrnames = ['/etc/passwd', '/etc/shadow', '/etc/group']):
    '''
        - Ensure NIS are legacy entries, should not be present in any
        - osrnames = ['/etc/passwd', '/etc/shadow', '/etc/group']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure NIS are legacy entries, '\
    'should not be present in %s'  % ( ' and '.join(osrnames))

    violations = []

    for osrname in osrnames:
        if os.path.isfile(osrname):
            cmd = "grep '^+:' " + osrname
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 1:
                violations.append("%s file contains NIS legacy entries, remove them" %(osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.3.2.2
def OSR_USR_RESTRICT(osrname='/usr',
                    agreeduser='root',
                    agreedgroup='root'):

    '''
        In /usr : all osr except /usr/local should be owned by
             user/group that are priviledged
        - osrname = '/usr'
        - agreeduser= 'root'
        - agreedgroup= 'root'
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking in %s: " % (osrname) + \
        "all osr except /usr/local should be owned by user/group that are priviledged"

    violations = []

    if not os.path.isdir(osrname):
        violations.append('%s: file MISSING' % (osrname))

    exception_dir = "/usr/local" # needs to to be an exception
    osr_list = list_osr(osrname, exception_dir, None)


    if len(osr_list)> 0:
        for osr in osr_list:
            if os.path.isfile(osr):
                #print(osr)
                user_id = os.stat(osr).st_uid
                #print(user_id)
                if not check_previledged_uid(user_id):
                    violations.append("%s osr is not owned by previledged user" %(osr))
                group_id = os.stat(osr).st_gid
                #print(group_id)
                if not check_previledged_gid(group_id):
                    violations.append("%s osr is not owned by previledged group" %(osr))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")


    return violations


# IZ.1.8.1.2
def OSR_OWNER_UID():
    '''
       - OSRs must be owned by one of the privileged IDs
         indicated in section AD.5.0.2 or AD.5.0.3
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "This techspec has been taken care "\
             "in AD.1.8.3.2.2 OSR_USR_RESTRICT"

    violations = []

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.1.3
def OSR_OWNER_GID():
    '''
       -  OSRs must be owned by one of the privileged
          group ids indicated in section 5.0.4
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "This techspec has been taken care "\
             "in AD.1.8.3.2.2 OSR_USR_RESTRICT"

    violations = []

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# AD.5.0.3
def PREVILEDGED_UID():
    '''
       -  A userid with a UID which is less than or equal to SYS_UID_MAX is
          considered privileged.
          If SYS_UID_MAX is not set, then a userid with a UID which is
          less than UID_MIN.
          Note: It is not valid for an OSR to be owned by a UID which
          does not have a userid defined to it with in /etc/passwd.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "This techspec has been taken care "\
             "in AD.1.8.3.2.2 OSR_USR_RESTRICT"

    violations = []

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# AD.5.0.4
def PREVILEDGED_GID():
    '''
       -  A userid with a UID which is less than or equal to SYS_UID_MAX is
          considered privileged.
          If SYS_UID_MAX is not set, then a userid with a UID which is
          less than UID_MIN.
          Note: It is not valid for an OSR to be owned by a UID which
          does not have a userid defined to it with in /etc/passwd.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "This techspec has been taken care "\
             "in AD.1.8.3.2.2 OSR_USR_RESTRICT"

    violations = []

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.9.1.3
def AUTH_IBMSINIT_SH(osrname='/etc/profile.d/IBMsinit.sh',
                     agreedperms='0755',agreedvalue='true'):
    '''
           - /etc/profile.d/IBMsinit.sh File must exists
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "file exists"
    violations = []

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.9.1.4
def AUTH_IBMSINIT_CSH(osrname='/etc/profile.d/IBMsinit.csh',
                      agreedperms='0755',agreedvalue='true'):
    '''
           - /etc/profile.d/IBMsinit.sh File must exists
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osrname) + \
        "file exists"
    violations = []

    cmd = "rpm -q tcsh"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" % (
            str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        log_audit("Package csh is not installed")
    else:
      if not os.path.isfile(osrname):
          violations.append('%s: file MISSING' % (osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.20.9
def AUDIT_REV_PATH_FILTER(osrnames=['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directives=["net.ipv4.conf.all.rp_filter = 1",
                                     "net.ipv4.conf.default.rp_filter = 1"]):
    '''
            In/etc/sysctl.conf', '/etc/sysctl.d/*'
            - Ensure utilization of reverse path filtering is set to 1
            - directives=["net.ipv4.conf.all.rp_filter",
                          "net.ipv4.conf.default.rp_filter"]
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Directives %s are within  %s"\
        % ( ' and '.join(directives), ' and '.join(osrnames))

    violations = []
    ret = {}
    new_osrnames = []

    osr_names = list_files_in_dir_with_extension(
        osrnames[1], extension='')
    if osr_names:
        for osr_name in osr_names:
            new_osrnames.append(osr_name)
    new_osrnames.append(osrnames[0])

    for directive in directives:
        cmd = "sysctl "+directive.split()[0]
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            if 'CMD_ERR' not in ret.keys():
                ret['CMD_ERR'] = []
            ret['CMD_ERR'].append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] == b'':
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []
            ret['MISSING_DIRECTIVES'].append(new_osrnames)
            violations.append("Directive MISSING: %s " % (directive))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if directive not in str(line):
                    if 'MISSING_DIRECTIVES' not in ret.keys():
                        ret['MISSING_DIRECTIVES'] = []
                    ret['MISSING_DIRECTIVES'].append(new_osrnames)
                    violations.append("Directive MISSING: %s " % (directive))
        for osr in new_osrnames:
            if os.path.isfile(osr):
                search_key = directive
                result = lookline_in_file(
                        afile=osr,
                        thevalues=search_key,
                        commentchr='#', case="sensitive")
                if not result:
                    if 'MISSING_DIRECTIVES' not in ret.keys():
                        ret['MISSING_DIRECTIVES'] = []
                    ret['MISSING_DIRECTIVES'].append(new_osrnames)
                    violations.append("Directive MISSING: %s" % (directive))

            else:
                ret = {'FILE_NOT_FOUND': osr}
                violations.append('%s : file MISSING' % (osr))


    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret


# IZ.1.5.9.21.1
def AUDIT_IPV6_ROUTER_ADV(osrnames=['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directives=["net.ipv6.conf.all.accept_ra = 0",
                                     "net.ipv6.conf.default.accept_ra = 0"]):
    '''
            In/etc/sysctl.conf', '/etc/sysctl.d/*'
            - Ensure disability of IPv6 router advertisements is set to 0
            - directives=["net.ipv6.conf.all.accept_ra = 0",
                          "net.ipv6.conf.default.accept_ra = 0"]
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Directives %s are within  %s"\
        % ( ' and '.join(directives), ' and '.join(osrnames))

    violations = []
    ret = {}
    new_osrnames = []

    osr_names = list_files_in_dir_with_extension(
        osrnames[1], extension='')
    if osr_names:
        for osr_name in osr_names:
            new_osrnames.append(osr_name)
    new_osrnames.append(osrnames[0])

    for directive in directives:
        cmd = "sysctl "+directive.split()[0]
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            if 'CMD_ERR' not in ret.keys():
                ret['CMD_ERR'] = []
            ret['CMD_ERR'].append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] == b'':
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []
            ret['MISSING_DIRECTIVES'].append(new_osrnames)
            violations.append("Directive MISSING: %s " % (directive))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if directive not in str(line):
                    if 'MISSING_DIRECTIVES' not in ret.keys():
                        ret['MISSING_DIRECTIVES'] = []
                    ret['MISSING_DIRECTIVES'].append(new_osrnames)
                    violations.append("Directive MISSING: %s " % (directive))
        for osr in new_osrnames:
            if os.path.isfile(osr):
                search_key = directive
                result = lookline_in_file(
                        afile=osr,
                        thevalues=search_key,
                        commentchr='#', case="sensitive")
                if not result:
                    if 'MISSING_DIRECTIVES' not in ret.keys():
                        ret['MISSING_DIRECTIVES'] = []
                    ret['MISSING_DIRECTIVES'].append(new_osrnames)
                    violations.append("Directive MISSING: %s" % (directive))

            else:
                ret = {'FILE_NOT_FOUND': osr}
                violations.append('%s : file MISSING' % (osr))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret


# IZ.1.5.9.21.2
def AUDIT_ICMP_REDIRECT(osrnames=['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directives=["net.ipv6.conf.all.accept_redirects = 0",
                                     "net.ipv6.conf.default.accept_redirects = 0"]):
    '''
            In/etc/sysctl.conf', '/etc/sysctl.d/*'
            - Ensure disability of ICMP redirectsby setting is set to 0
            - directives=["net.ipv6.conf.all.accept_redirects = 0",
                          "net.ipv6.conf.default.accept_redirects = 0"]
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Directives %s are within  %s"\
        % ( ' and '.join(directives), ' and '.join(osrnames))
    violations = []
    ret = {}
    new_osrnames = []

    osr_names = list_files_in_dir_with_extension(
        osrnames[1], extension='')
    if osr_names:
        for osr_name in osr_names:
            new_osrnames.append(osr_name)
    new_osrnames.append(osrnames[0])

    for directive in directives:
        cmd = "sysctl "+directive.split()[0]
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            if 'CMD_ERR' not in ret.keys():
                ret['CMD_ERR'] = []
            ret['CMD_ERR'].append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] == b'':
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []
            ret['MISSING_DIRECTIVES'].append(new_osrnames)
            violations.append("Directive MISSING1: %s " % (directive))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                #new_directive =  directive.replace('redirect', 'redirects')
                if directive not in str(line):
                    if 'MISSING_DIRECTIVES' not in ret.keys():
                        ret['MISSING_DIRECTIVES'] = []
                    ret['MISSING_DIRECTIVES'].append(new_osrnames)
                    violations.append("MISSING_DIRECTIVES: %s " % (directive))
        for osr in new_osrnames:
            if os.path.isfile(osr):
                result = lookline_in_file(
                        afile=osr,
                        thevalues=directive,
                        commentchr='#', case="sensitive")
                if not result:
                    if 'FILE_MISSING_DIRECTIVES' not in ret.keys():
                        ret['FILE_MISSING_DIRECTIVES'] = []
                    if osr not in ret['FILE_MISSING_DIRECTIVES']:
                        ret['FILE_MISSING_DIRECTIVES'].append(osr)
                        violations.append("FILE_MISSING_DIRECTIVES: %s" % (directive))

            else:
                ret = {'FILE_NOT_FOUND': osr}
                violations.append('%s : file MISSING' % (osr))
    #print("violations", violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret



# IZ.1.5.9.23
def AUDIT_TELNET():
    '''
            - Ensure telnet.socket deamon is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure telnet.socket is disabled'

    violations = []

    cmd = "rpm -q telnet"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        cmd = "systemctl is-enabled telnet.socket"
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_ret'] == 0:
            violations.append("Telnet deamon is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# AD.1.5.9.24.1.1
def AUDIT_VSFTPD():
    '''
            - Ensure vsftpd is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure vsftpd is disabled'

    violations = []

    cmd = "rpm -q vsftpd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        cmd = "systemctl is-enabled vsftpd"
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_ret'] == 0:
            violations.append("vsftpd is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#IZ.1.5.1.4
def NET_FTP_LIB_PERMS(osrnames= ['/var/ftp/lib', '/etc/vsftpd/vsftpd.conf'],
                  directives = ['anonymous_enable=YES', 'anon_root = *'], agreedperms='0555'):
    '''
        - If anonymous ftp is enabled, then lib subdirectory in ftp home directory must be owned by root and only the owner
           should have write access and the files present in lib directory should have '0555' permissions.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'If anonymous ftp is enabled, then lib subdirectory in ftp home directory must be owned by root and only the owner' \
                                       'should have write access and the files present in bin directory should have 0555 permissions'

    violations = []

    cmd = 'systemctl is-enabled vsftpd'
    cmd_exec = execute_command(cmd)

    lib_dir = osrnames[0]

    if cmd_exec['cmd_err']:
        violations.append("Unable to check the status for vsftpd")
    if cmd_exec['cmd_ret'] == 0:
        linefound = lookline_in_file(afile=osrnames[1], thevalues=directives[0], commentchr='#', case="sensitive")
        if (linefound):
            dirfound = lookline_in_file(afile=osrnames[1], by_regex=r'anon_root\s*=\s*.*$',
                                        commentchr='#', case="sensitive")
            if (dirfound):
                dir_split = dirfound[0].split("=")
                dir = dir_split[1]
                lib_dir = dir.rstrip("\n")
                lib_dir = lib_dir + '/lib'

        if(os.path.exists(lib_dir) and os.path.isdir(lib_dir)):
            mode = oct(os.stat(lib_dir)[ST_MODE])[-3:]
            dir_perm = str(mode)
            if (path.exists(lib_dir) and path.isdir(lib_dir)):
                if (pwd.getpwuid(os.stat(lib_dir).st_uid).pw_name != 'root'):
                    violations.append("%s directory owner is not root"  % (lib_dir))
                if(dir_perm[1] == '2' or dir_perm[1] == '3' or dir_perm[1] == '6' or dir_perm[1] == '7'):
                    violations.append("%s directory group has write permission"  % (lib_dir))
                if (dir_perm[2] == '2' or dir_perm[2] == '3' or dir_perm[2] == '6' or dir_perm[2] == '7'):
                    violations.append("%s directory other users have write permission"  % (lib_dir))

            drs = []
            drs.append(lib_dir)
            #permfailed = false
            files = list_files_in(drs, cond='os.access(%, os.F_OK)')
            if(files):
                for file in files:
                    permfailed = perm_violation(obj=file, refperms=agreedperms,
                                                mode='exact', category = 'all')
                    if permfailed:
                        violations.append("%s directory files do not have permissions %s" % (lib_dir, agreedperms))
                        break;


    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#IZ.1.5.1.5
def NET_FTP_ETC_PERMS(osrnames= ['/var/ftp/etc', '/etc/vsftpd/vsftpd.conf'],
                  directives = ['anonymous_enable=YES', 'anon_root = *'], agreedperms='0111'):
    '''
        - If anonymous ftp is enabled, then etc subdirectory in ftp home directory must be owned by root and only the owner
           should have write access and the files present in bin directory should have '0111' permissions.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'If anonymous ftp is enabled, then etc subdirectory in ftp home directory must be owned by root and only the owner' \
                                       ' should have write access and the files present in bin directory should have 0111 permissions.'

    violations = []

    cmd = 'systemctl is-enabled vsftpd'
    cmd_exec = execute_command(cmd)

    etc_dir = osrnames[0]

    if cmd_exec['cmd_err']:
        violations.append("Unable to check the status for vsftpd")
    if cmd_exec['cmd_ret'] == 0:
        linefound = lookline_in_file(afile=osrnames[1], thevalues=directives[0], commentchr='#', case="sensitive")
        if (linefound):
            dirfound = lookline_in_file(afile=osrnames[1], by_regex=r'anon_root\s*=\s*.*$',
                                        commentchr='#', case="sensitive")
            if (dirfound):
                dir_split = dirfound[0].split("=")
                dir = dir_split[1]
                etc_dir = dir.rstrip("\n")
                etc_dir = etc_dir + '/etc'

        if(os.path.exists(etc_dir) and os.path.isdir(etc_dir)):
            mode = oct(os.stat(etc_dir)[ST_MODE])[-3:]
            dir_perm = str(mode)
            if (path.exists(etc_dir) and path.isdir(etc_dir)):
                if (pwd.getpwuid(os.stat(etc_dir).st_uid).pw_name != 'root'):
                    violations.append("%s directory owner is not root"  % (etc_dir))
                if(dir_perm[1] == '2' or dir_perm[1] == '3' or dir_perm[1] == '6' or dir_perm[1] == '7'):
                    violations.append("%s directory group has write permission"  % (etc_dir))
                if (dir_perm[2] == '2' or dir_perm[2] == '3' or dir_perm[2] == '6' or dir_perm[2] == '7'):
                    violations.append("%s directory other users have write permission"  % (etc_dir))

            drs = []
            drs.append(etc_dir)
            #permfailed = false
            files = list_files_in(drs, cond='os.access(%, os.F_OK)')
            if(files):
                for file in files:
                    permfailed = perm_violation(obj=file, refperms=agreedperms,
                                                mode='exact', category = 'all')
                    if permfailed:
                        violations.append("%s directory files do not have permissions %s" % (etc_dir, agreedperms))
                        break;

            etc_passwd = etc_dir + '/passwd'
            if (os.path.exists(etc_passwd)):
                #AUTH_PASSWDF2(osrname=etc_passwd, fieldno=2)
                violation = check_field_in_file(afile=etc_passwd, fieldno=2, delim=':')
                if violation:
                    violations.append("%s file does not have the following password entries as null" % (etc_passwd))
                    violations.append(violation)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#IZ.1.5.9.24.1.1
def SERVICE_STOP_VSFTPD(agreedparams = 'deinstall'):
    '''
        - Ensure vsftpd is de installed or disabled.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure vsftpd is de installed or disabled'


    violations = []

    if (agreedparams == 'deinstall'):
        cmd  = 'rpm -q vsftpd'
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Unable to check the status for vsftpd")
        if cmd_exec['cmd_ret'] == 0:
            violations.append("VSFTPD installed")
    elif (agreedparams == 'disable'):
        cmd  = 'systemctl is-enabled vsftpd'
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_ret'] == 0:
            violations.append("VSFTPD enabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#IZ.1.5.9.25
def SERVICE_STOP_NFS(agreedparams = 'deinstall'):
    '''
        - Ensure nfs is de installed or disabled.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure nfs is de installed or disabled'


    violations = []

    if (agreedparams == 'deinstall'):
        cmd  = 'rpm -qa "nfs*"'
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Unable to check the status for nfs")
        if cmd_exec['cmd_out'] != '':
            violations.append("NFS installed")
    elif (agreedparams == 'disable'):
        cmd  = 'systemctl is-enabled nfs'
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_ret'] == 0:
            violations.append("NFS enabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.24.1.2
def OSR_VSFTPD(osrnames= ['/etc/vsftpd/vsftpd.conf', '/etc/vsftpd/user_list'],  agreedperms='0600'):
    '''
        - Ensure VSFTPD configuration files have permissions 600
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure VSFTPD configuration files have permissions 600'

    violations = []
    if (os.path.exists(osrnames[0]) and os.path.isfile(osrnames[0])):
        permfailed = perm_violation(obj=osrnames[0], refperms=agreedperms,
                                    mode='exact', category='all')
        if permfailed:
            violations.append("%s file does not have permission %s" % (osrnames[0], agreedperms))

    if (os.path.exists(osrnames[1]) and os.path.isfile(osrnames[1])):
        permfailed = perm_violation(obj=osrnames[1], refperms=agreedperms,
                                    mode='exact', category='all')
        if permfailed:
            violations.append("%s file does not have permission %s" % (osrnames[1], agreedperms))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.26 / IZ.1.5.9.27
def NET_DISABLE_TIME(directives=['time-dgram: off', 'time-stream: off']):
    '''
        -  Ensure if xinetd is enabled directives are present in off state
        - directives=['time-dgram: off', 'time-stream: off']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "If xinetd is enabled, ensure %s are"\
        " present chkconfig --list " % (' '.join(directives))

    violations = []
    present = []

    cmd = "chkconfig --list --type xinetd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for directive in directives:
            for line in cmd_exec['cmd_out'].splitlines():
                #if directive.split()[0] == line.split(':')[0] and directive.split()[1] in str(line):
                if directive.split(':')[0] == line.split(':')[0].lstrip() and directive.split()[1] in str(line):
                    present.append(directive)

        if len(present) == 0:
            violations.append("Both directives MISSING %s" % (directives))
        elif len(present) == 1:
            violations.append("Only single directive present %s" % (present))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.4.2.2
def OSR_ETC_GSHADOW(osrname='/etc/gshadow',
                    agreedperms='0000',
                    agreeduser='root',
                    agreedgroup='root'):
    '''
            - Ensure permissions on /etc/gshadow are configured to 0000 and
              ownership of 0:0
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname) + \
        "are configured to 0000 and ownership of 0:0"
    violations = []
    if not os.path.isfile(osrname):
        violations.append('%s: File MISSING' % (osrname))
    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return violations


# IZ.1.8.4.2.3
def OSR_ETC_SHADOW1(osrname='/etc/shadow-',
                    agreedperms='0000',
                    agreeduser='root',
                    agreedgroup='root'):
    '''
            - Ensure permissions on /etc/shadow- are configured to 0000 and
              ownership of 0:0
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname) + \
        "are configured to 0000 and ownership of 0:0"
    violations = []
    if not os.path.isfile(osrname):
        violations.append('%s: File MISSING' % (osrname))
    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            print(cmd_exec['cmd_out'])
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))
    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return violations


# IZ.1.8.4.2.4
def OSR_ETC_GSHADOW1(osrname='/etc/gshadow-',
                     agreedperms='0000',
                     agreeduser='root',
                     agreedgroup='root'):
    '''
            - Ensure permissions on /etc/gshadow- are configured to 0000 and
              ownership of 0:0
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname) + \
        "are configured to 0000 and ownership of 0:0"
    violations = []
    if not os.path.isfile(osrname):
        violations.append('%s: File MISSING' % (osrname))
    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return violations


# IZ.1.8.4.3.1
def OSR_CRONTAB(osrname='/etc/crontab',
                agreedperms='0600',
                agreeduser='root',
                agreedgroup='root'):
    '''
        Ensure permissions on /etc/crontab are configured to 0600 and
        ownership of 0:0
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname) + \
        "are configured to 0600 and ownership of 0:0"
    violations = []
    if not os.path.isfile(osrname):
        violations.append('%s: File MISSING' % (osrname))
    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return violations


# IZ.1.8.4.3.2
def OSR_CRON_HOURLY(osrname='/etc/cron.hourly',
                    agreedperms='0700',
                    agreeduser='root',
                    agreedgroup='root'):
    '''
        Ensure permissions on /etc/cron.hourly are configured to 0700 and
        ownership of 0:0
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname) + \
        "are configured to 0700 and ownership of 0:0"
    violations = []
    if not os.path.isdir(osrname):
        violations.append('%s: dir MISSING' % (osrname))
    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return violations
# IZ.1.5.9.24.4.1
def VSFTPD_SERVICE_CONFIGURATION_FOR_SECURE_FTP_PURCHASED_CERTIFICATES(
        osrname=["/etc/vsftpd/vsftpd.conf", "/etc/pki/tls/certs/vsftpd.crt", "/etc/pki/tls/private/vsftpd.key"],
        searchstrings=['ssl_enable=YES', 'allow_anon_ssl=YES', 'force_local_data_ssl=YES', 'force_local_logins_ssl=YES',
                       'ssl_sslv2=NO', 'ssl_sslv3=NO', 'ssl_tlsv1=NO', 'ssl_tlsv1_1=NO', 'ssl_tlsv1_2=YES',
                       'rsa_cert_file=/etc/pki/tls/certs/vsftpd.crt',
                       'rsa_private_key_file=/etc/pki/tls/private/vsftpd.key'], agreedvalue="yes", agreedperms='0600',
        mode='max', category='all', mustexist=True, agreeduser='root', directives=None):
    '''
       Ensure VSFTPD service is properly configured (when secure ftp is enabled). Purchased Cert Option 1
            - Ensure permissions on /etc/vsftpd/vsftpd.conf are configured to 0600
            - Ensure permissions on /etc/pki/tls/certs/vsftpd are configured to 0600
            - Ensure permissions on /etc/pki/tls/private/vsftpd are configured to 0600
    '''

    checkname = inspect.stack()[0][3]
    descr = "{} Ensure VSFTPD service is properly configured when secure FTP is enabled with required " \
            "restrictions".format(format_nicely(checkname))

    violations = []
    present = []
    line_not_present = []
    ret = {}
    if generic_check_if_package_installed("vsftpd"):
        ret[osrname[0]] = []
        # Check vsftp.config file present
        if not os.path.isfile(osrname[0]):
            violations.append('%s: File missing' % (osrname[0]))
            ret[osrname[0]].append('%s: File missing' % (osrname[0]))

        else:
            # Ensure config file permission
            cmd = "stat " + osrname[0]
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                violations.append("error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_out'] != b'':
                for line in cmd_exec['cmd_out'].splitlines():
                    if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                        access_line_array = str(line).split(')')
                        if agreedperms not in access_line_array[0]:
                            violations.append("%s: OSR permissions for file are not as expected." % (osrname[0]))
                            ret[osrname[0]].append("%s: OSR permissions for file are not as expected." % (osrname[0]))

            # ensure if suggested line are presnet in /etc/vsftpd/vsftpd.conf file
            for searchstring in searchstrings:
                result = lookline_in_file(afile=osrname[0],
                                          thevalues=searchstring,
                                          commentchr='#', case="sensitive")
                if not result:
                    line_not_present.append(searchstring)

            # check if lines are not repsent in file
            if line_not_present:
                violations.append('Not all required lines are present in file %s' % (osrname[0]))
                ret[osrname[0]].append('Not all required lines are present in file %s' % (osrname[0]))

                # Check if user provides purchased certificates
            if agreedvalue == "yes":
                osrname = osrname[1:4]
                for osr in osrname:
                    ret[osr] = []
                    # check if files present
                    if not os.path.isfile(osr):
                        violations.append('%s: File missing' % (osr))
                        ret[osr].append('%s: File missing' % (osr))
                    else:
                        # check if files have agreed permissions
                        cmd = "stat " + osr
                        cmd_exec = execute_command(cmd)
                        if cmd_exec['cmd_err']:
                            violations.append("error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
                        elif cmd_exec['cmd_out'] != b'':
                            for line in cmd_exec['cmd_out'].splitlines():
                                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                                    access_line_array = str(line).split(')')
                                    if agreedperms not in access_line_array[0]:
                                        violations.append("%s: OSR permissions for file are not as expected." % (osr))
                                        ret[osr].append("%s: OSR permissions for file are not as expected." % (osr))

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items() if len(entry[1]))
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.5.9.24.4.2
def VSFTPD_SERVICE_CONFIGURATION_FOR_SECURE_FTP_SELFSIGNED_CERTIFICATES(
        osrname=["/etc/vsftpd/vsftpd.conf", "/etc/vsftpd/vsftpd.pem"],
        searchstrings=['ssl_enable=YES', 'allow_anon_ssl=YES', 'force_local_data_ssl=YES', 'force_local_logins_ssl=YES',
                       'ssl_sslv2=NO', 'ssl_sslv3=NO', 'ssl_tlsv1=NO', 'ssl_tlsv1_1=NO', 'ssl_tlsv1_2=YES',
                       'rsa_cert_file=/etc/vsftpd/vsftpd.pem'], agreedvalue="yes", agreedperms='0600', mode='max',
        category='all', mustexist=True, agreeduser='root', directives=None):
    '''
       Ensure VSFTPD service is properly configured (when secure ftp is enabled). Purchased Cert Option 1
            - Ensure permissions on /etc/vsftpd/vsftpd.conf are configured to 0600
            - Ensure permissions on /etc/vsftpd/vsftpd.pem are configured to 0600

    '''

    checkname = inspect.stack()[0][3]
    descr = "{} Ensure VSFTPD service is properly configured when secure FTP is enabled with required " \
            "restrictions".format(format_nicely(checkname))

    violations = []
    present = []
    line_not_present = []
    ret = {}
    if generic_check_if_package_installed("vsftpd"):
        ret[osrname[0]] = []
        # Check vsftp.config file present
        if not os.path.isfile(osrname[0]):
            violations.append('%s: File missing' % (osrname[0]))
            ret[osrname[0]].append('%s: File missing' % (osrname[0]))
        else:
            # Ensure config file permission
            cmd = "stat " + osrname[0]
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                violations.append("error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_out'] != b'':
                for line in cmd_exec['cmd_out'].splitlines():
                    if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                        access_line_array = str(line).split(')')
                        if agreedperms not in access_line_array[0]:
                            violations.append("%s: OSR permissions for file are not as expected." % (osrname[0]))
                            ret[osrname[0]].append("%s: OSR permissions for file are not as expected." % (osrname[0]))

            # ensure if suggested line are presnet in /etc/vsftpd/vsftpd.conf file
            for searchstring in searchstrings:
                result = lookline_in_file(afile=osrname[0],
                                          thevalues=searchstring,
                                          commentchr='#', case="sensitive")
                if not result:
                    line_not_present.append(searchstring)

            # check if lines are not repsent in file
            if line_not_present:
                violations.append('Not all required lines are present in file %s' % (osrname[0]))
                ret[osrname[0]].append('Not all required lines are present in file %s' % (osrname[0]))

                # Check if user provides purchased certificates
            if agreedvalue == "yes":
                ret[osrname[1]] = []
                # check if files present
                if not os.path.isfile(osrname[1]):
                    violations.append('%s: File missing' % (osrname[1]))
                    ret[osrname[1]].append('%s: File missing' % (osrname[1]))
                else:
                    # check if files have agreed permissions
                    cmd = "stat " + osrname[1]
                    cmd_exec = execute_command(cmd)
                    if cmd_exec['cmd_err']:
                        violations.append("error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
                    elif cmd_exec['cmd_out'] != b'':
                        for line in cmd_exec['cmd_out'].splitlines():
                            if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                                access_line_array = str(line).split(')')
                                if agreedperms not in access_line_array[0]:
                                    violations.append("%s: OSR permissions for file are not as expected." % (osrname[1]))
                                    ret[osrname[1]].append(
                                        "%s: OSR permissions for file are not as expected." % (osrname[1]))
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items() if len(entry[1]))
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.5.9.29
def NET_AVAHI_DISABLE():
    '''
     - Ensure avahi server is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure avahi server is disabled'

    violations = []

    cmd = "systemctl is-enabled avahi-daemon"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("avahi-daemon is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.30
def NET_LDAP_DISABLE():
    '''
     - Ensure LDAP server is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure LDAP server is disabled'

    violations = []

    cmd = "systemctl is-enabled slapd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("slapd is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.31
def NET_IMAP_POP3_DISABLE():
    '''
     - Ensure IMAP and POP3 server is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure IMAP and POP3 server is disabled'

    violations = []

    cmd = "systemctl is-enabled dovecot"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("dovecot is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.32
def NET_HTTP_PROXY_DISABLE():
    '''
     - Ensure HTTP Proxy Server is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure HTTP Proxy Server is disabled'

    violations = []

    cmd = "systemctl is-enabled squid"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("squid is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.9.33
def NET_TALK_DISABLE():
    '''
     - Ensure Talk Server is disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure Talk Server is disabled'

    violations = []

    cmd = "systemctl is-enabled ntalk"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("ntalk is enabled, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.4.3.3
def OSR_CRON_DAILY(osrname='/etc/cron.daily',
                  agreedperms='0700',
                  agreeduser='root',
                  agreedgroup='root'):
    '''
        Ensure permissions on /etc/cron.daily are configured to 0600 and
        ownership of 0:0
        osrname='/etc/cron.daily',
        agreedperms='0700',
        agreeduser='root'
        agreedgroup='root'
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname) + \
        "are configured to 0700 and ownership of 0:0"

    violations = []

    if not os.path.isdir(osrname):
        violations.append('%s: dir MISSING' % (osrname))

    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.4.3.4
def OSR_CRON_WEEKLY(osrname='/etc/cron.weekly',
                  agreedperms='0700',
                  agreeduser='root',
                  agreedgroup='root'):
    '''
        Ensure permissions on /etc/cron.weekly are configured to 0600 and
        ownership of 0:0
        osrname='/etc/cron.weekly',
        agreedperms='0700',
        agreeduser='root'
        agreedgroup='root'
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname) + \
        "are configured to 0700 and ownership of 0:0"

    violations = []

    if not os.path.isdir(osrname):
        violations.append('%s: dir MISSING' % (osrname))

    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.4.3.5
def OSR_CRON_MONTHLY(osrname='/etc/cron.monthly',
                  agreedperms='0700',
                  agreeduser='root',
                  agreedgroup='root'):
    '''
        Ensure permissions on /etc/cron.monthly are configured to 0600 and
        ownership of 0:0
        osrname='/etc/cron.monthly',
        agreedperms='0700',
        agreeduser='root'
        agreedgroup='root'
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname) + \
        "are configured to 0700 and ownership of 0:0"

    violations = []

    if not os.path.isdir(osrname):
        violations.append('%s: dir MISSING' % (osrname))

    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.4.3.6
def OSR_CRON_D(osrname='/etc/cron.d',
                  agreedperms='0700',
                  agreeduser='root',
                  agreedgroup='root'):
    '''
        Ensure permissions on /etc/cron.d are configured to 0700 and
        ownership of 0:0
        osrname='/etc/cron.d',
        agreedperms='0700',
        agreeduser='root'
        agreedgroup='root'
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking permission on  %s: " % (osrname    ) + \
        "are configured to 0700 and ownership of 0:0"

    violations = []

    if not os.path.isdir(osrname):
        violations.append('%s: dir MISSING' % (osrname))

    else:
        cmd = "stat " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                    access_line_array =  str(line).split(')')
                    if agreeduser not in access_line_array[1]:
                        violations.append("OSR owned not by user %s" % (agreeduser))
                    if agreedgroup not in access_line_array[2]:
                        violations.append("OSR owned not by group %s" % (agreedgroup))
                    if agreedperms not in access_line_array[0]:
                        violations.append("OSR permissions not as expected %s" % (agreedperms))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.12.8
def OSR_GPGCHECK(osrnames=['/etc/yum.conf', '/etc/yum.repos.d/'],
                 directive='gpgcheck=1'):
    '''
        Ensure gpgcheck is globally activated
        osrnames=['/etc/yum.conf', '/etc/yum.repos.d/*'],
        directive='gpgcheck=1'
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure gpgcheck is globally activated and "\
            "gpgcheck flag for %s is set to 1" % (' and '.join(osrnames))

    violations = []

    new_osrnames = []

    osr_names = list_files_in_dir_with_extension(
        osrnames[1], extension='')
    if osr_names:
        for osr_name in osr_names:
            new_osrnames.append(osr_name)
    new_osrnames.append(osrnames[0])

    for osrname in new_osrnames:
        cmd = "grep ^gpgcheck " + osrname
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_out'] != b'':
            for line in cmd_exec['cmd_out'].splitlines():
                if directive not in str(line):
                    violations.append("In file %s gpgcheck is not set to 1" % (osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


def DISABLE_IPV6():
    '''
           - IPV6 should be disabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking IPV6 status"
    violations = []

    cmd = "ip a"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" % (
            str(cmd_exec['cmd_err'])))
    elif 'inet6' in str(cmd_exec['cmd_out']):
        violations.append("IPV6 is enabled")
    else:
        log_audit("IPV6 is disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.5.12.4
def NET_DISABLE_SENDMAIL():
    '''
    - Ensure sendmail is disabled.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'Ensure sendmail is not installed'

    violations = []

    cmd = "rpm -qa sendmail*"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        violations.append("sendmail is installed, remove it")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.2.7.6
def AUDIT_NTPD_NOEXCESSPRIV():
    '''
    - if ntpd is active, ensure it has least privilege configuration
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'If ntpd is active, ensure it has least privilege configuration'

    violations = []

    cmd = "systemctl status chronyd"
    cmd_exec = execute_command(cmd)

    cmd1 = "systemctl status ntpd"
    cmd_exec1 = execute_command(cmd1)
    if cmd_exec1['cmd_ret'] != 0 and cmd_exec['cmd_ret'] != 0:
        violations.append("Ntpd or chronyd is not active")
    elif cmd_exec1['cmd_ret'] == 0:
        cmd2 = "ps -u ntp | grep ntpd"
        cmd_exec2 = execute_command(cmd2)
        if cmd_exec2['cmd_ret'] or cmd_exec2['cmd_err']:
            violations.append("Ntpd task is not running as ntp id")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#IZ.1.4.2.2
def AUDIT_ROOT_GID(osrname = '/etc/passwd'):
    '''
    - Ensure default group for the root account is GID 0
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure default group for the root account is GID 0'

    violations = []

    cmd = 'grep "^root:" ' + osrname + ' | cut -f4 -d:'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode

    if cmd_ret != 0 or cmd_err:
        violations.append("Unable to check the GID for root user")
    elif cmd_ret == 0:
        if int(cmd_out) != 0:
            violations.append("Root GID is not 0")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#AD.1.3.0
def ANTIVIRUS_STATUS():
    '''
    - Ensure Trendmicro is installed and running
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure Trendmicro is installed and running'

    violations = []
    cmd1 = 'rpm -q ds_agent'
    cmd_exec1 = execute_command(cmd1)

    cmd2 = 'systemctl status ds_agent'
    cmd_exec2 = execute_command(cmd2)

    if cmd_exec1['cmd_ret'] != 0 or cmd_exec1['cmd_err']:
        violations.append("Trendmicro is not installed")
    elif cmd_exec2['cmd_ret'] != 0 or cmd_exec2['cmd_err']:
        violations.append("Trendmicro service is not running")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.4.3.1.1
def SELINUX_STATUS():
    '''
        - Ensure SELinux is installed.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure SELinux is installed'

    violations = []

    cmd = "rpm -q libselinux"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Unable to check the libselinux installation status")
    elif cmd_exec['cmd_ret'] != 0:
        violations.append("SElinux is not installed")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.4.3.1.2
def SELINUX_CONFIG_MODE(osrname='/etc/selinux/config', agreedvalue='enforcing'):

    '''
        Ensure that the SELinux state is either enforcing or permissive
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that the SELinux state in %s is %s" \
            % (osrname, agreedvalue)

    violations = []
    cmd = 'grep SELINUX=' + agreedvalue + ' ' + osrname
    cmd_exec = execute_command(cmd)

    if cmd_exec['cmd_ret'] != 0:
        violations = ["SELinux state in %s is not %s" % (osrname, agreedvalue)]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.4.3.1.4
def SELINUX_TYPE(osrname='/etc/selinux/config', agreedvalue='targeted'):

    '''
        Ensure that the SELinux type is either targeted or mls
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that the SELinux type in %s is %s" \
            % (osrname, agreedvalue)

    violations = []
    cmd = 'grep SELINUXTYPE=' + agreedvalue + ' ' + osrname
    cmd_exec = execute_command(cmd)

    if cmd_exec['cmd_ret']  != 0:
        violations = ["SELinux type in %s is not %s" % (osrname, agreedvalue)]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.4.3.3.1
def AUDITD_SERVICE():

    '''
        Ensure that the auditd service is enabled
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that the auditd service is enabled"

    violations = []
    cmd = 'systemctl is-enabled auditd'
    cmd_exec = execute_command(cmd)

    if cmd_exec['cmd_ret'] != 0:
        violations = ["Auditd service is not enabled"]

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#IZ.1.5.3.1
def OSR_NFS(osrname='/etc/exports',
            agreedperms='0644',
            mode ='max',
            category='all',
            mustexist = True,
            agreeduser='root'):

    '''
            Ensure that if NFS server is installed and running, the /etc/exports file must exist and must
            be owned by root and have 0644 permissions, or stricter.
    '''

    osr = osrname
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that if NFS server is installed and running, the %s file must exist and must " \
                                       "be owned by root and have 0644 permissions, or stricter. " % (osrname)

    violations = []
    ret = {}
    cmd = 'systemctl is-enabled nfs'
    cmd_exec = execute_command(cmd)

    if cmd_exec['cmd_ret'] == 0:
        if not os.path.isfile(osrname):
            if mustexist:
                violations.append("FS object %s not found" % (osr))
                ret[osr] = []
                ret[osr].append({'problem': 'missing'})
            else:
                pass
        else:
            ret[osr] = []
            # check ownership first
            if agreeduser:
                agreeduid = pwd.getpwnam(agreeduser).pw_uid
                owner_id = os.stat(osr).st_uid
                owner_name = pwd.getpwuid(owner_id).pw_name
                if owner_id != agreeduid:
                    violations.append("FS object owned not by %s, but by %s"
                                      % (agreeduser, owner_name))
                    ret[osr].append({'problem': 'ownership',
                                     'rightful_owner': agreeduser,
                                     'wrong_owner': owner_name})

            # now check permissions
            permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                        mode=mode, category=category)
            if permfailed:
                violations.append("FS object permissions: %s" % (permfailed))
                ret[osr].append({'problem': 'permissions',
                                 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    # remove the entries with value = [], because they are not violations
    # and we want to use ret as boolean
    # return dict(entry for entry in ret.iteritems() if len(entry[1]))

    # comment above line to support python 3 syntax replacing iteritems() with items()

    return dict(entry for entry in ret.items() if len(entry[1]))

# IZ.1.5.1.1
def WUFTPD_STATUS():
    '''
        - Ensure wu-ftpd is not active.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure wu-ftpd is not active'

    violations = []

    cmd = "rpm -q wu-ftpd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Unable to check the wu-ftpd installation status")
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("Wu-ftpd is installed")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.9.1.2
def AUTH_UMASK_BASHRC(target='/etc/bashrc',
                      directives=['if [ $UID -gt 199 ] && [ "`/usr/bin/id -gn`" = "`/usr/bin/id -un`" ]; then',
                                  'for i in /etc/profile.d/*.sh; do'], commentchr='#'):
    checkname = inspect.stack()[0][3]
    descr = "{}File /etc/bashrc must trigger an invocation of ./etc/profile.d/IBMsinit.sh".format(
        format_nicely(checkname))
    ret = {}
    violations = []
    profile_script_line_number = 0
    umask_script_line_number = 0
    ret["violations"] = []

    if not os.path.isfile(target):
        violations.append('%s: File missing' % (target))
        ret["violations"].append('File missing')
    else:
        with open(target) as myFile:
            validline_in_file = myFile.readlines()
            validline_in_file = [ln for ln in validline_in_file if not ln.strip().startswith(commentchr)]
        ret['validline_in_file'] = validline_in_file

        # Find line numbers of umask code and '/etc/profile.d/*.sh' script block
        for i in range(0, len(validline_in_file)):
            if directives[0] == validline_in_file[i].strip():
                umask_script_line_number = i
            if directives[1] == validline_in_file[i].strip():
                profile_script_line_number = i

        ret['profile_script_line_number'] = profile_script_line_number
        ret['umask_script_line_number'] = umask_script_line_number

        # If umask string appears after '/etc/profile.d/*.sh' script invocation block then raise voilation to move umask code block before script invocation.
        if profile_script_line_number < umask_script_line_number:
            violations.append("Invocation of ('/etc/profile.d/IBMsinit.sh') script")
            ret["violations"].append("Invocation of ('/etc/profile.d/IBMsinit.sh') script")
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.8.12.6
def OSR_IBMSINIT_SH(osrname='/etc/profile.d/IBMsinit.sh',
                    agreedperms='0755',
                    mode='exact',
                    category='others'):
    '''
            - Must have settings for "other" of r-x
            - Must have settings for "group" of r-x
              but write access is allowed for the group if the associated group is identified as having a privileged GID number
    '''

    osr = osrname
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions for 'IBMsinit.sh' should be r-x for other and  r-x or rwx for group"

    violations = []
    ret = {}

    if not os.path.isfile(osr):
        violations.append('%s: file MISSING' % (osr))
        ret[osr] = []
        ret[osr].append({'problem': 'missing'})
    else:
        ret[osr] = []
        # check permissions for others
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode, category=category)
        if permfailed:
            violations.append("File permissions for others: %s" % (permfailed))
            ret[osr].append({'problem': 'others permissions',
                             'perms': permfailed})
        # check permissions for group
        category = 'group'
        cmd = "stat -c \"%g\" " + osr
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Failed to check group for file %s" % (osr))
        else:
            gid = int(cmd_exec['cmd_out'])
            if check_previledged_gid(gid):
                agreedperms = '0775'
        permfailed1 = perm_violation(obj=osr, refperms=agreedperms,
                                     mode=mode, category=category)
        if permfailed1:
            violations.append("File permissions for group: %s" % (permfailed1))
            ret[osr].append({'problem': 'group permissions',
                             'right_perms': agreedperms,
                             'perms': permfailed1})
    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))


# IZ.1.8.12.7
def OSR_IBMSINIT_CSH(osrname='/etc/profile.d/IBMsinit.csh',
                     agreedperms='0755',
                     mode='exact',
                     category='others'):
    '''
            - Must have settings for "other" of r-x
            - Must have settings for "group" of r-x
              but write access is allowed for the group if the associated group is identified as having a privileged GID number
    '''

    osr = osrname

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking %s: " % (osr) + \
        "permissions for 'IBMsinit.csh' should be r-x for other and  r-x or rwx for group"

    violations = []
    ret = {}

    cmd = "rpm -q tcsh"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" % (
            str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        log_audit("Package csh is not installed")
    else:
        if not os.path.isfile(osr):
            violations.append('%s: file MISSING' % (osr))
            ret[osr] = []
            ret[osr].append({'problem': 'missing'})
        else:
            ret[osr] = []
            # check permissions for others
            permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                        mode=mode, category=category)
            if permfailed:
                violations.append("File permissions for others: %s" % (permfailed))
                ret[osr].append({'problem': 'others permissions',
                                 'perms': permfailed})
            # check permissions for group
            category = 'group'
            cmd = "stat -c \"%g\" " + osr
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                violations.append("Failed to check the file group %s" % (osr))
            else:
                gid = int(cmd_exec['cmd_out'])
                if check_previledged_gid(gid):
                    agreedperms = '0775'
            permfailed1 = perm_violation(obj=osr, refperms=agreedperms,
                                         mode=mode, category=category)
            if permfailed1:
                violations.append("File permissions for group: %s" % (permfailed1))
                ret[osr].append({'problem': 'group permissions',
                                 'right_perms': agreedperms,
                                 'perms': permfailed1})
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))


# AD.1.8.15.3
def OSR_CRONTAB_GROUP(osrname='/etc/crontab',
                      agreedperms='0744',
                      mode='max',
                      category='all'):

    '''

        Files executed via entries in /etc/crontab
            - no write by if owned by groups considered to be default groups
            for general users (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in %s: " % (osrname) + \
        "and owned by default groups "\
        " general users, permissions (744 or more restrictive)"

    violations = []
    ret = {}

    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#'):
        ret[osr] = []

        owner_gid = os.stat(osr).st_gid

        if default_group_check(owner_gid):

            permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                        mode=mode, category=category)

            if permfailed:
                violations.append("FS object %s permissions: %s"
                                  % (osr, permfailed))
                ret[osr].append({'problem': 'permissions',
                                 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))


# AD.1.1.12.0
def AUTH_PASS_NO_EXPIRY(maxage='90'):
    '''
       Exception to password expiry to the previledged users with password matching
       'x', '!', '!!', '*', if not add expiry of 90 days
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Exception to password expiry to the previledged"\
    " users with password matching 'x', '!', '!!', '*'"

    violations = []
    user_list = []

    for userid in range(1, 999):
        user_name = getfields_from_file(afile='/etc/passwd',
                         retfieldnos=[1],
                         keyfieldno=3,  keyval=str(userid),
                         delim=':', except_regex=None)

        user_list.extend(user_name)
    for user in user_list:
        user = user[0]
        pwd_age_arr = getfields_from_file(afile='/etc/shadow', retfieldnos=[2, 5],
                                      keyfieldno=1, keyval=user,
                                      delim=':', except_regex=None)
        #print(pwd_age_arr)
        (pwd, age) = pwd_age_arr[0]
        if pwd not in ('x', '!', '!!', '*'):  # pwd is set
            if not age or age != maxage:  # empty it means it never expires
                violations.append('User %s password expiry must be set'
                                  % (user))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")


    return violations

#IZ.1.5.9.10
def NET_REMOVE_FINGER():
    '''
            - Ensure finger is not present on the system
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        'Ensure finger is not present on the system'

    violations = []

    cmd = "rpm -q finger"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        violations.append("Finger is installed on the system")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#IZ.1.5.9.11
def NET_DISABLE_SPRAYD():
    '''
        - Ensure SPRAYD is disabled.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure SPRAYD is disabled'

    violations = []
    cmd = "rpcinfo"
    cmd_exec = execute_command(cmd, shell=True)
    if cmd_exec['cmd_err'] or cmd_exec['cmd_out'] != 0:
        violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for line in cmd_exec['cmd_out'].splitlines():
            if 'sprayd' in str(line):
                violations.append("sprayd present in rpc, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#IZ.1.5.9.12
def NET_DISABLE_PCNFSD():
    '''
        - Ensure PCNFSD is disabled.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure PCNFSD is disabled'

    violations = []
    cmd = "rpcinfo"
    cmd_exec = execute_command(cmd, shell=True)
    if cmd_exec['cmd_err'] or cmd_exec['cmd_out'] != 0:
        violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        for line in cmd_exec['cmd_out'].splitlines():
            if 'pcnfsd' in str(line):
                violations.append("pcnfsd present in rpc, need to be disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#IZ.1.5.9.14
def NET_DISABLE_RWHOD():
    '''
        - Ensure RWHO daemon is disabled.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure RWHO daemon is disabled'

    violations = []
    cmd = 'systemctl status rwhod'
    cmd_exec = execute_command(cmd)

    if cmd_exec['cmd_err'] or cmd_exec['cmd_out'] != 0:
        violations.append("Unable to check the rwhod service status")
    if cmd_exec['cmd_ret'] == 0:
        violations.append("RWHOD service is enabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#IZ.1.5.9.18.1
def NET_DISABLE_SNMPD():
    '''
        - Ensure SNMPD daemon is disabled.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure SNMPD daemon is disabled'

    violations = []
    cmd = 'systemctl is-enabled snmpd'
    cmd_exec = execute_command(cmd)

    if cmd_exec['cmd_err']:
        violations.append("Error checking the SNMPD service status")
    if cmd_exec['cmd_ret'] == 0:
        violations.append("SNMPD service is enabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.5.1.6
def NET_FTP_OTHER_PERMS(osrnames=['/var/ftp', '/etc/vsftpd/vsftpd.conf'],
                        directives=['anonymous_enable=YES', 'anon_root = *']):
    '''
        - If it home directory exists and anonymous ftp is enabled, home directory (/var/ftp) must not be owned by a general user account. If write access is granted to the group owner of the file or directory, membership in the group is a security administrative authority. Files and directories must allow only read/execute, write/execute, execute (directories only), or no access for other
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + 'If anonymous ftp is enabled, then subdirectories in ftp home directory must not be owned by a general user account. If write access is granted to the group owner of the file or directory, membership in the group is a security administrative authority. Files and directories must allow only read/execute, write/execute, execute (directories only), or no access for other'

    violations = []
    ret = {}
    dir_required_perms_change = []
    file_required_perms_change = []
    ret["violations"] = []
    cmd = 'systemctl is-enabled vsftpd'
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Unable to check the status for vsftpd")
        ret["violations"].append('Unable to check the status for vsftpd')
    if cmd_exec['cmd_ret'] == 0:
        if not (os.path.isfile(osrnames[1])):
            violations.append("File missing: %s" % (osrnames[1]))
            ret["violations"].append("File missing: %s" % (osrnames[1]))
        else:
            linefound = lookline_in_file(afile=osrnames[1], thevalues=directives[0], commentchr='#', case="sensitive")
            # Check if anonymous ftp is enable in config file
            if (linefound):
                home_dir = osrnames[0]
                # Get home directory from config file if exists else use default path
                dirfound = lookline_in_file(afile=osrnames[1], by_regex=r'anon_root\s*=\s*.*$', commentchr='#',
                                            case="sensitive")
                if (dirfound):
                    dir_split = dirfound[0].split("=")
                    dir = dir_split[1]
                    dir = dir.rstrip("\n")
                    home_dir = dir
                if (os.path.isdir(home_dir)):
                    # Fetch all files and directories inside home directory
                    osr_names = list_files_in_dir_with_extension(home_dir, extension='')
                    if (osr_names):
                        # Check permission of each file/directory
                        for osr in osr_names:
                            mode = oct(os.stat(osr)[ST_MODE])[-3:]
                            dir_perm = str(mode)
                            if (pwd.getpwuid(os.stat(osr).st_uid).pw_uid > 999):
                                if (os.path.isdir(osr)):
                                    if (dir_perm[2] == '2' or dir_perm[2] == '4' or dir_perm[2] == '6' or dir_perm[
                                        2] == '7'):
                                        dir_required_perms_change.append(osr)
                                        violations.append(
                                            "Other users of directory '%s' doesn't have required permission" % (osr))
                                        ret["violations"].append(
                                            "Other users of directory '%s' doesn't have required permission" % (osr))
                                if (os.path.isfile(osr)):
                                    if (dir_perm[2] == '1' or dir_perm[2] == '2' or dir_perm[2] == '3' or dir_perm[
                                        2] == '5' or dir_perm[2] == '6' or dir_perm[2] == '7'):
                                        file_required_perms_change.append(osr)
                                        violations.append(
                                            "Other users of file '%s' doesn't have required permission" % (osr))
                                        ret["violations"].append(
                                            "Other users of file '%s' doesn't have required permission" % (osr))

    ret["dir"] = dir_required_perms_change
    ret["file"] = file_required_perms_change
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# AD.1.5.1.7
def NET_FTP_DIR_CLASSIFIED_DATA(osrnames=['/var/ftp', '/etc/vsftpd/vsftpd.conf'],
                                directives=['anonymous_enable=YES', 'anon_root = *'],
                                directories_containing_classified_data=[]):
    '''
        - If it exists and anonymous ftp is enabled, READ access via anonymous FTP must not be granted to directories containing classified data.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + 'If it exists and anonymous ftp is enabled, READ access via anonymous FTP must not be granted to directories containing classified data.'

    violations = []
    ret = {}
    ret["violations"] = []
    dir_required_perms_change = []

    cmd = 'systemctl is-enabled vsftpd'
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Unable to check the status for vsftpd")
        ret["violations"].append('Unable to check the status for vsftpd')
    if cmd_exec['cmd_ret'] == 0:
        if not (os.path.isfile(osrnames[1])):
            violations.append("File missing: %s" % (osrnames[1]))
            ret["violations"].append("File missing: %s" % (osrnames[1]))
        else:
            linefound = lookline_in_file(afile=osrnames[1], thevalues=directives[0], commentchr='#', case="sensitive")
            # Check if anonymous ftp is enable in config file
            if (linefound):
                home_dir = osrnames[0]
                # Get home directory from config file if exists else use default path
                dirfound = lookline_in_file(afile=osrnames[1], by_regex=r'anon_root\s*=\s*.*$', commentchr='#',
                                            case="sensitive")
                if (dirfound):
                    dir_split = dirfound[0].split("=")
                    dir = dir_split[1]
                    dir = dir.rstrip("\n")
                    home_dir = dir
                if (os.path.isdir(home_dir)):
                    # Check permission for all directories containing classifed data
                    for osr in directories_containing_classified_data:
                        osr = home_dir + osr
                        if (os.path.isdir(osr)):
                            mode = oct(os.stat(osr)[ST_MODE])[-3:]
                            dir_perm = str(mode)
                            # Check required permisison
                            if (dir_perm[2] == '4' or dir_perm[2] == '5' or dir_perm[2] == '7' or dir_perm[2] == '6'):
                                dir_required_perms_change.append(osr)
                                violations.append(
                                    "Other users of directory '%s' doesn't have required permission" % (osr))
                                ret["violations"].append(
                                    "Other users of directory '%s' doesn't have required permission" % (osr))

    ret["dir"] = dir_required_perms_change
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.1.4.7
def AUTH_PAM_ORDER(osrnames=['/etc/pam.d/password-auth', '/etc/pam.d/system-auth'],
                   directives=['password pam_pwquality.so',
                               'password pam_pwhistory.so',
                               'password pam_unix.so',
                               'password pam_deny.so']):
    '''
        Ensure pam modules are in correct order in osrnames in directive order
        - osrnames=['/etc/pam.d/password-auth', '/etc/pam.d/system-auth']
        - directives=['password pam_pwquality.so',
                      'password pam_pwhistory.so',
                      'password pam_unix.so',
                      'password pam_deny.so']

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure pam modules are in correct order' + \
        ' in %s' % (' and '.join(osrnames))

    violations = []
    ret = {}

    for osrname in osrnames:
        if not os.path.isfile(osrname):
            violations.append('%s: file MISSING' % (osrname))
            ret = {'FILE_NOT_FOUND': osrname}
            directives = []  # for skipping the loop

        else:
            line_pos_dict = {}
            position_array = []
            for directive in directives:
                # 1st and 3rd  element
                search_key = ' '.join(directive.split()[0:2:1])
                pos = get_position_of_line_in_file(osrname, search_key)
                if pos != 0:
                    position_array.append(pos)
                    line_pos_dict[search_key] = pos
        if ((position_array) != sorted(position_array)):
            violations.append("Pam modules are not in correct order %s" %(line_pos_dict))
            ret[osrname] = line_pos_dict


    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")



    return ret


# IZ.1.1.13.3

def AUTH_FTP_RESTRICT(osrname='/etc/vsftpd/ftpusers'):
    '''
        If ftp is installed, ensure that users with non-expiring passwords
        must exist in below fie
        osrname='/etc/vsftpd/ftpusers'
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "If ftp is installed, ensure that users"\
    " with non-expiring passwords must exist in %s" %(osrname)

    violations = []

    cmd = "rpm -q vsftpd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        if not os.path.isfile(osrname):
            violations.append('%s: file MISSING' %(osrname))

        else:
            non_expiring_users = getfields_from_file(afile='/etc/shadow',
                                 retfieldnos=[1],
                                 keyfieldno=5, keyval='99999',
                                 delim=':', except_regex=None)
            empty_users = getfields_from_file(afile='/etc/shadow',
                                 retfieldnos=[1],
                                 keyfieldno=5, keyval='',
                                 delim=':', except_regex=None)
            non_expiring_users.extend(empty_users)
            for user in non_expiring_users:
                user = user[0]
                search_key = user
                result = lookline_in_file(afile=osrname,
                                          thevalues=search_key,
                                          commentchr='#', case="sensitive")
                if not result:
                    violations.append('%s User MISSING' % (user))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")


    return violations


# IZ.1.4.3.1.3
def SYS_SELINUX_DOMAIN(domain_name='httpd_t',
                       agreedvalue='enforcing'):
    '''
       - Ensure the SELinux state is permissive or enforcing, per domain when required.
       - domain_name= ''
       - agreedvalue= ''
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure the SELinux state is "\
            "%s, for domain %s " %(agreedvalue, domain_name)

    violations = []

    cmd = "getenforce"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_out'] != b'':
        if str(cmd_exec['cmd_out'], 'utf-8') == 'disabled':
            pass
        else:
            cmd = "semanage permissive -l"
            cmd_exec = execute_command(cmd, shell=True)
            if cmd_exec['cmd_err']:
                violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_out'] == b'' or domain_name not in str(cmd_exec['cmd_out']):
                if agreedvalue == "permissive":
                    violations.append("%s needs to be in permissive state" %(domain_name))
            elif cmd_exec['cmd_out'] == b'' or domain_name in str(cmd_exec['cmd_out']):
                if agreedvalue == "enforcing":
                    violations.append("%s needs to be in enforcing state" %(domain_name))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.8.14.3
def OSR_CRONROOT_GROUP(osrname='/var/spool/cron/root',
                       agreedperms='0755',
                       mode='max',
                       category='group',
                       mustexist=False):
    '''
        Files executed via entries in /var/spool/cron/root
        - should have permission 755 or more restrictive for group if
          owned by groups considered to be default groups for general users
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in %s: " % (osrname) + \
        "should have permission 755 or more restrictive for group considered to be default groups for general users"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#'):
        ret[osr] = []
        group_id = os.stat(osr).st_gid
        if default_group_check(group_id):
            permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                        mode=mode)
            if permfailed:
                violations.append("FS object %s permissions: %s"
                                  % (osr, permfailed))
                ret[osr].append({'problem': 'permissions',
                                 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))


# IZ.1.8.13.1.2
def OSR_UID_GID(agreeduser='root',
                agreedgroup='root'):

    '''
        Files executed via entries in osrnames should be owned by user/group that are priviledged
        - agreeduser= 'root'
        - agreedgroup= 'root'
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Files executed via entries in osrnames should be owned by user/group that are priviledged"

    violations = []
    osrs = set([])
    osrnames=["/var/spool/cron/root","/etc/crontab","/etc/cron.d/","/var/spool/cron/tabs/root"]

    for osrname in osrnames:
        if os.path.isdir(osrname):
            osrs.update(get_dir_exec_entries(osrname))
        elif os.path.isfile(osrname):
            osrs.update(get_exec_entries(osrname))
        else:
            violations.append('%s: FS object MISSING' % (osrname))

    # Extracting files and links to check Owner for files
    # executed via files or links contained in below directories
    osrdir = ["/etc/rc.d/","/etc/init.d"]
    osrs.update(list_files_in(osrdir, cond='os.access(%, os.X_OK)'))

    if len(osrs)> 0:
        for osr in osrs:
            user_id = os.stat(osr).st_uid
            if not check_previledged_uid(user_id):
                violations.append("%s osr is not owned by previledged user" %(osr))
            group_id = os.stat(osr).st_gid
            if not check_previledged_gid(group_id):
                violations.append("%s osr is not owned by previledged group" %(osr))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#IZ.1.5.9.20.4
def NET_IP_FORWARD(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directive = "net.ipv4.ip_forward = 0"):
    '''
        -  Ensure IP forwarding is disabled.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure the directives  %s are present in files %s and are included in sysctl output"\
        % ( directive, ' or '.join(osrnames))

    violations = []

    # Get the first part of directive
    value = directive.split()[0]

    # Add escape sequences to the string
    # grep_str = value.translate(str.maketrans({ ".": r"\." }))

    cmd = 'grep "' + value + '" ' + osrnames[0] + ' '
    args = shlex.split(cmd)
    # out = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = subprocess.Popen(args + glob.glob(osrnames[1] + "*"), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode('ascii')
    if cmd_err:
        violations.append("Error checking the contents of configuration files")
    if cmd_ret != 0:
        if (directive not in output) and ('Directive missing' not in violations) :
            violations.append("Directive missing")

    cmd = "sysctl " + directive.split()[0]
    cmd_exec = execute_command(cmd)
    output = cmd_exec['cmd_out'].decode('ascii')
    if cmd_exec['cmd_ret'] != 0 or cmd_exec['cmd_err']:
        violations.append("Error executing command")
    elif (directive not in output) and ('Directive missing' not in violations):
        violations.append("Directive missing")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations



#IZ.1.5.9.20.5
def NET_SOURCE_ROUTE(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directives = ['net.ipv4.conf.all.accept_source_route = 0','net.ipv4.conf.default.accept_source_route = 0']):
    '''
        -  Ensure source routed packets are not accepted
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure the directives  %s are present in files %s and are included in sysctl output"\
        % ( ' and '.join(directives), ' or '.join(osrnames))

    violations = []

    for directive in directives:
        #Get the first part of directive
        value = directive.split()[0]

        #Add escape sequences to the string
        #grep_str = value.translate(str.maketrans({ ".": r"\." }))

        cmd = 'grep "'+ value +'" ' + osrnames[0] + ' '
        args = shlex.split(cmd)
        #out = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out = subprocess.Popen(args + glob.glob(osrnames[1] + "*"), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (cmd_out, cmd_err) = out.communicate()
        cmd_ret = out.returncode
        output = cmd_out.decode('ascii')
        if cmd_err:
            violations.append("Error checking the contents of configuration files")
        if cmd_ret != 0:
            if (directive not in output) and  ('Directive missing' not in violations):
                violations.append("Directive missing")

        cmd = "sysctl " + directive.split()[0]
        cmd_exec = execute_command(cmd)
        output = cmd_exec['cmd_out'].decode('ascii')
        if cmd_exec['cmd_ret'] != 0 or cmd_exec['cmd_err']:
            violations.append("Error executing command")
        elif (directive not in output) and ('Directive missing' not in violations):
            violations.append("Directive missing")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#IZ.1.5.9.20.6
def NET_SECURE_ICMP_REDIRECTS(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directives = ['net.ipv4.conf.all.secure_redirects = 0','net.ipv4.conf.default.secure_redirects = 0']):
    '''
        -  Ensure secure ICMP redirects are not accepted
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure the directives  %s are present in files %s and are included in sysctl output"\
        % ( ' and '.join(directives), ' or '.join(osrnames))

    violations = []

    for directive in directives:
        #Get the first part of directive
        value = directive.split()[0]

        #Add escape sequences to the string
        #grep_str = value.translate(str.maketrans({ ".": r"\." }))

        cmd = 'grep "'+ value +'" ' + osrnames[0] + ' '
        args = shlex.split(cmd)
        #out = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out = subprocess.Popen(args + glob.glob(osrnames[1] + "*"), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (cmd_out, cmd_err) = out.communicate()
        cmd_ret = out.returncode
        output = cmd_out.decode('ascii')
        if cmd_err:
            violations.append("Error checking the contents of configuration files")
        if cmd_ret != 0:
            if (directive not in output) and ('Directive missing' not in violations):
                violations.append("Directive missing")

        cmd = "sysctl " + directive.split()[0]
        cmd_exec = execute_command(cmd)
        output = cmd_exec['cmd_out'].decode('ascii')
        if cmd_exec['cmd_ret'] != 0 or cmd_exec['cmd_err']:
            violations.append("Error executing command")
        elif (directive not in output) and ('Directive missing' not in violations):
            violations.append("Directive missing")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#IZ.1.5.9.20.7
def NET_LOG_MARTIANS(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directives = ['net.ipv4.conf.all.log_martians = 1','net.ipv4.conf.default.log_martians = 1']):
    '''
        -  Ensure suspicious packets are logged
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure the directives  %s are present in files %s and are included in sysctl output"\
        % ( ' and '.join(directives), ' or '.join(osrnames))

    violations = []

    for directive in directives:

        #Get the first part of directive
        value = directive.split()[0]

        #Add escape sequences to the string
        #grep_str = value.translate(str.maketrans({ ".": r"\." }))

        cmd = 'grep "'+ value +'" ' + osrnames[0] + ' '
        args = shlex.split(cmd)
        #out = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out = subprocess.Popen(args + glob.glob(osrnames[1] + "*"), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (cmd_out, cmd_err) = out.communicate()
        cmd_ret = out.returncode
        output = cmd_out.decode('ascii')
        if cmd_err:
            violations.append("Error checking the contents of configuration files")
        if cmd_ret != 0:
            if (directive not in output) and ('Directive missing' not in violations):
                violations.append("Directive missing")


        cmd = "sysctl " + directive.split()[0]
        cmd_exec = execute_command(cmd)
        output = cmd_exec['cmd_out'].decode('ascii')
        if cmd_exec['cmd_ret'] != 0 or cmd_exec['cmd_err']:
            violations.append("Error executing command")
        elif (directive not in output) and ('Directive missing' not in violations):
            violations.append("Directive missing")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


#IZ.1.5.9.20.8
def NET_ICMP_BOGUS_RESPONSES(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directive = "net.ipv4.icmp_ignore_bogus_error_responses = 1"):
    '''
        -  Ensure bogus ICMP responses are ignored
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure the directives  %s are present in files %s and are included in sysctl output"\
        % ( directive, ' or '.join(osrnames))

    violations = []

    #Get the first part of directive
    value = directive.split()[0]

    #Add escape sequences to the string
    #grep_str = value.translate(str.maketrans({ ".": r"\." }))

    cmd = 'grep "'+ value +'" ' + osrnames[0] + ' '
    args = shlex.split(cmd)
    #out = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = subprocess.Popen(args + glob.glob(osrnames[1] + "*"), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode('ascii')
    if cmd_err:
        violations.append("Error checking the contents of configuration files")
    if cmd_ret != 0:
        if (directive not in output) and ('Directive missing' not in violations) :
            violations.append("Directive missing")

    cmd = "sysctl " + directive.split()[0]
    cmd_exec = execute_command(cmd)
    output = cmd_exec['cmd_out'].decode('ascii')
    if cmd_exec['cmd_ret'] != 0 or cmd_exec['cmd_err']:
        violations.append("Error executing command")
    elif (directive not in output) and ('Directive missing' not in violations):
        violations.append("Directive missing")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.2.1.3.0
def PASSWORD_ALGO():
    '''
        -  Ensure sha512 is being used for system password hashing
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure sha512 is being used for system password hashing"

    violations = []
    present = []

    ps = subprocess.Popen(['authconfig', '--test'], shell=False, stdout=subprocess.PIPE)
    grep = subprocess.Popen(['grep', 'hash'], shell=False, stdin=ps.stdout, stdout=subprocess.PIPE)
    grep_output, err = grep.communicate()

    if err:
        violations.append("Error, failed in executing command: %s" % (str(err)))

    elif grep_output != b'':
        if "sha512" not in str(grep_output):
            violations.append("sha512 is not being used for password hashing")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.4.6.3
def AUTO_LOGOFF_SH(osrname = '/etc/profile.d/IBMsinit.sh', directives=['TMOUT=21600', 'export TMOUT']):
    '''
        -  Automatically log off users after a defined period of inactivity
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Automatically log off users after a defined period of inactivity"
    violations = []
    present = []

    val= ''
    if os.path.isfile(osrname):
        val = lookline_in_file(afile=osrname, by_regex=r'TMOUT\s*=\s*.*$',  commentchr='#', case="sensitive")
    
        #print val
        if val:
            val_split = val[0].split("=")
            time = val_split[1]
            #print time
            expected_time_list = directives[0].split("=")
            expected_time = expected_time_list[1]
            if(int(time) != int(expected_time)):
                violations.append("%s directive time is not set as expected in /etc/profile.d/IBMsinit.sh"%(val[0]))
        else:
            violations.append("%s directive is not a part of /etc/profile.d/IBMsinit.sh" % (directives[0]))
    
        val1 = ''
        val1 = lookline_in_file(afile=osrname, thevalues=directives[1], commentchr='#', case="sensitive")

        if not val1:
            violations.append("%s directive is not a part of /etc/profile.d/IBMsinit.sh" % (directives[1]))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.4.6.4
def AUTO_LOGOFF_CSH(osrname = '/etc/profile.d/IBMsinit.csh', directive='autologout=360'):
    '''
        -  Automatically log off users after a defined period of inactivity
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Automatically log off users after a defined period of inactivity"

    violations = []
    present = []

    if os.path.isfile(osrname):
        val= ''
        val = lookline_in_file(afile=osrname, by_regex=r'autologout\s*=\s*.*$',
                                        commentchr='#', case="sensitive")

        #print val
        if val:
            val_split = val[0].split("=")
            time = val_split[1]
            #print time
            expected_time_list = directive.split("=")
            expected_time = expected_time_list[1]
            if(int(time) != int(expected_time)):
                violations.append("%s directive time is not set as expected in /etc/profile.d/IBMsinit.csh"%(val[0]))
        else:
            violations.append("%s directive is not a part of /etc/profile.d/IBMsinit.csh" % (directive))


    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

#AD.30.0.1.0
def AUTO_LOGOFF(osrnames = ['/root/.bashrc', '/root/.bash_profile'], directive=''):
    '''
        -  Automatically log off users after a defined period of inactivity
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Automatically log off users after a defined period of inactivity"

    violations = []
    present = []

    val= ''
    val1 = lookline_in_file(afile=osrnames[0], by_regex=r'TMOUT\s*=\s*.*$',
                                    commentchr='#', case="sensitive")

    val2 = lookline_in_file(afile=osrnames[1], by_regex=r'TMOUT\s*=\s*.*$',
                            commentchr='#', case="sensitive")
    #print val

    if not val1 and not val2:
        violations.append("%s directive is missing from both files /root/.bashrc and /root/.bash_profile" % (directive))
    elif val1 and val2:
        val_split1 = val1[0].split("=")
        time1 = val_split1[1]
        val_split2 = val2[0].split("=")
        time2 = val_split2[1]
        #print time
        expected_time_list = directive.split("=")
        expected_time = expected_time_list[1]
        if(int(time1) != int(expected_time)):
            violations.append("%s directive time is not set as expected in /root/.bashrc"%(val1[0]))
        if (int(time2) != int(expected_time)):
            violations.append("%s directive time is not set as expected in /root/.bash_profile" % (val2[0]))
    elif val1:
        val_split1 = val1[0].split("=")
        time1 = val_split1[1]
        expected_time_list = directive.split("=")
        expected_time = expected_time_list[1]
        if (int(time1) != int(expected_time)):
            violations.append("%s directive time is not set as expected in /root/.bashrc" % (val1[0]))

        violations.append("%s directive is missing from file /root/.bash_profile" % (directive))
    elif val2:
        val_split2 = val2[0].split("=")
        time2 = val_split2[1]
        # print time
        expected_time_list = directive.split("=")
        expected_time = expected_time_list[1]
        if (int(time2) != int(expected_time)):
            violations.append("%s directive time is not set as expected in /root/.bash_profile" % (val2[0]))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.5.12.4
def NET_MTA_LOCAL_ONLY(osrname = '/etc/postfix/main.cf',
                       directives = ['tcp 0 0 127.0.0.1:25 0.0.0.0:* LISTEN',
                                     'inet_interfaces = loopback-only']):

    '''
       -  Ensure that the MTA is not listening on any non-loopback address
       - osrname= '/etc/postfix/main.cf'
       - directives= ['inet_interfaces = loopback-only']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + " Ensure that the MTA is not "\
        " listening on any non-loopback address"

    violations = []

    cmd_out =  subprocess.getoutput("netstat -an | grep LIST | grep ':25[[:space:]]' ")
    if cmd_out:
        cmd_out_array = cmd_out.split()
        cmd_out = ' '.join(cmd_out_array)
        if directives[0] not in cmd_out:
            violations.append("MTA is listening on non-loopback address")
    else:
        violations.append("MTA is listening on non-loopback address")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.2.0.1.1
def GMD_BUSINESS_USE(osrnames = ['/etc/dconf/profile/gdm',
                                 '/etc/dconf/db/gdm.d/01-banner-message'],
                     gdm_directives = ['user-db:user','system-db:gdm','file-db:/usr/share/gdm/greeter-dconf-defaults'],
                     banner_directives = ['[org/gnome/login-screen]',
                                          'banner-message-enable=true',
                                           "banner-message-text='Authorized uses only. All activity may be monitored and reported.'"]):

    '''
       - Ensure Business Use Notice exists in Gnome
       - osrnames = ['/etc/dconf/profile/gdm',
                     '/etc/dconf/db/gdm.d/01-banner-message']
       - gdm_directives = ['user-db:user','system-db:gdm','file-db:/usr/share/gdm/greeter-dconf-defaults'],
       - banner_directives = ['[org/gnome/login-screen]',
                            'banner-message-enable=true',
                             "banner-message-text='Authorized uses only. All activity may be monitored and reported.'"]
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + " Ensure Business Use Notice exists in Gnome"

    violations = []
    ret = {}

    cmd = "systemctl status display-manager"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        if 'CMD_ERR' not in ret.keys():
            ret['CMD_ERR'] = []
        ret['CMD_ERR'].append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        if not os.path.isfile(osrnames[0]):
            if 'FILE_NOT_FOUND' not in ret.keys():
                ret['FILE_NOT_FOUND'] = []
            ret['FILE_NOT_FOUND'].append(osrnames[0])
            violations.append('%s: GDM file MISSING' % (osrnames[0]))
        else:
            for directive in gdm_directives:
                search_key = directive
                result = lookline_in_file(
                    afile=osrnames[0],
                    thevalues=search_key,
                    commentchr='#', case="sensitive")
                if not result:
                    if 'MISSING_DIRECTIVES' not in ret.keys():
                        ret['MISSING_DIRECTIVES'] = []
                    ret['MISSING_DIRECTIVES'].append(directive)
                    violations.append('GDM Line not found in file %s' % (osrnames[0]))

        if not os.path.isfile(osrnames[1]):
            if 'FILE_NOT_FOUND' not in ret.keys():
                ret['FILE_NOT_FOUND'] = []
            ret['FILE_NOT_FOUND'].append(osrnames[1])
            violations.append('%s: Banner file MISSING' % (osrnames[1]))
        else:
            for directive in banner_directives:
                search_key = directive
                result = lookline_in_file(
                    afile=osrnames[1],
                    thevalues=search_key,
                    commentchr='#', case="sensitive")
                if not result:
                     if 'MISSING_DIRECTIVES' not in ret.keys():
                         ret['MISSING_DIRECTIVES'] = []
                     ret['MISSING_DIRECTIVES'].append(directive)
                     violations.append('Banner Line not found in file %s' % (osrnames[1]))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret


# IZ.1.5.1.8
def NET_FTP_DIR_PERMS(osrnames=['/var/ftp', '/etc/vsftpd/vsftpd.conf'], directives=['anonymous_enable=YES', 'anon_root=*']):
    '''
        - If home directory exists and anonymous ftp is enabled, each directory under home directory may allow read access or write access to anonymous users, but not both.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + 'If home directory exists and anonymous ftp is enabled, each directory under home directory may allow read access or write access to anonymous users, but not both.'

    violations = []
    ret = {}
    ret["violations"] = []
    dir_required_perms_change = []
    home_dir = osrnames[0]
    cmd = 'systemctl is-enabled vsftpd'
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Unable to check the status for vsftpd")
        ret["violations"].append('Unable to check the status for vsftpd')
    if cmd_exec['cmd_ret'] == 0:
        if not (os.path.isfile(osrnames[1])):
            violations.append("File missing: %s" % (osrnames[1]))
            ret["violations"].append("File missing: %s" % (osrnames[1]))
        else:
            linefound = lookline_in_file(afile=osrnames[1], thevalues=directives[0], commentchr='#', case="sensitive")

            # Check if anonymous ftp is enable in config file
            if (linefound):
                dirfound = lookline_in_file(afile=osrnames[1], thevalues=directives[1], commentchr='#',
                                            case="sensitive")
                if dirfound:
                    dir_split = dirfound[0].split("=")
                    home_dir = dir_split[1]
                if (os.path.exists(home_dir) and os.path.isdir(home_dir)):
                    osr_names = list_files_in_dir_with_extension(home_dir, extension='')
                    if (osr_names):
                        # Check permission of each file/directory
                        for osr in osr_names:
                            mode = oct(os.stat(osr)[ST_MODE])[-3:]
                            dir_perm = str(mode)
                            if (os.path.isdir(osr)):
                                if (dir_perm[2] == '6' or dir_perm[2] == '7'):
                                    dir_required_perms_change.append(osr)
                                    violations.append(
                                        "Other users of directory '%s' doesn't have required permission" % (osr))
                                    ret["violations"].append(
                                        "Other users of directory '%s' doesn't have required permission" % (osr))

    ret["dir"] = dir_required_perms_change
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.5.2.1
def NET_TFTP_OTHER_PERMS(tftp_enabled=True, osrname='/etc/xinetd.d/tftp', permitted_directory='/tmp/tftp'):
    '''
       If TFTP is enabled, the permitted directory must be specified with the -s parameter to server_args.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + 'If TFTP is enabled, the permitted directory must be specified with the -s parameter to server_args.'
    ret = {}
    ret["violations"] = []
    violations = []
    new_content = []
    if tftp_enabled:
        cmd = 'chkconfig --list --type xinetd'
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Unable to find xinetd service")
            ret["violations"].append("Unable to find xinetd service")
        if cmd_exec['cmd_ret'] == 0:
            if not cmd_exec['cmd_out'] == '':
                if os.path.isfile(osrname):
                    linefound = lookline_in_file(afile=osrname, thevalues='server_args', commentchr='#',
                                                 case="sensitive")
                    # Check if permitted directory is not specified
                    is_permitted_directory = lookline_in_file(afile=osrname, thevalues=permitted_directory,
                                                              commentchr='#', case="sensitive")
                    if not is_permitted_directory:
                        ret["linefound"] = linefound[0]
                        violations.append(
                            "Permitted directory '%s' is not specified with the -s parameter to server_args inside file '%s'" % (
                            permitted_directory, osrname))
                        ret["violations"].append(
                            "Permitted directory '%s' is not specified with the -s parameter to server_args inside file '%s'" % (
                            permitted_directory, osrname))
                else:
                    violations.append("File Missing %s" % (osrname))
                    ret["violations"].append("File Missing %s" % (osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations


# AD.1.8.18.2
def OSR_INITD_RCD_OTHERS(osrnames=["/etc/rc.d/rc0.d", "/etc/rc.d/rc1.d",
                                   "/etc/rc.d/rc2.d", "/etc/rc.d/rc3.d",
                                   "/etc/rc.d/rc4.d", "/etc/rc.d/rc5.d",
                                   "/etc/rc.d/rc6.d", "/etc/rc.d/rcS.d"],
                         agreedperms='0755',
                         mode='max',
                         category='others'):
    '''
        Files executed via files or links contained in
        /etc/rc.d/rc0.d, /etc/rc.d/rc1.d, /etc/rc.d/rc2.d, /etc/rc.d/rc3.d,
        /etc/rc.d/rc4.d, /etc/rc.d/rc5.d, /etc/rc.d/rc6.d, /etc/rc.d/rcS.d
        - should have permission 755 or more restrictive for others
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Files executed via files or links " + \
        "contained in %s: " % (' or '.join(osrnames)) + \
        "should have permission 755 or more restrictive for others"

    violations = []
    new_osrnames = []

    for osr in osrnames:
        if os.path.isdir(osr):
            new_osrnames.append(osr)

    executable_files = list_files_in(new_osrnames, cond='os.access(%, os.X_OK)')
    new_osrnames.extend(executable_files)
    for osr in new_osrnames:
        permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                    mode=mode,category =category)
        if permfailed:
            violations.append("%s FS object do not have permission: %s" %
                              (osr, permfailed))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return violations


# AD.1.8.18.3
def OSR_INITD_RCD_GROUP(osrnames=["/etc/rc.d/rc0.d", "/etc/rc.d/rc1.d",
                                  "/etc/rc.d/rc2.d", "/etc/rc.d/rc3.d",
                                  "/etc/rc.d/rc4.d", "/etc/rc.d/rc5.d",
                                  "/etc/rc.d/rc6.d", "/etc/rc.d/rcS.d"],
                        agreedperms='0755',
                        mode='max',
                        category='group'):
    '''
        Files executed via files or links contained in
        /etc/rc.d/rc0.d, /etc/rc.d/rc1.d, /etc/rc.d/rc2.d, /etc/rc.d/rc3.d,
        /etc/rc.d/rc4.d, /etc/rc.d/rc5.d, /etc/rc.d/rc6.d, /etc/rc.d/rcS.d
        - should have permission 755 or more restrictive for group if
          owned by groups considered to be default groups for general users
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Files executed via files or links " + \
        "contained in %s: " % (' or '.join(osrnames)) + \
        "should have permission 755 or more restrictive for group"

    violations = []
    new_osrnames = []

    for osr in osrnames:
        if os.path.isdir(osr):
            new_osrnames.append(osr)

    executable_files = list_files_in(new_osrnames, cond='os.access(%, os.X_OK)')
    new_osrnames.extend(executable_files)
    for osr in new_osrnames:
        group_id = os.stat(osr).st_gid
        if default_group_check(group_id):
            permfailed = perm_violation(obj=osr, refperms=agreedperms,
                                        mode=mode,category =category)
            if permfailed:
                violations.append("%s FS object do not have permission: %s" %
                                  (osr, permfailed))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return violations


# IZ.1.8.22.1
def OPT_DIR_FILES_PERMS(osrname='/opt'):
    '''
       Files in directory /opt may not have both the other-write and any execute permissions set. This requirement to be applied recursively to files contained within subdirectories.

    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + 'Files in (opt) directory may not have both the other-write and any execute permissions set. This requirement to be applied recursively to files contained within subdirectories.'

    violations = []
    ret = {}
    files_required_perms_change = []
    ret["violations"] = []
    files = []

    if not (os.path.isdir(osrname)):
        violations.append("Directory missing: %s" % (osrname))
        ret["violations"].append("Directory missing: %s" % (osrname))
    else:
        # r=root, d=directories, f = files
        for r, d, f in os.walk(osrname):
            for file in f:
                files.append(os.path.join(r, file))

        # Check permission & uid of each file
        for osr in files:
            mode = oct(os.stat(osr)[ST_MODE])[-3:]
            dir_perm = str(mode)
            if (pwd.getpwuid(os.stat(osr).st_uid).pw_uid > 999):
                if (dir_perm[2] !='4'):
                    files_required_perms_change.append(osr)
                    violations.append("Other users of directory '%s' doesn't have required permission" % (osr))
                    ret["violations"].append("Other users of directory '%s' doesn't have required permission" % (osr))

    ret["files"] = files_required_perms_change
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.8.22.2
def VAR_DIR_FILES_PERMS(osrname='/var'):
    '''
       Files in directory /var may not have both the other-write and any execute permissions set. This requirement to be applied recursively to files contained within subdirectories.

    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + 'Files in (/var) directory may not have both the other-write and any execute permissions set. This requirement to be applied recursively to files contained within subdirectories.'

    violations = []
    ret = {}
    files_required_perms_change = []
    ret["violations"] = []
    files = []

    if not (os.path.isdir(osrname)):
        violations.append("Directory missing: %s" % (osrname))
        ret["violations"].append("Directory missing: %s" % (osrname))
    else:
        # r=root, d=directories, f = files
        for r, d, f in os.walk(osrname):
            for file in f:
                files.append(os.path.join(r, file))

        # Check permission & uid of each file
        for osr in files:
            mode = oct(os.stat(osr)[ST_MODE])[-3:]
            dir_perm = str(mode)
            if (pwd.getpwuid(os.stat(osr).st_uid).pw_uid > 999):
                if (dir_perm[2] == '3' or dir_perm[2] == '7'):
                    files_required_perms_change.append(osr)
                    violations.append("Other users of directory '%s' doesn't have required permission" % (osr))
                    ret["violations"].append("Other users of directory '%s' doesn't have required permission" % (osr))

    ret["files"] = files_required_perms_change
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.8.22.3
def USRLOCAL_DIR_FILES_PERMS(osrname='/usr/local'):
    '''
       Files in directory /usr/local may not have both the other-write and any execute permissions set. This requirement to be applied recursively to files contained within subdirectories.

    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + 'Files in (/usr/local) directory may not have both the other-write and any execute permissions set. This requirement to be applied recursively to files contained within subdirectories.'

    violations = []
    ret = {}
    files_required_perms_change = []
    ret["violations"] = []
    files = []

    if not (os.path.isdir(osrname)):
        violations.append("Directory missing: %s" % (osrname))
        ret["violations"].append("Directory missing: %s" % (osrname))
    else:
        # r=root, d=directories, f = files
        for r, d, f in os.walk(osrname):
            for file in f:
                files.append(os.path.join(r, file))

        # Check permission & uid of each file
        for osr in files:
            if (os.path.isfile(osr)):
                mode = oct(os.stat(osr)[ST_MODE])[-3:]
                dir_perm = str(mode)
                if (pwd.getpwuid(os.stat(osr).st_uid).pw_uid > 999):
                    if (dir_perm[2] == '3' or dir_perm[2] == '7'):
                        files_required_perms_change.append(osr)
                        violations.append("Other users of directory '%s' doesn't have required permission" % (osr))
                        ret["violations"].append("Other users of directory '%s' doesn't have required permission" % (osr))

    ret["files"] = files_required_perms_change
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.8.22.4
def TMP_DIR_FILES_PERMS(osrname='/tmp'):
    '''
       Files in directory /tmp may not have both the other-write and any execute permissions set. This requirement to be applied recursively to files contained within subdirectories.

    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + 'Files in (/tmp) directory may not have both the other-write and any execute permissions set. This requirement to be applied recursively to files contained within subdirectories.'

    violations = []
    ret = {}
    files_required_perms_change = []
    ret["violations"] = []
    files = []

    if not (os.path.isdir(osrname)):
        violations.append("Directory missing: %s" % (osrname))
        ret["violations"].append("Directory missing: %s" % (osrname))
    else:
        # r=root, d=directories, f = files
        for r, d, f in os.walk(osrname):
            for file in f:
                files.append(os.path.join(r, file))

        # Check permission & uid of each file
        for osr in files:
            mode = oct(os.stat(osr)[ST_MODE])[-3:]
            dir_perm = str(mode)
            if (pwd.getpwuid(os.stat(osr).st_uid).pw_uid > 999):
                if (dir_perm[2] == '3' or dir_perm[2] == '7'):
                    files_required_perms_change.append(osr)
                    violations.append("Other users of directory '%s' doesn't have required permission" % (osr))
                    ret["violations"].append("Other users of directory '%s' doesn't have required permission" % (osr))

    ret["files"] = files_required_perms_change
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# IZ.1.8.23.1
def SET_STICKY_BIT_WORLD_WRITEABLE_DIR():
    '''
       Set the sticky bit on world writeable directories.

    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Set the sticky bit on world writeable directories.'
    violations = []
    ret = {}
    osr_names = []
    cmd = "find / -xdev -type d \( -perm -0002 -a ! -perm -1000 \) -print"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
        ret["violations"] = "Error, failed in executing command: %s" % (str(cmd_exec['cmd_err']))
    if cmd_exec['cmd_out']:
        osr_names = cmd_exec['cmd_out'].decode().split("\n")
        osr_names = osr_names[0:(len(osr_names) - 1)]
        ret["world_writeable_directories"] = osr_names
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    elif len(osr_names) > 0:
        log_audit(descr, "FAILED")
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# IZ.1.5.9.24.2
def DISABLE_ANON_FTPD(osrname='/etc/vsftpd/vsftpd.conf', directive='anonymous_enable=NO'):
    '''
        If ftpd is installed, disable anonymous ftp in $file /etc/vsftpd/vsftpd.conf via: anonymous_enable=NO
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'If ftpd is installed, disable anonymous ftp in $file /etc/vsftpd/vsftpd.conf'
    violations = []
    # Check if vsftpd is installed
    cmd = "rpm -q vsftpd"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] == 0:
        # Check if vsftpd is enabled
        cmd = 'systemctl is-enabled vsftpd'
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_ret'] == 0:
            if os.path.isfile(osrname):
                linefound = lookline_in_file(afile=osrname, thevalues=directive, commentchr='#', case="sensitive")
                if not linefound:
                    search_string = directive.split('=')[0] + '=YES'
                    vsftpd_enabled = lookline_in_file(afile=osrname, thevalues=search_string, commentchr='#', case="sensitive")
                    if vsftpd_enabled:
                        # anonymous_enable=YES
                        violations.append("Directive is present")
                    else:
                        violations.append("Directive is absent")
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations

#AV.1.2.1.2:AV.1.2.1.3
def RSYS_LOGLEVEL_SET_INFO(osrname = '/etc/rsyslog.conf', txt='', message=''):

    '''
        ----------------
            REQ_ID: 17
        ----------------

        /etc/rsyslog.conf
            -   should contain info msgs in /var/log/messages if not then it should be get written to the file
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking messages passing to  %s in %s to be %s" \
        % (txt, osrname, message)

    violations = []
    result = {}

    if os.path.isfile(osrname) and os.stat(osrname).st_size:
        match = lookline_in_file(afile=osrname,
                                  thevalues=txt,
                                  commentchr='#', case="sensitive")
        
        msgline = "".join(match)

        if txt in msgline:
            thisline = msgline.strip()
            if thisline.split() == message.strip().split():
                violations = []

            if thisline.split() != message.strip().split():
                violations.append("File have wrong message %s" % (osrname))
                violations.append(str(thisline))
                result[osrname, thisline] = []
                result[osrname, thisline].append({'problem': 'wrong entry'})

        else:
            violations.append("File dont have *info in messages %s" % (osrname))
            result[osrname] = []
            result[osrname].append({'problem': 'missing'})

        if violations:
            log_audit(descr, "FAILED", details=violations)
        else:
            log_audit(descr, "PASS")

        return violations

# IZ.C.1.6.1.5
def  MCS_SERVICE():
    '''
        Ensure the MCS Translation Service (mcstrans) is not installed
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that the mcstrans service is not installed"

    violations = []

    if generic_check_if_package_installed("mcstrans"):
        violations.append("mcstrans service is installed")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.7.3
def  PASSWORD_SYS_IDS():
    '''
        Password must not be assigned for these system IDs
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Password must not be assigned for these system IDs"
    violations = []
    user_list = ['bin','daemon','adm','lp','sync','shutdown','halt','mail','uucp','operator','games','gopher','ftp','nobody','dbus','usbmuxd','rpc','avahi-autoipd','vcsa','rtkit','saslauth','postfix','avahi','ntp','apache','radvd','rpcuser','nfsnobody','qemu','haldaemon','nm-openconnect','pulse','gsanslcd','gdm','sshd','tcpdump','abrt','chrony','colord','geoclue','gluster','gnome-initial-setup','insights','polkitd','rpc','setroubleshoot','sssd','systemd-bus-proxy','systemd-network','tss','unbound']
    for usr in range(0,len(user_list)):
        user = user_list[usr]
        pwd_age_arr = getfields_from_file(afile='/etc/shadow', retfieldnos=[1, 2],
                                      keyfieldno=1, keyval=user,
                                      delim=':', except_regex=None)
        if pwd_age_arr:
          (usr, pwd) = pwd_age_arr[0]
          if pwd not in ('x', '!', '!!', '*','!*'):  # pwd is set
              #print("violation:",user)
              violations.append('Password is set for the ID %s it must be locked'
                                  % (user))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.5.10.3
def  NIS_SETTINGS():
    '''
        Network information services plus (nis+) settings
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that the ypbind service is not installed"

    violations = []

    if generic_check_if_package_installed("ypbind"):
        violations.append("ypbind service is installed")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations
    
# IZ.2.1.2
def  CHECKSUM_FUNCTION_INSTALL():
    '''
        The 'native' encryption/checksum function utilizing at a minimum sha512 and SHA-1 algorithm must be installed
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure that the coreutils/openssl service is installed"

    violations = []
    service_list = ['coreutils','openssl']

    if not generic_check_if_package_installed("coreutils"):
        if not generic_check_if_package_installed("openssl"):
            violations.append("coreutils,openssl services not installed")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.2.1.4.0
def CRYPTO_POLICIES():
    '''
        System-wide Cryptographic policies
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Set Crypto Policy to any valid value (DEFAULT, FUTURE, or FIPS ) except LEGACY'
    violations = []
    ret = {}

    cmd = "update-crypto-policies --show"
    cmd_exec = execute_command(cmd,shell=True)
    if cmd_exec['cmd_err']:
        log_audit(descr, "N/A")
        return
    if cmd_exec['cmd_ret'] == 0 and 'LEGACY' in str(cmd_exec['cmd_out']):
        violations.append("Cryptographic policy is set to LEGACY")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
       
    return violations

# IZ.C.1.1.1.1
def DISABLE_CRAMFS_MOUNT():
    '''
        Ensure mounting of cramfs filesystems is disabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure mounting of cramfs filesystems is disabled'
    violations = []
    ret = {}

    cmd = "modprobe -n -v cramfs"
    cmd1= "lsmod"
    cmd_exec = execute_command(cmd)
    cmd_exec1 = execute_command(cmd1)
    if cmd_exec['cmd_err'] or cmd_exec1['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if 'cramfs' in str(cmd_exec1['cmd_out']):
        violations.append("mounting of cramfs filesystems is not disabled")
    if cmd_exec['cmd_ret'] == 0 and 'install /bin/true' not in str(cmd_exec['cmd_out']):
        violations.append("mounting of cramfs filesystems is not disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.C.1.1.1.2
def DISABLE_FREEVXFS_MOUNT():
    '''
        Ensure mounting of freevxfs filesystems is disabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure mounting of freevxfs filesystems is disabled'
    violations = []
    ret = {}

    cmd = "modprobe -n -v freevxfs"
    cmd1= "lsmod"
    cmd_exec = execute_command(cmd)
    cmd_exec1 = execute_command(cmd1)
    if cmd_exec['cmd_err'] or cmd_exec1['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if 'freevxfs' in str(cmd_exec1['cmd_out']):
        violations.append("mounting of freevxfs filesystems is not disabled")
    if cmd_exec['cmd_ret'] == 0 and 'install /bin/true' not in str(cmd_exec['cmd_out']):
        violations.append("mounting of freevxfs filesystems is not disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.C.1.1.1.3
def DISABLE_JFFS2_MOUNT():
    '''
        Ensure mounting of jffs2 filesystems is disabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure mounting of jffs2 filesystems is disabled'
    violations = []
    ret = {}

    cmd = "modprobe -n -v jffs2"
    cmd1= "lsmod"
    cmd_exec = execute_command(cmd)
    cmd_exec1 = execute_command(cmd1)
    if cmd_exec['cmd_err'] or cmd_exec1['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if 'jffs2' in str(cmd_exec1['cmd_out']):
        violations.append("mounting of jffs2 filesystems is not disabled")
    if cmd_exec['cmd_ret'] == 0 and 'install /bin/true' not in str(cmd_exec['cmd_out']):
        violations.append("mounting of jffs2 filesystems is not disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.C.1.1.1.4
def DISABLE_HFS_MOUNT():
    '''
        Ensure mounting of hfs filesystems is disabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure mounting of hfs filesystems is disabled'
    violations = []
    ret = {}

    cmd = "modprobe -n -v hfs"
    cmd1= "lsmod"
    cmd_exec = execute_command(cmd)
    cmd_exec1 = execute_command(cmd1)
    if cmd_exec['cmd_err'] or cmd_exec1['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if 'hfs' in str(cmd_exec1['cmd_out']):
        violations.append("mounting of hfs filesystems is not disabled")
    if cmd_exec['cmd_ret'] == 0 and 'install /bin/true' not in str(cmd_exec['cmd_out']):
        violations.append("mounting of hfs filesystems is not disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.C.1.1.1.5
def DISABLE_HFSPLUS_MOUNT():
    '''
        Ensure mounting of hfsplus filesystems is disabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure mounting of hfsplus filesystems is disabled'
    violations = []
    ret = {}

    cmd = "modprobe -n -v hfsplus"
    cmd1= "lsmod"
    cmd_exec = execute_command(cmd)
    cmd_exec1 = execute_command(cmd1)
    if cmd_exec['cmd_err'] or cmd_exec1['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if 'hfsplus' in str(cmd_exec1['cmd_out']):
        violations.append("mounting of hfsplus filesystems is not disabled")
    if cmd_exec['cmd_ret'] == 0 and 'install /bin/true' not in str(cmd_exec['cmd_out']):
        violations.append("mounting of hfsplus filesystems is not disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.C.1.1.1.6
def DISABLE_SQUASHFS_MOUNT():
    '''
        Ensure mounting of squashfs filesystems is disabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure mounting of squashfs filesystems is disabled'
    violations = []
    ret = {}

    cmd = "modprobe -n -v squashfs"
    cmd1= "lsmod"
    cmd_exec = execute_command(cmd)
    cmd_exec1 = execute_command(cmd1)
    if cmd_exec['cmd_err'] or cmd_exec1['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if 'squashfs' in str(cmd_exec1['cmd_out']):
        violations.append("mounting of squashfs filesystems is not disabled")
    if cmd_exec['cmd_ret'] == 0 and 'install /bin/true' not in str(cmd_exec['cmd_out']):
        violations.append("mounting of squashfs filesystems is not disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.C.1.1.1.7
def DISABLE_UDF_MOUNT():
    '''
        Ensure mounting of udf filesystems is disabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure mounting of udf filesystems is disabled'
    violations = []
    ret = {}

    cmd = "modprobe -n -v udf"
    cmd1= "lsmod"
    cmd_exec = execute_command(cmd)
    cmd_exec1 = execute_command(cmd1)
    if cmd_exec['cmd_err'] or cmd_exec1['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if 'udf' in str(cmd_exec1['cmd_out']):
        violations.append("mounting of udf filesystems is not disabled")
    if cmd_exec['cmd_ret'] == 0 and 'install /bin/true' not in str(cmd_exec['cmd_out']):
        violations.append("mounting of udf filesystems is not disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.7.2
def RESTRICT_LOGIN_ACCESS():
    '''
        Login access must be restricted to the physical console, or to a method that provides accountability to an individual
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Login access must be restricted to the physical console, or to a method that provides accountability to an individual'
    violations = []
    ret = {}
    cmd= "grep pts /etc/securetty"
    cmd_exec = execute_command(cmd)
    if not (os.path.isfile("/etc/securetty")):
        violations.append("securetty file is not present")
    elif 'pts' in str(cmd_exec['cmd_out']):
        violations.append("pts entry is present in file")
        
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.2.4.3
def DIR_FAILLOCK_EXISTS():
    '''
        /var/run/faillock directory must exist for all systems using pam_faillock.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + '/var/run/faillock directory must exist for all systems using pam_faillock.'
    violations = []

    cmd= "grep 'pam_faillock.so' /etc/pam.d/system-auth"
    cmd_exec = execute_command(cmd)
    cmd1= "grep 'pam_faillock.so' /etc/pam.d/password-auth"
    cmd_exec1 = execute_command(cmd1)
    if 'pam_faillock.so' in str(cmd_exec['cmd_out']) or 'pam_faillock.so' in str(cmd_exec1['cmd_out']):
        if not (os.path.isdir("/var/run/faillock")):
            violations.append("faillock is not present")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.C.6.2.11
def FORWARD_FILES():
    '''
        Ensure no users have .forward files in directories located in local file systems.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure no users have .forward files in directories located in local file systems.'
    violations = []
    ret = []

    homedirs_users = set([(entr.pw_uid, entr.pw_dir) for entr in pwd.getpwall()
                      if 1000 < entr.pw_uid < 6000])
    for (agreeduid, dr) in homedirs_users:
        files = dr + "/.forward"
        if not os.path.isdir(dr):
            pass
        elif os.path.isfile(files):
            violations.append('.forward file is present')
            ret.append(files)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret

# IZ.C.6.2.12
def NETRC_FILES():
    '''
        Ensure no users have .netrc files in directories located in local file systems.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure no users have .netrc files in directories located in local file systems.'
    violations = []
    ret = []

    homedirs_users = set([(entr.pw_uid, entr.pw_dir) for entr in pwd.getpwall()
                      if 1000 < entr.pw_uid < 6000])
    for (agreeduid, dr) in homedirs_users:
        files = dr + "/.netrc"
        if not os.path.isdir(dr):
            pass
        elif os.path.isfile(files):
            violations.append('.netrc file is present')
            ret.append(files)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret

# IZ.C.6.2.14
def RHOSTS_FILES():
    '''
        Ensure no users have .rhosts files in directories located in local file systems.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure no users have .rhosts files in directories located in local file systems.'
    violations = []
    ret = []

    homedirs_users = set([(entr.pw_uid, entr.pw_dir) for entr in pwd.getpwall()
                      if 1000 < entr.pw_uid < 6000])
    for (agreeduid, dr) in homedirs_users:
        files = dr + "/.rhosts"
        if not os.path.isdir(dr):
            pass
        elif os.path.isfile(files):
            violations.append('.rhosts file is present')
            ret.append(files)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret

# AD.5.0.5
def FIREWALLD_CONFIG():
    '''
        Ensure Firewalld is configured.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure Firewalld is configured.'
    violations = []
    ret = {}

    cmd = "which firewalld"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if cmd_exec['cmd_ret'] != 0 :
        violations.append("Firewalld is not configured.")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# AD.5.0.7
def DELETE_TEMP_FILES():
    '''
        Temporary files can contain sensitive information that can be used by local attackers, deleted at regular intervals
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure no files older than 90 days are present'
    violations = []
    ret = {}

    cmd = "find /tmp -type f -mtime +90 -print"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if cmd_exec['cmd_out']:
        violations.append("Temporary files older than 90 days are present")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.1.1.9.0
def NON_PREVILEDGED_ID_PASSWORD(maxage='365'):
    '''
       Allow non-privileged ID to have a password expiration of 365 days, or more strict
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Exception to password expiry to the non-previledged"\
    " users with password matching 'x', '!', '!!', '*'"

    violations = []
    user_list = []

    for userid in range(1000, 60000):
        user_name = getfields_from_file(afile='/etc/passwd',
                         retfieldnos=[1],
                         keyfieldno=3,  keyval=str(userid),
                         delim=':', except_regex=None)

        user_list.extend(user_name)
    for user in user_list:
        user = user[0]
        pwd_age_arr = getfields_from_file(afile='/etc/shadow', retfieldnos=[2, 5],
                                      keyfieldno=1, keyval=user,
                                      delim=':', except_regex=None)
        #print(pwd_age_arr)
        (pwd, age) = pwd_age_arr[0]
        if pwd not in ('x', '!', '!!', '*'): 
            if not age or age != maxage: 
                violations.append('User %s password expiry must be set'
                                  % (user))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# IZ.C.4.1.3
def ENABLE_AUDITING():
    '''
       Ensure auditing for processes that start prior to auditd is enabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure auditing for processes that start prior to auditd is enabled"

    violations = []

    cmd = "grep '^\s*linux' /boot/grub2/grub.cfg"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" %(str(cmd_exec['cmd_err'])))
    if cmd_exec['cmd_out'] == b'' or cmd_exec['cmd_out'] == '':
        violations.append("Ensure auditd is enabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# AD.5.0.6
def KERNEL_IP_CONFIG(osrname='/etc/sysctl.conf',
                         directives=["net.ipv4.conf.all.send_redirects = 0","net.ipv4.conf.default.accept_redirects = 0",
                                     "kernel.dmesg_restrict = 1","kernel.kptr_restrict = 2","kernel.sysrq = 0","kernel.yama.ptrace_scope = 1 2 3"]):
    '''
        The kernel and networkparameters of the Linux operating systems to be hardened properly.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Directives %s are within  %s"\
        % ( ' and '.join(directives), ' and '.join(osrname))

    violations = []
    ret = {}

    for directive in directives:
            if os.path.isfile(osrname):
                search_key = directive.split()[0]
                result = lookline_in_file(
                        afile=osrname,
                        thevalues=search_key,
                        commentchr='#', case="sensitive")
                if result:
                    result1 = lookline_in_file(
                        afile=osrname,
                        thevalues=directive,
                        commentchr='#', case="sensitive")
                    if not result1:
                        if 'MISSING_Value' not in ret.keys():
                            ret['MISSING_Value'] = []
                        ret['MISSING_Value'].append(directive)
                        violations.append("Value MISSING: %s" % (directive))
                if not result:
                    if 'MISSING_DIRECTIVES' not in ret.keys():
                        ret['MISSING_DIRECTIVES'] = []
                    ret['MISSING_DIRECTIVES'].append(directive)
                    violations.append("Directive MISSING: %s" % (directive))

            else:
                ret = {'FILE_NOT_FOUND': osrname}
                violations.append('%s : file MISSING' % (osrname))


    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return ret

# AD.5.0.3
def SSH_CONFIG(osrname='/etc/ssh/sshd_config',
                      searchstrings=['AllowAgentForwarding no','AllowTcpForwarding no','ClientAliveCountMax 2','Compression no','LogLevel VERBOSE','MaxSessions 2','TCPKeepAlive no','X11Forwarding no']):
    '''
            In /etc/ssh/sshd_config fix weak SSH Conﬁguration
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Search strings %s are within  %s"\
        % (searchstrings, osrname)

    violations = []

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
    else:
        descr = format_nicely(checkname) + "Checking weak SSH Conﬁguration"
        for value in searchstrings:
            search_key = value.split(' ')[0]
            key_val = value.split(' ')[1]
            result = lookline_in_file(
                afile=osrname,
                thevalues=search_key,
                commentchr='#', case="sensitive")
            if not result:
                violations.append('Line %s not found in file %s' % (value,osrname))
            else:
                for crtline in result:
                    crt_value = crtline.split()[1]
                    if crt_value != key_val:
                        violations.append(
                            '%s is set to %s in file %s' % (search_key,crt_value, osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations

# AD.5.0.9 & IV.5.0.2
def SU_COMMAND_RESTRICTION(directive,
                       pamfiles=['/etc/pam.d/su']):
    '''
        -----------------------
            REQ_ID:  52_1
        -----------------------

        /etc/pam.d/other:
            - auth required  pam_wheel.so use_uid

    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
        "Looking for directive '%s'" % (directive) + \
        " in  %s" % (', '.join(pamfiles))

    violations = []

    for fl in pamfiles:
        if not lookline_in_file(afile=fl, thevalues=directive):
            violations.append(fl)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations
def CURRENT_PERMS_OF_FILES():
    '''
        Test function
    '''
    checkname = inspect.stack()[0][3]
    #descr = format_nicely(checkname) + "Test function to check initial permissions of files"
    violations = []
    ret = {}
    all_file_perms = []
    osrnames = ["/etc/shadow", "/etc/shadow-", "/var/log/tallylog", "/var/log/messages", "/var/log/wtmp", "/etc/profile.d/IBMsinit.sh"]
    for osrname in osrnames:
        if os.path.isfile(osrname):
            cmd = "stat " + osrname
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_out'] != b'':
                for line in cmd_exec['cmd_out'].splitlines():
                    if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                        access_line_array = str(line).split(')')
                        ret[osrname] = access_line_array
                        all_file_perms.append(osrname)
                        all_file_perms.append(access_line_array)
                        print("\nPermission of file",osrname," is ",access_line_array)
    ret["violations"] = violations
    descr = format_nicely(checkname) + "Test function to check initial permissions of files\n"+ "List of files %s: " % (all_file_perms)
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, dict(entry for entry in ret.items())
 
    
def AFTER_PERMS_OF_FILES():
    '''
	Test function
    '''
    checkname = inspect.stack()[0][3]
    #descr = format_nicely(checkname) + "Test function to check initial permissions of files"
    violations = []
    ret = {}
    all_file_perms = []
    osrnames = ["/etc/shadow", "/etc/shadow-", "/var/log/tallylog", "/var/log/messages", "/var/log/wtmp", "/etc/profile.d/IBMsinit.sh"]
    for osrname in osrnames:
        if os.path.isfile(osrname):
            cmd = "stat " + osrname
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_out'] != b'':
                for line in cmd_exec['cmd_out'].splitlines():
                    if 'Access' in str(line) and 'Uid' in str(line) and 'Gid' in str(line):
                        access_line_array = str(line).split(')')
                        ret[osrname] = access_line_array
                        all_file_perms.append(osrname)
                        all_file_perms.append(access_line_array)
                        print("\nPermission of file",osrname," is ",access_line_array)
    ret["violations"] = violations
    descr = format_nicely(checkname) + "Test function to check initial permissions of files\n"+ "List of files %s: " % (all_file_perms)
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, dict(entry for entry in ret.items())
# IZ.C.1.1.2

def TMP_PARTITION_EXIST(osrname="/etc/systemd/system/local-fs.target.wants/tmp.mount", directive='/tmp'):
    '''
              Ensure separate partition exists for /home partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure separate partition exists for /tmp partition"
    violations = []
    cmd = "mount | grep ' /tmp '"
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    print("OUTPUT",output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if not output:
        violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations
                
        
# IZ.C.1.1.3
def TMP_PARTITION_CONFIGURATION_NODEV(osrname="/etc/systemd/system/local-fs.target.wants/tmp.mount", directive="nodev"):

# Ensure nodev option set on /tmp partition
    
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure nodev option set on /tmp partition"
    violations = []
    cmd = "mount | grep ' /tmp '"
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")

    if cmd_err:
        violations.append("Error in executing command")

    if output:
        if directive not in output[0]:
            violations.append("Update config file")

    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations
        

# IZ.C.1.1.4 
def TMP_PARTITION_CONFIGURATION_NOSUID(osrname="/etc/systemd/system/local-fs.target.wants/tmp.mount", directive="nosuid"):
    
    # Ensure nosuid option set on /tmp partition
    
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure nosuid option set on /tmp partition"
    violations = []
    cmd = "mount | grep ' /tmp '"
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
        
    print(violations)    
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations
        
               
# IZ.C.1.1.5
def TMP_PARTITION_CONFIGURATION_NOEXEC(osrname="/etc/systemd/system/local-fs.target.wants/tmp.mount", directive="noexec"):
    
    # Ensure noexec option set on /tmp partition
    
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure noexec option set on /tmp partition"
    violations = []
    cmd = "mount | grep ' /tmp '"
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    print(output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
        
    print(violations)    
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations

# IZ.C.1.1.6

def VAR_PARTITION_EXIST(osrname="/etc/fstab", directive='/var'):
    '''
              Ensure separate partition exists for /var partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure separate partition exists for /var partition"
    violations = []
    cmd = "mount | grep ' /var '"
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    print("OUTPUT",output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if not output:
        violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations

# IZ.C.1.1.7

def VAR_TMP_PARTITION_EXIST(osrname="/etc/fstab", directive='/var/tmp'):
    '''
              Ensure separate partition exists for /var/tmp partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure separate partition exists for /var/tmp partition"
    violations = []
    cmd = 'mount | grep /var/tmp'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    print("OUTPUT",output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if not output:
        violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.C.1.1.8

def VAR_TMP_PARTITION_CONFIGURATION_NODEV(osrname="/etc/fstab", directive='nodev'):
    '''
              Ensure nodev option set on /var/tmp partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure nodev option set on /var/tmp partition"
    violations = []
    cmd = 'mount | grep /var/tmp'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    print(output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.C.1.1.9

def VAR_TMP_PARTITION_CONFIGURATION_NOSUID(osrname="/etc/fstab", directive='nosuid'):
    '''
              Ensure nosuid option set on /var/tmp partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure nosuid option set on /var/tmp partition"
    violations = []
    cmd = 'mount | grep /var/tmp'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    print(output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations
        

 # IZ.C.1.1.10

def VAR_TMP_PARTITION_CONFIGURATION_NOEXEC(osrname="/etc/fstab", directive='noexec'):
    '''
              Ensure noexec option set on /var/tmp partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure noexec option set on /var/tmp partition"
    violations = []
    cmd = 'mount | grep /var/tmp'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    print(output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.C.1.1.13

def HOME_PARTITION_EXIST(osrname="/etc/fstab", directive='/home'):
    '''
              Ensure separate partition exists for /home partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure separate partition exists for /home partition"
    violations = []
    cmd = 'mount | grep /home'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    print("OUTPUT",output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if not output:
        violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations

 # IZ.C.1.1.14

def HOME_PARTITION_CONFIGURATION_NODEV(osrname="/etc/fstab", directive='nodev'):
    '''
              Ensure nodev option set on /home partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure nodev option set on /home partition"
    violations = []
    cmd = " mount | grep ' /home '"
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    print(output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.1.5.10.1
def CHECK_YPPASSWD_DAEMON():
    '''
        - Ensure ypbind, ypserv is not installed 
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Ensure ypbind, ypserv is not installed'

    violations = []

    cmd = "rpm -q ypbind"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
    out_put_lines = str(cmd_exec['cmd_out'], 'utf-8')
    if 'package ypbind' not in out_put_lines:
        violations.append("package ypbind is installed")

    cmd = "rpm -q ypserv"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
    out_put_lines = str(cmd_exec['cmd_out'], 'utf-8')
    if 'package ypserv' not in out_put_lines:
        violations.append("package ypserv is installed")

    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


# IZ.1.4.6.7

def RESTRICT_USER_SELECTION_TO_LOGIN_SHELLS(osrname='/etc/shells',directives=["/bin/sh", "/bin/bash", "/sbin/nologin", "/usr/bin/sh", "/usr/bin/bash", "/usr/sbin/nologin", "/bin/tcsh", "/bin/csh", "/bin/ksh", "/bin/rksh", "/bin/false", "/bin/ksh93", "/usr/bin/ksh", "/usr/bin/rksh", "/usr/bin/ksh93"]):
    '''
       Restrict user selection to login shells which supports time out
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Restrict user selection to login shells which supports time out'

    violations = []
    ret = {}
    ret["shell_not_found"] = []
    ret["non_compliant_line_found"] = []
    if not os.path.isfile(osrname):
        violations.append('file MISSING')
        ret[osrname].append('file MISSING')
    else:
        for directive in directives:
            if not lookline_in_file(afile=osrname, thevalues=directive):
                violations.append('File %s - missing directive %s' % (osrname, directive))
                ret["shell_not_found"].append({'problem': 'shell_not_found', 'shell_name': directive})
             
        # Remove non-compliant entries   
        with open(osrname, 'r+') as fd:
            contents = fd.readlines()
            fd.seek(0)
            for line in contents:
                if line.strip() not in directives:
                    violations.append('File %s - missing directive %s' % (osrname, directive))
                    ret["non_compliant_line_found"].append({'problem': 'non_compliant_line_found', 'shell_name': line.strip()})
                    
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items() if len(entry[1]))
    else:
        log_audit(descr, "PASS")
        return True, dict(entry for entry in ret.items() if len(entry[1]))


# IZ.1.1.13.2
        
def DENY_INTERACTIVE_LOGIN(maxage='90',osrname='/etc/security/remote_deny'):
    '''
       Users that are not Allowed to perform interactive login to the machine
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Users that are restricted for "\
    " interactive login to the machine"

    violations = []
    user_list = []

    for userid in range(1, 10100):
        user_name = getfields_from_file(afile='/etc/passwd',
                         retfieldnos=[1,3],
                         keyfieldno=3,  keyval=str(userid),
                         delim=':', except_regex=None)

        user_list.extend(user_name)
    #print(user_list)
    for user in user_list:
        id = user[1]
        #print(id)
        user = user[0]
        #print(user)
        pwd_age_arr = getfields_from_file(afile='/etc/shadow', retfieldnos=[2, 5],
                                      keyfieldno=1, keyval=user,
                                      delim=':', except_regex=None)
        #print(pwd_age_arr)
        (pwd, age) = pwd_age_arr[0]
        #print(age)
        if pwd not in ('x', '!', '!!', '*'):  # pwd is set
            if not age or age != maxage:  # empty it means it never expires
                #print(id) 
                if os.path.isfile(osrname):   
                  result = lookline_in_file(afile=osrname,
                                            thevalues=id,
                                            commentchr='#', case="sensitive")     
                  if not result :    
                    violations.append('id %s needs to be added in /etc/security/remote_deny' 
                                % (id))   
                else:
                    violations.append('id %s and File not present'
                                 % (id))
                print(violations)
                
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")


    return violations
    
    
# IZ.1.1.13.1
        
def ETC_SECURITY_REMOTE(directive, pamfile_1, pamfile_2):
    '''
       PAM file must have these settings auth required pam_listfile.so 
       item=user sense=deny file=/etc/security/nologin onerr=succeed

    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
          "Looking for directive auth required pam_listfile.so  item=user sense=deny file=/etc/security/nologin onerr=succeed " 

    violations = []
    ret = {}
    
    if not lookline_in_file(afile=pamfile_1, thevalues=directive):
      violations.append('File %s - missing directive \n' %
                                  (pamfile_1))
    
    if not lookline_in_file(afile=pamfile_2, thevalues=directive):
      violations.append('File %s - missing directive \n' %
                                  (pamfile_2))

    print(violations)
    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")


    return violations


# IZ.C.1.1.11
def VAR_LOG_PARTITION(osrname='/etc/fstab',
                                    directive="/var/log"):
    '''
	      Ensure separate partition exists for /var/log
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure separate partition exists for /var/log"
    violations = []
    ret = {}
    cmd = 'mount | grep /var/log'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if "/var/log" in output[0]:
            violations.append("Partition Exists")
        
    print(violations)    
    if violations:
        log_audit(descr, "PASS")
        return True, violations
    else:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
        

# IZ.C.1.1.12
def VAR_LOG_AUDIT_PARTITION(osrname='/etc/fstab',
                                    directive="/var/log/audit"):
    '''
	      Ensure separate partition exists for /var/log/audit
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure separate partition exists for /var/log/audit"
    violations = []
    ret = {}
    cmd = 'mount | grep /var/log/audit'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if "/var/log/audit" in output[0]:
            violations.append("Partition Exists")
        
    print(violations)    
    if violations:
        log_audit(descr, "PASS")
        return True, violations
    else:
        log_audit(descr, "FAILED", details=violations)
        return False, violations 


# IZ.C.1.1.15
def DEV_SHM_PARTITION_CONFIG_NODEV(osrname="/etc/fstab", directive='nodev'):
    '''
              Ensure nodev option set on /dev/shm partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure nodev option set on /dev/shm partition"
    violations = []
    cmd = 'mount | grep /dev/shm'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    # print(output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations


# IZ.C.1.1.16
def DEV_SHM_PARTITION_CONFIG_NOSUID(osrname="/etc/fstab", directive='nosuid'):
    '''
              Ensure nosuid option set on /dev/shm partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure nosuid option set on /dev/shm partition"
    violations = []
    cmd = 'mount | grep /dev/shm'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    # print(output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations
        
        
# IZ.C.1.1.17
def DEV_SHM_PARTITION_CONFIG_NOEXEC(osrname="/etc/fstab", directive='noexec'):
    '''
              Ensure noexec option set on /dev/shm partition
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Ensure noexec option set on /dev/shm partition"
    violations = []
    cmd = 'mount | grep /dev/shm'
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode
    output = cmd_out.decode("utf-8").strip("\n")
    output = output.split("\n")
    # print(output)
    
    if cmd_err:
        violations.append("Error in executing command")
    
    if output:
        if directive not in output[0]:
            violations.append("Update config file")
    print(violations)
 
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations


 # IZ.6.2.18
def DUPLICATE_USER_ETC_PASSWD(osrname='/etc/passwd'):
    '''

        USER NAME:     Each User Name must only be used once.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking for duplicate User Names in %s"\
        % (osrname)
    # print descr
    # sys.stdout.write(descr)

    violations = duplicates_in(thefile=osrname, fieldno=1)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations


 # IZ.6.2.19
def DUPLICATE_GROUP_ETC_GROUP(osrname='/etc/group'):
    '''

        USER NAME:     Each Group Name must only be used once.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Checking for duplicate Group Names in %s"\
        % (osrname)
    # print descr
    # sys.stdout.write(descr)

    violations = duplicates_in(thefile=osrname, fieldno=1)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations
