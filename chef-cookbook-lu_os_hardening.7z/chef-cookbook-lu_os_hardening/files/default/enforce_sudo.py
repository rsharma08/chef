# frozen_string_literal: true

#! /usr/bin/env python

# Copyright:: Kyndryl 2022

import helper_funcs
import check
import check_sudo
from helper_funcs import *
import pwd
import grp
import os
import inspect
from stat import *
from subprocess import Popen, PIPE

# ZY.1.8.1.0
def SUDO_FILE_WORD_WRITABLE(osrname='/etc/sudoers'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for violation in fails:
        if ("Directory owner is not root") in violation:
            uid = pwd.getpwnam("root").pw_uid
            os.chown(osrname, uid, -1)
            log_enforce("Changed the %s directory owner to root\n" % (osrname))
            log_enforce(format_nicely(checkname) + "%s \n" % (violation))

        # Enforce file permissions
        if "Directory is word-writable" in violation:
            agreedperms = oct(os.stat(osrname)[ST_MODE])[-3:]
            file_perm = str(agreedperms)
            file_owner_perms = int(file_perm[0])
            file_group_perms = int(file_perm[1])
            file_other_perms = int(file_perm[2])
            if file_owner_perms == 2 or file_owner_perms == 3 or file_owner_perms == 6 or file_owner_perms == 7:
                # Remove write access from permissions of owner
                file_owner_perms = file_owner_perms - 2
            if file_group_perms == 2 or file_group_perms == 3 or file_group_perms == 6 or file_group_perms == 7:
                # Remove write access from permissions of group
                file_group_perms = file_group_perms - 2
            if file_other_perms == 2 or file_other_perms == 3 or file_other_perms == 6 or file_other_perms == 7:
                # Remove write access from permissions of other
                file_other_perms = file_other_perms - 2

            cmd = "chmod " + str(file_owner_perms) + str(file_group_perms) + str(file_other_perms) + " " + osrname
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce("Enforced the permissions of '%s' file to remove write permission.\n" % (osrname))

            else:
                log_enforce("ERROR enforcing the permission: %s. Please check manually.\n" % (cmd_exec['cmd_err']))

    log_enforce('DONE\n')


# ZY.1.2.1
def SUDO_ENSURE_LOGGING(osrname='/etc/sudoers', directive='!logfile'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for violation in fails:
        if ("Sudo Logging is disabled") in violation:
            lines_to_file = "#" + directive
            update_line = search_file_replace_line(
                osrname, directive, lines_to_file, commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) + ': Unable to enable sudo logging \n')
            else:
                log_enforce('Sudo logging is enabled successfully \n')
    log_enforce('DONE\n')


# ZY.1.2.4
def SUDO_LOG_RETENTION_TIMEFRAME(osrname='/etc/logrotate.conf', directive='/var/sudo.log', timeframe='90'):
    '''
        Log retention timeframe: Period of time to retain sudo security log should set to 90 days
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Setting Log retention timeframe'
    violations = ""
    lines = []
    ret = {}
    update_log_retention_timeframe = ""
    line_to_be_replaced = ""

    # Check if Sudo configuration file present
    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        # Check if directive found i.e check if have settings for sudo.log file
        linefound = lookline_in_file(afile=osrname, thevalues=directive, commentchr='#', case="sensitive")
        if linefound:
            with open(osrname, 'r+') as fd:
                contents = fd.readlines()
                for index, line in enumerate(contents):
                    # mark falg as true once you found settings for sudo.log file
                    if directive in line:
                        flag = True
                    # Check for maxage property inside settings
                    if 'maxage' in line and flag:
                        line_to_be_replaced = line
                        if not 'maxage ' + timeframe in line:
                            update_log_retention_timeframe = line[0:len(line) - 3] + timeframe + "\n"
                            violations = "Log retention timeframe is not set to %s days\n" % (timeframe)
                            break
                        flag = False
        fd.close()
    ret["violations"] = violations
    ret["update_log_retention_timeframe"] = update_log_retention_timeframe
    ret["line_to_be_replaced"] = line_to_be_replaced

    if violations:
        log_audit(descr, "FAILED", violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# ZY.1.2.4
def SUDO_LOG_RETENTION_TIMEFRAME(osrname='/etc/logrotate.conf', directive='/var/sudo.log', timeframe='90'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    log_retention_timeframe = fails["update_log_retention_timeframe"]
    line_to_be_replaced = fails["line_to_be_replaced"]
    if "Log retention timeframe is not set to" in fails["violations"]:
        update_line = search_file_replace_line(osrname, line_to_be_replaced, log_retention_timeframe, commentchr='#')
        if update_line != 1:
            log_enforce(format_nicely(checkname) + ': Unable to set log retention timeframe \n')
        else:
            log_enforce(format_nicely(checkname) + "Log retention timeframe is set to %s .\n" % (timeframe))

    log_enforce('DONE\n')

# ZY.1.2.2
def SUDO_SPECIFIC_LOGFILE(osrname='/etc/sudoers', sudologfilename='/var/log/sudo.log'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    directive = 'Defaults  logfile="'+sudologfilename+'"'
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check_sudo.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for violation in fails:
        if ("FILE MISSING") in violation:
            log_enforce("create sudo log file")
            create_osr(osr=sudologfilename, res_type='file',perms='0755', ownername='root')
            log_enforce("Created the %s file with root owner 755 permission \n" %(sudologfilename))

    log_enforce('DONE\n')


# ZY.1.8.1.3
def OSR_SUDOERS_D_PERMS(osrname='/etc/sudoers', agreedperms='0744', mode='max', category='all', mustexist=False,
                        agreeduser='root'):
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check_sudo.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                log_enforce(format_nicely(checkname) + "File missing: %s \n" % (osrname))
            if prob['problem'] == 'ownership':
                log_enforce(format_nicely(checkname) + "Changing onwer of FS object '%s' to %s \n" % (dr, agreeduser))
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms, crtperm=crtperm, mode=mode, category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce(format_nicely(checkname) + "Changing permissions of FS object '%s' from %s to %s \n" % (
                dr, crtperm, rightperm))

    log_enforce('DONE\n')

# ZY.1.8.1.4
def OSR_SUDOERS_FILE_CMD(osrname='/etc/sudoers'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if fails["violations"]:
        log_enforce(format_nicely(checkname) + "Please manually check if included files %s are fully qualified in '%s' file\n" %(fails["included_files"],osrname))
    log_enforce('DONE\n')

# ZY.1.8.1.6
def OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS(osrname='/etc/sudoers', category='all', agreeduser='root'):
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check_sudo.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                log_enforce(format_nicely(checkname) + "File missing: %s \n" % (dr))
            if prob['problem'] == 'ownership':
                log_enforce(format_nicely(checkname) + "Changing owner of FS object '%s' to %s \n" % (dr, agreeduser))
                os.chown(dr, name2uid(prob['rightful_owner']), name2gid(prob['rightful_owner']))
            if prob['problem'] == 'Directory is word-writable':
                agreedperms = oct(os.stat(dr)[ST_MODE])[-3:]
                file_perm = str(agreedperms)
                file_owner_perms = int(file_perm[0])
                file_group_perms = int(file_perm[1])
                file_other_perms = int(file_perm[2])
                if file_owner_perms == 2 or file_owner_perms == 3 or file_owner_perms == 6 or file_owner_perms == 7:
                    # Remove write access from permissions of owner
                    file_owner_perms = file_owner_perms - 2
                if file_group_perms == 2 or file_group_perms == 3 or file_group_perms == 6 or file_group_perms == 7:
                    # Remove write access from permissions of group
                    file_group_perms = file_group_perms - 2
                if file_other_perms == 2 or file_other_perms == 3 or file_other_perms == 6 or file_other_perms == 7:
                    # Remove write access from permissions of other
                    file_other_perms = file_other_perms - 2

                cmd = "chmod " + str(file_owner_perms) + str(file_group_perms) + str(file_other_perms) + " " + dr
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce("Enforced the permissions of '%s' file to remove write permission.\n" % (dr))

                else:
                    log_enforce("ERROR enforcing the permission: %s. Please check manually.\n" % (cmd_exec['cmd_err']))

    log_enforce('DONE\n')

# ZY.1.8.1.5
def OSR_SUDOERS_FILE_PERMS(osrname='/etc/sudoers', agreedperms='0744', mode='max', mustexist=False, agreeduser='root'):
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check_sudo.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                log_enforce(format_nicely(checkname) + "File missing: %s \n" % (osrname))
            if prob['problem'] == 'ownership':
                log_enforce(format_nicely(checkname) + "Changing onwer of FS object '%s' to %s \n" % (dr, agreeduser))
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms, crtperm=crtperm, mode=mode)
                os.chmod(dr, int(rightperm, 8))
                log_enforce(format_nicely(checkname) + "Changing permissions of FS object '%s' from %s to %s \n" % (dr, crtperm, rightperm))

    log_enforce('DONE\n')


# ZY.1.4.3.3
def OSR_SUDOERS_FILE_NESTED_SUDO_INVOCATION(osrname='/etc/sudoers', directive=["Cmnd_Alias SUDOSUDO = /usr/local/bin/sudo, /usr/bin/sudo, /bin/sudo", "ALL ALL=!SUDOSUDO"]):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    print("Lines: ", type(directive))
    for violation in fails:
        if ("Sudo configuration file doesn't prevent users from using sudo to invoke sudo") in violation:
            line_added = write_multi_lines_infile(osrname, lines=directive, mode='append')
            if not line_added:
                log_enforce(format_nicely(checkname) + ': Unable to prevent Nested Sudo invocation \n')
            else:
                log_enforce('Preventing Nested Sudo invocation is successful.\n')
    log_enforce('DONE\n')

# ZY.1.8.1.2
def OSR_SUDOERS_D_CMD(osrname='/etc/sudoers'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if fails["violations"]:
        log_enforce(format_nicely(checkname) + "Please manually check if included directories %s are fully qualified in '%s' file\n" %(fails["included_dir"],osrname))
    log_enforce('DONE\n')

# ZY.1.8.2.3
def OSR_SUDOERS_GROUP(osrname='/etc/sudoers', agreedperms='0744', mode='max', category='all'):
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check_sudo.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'permissions':
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms, crtperm=crtperm, mode=mode, category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('Permissions of %s changed to %s\n' % (dr, rightperm))

    log_enforce('DONE\n')

# ZY.1.4.5
def SUDO_FILE_SUDOEDIT(osrname='/etc/sudoers'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return
    else:
        directive_string = ' '.join(map(str, fails["directive"]))
        lines_to_search = "#" + directive_string
        update_line = writelines_infile(osrname, fails["directive"])
        print(update_line)
        if update_line != 1:
            log_enforce(format_nicely(checkname) + ': Unable to set sudoedit \n')
        else:
            log_enforce(format_nicely(checkname) + "Sudoedit is set for ")
    log_enforce('DONE\n')


# ZY.1.4.4
def OSR_SUDOERS_LOGGING_CMD(osrname='/etc/sudoers', directive='= ALL'):
    '''
       Sudo-related logging configurations must provide for the creation of log records documenting the individual issuing the command for commands issued using sudo privileges.
    '''
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check_sudo.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    violated_lines = fails['details']

    for line in violated_lines:
        comment_the_line = "#" + line
        search_file_replace_line(target=osrname, regex=line, newline=comment_the_line, commentchr='#', uniq_occur=None,
                                 case='sensitive', replace_full_line=True)

    log_enforce('DONE\n')


# ZY.1.4.2.1
def OSR_SUDOERS_SHELL_ESCAPE(osrname='/etc/sudoers',
                             directives=['bash2bug', 'bashbug', 'ed', 'ex', 'ftp', 'format', 'less', 'more', 'pg', 'vi',
                                         'view', 'vim', 'gvim', 'gview', 'evim', 'eview', 'vimdiff', 'find']):
    '''
       Commands which allow shell escape - Sudo configurations must not allow shell escapes (eg the ability to execute subcommands without restriction) that allow access to unauthorized privileges.
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check_sudo.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    violated_lines = fails['details']
    for line in violated_lines:
        splited_line = line.split("=")
        add_no_exec_tag = splited_line[0] + "= NOEXEC:" + splited_line[1]
        search_file_replace_line(target=osrname, regex=line, newline=add_no_exec_tag, commentchr='#', uniq_occur=None,
                                 case='sensitive', replace_full_line=True)

    log_enforce('DONE\n')

# ZY.1.2.3
def SUDO_SECONDARY_LOGGING(osrname ='/etc/sudoers'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return
    else:
        user_name = ' '.join(map(str, fails["user_name"]))
        user_name_list = user_name.split(" ")
        for user in user_name_list:
            if user != 'root':
                # Create directory for logging other users
                log_history_dir="/var/log/users_historylogs"
                os.system("mkdir -p /var/log/users_historylogs/")

                # Set the sticky bit on /var/log/users_historylogs/
                os.chmod(log_history_dir, 02755)

                # Create a new script inside /etc/profile.d/
                history_log_script_file= "/etc/profile.d/history_log.sh"
                history_log_script=["_who_am_i=$(who am i|awk '{print $1}')\n", "_ID=$(id -u $_who_am_i)\n", "\n", "if [ \"$_ID\" > 0 ]\n", "then\n", "export HISTSIZE=10000\n", "export HISTTIMEFORMAT='%F %T '\n", "export HISTFILE=/var/log/users_historylogs/history-users-$(who am i | awk '{print $1}';exit)-$(date +%F)\n", "export PROMPT_COMMAND='history -a'\n", "fi"]
                writelines_infile(history_log_script_file, history_log_script)

                # Set the permission for history_log.sh
                os.chmod(history_log_script_file, 0770)

                # Activate the script
                pipe = Popen(". %s; env" % history_log_script_file, stdout=PIPE, shell=True)
                data = pipe.communicate()[0]
                env = dict((line.split("=", 1) for line in data.splitlines()))
                return

    log_enforce('DONE\n')

# ZY.1.8.1.1
def OSR_SUDOERS_D_OWNER_PERMS(osrname='/etc/sudoers', agreedperms='0700', mode='max', mustexist=False, agreeduser='root'):
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check_sudo.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                log_enforce(format_nicely(checkname) + "File missing: %s \n" % (osrname))
            if prob['problem'] == 'ownership':
                log_enforce(format_nicely(checkname) + "Changing onwer of FS object '%s' to %s \n" % (dr, agreeduser))
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms, crtperm=crtperm, mode=mode, category="all")
                os.chmod(dr, int(rightperm, 8))
                log_enforce(format_nicely(checkname) + "Changing permissions of FS object '%s' from %s to %s \n" % (dr, crtperm, rightperm))

    log_enforce('DONE\n')

# ZY.1.4.3.1
def OSR_SUDOERS_FILE_LISTED_CMD(osrname='/etc/sudoers'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check_sudo.' + checkname)(**args)
    if succeeded:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if fails["violations"]:
        log_enforce(format_nicely(checkname) + "Please manually check if the commands %s under Cmnd_Alias is fully qualified in '%s' file\n" %(fails["violated_commands"],osrname))
    log_enforce('DONE\n')

# ZY.30.0.2
def OSR_SUDOERS_LOGGING_EXTERNAL_SYS(osrname='/etc/rsyslog.conf',
                 audits="authpriv.*         /var/log/secure",
                 by_regex=''):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check_sudo.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for audit in fails:
        writelines_infile(target=osrname,
                          lines=audit + '\n',
                          mode='append')

    log_enforce('DONE\n')


