# frozen_string_literal: true

#! /usr/bin/env python

# Copyright:: Kyndryl 2022

from helper_funcs import *
import inspect
import pwd
from os import path


# ZY.1.8.1.0
def SUDO_FILE_WORD_WRITABLE(osrname='/etc/sudoers'):
    '''
        File must be owned by root, and must not be world-writable.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'File must be owned by root, and must not be world-writable'
    violations = []
    osr_names = []

    # Check if sudo configuration file exists
    if (path.exists(osrname) and path.isfile(osrname)):
        # Files must be owned by root
        if (pwd.getpwuid(os.stat(osrname).st_uid).pw_name != 'root'):
            violations.append("Directory owner is not root: [ %s ]" % (osrname))

        # File Must not be Word-writable
        cmd = "find / -xdev -type f \( -perm -0002 -a ! -perm -1000 \) -print"
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
        if cmd_exec['cmd_out']:
            osr_names = cmd_exec['cmd_out'].split("\n")
            osr_names = osr_names[0:(len(osr_names) - 1)]
        for osr in osr_names:
            if osr == osrname:
                violations.append("Directory is word-writable: [ %s ]" % (osr))
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations


# ZY.1.2.1
def SUDO_ENSURE_LOGGING(osrname='/etc/sudoers', directive='!logfile'):
    '''
        Sudo Logging, must not be disabled
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Sudo Logging, must not be disabled'
    violations = []

    # Check if Sudo configuration file present
    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        linefound = lookline_in_file(afile=osrname, thevalues=directive, commentchr='#', case="sensitive")
        if linefound:
            violations.append("Sudo Logging is disabled")

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations

# ZY.1.2.4
def SUDO_LOG_RETENTION_TIMEFRAME(osrname='/etc/logrotate.conf', directive='/var/sudo.log', timeframe='90'):
    '''
        Log retention timeframe: Period of time to retain sudo security log should set to 90 days
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + 'Setting Log retention timeframe'
    violations = ""
    lines = []
    ret = {}
    update_log_retention_timeframe = ""
    line_to_be_replaced = ""

    # Check if Sudo configuration file present
    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        # Check if directive found i.e check if have settings for sudo.log file
        linefound = lookline_in_file(afile=osrname, thevalues=directive, commentchr='#', case="sensitive")
        if linefound:
            with open(osrname, 'r+') as fd:
                contents = fd.readlines()
                for index, line in enumerate(contents):
                    # mark falg as true once you found settings for sudo.log file
                    if directive in line:
                        flag = True
                    # Check for maxage property inside settings
                    if 'maxage' in line and flag:
                        line_to_be_replaced = line
                        if not 'maxage ' + timeframe in line:
                            update_log_retention_timeframe = line[0:len(line) - 3] + timeframe + "\n"
                            violations = "Log retention timeframe is not set to %s days\n" % (timeframe)
                            break
                        flag = False
        fd.close()
    ret["violations"] = violations
    ret["update_log_retention_timeframe"] = update_log_retention_timeframe
    ret["line_to_be_replaced"] = line_to_be_replaced

    if violations:
        log_audit(descr, "FAILED", violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# ZY.1.2.2
def SUDO_SPECIFIC_LOGFILE(osrname='/etc/sudoers', sudologfilename='/var/log/sudo.log'):
    '''
        Defaults  logfile="/var/log/sudo.log" entry in /etc/sudoers
    '''

    checkname = inspect.stack()[0][3]
    directive = 'Defaults  logfile="'+sudologfilename+'"'
    descr = format_nicely(checkname) + \
        "Looking for directive '%s'" % (directive) + " in the sudoers files"

    violations = []
    ret = {}

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
    else:
        # 1st and 3rd element
        search_key = ' '.join(directive.split()[0:3:2])
        result = lookline_in_file(
            afile=osrname,
            thevalues=search_key,
            commentchr='#', case="sensitive")
        if not result:
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []

            ret['MISSING_DIRECTIVES'].append(osrname)
        else:  # found the directive
            if not os.path.isfile(sudologfilename):
                violations.append("FILE MISSING: %s" % (sudologfilename))
                ret = {'FILE_NOT_FOUND': osrname}

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return violations
    else:
        log_audit(descr, "PASS")
        return violations


# ZY.1.8.1.3
def OSR_SUDOERS_D_PERMS(osrname='/etc/sudoers', agreedperms='0744', mode='max', category='all', mustexist=False,
                        agreeduser='root'):
    '''
        Directories included in /etc/sudoers file via #includedir directive
            - no write by general users (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
            "Directories included in %s file : " % (
                osrname) + "should have no write by general users (744 or more restrictive)"

    violations = []
    included_files_and_dir = []
    all_files = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    # Parse sudoers file to search for '#indlude' & '#inmcludedir' directive and prepare list
    with open(osrname, 'r+') as fd:
        contents = fd.readlines()
    for line in contents:
        array_char_command = line.split()
        if array_char_command:
            if '#includedir' in array_char_command[0] or '#include' in array_char_command[0]:
                included_files_and_dir.append(array_char_command[1])
    print("included_files_and_dir: ", included_files_and_dir)
    # Prepare list of files and directories to which settings are applied
    for files_or_dir in included_files_and_dir:
        # If its directory, include all files under that directory
        if os.path.isdir(files_or_dir):
            all_files.append(files_or_dir)
            for osr in list_files_in(drs=[files_or_dir], cond='os.access(%, os.EX_OK)'):
                all_files.append(osr)
        elif os.path.isfile(files_or_dir):
            all_files.append(files_or_dir)
    print("all_files: ", all_files)
    # Check settings for all files_or_dir
    for osr in all_files:
        ret[osr] = []
        # Check ownership
        if agreeduser:
            agreeduid = pwd.getpwnam(agreeduser).pw_uid
            owner_id = os.stat(osr).st_uid
            owner_name = pwd.getpwuid(owner_id).pw_name
            if owner_id != agreeduid:
                violations.append("FS object %s owned not by %s, but by %s" % (osr, agreeduser, owner_name))
                ret[osr].append({'problem': 'ownership', 'rightful_owner': agreeduser, 'wrong_owner': owner_name})

        # Check permissions
        permfailed = perm_violation(obj=osr, refperms=agreedperms, mode=mode)
        if permfailed:
            violations.append("FS object %s permissions: %s" % (osr, permfailed))
            ret[osr].append({'problem': 'permissions', 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return dict(entry for entry in ret.items() if len(entry[1]))

# ZY.1.8.1.4
def OSR_SUDOERS_FILE_CMD(osrname='/etc/sudoers'):
    '''
        Files in /etc/sudoers should have each File named must specify the full path of the included files.
            - should start with a / to show fully qualified path for files
    '''
    checkname = inspect.stack()[0][3]
    violations = []
    ret = {}
    ret["included_files"] = []
    ret["violations"] = []
    descr = format_nicely(checkname) + "Files in %s file " % (
        osrname) + "should have each file named must specify the full path of the included file"

    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        with open(osrname, 'r+') as fd:
            contents = fd.readlines()
        for line in contents:
            array_char_command = line.split()
            # Only if line is not empty
            if array_char_command:
                if '#include ' in line:
                    if array_char_command[1][0] != '/':
                        ret["included_files"].append(array_char_command[1])
                        ret["violations"].append(
                            "FS object %s has a file included which is not of fully qualified path" % (osrname))
                        violations.append(
                            "FS object %s has a file included which is not of fully qualified path" % (osrname))
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# ZY.1.8.1.6
def OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS(osrname='/etc/sudoers', category='all', agreeduser='root'):
    '''
        Directories included in /etc/sudoers file via env_file directive
            - must be owned by root, and must not be world-writable.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
            "Directories included in %s file via env_file directive: " % (
                osrname) + "must be owned by root, and must not be world-writable."

    violations = []
    env_file = []
    ret = {}
    osr_names = []

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    # Find directories included in suders file
    with open(osrname, 'r+') as fd:
        contents = fd.readlines()
    for line in contents:
        array_char_command = line.split()
        # Only if line is not empty
        if array_char_command:
            if 'env_file' in array_char_command[0]:
                env_file.append(array_char_command[1])

    print(env_file)
    for osr in env_file:
        if os.path.isfile(osr):
            ret[osr] = []
            # first, check ownership
            if agreeduser:
                agreeduid = pwd.getpwnam(agreeduser).pw_uid
                owner_id = os.stat(osr).st_uid
                owner_name = pwd.getpwuid(owner_id).pw_name
                if owner_id != agreeduid:
                    violations.append("FS object %s owned not by %s, but by %s" % (osr, agreeduser, owner_name))
                    ret[osr].append({'problem': 'ownership', 'rightful_owner': agreeduser, 'wrong_owner': owner_name})

            # File Must not be Word-writable
            cmd = "find / -xdev -type f \( -perm -0002 -a ! -perm -1000 \) -print"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                violations.append("Error, failed in executing command: %s" % (str(cmd_exec['cmd_err'])))
            if cmd_exec['cmd_out']:
                osr_names = cmd_exec['cmd_out'].split("\n")
                osr_names = osr_names[0:(len(osr_names) - 1)]
            for file in osr_names:
                if file == osr:
                    violations.append("Directory is word-writable: [ %s ]" % (file))
                    ret[osr].append({'problem': 'Directory is word-writable'})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return dict(entry for entry in ret.items() if len(entry[1]))

# ZY.1.8.1.5
def OSR_SUDOERS_FILE_PERMS(osrname='/etc/sudoers', agreedperms='0744', mode='max', mustexist=False, agreeduser='root'):
    '''
        File included in /etc/sudoers file via #includedir directive
            - no write by general users (744 or more restrictive)
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
            "Files included in %s file : " % (
                osrname) + "should have no write by general users (744 or more restrictive)"

    violations = []
    included_file = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    # Find directories included in sudoers file
    with open(osrname, 'r+') as fd:
        contents = fd.readlines()

    for line in contents:
        array_char_command = line.split()
        if array_char_command:
            if '#include' in array_char_command[0]:
                included_file.append(array_char_command[1])
    for osr in included_file:
        if os.path.isfile(osr):
            ret[osr] = []
            # first, check ownership
            if agreeduser:
                agreeduid = pwd.getpwnam(agreeduser).pw_uid
                owner_id = os.stat(osr).st_uid
                owner_name = pwd.getpwuid(owner_id).pw_name
                if owner_id != agreeduid:
                    violations.append("FS object %s owned not by %s, but by %s" % (osr, agreeduser, owner_name))
                    ret[osr].append({'problem': 'ownership', 'rightful_owner': agreeduser, 'wrong_owner': owner_name})

            # now check permissions
            permfailed = perm_violation(obj=osr, refperms=agreedperms, mode=mode)
            if permfailed:
                violations.append("FS object %s permissions: %s" % (osr, permfailed))
                ret[osr].append({'problem': 'permissions', 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return dict(entry for entry in ret.items() if len(entry[1]))


# ZY.1.4.3.3
def OSR_SUDOERS_FILE_NESTED_SUDO_INVOCATION(osrname='/etc/sudoers', directive=["Cmnd_Alias SUDOSUDO = /usr/local/bin/sudo, /usr/bin/sudo, /bin/sudo", "ALL ALL=!SUDOSUDO"]):
    '''
        The sudo configuration file must prevent users from using sudo to invoke sudo.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "The sudo configuration file must prevent users from using sudo to invoke sudo"
    violations = []

    # Check if Sudo configuration file present
    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        # Check if directive found i.e check if have settings for sudo.log file
        linefound = lookline_in_file(afile=osrname, thevalues=directive[1], commentchr='#', case="sensitive")
        if not linefound:
            violations.append("Sudo configuration file doesn't prevent users from using sudo to invoke sudo.")

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, violations
    else:
        log_audit(descr, "PASS")
        return True, violations

# ZY.1.8.1.2
def OSR_SUDOERS_D_CMD(osrname='/etc/sudoers'):
    '''
        Directories in /etc/sudoers should have each directory named must specify the full path of the included directory.
            - should start with a '/' to show fully qualified path for directory
    '''
    checkname = inspect.stack()[0][3]
    violations = []
    ret = {}
    ret["included_dir"] = []
    ret["violations"] = []
    descr = format_nicely(checkname) + "Directories in %s file " % (
        osrname) + "should have each directory named must specify the full path of the included directory"

    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        with open(osrname, 'r+') as fd:
            contents = fd.readlines()
        for line in contents:
            array_char_command = line.split()
            # Only if line is not empty
            if array_char_command:
                if '#includedir ' in line:
                    if array_char_command[1][0] != '/':
                        ret["included_dir"].append(array_char_command[1])
                        ret["violations"].append(
                            "FS object %s has a directory included which is not of fully qualified path" % (osrname))
                        violations.append(
                            "FS object %s has a directory included which is not of fully qualified path" % (osrname))

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# ZY.1.8.2.3
def OSR_SUDOERS_GROUP(osrname='/etc/sudoers', agreedperms='0744', mode='max', category='all'):
    '''

        Files executed via entries in /etc/sudoers
            - no write by if owned by groups considered to be default groups for general users (744 or more restrictive)
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Files executed via entries in %s file " % (osrname) +"and owned by default groups general users, permissions (744 or more restrictive)"

    violations = []
    ret = {}
    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#'):
        print(osr)
    for osr in get_exec_entries(thefile=osrname, delim=':|\s', commentchr='#'):
        ret[osr] = []

        owner_gid = os.stat(osr).st_gid

        if default_group_check(owner_gid):
            permfailed = perm_violation(obj=osr, refperms=agreedperms, mode=mode, category=category)
            if permfailed:
                violations.append("FS object %s permissions: %s" % (osr, permfailed))
                ret[osr].append({'problem': 'permissions', 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))

# ZY.1.2.3
def SUDO_FILE_SUDOEDIT(osrname='/etc/sudoers'):
    '''
        %editors_group ALL=(ALL) sudoedit filename  entry in /etc/sudoers
    '''

    checkname = inspect.stack()[0][3]

    violations = []
    include_file = []
    include_file_list = []
    ret = {}
    ret["directive"] = []
    osr_names = []

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    # Find files included in sudoers file
    with open(osrname, 'r+') as fd:
        contents = fd.readlines()
    for line in contents:
        array_char_command = line.split()
        # Only if line is not empty
        if array_char_command:
            if '#include' in array_char_command[0]:
                include_file.append(array_char_command[1])

    print(include_file)

    for osr in include_file:
        if os.path.isfile(osr):
            include_file_list.append(osr)
            # include_file_list = include_file_list + osr + ', '
            print(osr)

    print(include_file_list)
    include_file_list_str = (", ".join(include_file_list))
    directive = '%editors_group ALL=(ALL) sudoedit ' + include_file_list_str
    print(directive)
    descr = format_nicely(checkname) + \
            "Looking for directive '%s' " % (directive) + "in sudoers file"

    # Check if Sudo configuration file present
    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        linefound = lookline_in_file(afile=osrname, thevalues=directive, commentchr='#', case="sensitive")
        if not linefound:
            ret["directive"].append(directive)
            violations.append("Sudoedit is not set")

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations


# ZY.1.4.4
def OSR_SUDOERS_LOGGING_CMD(osrname='/etc/sudoers', directive='= ALL'):
    '''
       Sudo-related logging configurations must provide for the creation of log records documenting the individual issuing the command for commands issued using sudo privileges.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + "Sudo-related logging configurations must provide for the creation of log records documenting the individual issuing the command for commands issued using sudo privileges."
    violation = []
    ret = {}

    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        lines = lookline_in_file(afile=osrname, thevalues=directive, commentchr='#', case="sensitive", by_regex=None,
                                 delim=None)
        validlines = []
        for line in lines:
            # except setting for root
            if 'root' in line or 'log_output' in line or 'log_input' in line:
                continue
            validlines.append(line)
        if validlines:
            violation.append("Sudo permissions are violated")
            ret['details'] = validlines

    if violation:
        log_audit(descr, "FAILED", details=dict(entry for entry in ret.items()))
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))


# ZY.1.4.2.1
def OSR_SUDOERS_SHELL_ESCAPE(osrname='/etc/sudoers',
                             directives=['bash2bug', 'bashbug', 'ed', 'ex', 'ftp', 'format', 'less', 'more', 'pg', 'vi',
                                         'view', 'vim', 'gvim', 'gview', 'evim', 'eview', 'vimdiff', 'find']):
    '''
       Commands which allow shell escape - Sudo configurations must not allow shell escapes (eg the ability to execute subcommands without restriction) that allow access to unauthorized privileges.
    '''
    checkname = inspect.stack()[0][3]
    descr = format_nicely(
        checkname) + "Commands which allow shell escape - Sudo configurations must not allow shell escapes (eg the ability to execute subcommands without restriction) that allow access to unauthorized privileges."
    violation = []
    ret = {}
    if (os.path.exists(osrname) and os.path.isfile(osrname)):
        violated_lines = []
        for directive in directives:
            # This "/usr/bin/" is appended to directive by consider that all executable does exists in /usr/bin/ directory
            directive = "/usr/bin/" + directive
            lines = lookline_in_file(afile=osrname, thevalues='', commentchr='#', case="sensitive", by_regex=directive,
                                     delim=None)
            for line in lines:
                if not 'NOEXEC' in line:
                    violated_lines.append(line)

        if violated_lines:
            violation.append("Sudo configurations for shell escape are violated")
            ret['details'] = violated_lines
    if violation:
        log_audit(descr, "FAILED", details=dict(entry for entry in ret.items()))
    else:
        log_audit(descr, "PASS")

    return dict(entry for entry in ret.items() if len(entry[1]))


# ZY.1.2.3
def SUDO_SECONDARY_LOGGING(osrname='/etc/sudoers'):
    '''
        user ALL = ALL, /bin/su entry in /etc/sudoers
    '''

    checkname = inspect.stack()[0][3]
    directive = 'user ALL = ALL, /bin/su'
    descr = format_nicely(checkname) + \
            "Looking for directive '%s'" % (directive) + " in the sudoers files"

    violations = []
    ret = {}
    ret["user_name"] = []
    user_name = []

    if not os.path.isfile(osrname):
        violations.append('%s: file MISSING' % (osrname))
    else:
        # 1st and 3rd element
        search_key = ' '.join(directive.split()[0:3:2])

        result = lookline_in_file(
            afile=osrname,
            thevalues='/bin/su',
            commentchr='#', case="sensitive")
        if not result:
            if 'MISSING_DIRECTIVES' not in ret.keys():
                ret['MISSING_DIRECTIVES'] = []

            ret['MISSING_DIRECTIVES'].append(osrname)
        else:  # found the directive
            violations.append("su is enabled for user")
            ret = {'FILE_NOT_FOUND': osrname}

    for entry in result:
        users = entry.split()[0]
        user_name.append(users)
    ret["user_name"] = user_name

    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# ZY.1.8.1.1
def OSR_SUDOERS_D_OWNER_PERMS(osrname='/etc/sudoers', agreedperms='0700', mode='max', mustexist=False,
                              agreeduser='root'):
    '''
       Each directory and file which is not an OS OSR must be owned by root and have permissions of 700. OS OSR may be owned and with permissions as allowed by the OS OSR requirements.
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + \
            "Directories included in %s file : " % (
                osrname) + "which is not an OS OSR must be owned by root and have permissions of 700. OS OSR may be owned and with permissions as allowed by the OS OSR requirements.)"

    violations = []
    included_dir = []
    ret = {}

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    # Find directories included in suders file
    with open(osrname, 'r+') as fd:
        contents = fd.readlines()
    for line in contents:
        array_char_command = line.split()
        # Only if line is not empty
        if array_char_command:
            if '#includedir' in array_char_command[0]:
                included_dir.append(array_char_command[1])

    for osr in included_dir:
        if os.path.isdir(osr):
            ret[osr] = []
            # first, check ownership
            if agreeduser:
                agreeduid = pwd.getpwnam(agreeduser).pw_uid
                owner_id = os.stat(osr).st_uid
                owner_name = pwd.getpwuid(owner_id).pw_name
                if owner_id != agreeduid:
                    violations.append("FS object %s owned not by %s, but by %s" % (osr, agreeduser, owner_name))
                    ret[osr].append({'problem': 'ownership', 'rightful_owner': agreeduser, 'wrong_owner': owner_name})

            # now check permissions
            permfailed = perm_violation(obj=osr, refperms=agreedperms, mode=mode)
            print("OSR: ", osr, "permfailed: ", permfailed)
            if permfailed:
                violations.append("FS object %s permissions: %s" % (osr, permfailed))
                ret[osr].append({'problem': 'permissions', 'perms': permfailed})

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")
    return dict(entry for entry in ret.items() if len(entry[1]))

# ZY.1.4.3.1
def OSR_SUDOERS_FILE_LISTED_CMD(osrname='/etc/sudoers'):
    '''
        Commands in /etc/sudoers should have the full path.
            - should start with a / to show fully qualified path for files
    '''
    checkname = inspect.stack()[0][3]
    violations = []
    command_list = []
    ret = {}
    ret["violated_commands"] = []
    ret["violations"] = []

    descr = format_nicely(checkname) + "Files in %s file " % (
        osrname) + "should have each file named must specify the full path of the included file"

    if not os.path.isfile(osrname):
        if mustexist:
            violations.append("FS object %s not found" % (osrname))
            ret[osrname] = []
            ret[osrname].append({'problem': 'missing'})
        else:
            pass

    # Find commands included in sudoers file
    with open(osrname, 'r+') as fd:
        contents = fd.readlines()

    for line in contents:
        array_char_command = line.split()
        if array_char_command:
            if 'Cmnd_Alias' in array_char_command[0]:
                command_alias_line=line.split('=')
                command_list=command_alias_line[1].split(',')
                for cmd in command_list:
                    if cmd.startswith(" /"):
                        print("Command %s has fully qualified path" % (cmd))
                    else:
                        ret["violated_commands"].append(cmd)
                        ret["violations"].append(
                            "Cmnd_Alias object in %s has a command which doesnot have fully qualified path" % (osrname))
                        violations.append(
                            "Cmnd_Alias object in %s has a command which doesnot have fully qualified path" % (osrname))
    if violations:
        log_audit(descr, "FAILED", details=violations)
        return False, dict(entry for entry in ret.items())
    else:
        log_audit(descr, "PASS")
        return True, violations

# ZY.30.0.2
def OSR_SUDOERS_LOGGING_EXTERNAL_SYS(osrname='/etc/rsyslog.conf',
                 audits="authpriv.*         /var/log/secure",
                 by_regex=''):
    '''
        /etc/rsyslog.conf:
            - Ensure audit controls in place with strings
            - audits=['authpriv.* /var/log/secure']
    '''

    checkname = inspect.stack()[0][3]
    descr = format_nicely(checkname) + "Directives %s are within  %s"\
        % (' and '.join(audits), osrname)

    violations = []
    if os.path.isfile(osrname):
        check_for_line = lookline_in_file(
            afile=osrname, thevalues=audits)
        if not check_for_line:
            violations.append(audits)

    if violations:
        log_audit(descr, "FAILED", details=violations)
    else:
        log_audit(descr, "PASS")

    return violations
