# frozen_string_literal: true

#! /usr/bin/env python

# Copyright:: Kyndryl 2022

import helper_funcs
import check
from helper_funcs import *

import os
import sys
import inspect
import tempfile
import subprocess
import fileinput
import grp
import pwd
import shutil
import shlex
from stat import *


# IZ.1.1.8.2
def USERIDS_UID(osrname='/etc/passwd'):
    '''
        Removes the duplicates from /etc/passwd, by keeping only the last entry
        for each UID
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # call the twin function from the check module, with the same args
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {490: ['line_1', 'line_2', 'line_3'], 0: ['ln_x', 'ln_y']}

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    all_lines = loadfile2dict(thefile=osrname, byfieldno=3, delim=':')
    # keep_entries = [val[-1] for (key, val) in all_lines.iteritems()]

    # comment above line to support python 3 syntax replacing iteritems() with items()

    keep_entries = [val[-1] for (key, val) in all_lines.items()]

    writelines_infile(target=osrname, lines=keep_entries, mode='rewrite')

    log_enforce('DONE\n')

# IZ.1.1.8.3.1


def USERIDS_GID(osrname='/etc/group'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {490: ['usr1', 'usr2', 'usr3'], 0: ['adm', 'root']}

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    all_lines = loadfile2dict(thefile=osrname, byfieldno=3, delim=':')
    # keep_entries = [val[-1] for (key, val) in all_lines.iteritems()]

    # comment above line to support python 3 syntax replacing iteritems() with items()

    keep_entries = [val[-1] for (key, val) in all_lines.items()]

    writelines_infile(target=osrname, lines=keep_entries, mode='rewrite')

    log_enforce('DONE\n')

# NOT PRESENT


def AUTH_COMMAUTH(directive,
                  pamfiles=['/etc/pam.d/login', '/etc/pam.d/passwd',
                            '/etc/pam.d/sshd', '/etc/pam.d/su']):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    if 'FILE_NOT_FOUND' in fails.keys():
        for osrname in fails['FILE_NOT_FOUND']:
            writelines_infile(target=osrname,
                              lines=directive + "\n",
                              mode='append')

    if 'MISSING_DIRECTIVES' in fails.keys():
        for osrname in fails['MISSING_DIRECTIVES']:
            writelines_infile(target=osrname,
                              lines=directive + "\n",
                              mode='append')

    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        for osrname in fails['BAD_PARAM_DIRECTIVES']:
            # 1st and 3rd element
            search_key = '.*'.join(directive.split()[0:3:2])
            # wrong value => replace with the right one
            search_file_replace_line(target=osrname,
                                     regex=search_key,
                                     newline=directive + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')

# NOT PRESENT


def AUTH_COMMACC(directive,
                 pamfiles=['/etc/pam.d/login', '/etc/pam.d/passwd',
                           '/etc/pam.d/sshd', '/etc/pam.d/su']):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if 'FILE_NOT_FOUND' in fails.keys():
        for osrname in fails['FILE_NOT_FOUND']:
            writelines_infile(target=osrname,
                              lines=directive + "\n",
                              mode='append')

    if 'MISSING_DIRECTIVES' in fails.keys():
        for osrname in fails['MISSING_DIRECTIVES']:
            writelines_infile(target=osrname,
                              lines=directive + "\n",
                              mode='append')

    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        for osrname in fails['BAD_PARAM_DIRECTIVES']:
            # 1st and 3rd element
            search_key = '.*'.join(directive.split()[0:3:2])
            # wrong value => replace with the right one
            search_file_replace_line(target=osrname,
                                     regex=search_key,
                                     newline=directive + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')

# NOT PRESENT


def AUTH_COMMPASS(directive,
                  pamfiles=['/etc/pam.d/login', '/etc/pam.d/passwd',
                            '/etc/pam.d/sshd', '/etc/pam.d/su']):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if 'FILE_NOT_FOUND' in fails.keys():
        for osrname in fails['FILE_NOT_FOUND']:
            writelines_infile(target=osrname,
                              lines=directive + "\n",
                              mode='append')

    if 'MISSING_DIRECTIVES' in fails.keys():
        for osrname in fails['MISSING_DIRECTIVES']:
            writelines_infile(target=osrname,
                              lines=directive + "\n",
                              mode='append')

    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        for osrname in fails['BAD_PARAM_DIRECTIVES']:
            # 1st and 3rd element
            search_key = '.*'.join(directive.split()[0:3:2])
            # wrong value => replace with the right one
            search_file_replace_line(target=osrname,
                                     regex=search_key,
                                     newline=directive + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')

# IZ.1.1.1.1

def AUTH_MAXDAYS(osrname='/etc/login.defs',
                 directive="PASS_MAX_DAYS",
                 agreedvalue="60",
                 expirepassword="true"):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['PASS_MAX_DAYS  100']  or ['PASS_MAX_DAYS  10', 'PASS_MAX_DAYS 99']

    if not fails:
        return

    if expirepassword == "false":
        log_enforce("changing last pass change date ...\n")
        os.system("chage -d $(expr $(date +%s) / 86400) root")

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if fails == ['Directive MISSING']:  # append the line to the file
        writelines_infile(target=osrname,
                          lines=[directive + '\t' + agreedvalue + '\n'],
                          mode='append')
    else:  # wrong value => replace with the right one
        # or...multiple occurences => replace all
        search_file_replace_line(target=osrname,
                                 regex=directive,
                                 newline=directive + '\t' + agreedvalue,
                                 commentchr='#',
                                 uniq_occur=1)

    log_enforce('DONE\n')

# IZ.1.1.3.1


def AUTH_MINDAYS(osrname='/etc/login.defs',
                 directive="PASS_MIN_DAYS",
                 agreedvalue="15"):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['PASS_MAX_DAYS  100']  or ['PASS_MAX_DAYS  10', 'PASS_MAX_DAYS 99']

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if fails == ['Directive MISSING']:  # append the line to the file
        writelines_infile(target=osrname,
                          lines=[directive + '\t' + agreedvalue + '\n'],
                          mode='append')
    else:  # wrong value => replace with the right one
        # or...multiple occurences => replace all
        search_file_replace_line(target=osrname,
                                 regex=directive,
                                 newline=directive + '\t' + agreedvalue,
                                 commentchr='#',
                                 uniq_occur=1)

    log_enforce('DONE\n')

# IZ.1.1.1.2


def AUTH_SHADOWF5(osrname='/etc/shadow',
                  fieldno=5,
                  agreedvalue="60",
                  except_regex=r'^[^:]+:(!!|!|\*|):'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {}  or [{'line 3' : 'entire_line'}] or
    # [{'line n' : 'line content'}]

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    search_file_replace_field(target=osrname,
                              fieldno=fieldno,
                              agreedvalue=agreedvalue,
                              delim=':', commentchr=None,
                              except_regex=except_regex)

    log_enforce('DONE\n')

# IZ.1.1.3.2


def AUTH_SHADOWF4(osrname='/etc/shadow',
                  fieldno=4,
                  agreedvalue="15",
                  except_regex=r'^[^:]+:(!!|!|\*|):'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {}  or [{'line 3' : 'entire_line'}] or
    # [{'line n' : 'line content'}]

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    search_file_replace_field(target=osrname,
                              fieldno=fieldno,
                              agreedvalue=agreedvalue,
                              delim=':', commentchr=None,
                              except_regex=except_regex)

    log_enforce('DONE\n')

# IZ.2.0.1.0
# def AUTH_BUN(text, files=['/etc/motd', '/etc/issue']):


def AUTH_BUN(text='', files=''):

    # text = params['text']
    # files = params['files']

    # checkname = inspect.stack()[0][3]  # this function's name as string
    # args = inspect.getcallargs(eval(checkname))  # the function args, as dict

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # print "Name: ", checkname
    # print "ENFORCE -- args: ", args

    fails = eval('check.' + checkname)(**args)
    # fails = eval('check.' + checkname)(files=files, text=text)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for fl in files:
        writelines_infile(target=fl, lines=[text + '\n'], mode='rewrite')

    log_enforce('DONE\n')

# IZ.1.9.1.2.1 and IZ.1.9.1.2
def AUTH_UMASK(osrnames=['/etc/login.defs','/etc/bashrc'], directive="UMASK", agreedvalue="0777"):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for (dr, probs) in fails.items():
        if probs == ['Directive MISSING']:
            writelines_infile(target=dr, lines=[directive + '\t' + agreedvalue + '\n'], mode='append')
        else:  # wrong value => replace with the right one
            search_file_replace_line(target=dr, regex=directive, case='insensitive' , newline=directive + '\t' + agreedvalue, commentchr='#', uniq_occur=None)

    log_enforce('DONE\n')

def AUTH_HOMES(agreedperms='0700',
               mode="exact",
               category="all",
               mustexist=True):
    '''
        $HOME: permissions of 700 at creation time
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='dir',
                           perms=agreedperms,
                           ownerid=prob['rightful_ownerid'])
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.2.1


def OSR_RHOSTS(osrname=os.path.join(os.path.expanduser("~root"), '.rhosts'),
               agreedperms='0600',
               mode="exact",
               category="all",
               mustexist=False,
               agreeduser='root'):
    '''
        ~root/.rhosts : If exists, only read and write by root
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.2.2 & IZ.C.6.2.13


def OSR_NETRC(osrname=os.path.join(os.path.expanduser("~root"), '.netrc'),
              agreedperms='0600',
              mode="exact",
              category="all",
              mustexist=False,
              agreeduser='root'):
    '''
        ~root/.netrc : If exists, only read and write by root
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.3.1


def OSR_FSROOT(osrname='/',
               agreedperms='0005',
               mode='max',
               category='others',
               mustexist=True,
               agreeduser='root'):
    '''
        / : Setting for other r-x or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='dir',
                           perms=agreedperms, ownername=agreeduser,
                           category=category)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.3.2.1


def OSR_USR(osrname='/usr',
            agreedperms='0005',
            mode='max',
            category='others',
            mustexist=True,
            agreeduser='root'):
    '''
        /usr : Setting for other r-x or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='dir',
                           perms=agreedperms, ownername=agreeduser,
                           category=category)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.3.3


def OSR_ETC(osrname='/etc',
            agreedperms='0005',
            mode='max',
            category='others',
            mustexist=True,
            agreeduser='root'):
    '''
        /etc : Setting for other r-x or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='dir',
                           perms=agreedperms, ownername=agreeduser,
                           category=category)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.4.1


def OSR_ETCSECOPASSWD(osrname='/etc/security/opasswd',
                      agreedperms='0600',
                      mode='max',
                      category='all',
                      mustexist=True,
                      agreeduser='root'):
    '''
        /etc/security/opasswd : Must exist.
        Setting  rw- --- --- or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.4.2.1


def OSR_ETCSHADOW(osrname='/etc/shadow',
                  agreedperms='0600',
                  mode='max',
                  category='all',
                  mustexist=True,
                  agreeduser='root'):
    '''
        /etc/shadow : Must exist.
        Setting  rw- --- --- or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                print("Current perms: ",crtperm, "\n Agreed perms: ",agreedperms)
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.5.1


def OSR_VAR(osrname='/var',
            agreedperms='0005',
            mode='max',
            category='others',
            mustexist=True,
            agreeduser='root'):
    '''
        /var : Setting for other r-x or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='dir',
                           perms=agreedperms, ownername=agreeduser,
                           category=category)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.11


def OSR_VARTMP(osrname='/var/tmp',
               agreedperms='01777',
               mode='exact',
               category='all',
               mustexist=True,
               agreeduser=False):
    '''
        /var/tmp : Settings must be rwxrwxrwt(1777)
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='dir',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.5.2


def OSR_VARLOG(osrname='/var/log',
               agreedperms='0005',
               mode='max',
               category='others',
               mustexist=True,
               agreeduser='root'):
    '''
        /var/log : Setting for other r-x or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='dir',
                           perms=agreedperms, ownername=agreeduser,
                           category=category)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# AD.1.8.6.1


def OSR_FAILLOG(osrname='/var/log/faillog',
                agreedperms='0600',
                mode="exact",
                category="all",
                mustexist=True,
                agreeduser='root'):
    '''
        /var/log/faillog :
          - must be set to rw- --- --- for all systems not using pam_tally2.so
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.6.2


def OSR_TALLYLOG(osrname='/var/log/tallylog',
                 agreedperms='0600',
                 mode="exact",
                 category="all",
                 mustexist=True,
                 agreeduser='root'):
    '''
        /var/log/tallylog :
          - must be set to rw- --- --- for all systems using pam_tally2.so
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# AD 1.2.3.1
# IZ 1.8.7.1


def OSR_VARLOGMESSAGES(osrname='/var/log/messages',
                       agreedperms='0744',
                       mode='max',
                       category='all',
                       mustexist=True,
                       agreeduser='root'):
    '''
        /var/log/messages : must be set rwx r-- r-- or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                print("Current perms: ",crtperm, "\n Agreed perms: ",agreedperms)
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.7.2
def OSR_VARLOGWTMP(osrname='/var/log/wtmp',
                   agreedperms='0764',
                   mode='max',
                   category='all',
                   mustexist=True,
                   agreeduser='root'):
    '''
        /var/log/wtmp : must be set rwx rw- r- or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                print("Current perms: ",crtperm, "\n Agreed perms: ",agreedperms)
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
            if prob['problem'] == 'groupownership':
                os.chown(dr, -1, name2gid(prob['rightful_group']))
                log_enforce('Directory %s group updated successfully\n' %(dr))
                # print rightperm
                #os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.8


def OSR_VARLOGSECURE(osrname='/var/log/secure',
                     agreedperms='0740',
                     mode='max',
                     category='all',
                     mustexist=True,
                     agreeduser='root'):
    '''
        /var/log/secure : must be set rwx r-- --- or more restrictive
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.9


def OSR_TMP(osrname='/tmp',
            agreedperms='01777',
            mode='exact',
            category='all',
            mustexist=True,
            agreeduser='root'):
    '''
        /tmp : Settings must be rwxrwxrwt(1777)
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='dir',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.10


def OSR_SNMPDCONF(osrname='/etc/snmp/snmpd.conf',
                  agreedperms='0540',
                  mode='max',
                  category='all',
                  mustexist=False,
                  agreeduser='root'):
    '''
        snmpd.conf : if exists, r-x r-- --- or more restrictive
    '''

    # print agreeduser
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# NOT PRESENT


def OSR_INITTAB(osrname='/etc/inittab',
                agreedperms='0744',
                mode='max',
                category='all',
                mustexist=False,
                agreeduser='root'):
    '''
        Files executed via entries in /etc/inittab
            - no write by general users (744 or more restrictive)
    '''

    # print agreeduser
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.14.2


def OSR_CRONROOT(osrname='/var/spool/cron/root',
                 agreedperms='0745',
                 mode='max',
                 category='all',
                 mustexist=False,
                 agreeduser='root'):
    '''
        Files executed via entries in /var/spool/cron/root
            - no write by general users (745 or more restrictive)
    '''

    # print agreeduser
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# NOT PRESENT


def OSR_CRONTABSROOT(osrname='/var/spool/cron/tabs/root',
                     agreedperms='0744',
                     mode='max',
                     category='all',
                     mustexist=False,
                     agreeduser='root'):
    '''
        Files executed via entries in /var/spool/cron/tabs/root
            - no write by general users (744 or more restrictive)
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.8.15.2


def OSR_ETCCRONTAB(osrname='/etc/crontab',
                   agreedperms='0744',
                   mode='max',
                   category='all',
                   mustexist=False,
                   agreeduser='root'):
    '''
        Files executed via entries in /etc/crontab
            - no write by general users (744 or more restrictive)
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# AD.1.8.20.2
# IZ.1.8.20.3

def OSR_ETCCRONDALL(osrname='/etc/cron.d',
                    agreedperms='0744',
                    mode='max',
                    category='all',
                    mustexist=False,
                    agreeduser='root'):
    '''
        Files executed via entries in files located in /etc/cron.d/*
            - no write by general users (744 or more restrictive)
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# NOT PRESENT


def OSR_ETCXINETDCONF(osrname='/etc/xinetd.conf',
                      agreedperms='0744',
                      mode='max',
                      category='all',
                      mustexist=False,
                      agreeduser='root'):
    '''
        Files executed via entries in /etc/xinetd.conf
            - no write by general users (744 or more restrictive)
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# NOT PRESENT


def OSR_INITD_RCD(osrname=['/etc/init.d/', '/etc/rc.d/'],
                  agreedperms='0744',
                  mode='max',
                  category='all',
                  mustexist=False,
                  agreeduser='root'):
    '''
        Files executed via files or links contained in /etc/init.d/ or
        /etc/rc.d/:
            - should have no write by general users (744 or more restrictive)
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# AD.1.8.18.2


def OSR_INITD_RCD_ALL(osrname=["/etc/init.d/rc0.d", "/etc/init.d/rc1.d",
                               "/etc/init.d/rc2.d", "/etc/init.d/rc3.d",
                               "/etc/init.d/rc4.d", "/etc/init.d/rc5.d",
                               "/etc/init.d/rc6.d", "/etc/init.d/rcS.d",
                               "/etc/rc.d/rc0.d", "/etc/rc.d/rc1.d",
                               "/etc/rc.d/rc2.d", "/etc/rc.d/rc3.d",
                               "/etc/rc.d/rc4.d", "/etc/rc.d/rc5.d",
                               "/etc/rc.d/rc6.d", "/etc/rc.d/rcS.d"],
                      agreedperms='0744',
                      mode='max',
                      category='all',
                      mustexist=False,
                      agreeduser='root'):
    '''
        Files executed via files or links contained in
        /etc/init.d/rc0.d, /etc/init.d/rc1.d, /etc/init.d/rc2.d,
        /etc/init.d/rc3.d, /etc/init.d/rc4.d, /etc/init.d/rc5.d,
        /etc/init.d/rc6.d, /etc/init.d/rcS.d directories
            - or -
        /etc/rc.d/rc0.d, /etc/rc.d/rc1.d, /etc/rc.d/rc2.d, /etc/rc.d/rc3.d,
        /etc/rc.d/rc4.d, /etc/rc.d/rc5.d, /etc/rc.d/rc6.d, /etc/rc.d/rcS.d
                - should have no write by general users
                (744 or more restrictive)
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                # crtperm = oct(stat.S_IMODE(os.stat(dr).st_mode)) or...
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')


# IZ.1.5.9.20.1

def NET_SYNCOOKIES(osrname='/etc/sysctl.conf',
                   directive="net.ipv4.tcp_syncookies",
                   agreedvalue="1",
                   delim='='):
    '''
        /etc/sysctl.conf:
            - should contain net.ipv4.tcp_syncookies = 1
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if fails == ['Directive MISSING']:  # append the line to the file
        writelines_infile(target=osrname,
                          lines=[directive + ' %s ' % delim + agreedvalue +
                                 '\n'],
                          mode='append')
    else:  # wrong value => replace with the right one
        # or...multiple occurences => replace all
        search_file_replace_line(target=osrname,
                                 regex=directive,
                                 newline=directive + ' %s ' % delim +
                                 agreedvalue,
                                 commentchr='#',
                                 uniq_occur=1)

    log_enforce('DONE\n')

# IZ.1.5.9.20.2


def NET_BROADCASTS(osrname='/etc/sysctl.conf',
                   directive="net.ipv4.icmp_echo_ignore_broadcasts",
                   agreedvalue="1",
                   delim='='):
    '''
        /etc/sysctl.conf:
            - should contain net.ipv4.icmp_echo_ignore_broadcasts = 1
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if fails == ['Directive MISSING']:  # append the line to the file
        writelines_infile(target=osrname,
                          lines=[directive + ' %s ' % delim + agreedvalue +
                                 '\n'],
                          mode='append')
    else:  # wrong value => replace with the right one
        # or...multiple occurences => replace all
        search_file_replace_line(target=osrname,
                                 regex=directive,
                                 newline=directive + ' %s ' % delim +
                                 agreedvalue,
                                 commentchr='#',
                                 uniq_occur=1)

    log_enforce('DONE\n')

# IZ.1.5.9.20.3


def NET_REDIRECTS(osrname='/etc/sysctl.conf',
                  directive="net.ipv4.conf.all.accept_redirects",
                  agreedvalue="0",
                  delim='='):
    '''
        /etc/sysctl.conf:
            - should contain net.ipv4.conf.all.accept_redirects = 0
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if fails == ['Directive MISSING']:  # append the line to the file
        writelines_infile(target=osrname,
                          lines=[directive + ' %s ' % delim + agreedvalue +
                                 '\n'],
                          mode='append')
    else:  # wrong value => replace with the right one
        # or...multiple occurences => replace all
        search_file_replace_line(target=osrname,
                                 regex=directive,
                                 newline=directive + ' %s ' % delim +
                                 agreedvalue,
                                 commentchr='#',
                                 uniq_occur=1)

    log_enforce('DONE\n')

# IZ.1.5.9.18.3
# IZ.1.5.9.18.2


def NET_SNMPSERVICE(osrname='/etc/snmp/snmpd.conf',
                    communities=['public', 'private']):
    '''
        /etc/snmp/snmpd.conf:
            - Community name of 'public' and 'private' are not permitted
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if fails:  # append the line to the file
        comment_lines_infile(target=osrname,
                             regex='(' + '|'.join(communities) + ')',
                             # (public|private)
                             commentchr='#')

    log_enforce('DONE\n')

# IZ.1.1.4.6


def SSAA_PAMD_OTH_AUTH(directive,
                       pamfiles=['/etc/pam.d/other']):
    '''
        /etc/pam.d/other:
            - auth required pam_deny.so

    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for osrname in fails:
        writelines_infile(target=osrname,
                          lines=[directive + '\n'],
                          mode='append')

    log_enforce('DONE\n')

# IZ.1.4.1


def SSAA_PAMD_OTH_ACC(directive,
                      pamfiles=['/etc/pam.d/other']):
    '''
        /etc/pam.d/other:
            - account required pam_deny.so
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for osrname in fails:
        writelines_infile(target=osrname,
                          lines=[directive + '\n'],
                          mode='append')

    log_enforce('DONE\n')

# IZ.1.1.6.0


def SLA_PASSWORD_AUTH(directives,
                      pamfiles=['/etc/pam.d/password-auth']):
    '''
        /etc/pam.d/password-auth:
            - auth required pam_tally.so deny=5
            - account required pam_tally.so
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for osrname in fails.keys():
        toadd = [ln + '\n' for ln in fails[osrname]]
        writelines_infile(target=osrname,
                          lines=toadd,
                          mode='append')

    log_enforce('DONE\n')

# NOT PRESENT


def SLA_PASSWORD_AUTH2(directives,
                       pamfiles=['/etc/pam.d/password-auth']):
    '''
        /etc/pam.d/password-auth:
            - auth required pam_tally.so deny=3
            - account required pam_tally.so
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for osrname in fails.keys():
        search_line_and_add_newline_before(osrname, directives=["auth", "sufficient"], newline=directives[0], commentchr="#", uniq_occur=None, case='sensitive', replace_full_line=True)
        search_line_and_add_newline_before(osrname, directives=["account", "sufficient"], newline=directives[1], commentchr="#", uniq_occur=None, case='sensitive', replace_full_line=True)

    log_enforce('DONE\n')

# IZ.1.1.7.1


def SSAA_ROOTPWD(agreeduser, maxage):
    '''
        root user:
            - if password is set, must expire
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    osrname = '/etc/shadow'
    fieldno = 5
    except_regex = r'^(?!(%s)).*' % agreeduser

    if fails:
        search_file_replace_field(target=osrname,
                                  fieldno=fieldno,
                                  agreedvalue=maxage,
                                  delim=':', commentchr=None,
                                  except_regex=except_regex)
        os.system("sudo passwd -e %s" % agreeduser)

    log_enforce('DONE\n')

# NOT PRESENT


def SSAA_ROOT_CONSOLE(osrname='/etc/ssh/sshd_config',
                      directive='PermitRootLogin',
                      agreedvalue='no'):
    '''
        root user:
            - login restricted to system console - PermitRootLogin no
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if fails == ['Directive MISSING']:  # append the line to the file
        writelines_infile(target=osrname,
                          lines=[directive + '\t' + agreedvalue + '\n'],
                          mode='append')
    else:  # wrong value => replace with the right one
        # or...multiple occurences => replace all
        search_file_replace_line(target=osrname,
                                 regex=directive,
                                 newline=directive + '\t' + agreedvalue,
                                 commentchr='#',
                                 uniq_occur=1, case='insensitive')
        os.system("service sshd restart")

    log_enforce('DONE\n')



# IZ.1.5.10.1
def NET_YPPASSWDD(status_cmd, update_cmd, cfgfile='/etc/init.d/yppasswdd',
                  service='yppasswdd'):
    '''
        - yppasswd daemon - disabled:
            - /etc/init.d/yppasswdd - if file exists, disable yppasswdd service
                = RHEL, SLES:
                    = status_cmd: chkconfig --list yppasswdd
                    = update_cmd: chkconfig yppasswdd off
                = Debian:
                    =
                    = update-rc.d yppasswdd disable
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    status_cmd = re.sub('%', service, status_cmd)
    update_cmd = re.sub('%', service, update_cmd)

    x = subprocess.Popen(update_cmd.split(), stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = x.communicate()
    cmd_ret = x.returncode

    if cmd_ret == 0 and not cmd_err:
        log_enforce('DONE\n')
    else:
        log_enforce('ERROR enforcing: %s\n' % (cmd_err))


# def AUTH_PWD_COMPLEX(osrname,
#                      directives=['password required pam_cracklib.so retry=3 \
#                                   minlen=8 dcredit=-1 ucredit=0 lcredit=-1 \
#                                   ocredit=0 type= reject_username',
#                                  'password required pam_passwdqc.so \
#                                   min=disabled,8,8,8,8 passphrase=0 \
#                                   random=0 enforce=everyone']):
#
#     '''
#         One of these two options must be implemented:
#             - Parameters of "retry=3 minlen=8 dcredit=-1 ucredit=0 lcredit=-1
#                 ocredit=0 type= reject_username" to the
#                 "password required pam_cracklib.so ..." stanza
#             - parameters of "min=disabled,8,8,8,8 passphrase=0 random=0
#                 enforce=everyone" to the
#                 "password required pam_passwdqc.so" stanza
#         The "type=" parameter to pam_crackllib.so may be omitted
#         if it causes problems.
#
#         RHEL -> '/etc/pam.d/system-auth'
#         SLES -> '/etc/pam.d/common-auth'
#     '''
#
#     frame = inspect.currentframe()
#     args, _, _, values = inspect.getargvalues(frame)
#     checkname = inspect.getframeinfo(frame)[2]
#     args = dict((i, values[i]) for i in args)
#
#     fails = eval('check.' + checkname)(**args)
#     # e.g: fails = []  or ['Directive MISSING'] or
#     # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
#     # print "fails: ", fails
#     if not fails:
#         return
#
#     log_enforce(format_nicely(checkname) + "ENFORCING ...")
#
#     fix_directive = directives[0]
#
#     if fails[fix_directive] == 'MISSING':  # append the line to the file
#         writelines_infile(target=osrname,
#                           lines=[fix_directive + '\n'],
#                           mode='append')
#     else:  # wrong value => replace with the right one
#         # or...multiple occurences => replace all
#         search_file_replace_line(target=osrname,
#                                  regex='.*'.join(fix_directive.split()[0:3:2]),
#                                  newline=fix_directive,
#                                  commentchr='#',
#                                  uniq_occur=1)
#
#     log_enforce('DONE\n')

# AD 1.1.2.0
def AUTH_PWD_COMPLEX(osrnames,
                     directives=['password requisite pam_pwquality.so retry=3 \
                                  minlen=15 dcredit=-1 ucredit=0 lcredit=-1 \
                                  ocredit=0 type= reject_username']):

    '''
        One of these two options must be implemented:
            - Parameters of "retry=3 minlen=8 dcredit=-1 ucredit=0 lcredit=-1
                ocredit=0 type= reject_username" to the
                "password requisite pam_pwquality.so..." stanza

        RHEL -> '/etc/pam.d/system-auth'
        SLES -> '/etc/pam.d/common-auth'
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
       return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    # for osrname in osrnames:
    if 'FILE_NOT_FOUND' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n' for directive in directives],
                          mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        for osrname in fails['MISSING_DIRECTIVES']:
            line_after_to_add_line ="pam_permit.so"
            add_lines = insertlines_infile_after_line(target=osrname,
                                                      lines= "\n" + ' '.join(directives) ,
                                                      searchline=line_after_to_add_line)
    else:
        osrnames = fails.keys()
        for osrname in osrnames:
           for (badline, goodline) in fails[osrname].items():
                search_file_replace_line(target=osrname,
                                         regex=badline,
                                         newline=goodline + "\n",
                                         commentchr='#',
                                         uniq_occur=1)

    log_enforce('DONE\n')



# IZ.1.1.2.0
def AUTH_PWD_MINLEN(osrnames=['/etc/pam.d/system-auth', '/etc/pam.d/password-auth'],
                    directive=['password requisite pam_pwquality.so'],
                    argum='minlen=17'):
    '''
        Password minimum length:   17
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for osrname in osrnames:
        if "Directive MISSING" in fails.keys():
            for osrname in fails['MISSING_DIRECTIVES']:
                line_after_to_add_line ="pam_permit.so"
                add_lines = insertlines_infile_after_line(target=osrname,
                                                        lines= "\n" + ' '.join(directive) +  " " + argum ,
                                                        searchline=line_after_to_add_line)

        else:  # wrong value => replace with the right one
            for osrname in fails.keys():
                for fail in fails[osrname]:
                    if re.search(r'minlen=\d+', fail):
                        print(fails[osrname])
                        search_file_replace_line(target=osrname,
                                                 regex=fail,
                                                 # newline=directive + '\n',
                                                 newline=re.sub(r'minlen=\d+',
                                                                argum, fail),
                                                 commentchr='#',
                                                 uniq_occur=1)
                    else:
                        search_file_replace_line(target=osrname,
                                                 regex=fail,
                                                 newline=fail.replace(
                                                     "\n", " ") + argum + '\n',
                                                 commentchr='#',
                                                 uniq_occur=1)

    log_enforce('DONE\n')

# NOT PRESENT


def SSAA_SUDO_SU(osrname='/etc/sudoers', addsudoers=[]):
    '''
        su verifications:
            - rename it to /bin/suDISABLED
            - remove x right for owner, group and others
        sudo:
            - at least one active users or group with and active user,
            allowed to login (login shell or password not disabled)
            should have an active (uncommented) entry in /etc/sudoers
            for all commands (last word is ALL)
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    allerrors = fails.keys()

    if 'supath' in allerrors:  # the su binary file exists

        supath = which_py('su')
        crtperm = os.stat(supath).st_mode
        os.rename(supath, supath + 'DISABLED')

        if 'su_executable' in allerrors:
            # the us binary exists and is executable
            os.chmod(supath + 'DISABLED', crtperm)  # chmod -x
            # os.chmod(supath + 'DISABLED', crtperm & 0666)  # chmod -x

    if 'no_sudoers' in allerrors:
        if not addsudoers:
            log_enforce('ERROR - sudoer users not provided, cannot enforce\n')
            return

        directives = ['%s ALL=(ALL) ALL\n' % elem for elem in addsudoers]
        writelines_infile(target=osrname,
                          lines=directives,
                          mode='append')

    if 'invalid_sudoers' in allerrors:
        log_enforce(' *** WARNING *** manual intervention required:' +
                    ' Please set the passwd and/or login shell for at least ' +
                    'one of the following users: %s\n'
                    % fails['invalid_sudoers'])
        return

    log_enforce('DONE\n')

# IZ.1.1.4.1
def AUTH_REUSE_RHEL(osrnames,
                    directives):
    '''
        RHEL:
            - /etc/pam.d/password-auth, /etc/pam.d/system-auth:
                password required pam_unix.so remember=8 use_authtok md5 shadow
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # if 'File MISSING' in fails.values():
    #     create_osr(osr=osrname, res_type='file')
    #     writelines_infile(target=osrname,
    #                       lines=[directive + '\n'],
    #                       mode='append')


    if 'FILE_NOT_FOUND' in fails.keys():
        osrnames = fails['FILE_NOT_FOUND']
        for osrname in osrnames:
            writelines_infile(target=osrname,
                              lines=[directive + '\n' for directive in directives],
                              mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        line_after_to_add_line ="pam_pwquality.so"
        osrnames = fails['MISSING_DIRECTIVES']
        for osrname in osrnames:
            add_lines = insertlines_infile_after_line(target=osrname,
                                                  lines=' '.join(directives) + "\n",
                                                  searchline=line_after_to_add_line)

    else:
        osrnames = fails.keys()
        for osrname in osrnames:
            for (badline, goodline) in fails[osrname].items():
                search_file_replace_line(target=osrname,
                                        regex=badline,
                                        newline=goodline + "\n",
                                        commentchr='#',
                                        uniq_occur=1)

    log_enforce('DONE\n')


def SLA_COMMON_AUTH(osrname,
                    directives):
    '''
        /etc/pam.d/common-auth:
           - auth required pam_tally.so deny=5 onerr=fail per_user no_lock_time

    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # if 'File MISSING' in fails.values():
    #     create_osr(osr=osrname, res_type='file')
    #     writelines_infile(target=osrname,
    #                       lines=[directive + '\n'],
    #                       mode='append')

    if 'FILE_NOT_FOUND' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n' for directive in directives],
                          mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n'
                                 for directive in fails['MISSING_DIRECTIVES']],
                          mode='append')
    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        # wrong value => replace with the right one

        # for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].iteritems():

        # comment above line to support python 3 syntax replacing iteritems() with items()

        for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].items():
            search_file_replace_line(target=osrname,
                                     regex=badline,
                                     newline=''.join(directives) + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')


def SLA_COMMON_AUTH2(osrname,
                     directives):
    '''
        /etc/pam.d/common-auth:
           -auth required pam_tally2.so deny=5 onerr=fail per_user no_lock_time

    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # if 'File MISSING' in fails.values():
    #     create_osr(osr=osrname, res_type='file')
    #     writelines_infile(target=osrname,
    #                       lines=[directive + '\n'],
    #                       mode='append')

    if 'FILE_NOT_FOUND' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n' for directive in directives],
                          mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n'
                                 for directive in fails['MISSING_DIRECTIVES']],
                          mode='append')
    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        # wrong value => replace with the right one

        # for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].iteritems():

        # comment above line to support python 3 syntax replacing iteritems() with items()

        for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].items():
            search_file_replace_line(target=osrname,
                                     regex=badline,
                                     newline=''.join(directives) + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')


def SLA_COMMON_ACC(osrname,
                   directives):
    '''
        /etc/pam.d/common-account (for pam_tally.so use)
           - account required pam_tally.so
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # if 'File MISSING' in fails.values():
    #     create_osr(osr=osrname, res_type='file')
    #     writelines_infile(target=osrname,
    #                       lines=[directive + '\n'],
    #                       mode='append')

    if 'FILE_NOT_FOUND' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n' for directive in directives],
                          mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n'
                                 for directive in fails['MISSING_DIRECTIVES']],
                          mode='append')
    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        # wrong value => replace with the right one

        # for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].iteritems():

        # comment above line to support python 3 syntax replacing iteritems() with items()

        for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].items():
            search_file_replace_line(target=osrname,
                                     regex=badline,
                                     newline=''.join(directives) + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')


def SLA_COMMON_ACC2(osrname,
                    directives):
    '''
        /etc/pam.d/common-account (for pam_tally2.so use)
           - account required pam_tally2.so
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # if 'File MISSING' in fails.values():
    #     create_osr(osr=osrname, res_type='file')
    #     writelines_infile(target=osrname,
    #                       lines=[directive + '\n'],
    #                       mode='append')

    if 'FILE_NOT_FOUND' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n' for directive in directives],
                          mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n'
                                 for directive in fails['MISSING_DIRECTIVES']],
                          mode='append')
    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        # wrong value => replace with the right one

        # for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].iteritems():

        # comment above line to support python 3 syntax replacing iteritems() with items()

        for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].items():
            search_file_replace_line(target=osrname,
                                     regex=badline,
                                     newline=''.join(directives) + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')


def AUTH_REUSE_PWCHECK(osrname="/etc/security/pam_pwcheck.conf",
                       directives=["password: md5 remember=8"]):
    '''
        SLES: /etc/security/pam_pwcheck.conf
            - password: md5 remember=8
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # if 'File MISSING' in fails.values():
    #     create_osr(osr=osrname, res_type='file')
    #     writelines_infile(target=osrname,
    #                       lines=[directive + '\n'],
    #                       mode='append')

    if 'FILE_NOT_FOUND' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n' for directive in directives],
                          mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n'
                                 for directive in fails['MISSING_DIRECTIVES']],
                          mode='append')
    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        # wrong value => replace with the right one

        # for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].iteritems():

        # comment above line to support python 3 syntax replacing iteritems() with items()

        for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].items():
            search_file_replace_line(target=osrname,
                                     regex=badline,
                                     newline=''.join(directives) + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')


def AUTH_REUSE_SLES(osrname,
                    options):
    '''
        SLES:	/etc/pam.d/common-password
            - file must exist and include these one of these two settings:
                - Option 1 (include both):
                    = password required pam_unix2.so md5
                    = password required pam_pwcheck.so remember=8
                - Option 2:
                    = password required pam_unix_passwd.so remember=7
                    use_authtok md5 shadow
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # if 'File MISSING' in fails.values():
    #     create_osr(osr=osrname, res_type='file')
    #     writelines_infile(target=osrname,
    #                       lines=[directive + '\n'],
    #                       mode='append')

    if 'FILE_NOT_FOUND' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n' for directives in options
                                 for directive in directives],
                          mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n'
                                 for directive in fails['MISSING_DIRECTIVES']],
                          mode='append')
    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        # wrong value => replace with the right one

        # for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].iteritems():

        # comment above line to support python 3 syntax replacing iteritems() with items()

        for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].items():
            search_file_replace_line(target=osrname,
                                     regex=badline,
                                     newline=goodline + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')


# -------------------- 3d iteration -----------------


def AUTH_PAMUNIX2CONF(osrname="/etc/security/pam_unix2.conf",
                      directives=["password: md5 shadow"]):
    '''
        SLES: /etc/security/pam_unix2.conf
            - password: md5 shadow
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or ['Directive MISSING'] or
    # ['UMASK 0033']  or ['UMASK 0005', 'UMASK 0001']
    # print "fails: ", fails
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # if 'File MISSING' in fails.values():
    #     create_osr(osr=osrname, res_type='file')
    #     writelines_infile(target=osrname,
    #                       lines=[directive + '\n'],
    #                       mode='append')

    if 'FILE_NOT_FOUND' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n' for directive in directives],
                          mode='append')
        log_enforce('DONE\n')
        return

    if 'MISSING_DIRECTIVES' in fails.keys():
        writelines_infile(target=osrname,
                          lines=[directive + '\n'
                                 for directive in fails['MISSING_DIRECTIVES']],
                          mode='append')
    if 'BAD_PARAM_DIRECTIVES' in fails.keys():
        # wrong value => replace with the right one

        # for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].iteritems():

        # comment above line to support python 3 syntax replacing iteritems() with items()

        for (badline, goodline) in fails['BAD_PARAM_DIRECTIVES'].items():
            search_file_replace_line(target=osrname,
                                     regex=badline,
                                     newline=''.join(directives) + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

    log_enforce('DONE\n')

# IZ.1.4.6.5
def AUTO_SKEL(osrnames=['/etc/skel/.cshrc', '/etc/skel/.login',
                        '/etc/skel/.profile', '/etc/skel/.bashrc',
                        '/etc/skel/.bash_profile', '/etc/skel/.bash_login',
                        '/etc/skel/.tcshrc'],
              directive="TMOUT",
              acceptedvalue="1800"):
    '''
        - /etc/skel/.cshrc, /etc/skel/.login, /etc/skel/.profile,
        /etc/skel/.bashrc, /etc/skel/.bash_profile, /etc/skel/.bash_login,
        /etc/skel/.tcshrc
        - if the files exist, look for TMOUT parameter and set it to 1800 if found
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (osrname, result) in fails:
          goodline = directive + "=" + acceptedvalue
        # delete the wrong lines
          search_file_replace_line(target=osrname, regex=directive,
                                     newline=goodline, commentchr='#',
                                     uniq_occur=None, case='sensitive')

    log_enforce('DONE\n')

# IZ.1.4.6.6
def CHECK_ALLOWED_SHELL():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'Symbolic Link not present' in entry or 'Shell found' in entry:
            cmd = "ln -sf bash /bin/sh"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            else:
                log_enforce('Symbolic Link created successfully \n')
    log_enforce('\nDONE\n')

# IZ.1.9.1.7
def AUTH_SKEL(osrnames=['/etc/skel/.cshrc', '/etc/skel/.login',
                        '/etc/skel/.profile', '/etc/skel/.bashrc',
                        '/etc/skel/.bash_profile', '/etc/skel/.bash_login',
                        '/etc/skel/.tcshrc'],
              directive="UMASK",
              acceptedvalue="077"):
    '''
        - /etc/skel/.cshrc, /etc/skel/.login, /etc/skel/.profile,
        /etc/skel/.bashrc, /etc/skel/.bash_profile, /etc/skel/.bash_login,
        /etc/skel/.tcshrc
        - if the files exist, they do not override the umask 077
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (osrname, badlines) in fails:
        # delete the wrong lines
        for badline in badlines:
            search_file_replace_line(target=osrname, regex=badline,
                                     newline='', commentchr='#',
                                     uniq_occur=None, case='sensitive')

    log_enforce('DONE\n')

# IZ.1.4.6.1
def AUTH_ETCPROFILE(osrnames=['/etc/profile'],
                    directive="UMASK",
                    acceptedvalue="077",
                    mustexist=True):
    '''
        - /etc/profile
            - File must exist and does not set/reset umask after that
            invocation.
            Some systems will have /etc/profile invoke /etc/profile.local
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (osrname, badlines, file_missing) in fails:

        if file_missing:
            create_osr(osr=osrname, res_type='file')
            # it's enough to create the file, because it must only exist, NOT
            # necessarilly to also contain the UMASK directive....
            continue

        # if it DOES contain it, with wrong value, we delete the wrong lines
        for badline in badlines:
            search_file_replace_line(target=osrname, regex=badline,
                                     newline='', commentchr='#',
                                     uniq_occur=None, case='sensitive')

    log_enforce('DONE\n')

# IZ.1.4.6.2
def AUTH_CSHLOGIN(osrnames=['/etc/csh.login'],
                  directive="UMASK",
                  acceptedvalue="077",
                  mustexist=True):
    '''
        - /etc/csh.login
            - File must exist and does not set/reset umask after that
            invocation.
            Some systems will have /etc/csh.login invoke /etc/csh.login.local
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (osrname, badlines, file_missing) in fails:

        if file_missing:
            create_osr(osr=osrname, res_type='file')
            # it's enough to create the file, because it must only exist, NOT
            # necessarilly to also contain the UMASK directive....
            continue

        # if it DOES contain it, with wrong value, we delete the wrong lines
        for badline in badlines:
            search_file_replace_line(target=osrname, regex=badline,
                                     newline='', commentchr='#',
                                     uniq_occur=None, case='sensitive')

    log_enforce('DONE\n')


def IPC_MD5SHADOW(pamfiles=["/etc/pam.d/passwd", "/etc/pam.d/system-auth",
                            "/etc/pam.d/password-auth"],
                  mustexist=True,
                  options=["md5", "shadow"]):
    '''
        /etc/pam.d/passwd, /etc/pam.d/system-auth, /etc/pam.d/password-auth
        and any file in /etc/pam.d containing
        "password required|sufficient (lib/security/$ISA)/pam_unix.so"
            - should include options: md5 shadow
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (fl, ln, missingopts) in fails:

        if ln == 'MISSING':  # the file is missing
            create_osr(osr=fl, res_type='file')
            continue
        if 'md5' in missingopts:
            if 'sha512' in ln:
                goodline = (ln.strip() + " " +
                            " ".join(missingopts) + "\n").replace("sha512", "")
            if 'sha256' in ln:
                goodline = (ln.strip() + " " +
                            " ".join(missingopts) + "\n").replace("sha256", "")
        else:
            goodline = ln.strip() + " " + " ".join(missingopts) + "\n"
        search_file_replace_line(target=fl, regex=ln,
                                 newline=goodline,
                                 commentchr='#',
                                 uniq_occur=None, case='sensitive')

    log_enforce('DONE\n')


def IPC_ETCDEFPASSWD(osrnames=['/etc/default/passwd'],
                     directive='CRYPT_FILES',
                     mustexist=True,
                     agreedvalue='md5',
                     delim='='):
    '''
        /etc/default/passwd
            - CRYPT_FILES=md5
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (fl, error) in fails:

        if error == ['MISSING']:  # the file is missing
            create_osr(osr=fl, res_type='file')
            continue

        if error == ['DIRECTIVE_MISSING']:
            writelines_infile(target=fl,
                              lines=[directive + delim + agreedvalue + '\n'],
                              mode='append')
            continue

        # else...replace by regex
        search_file_replace_line(target=fl, regex=directive,
                                 newline=directive + delim + agreedvalue,
                                 commentchr='#',
                                 uniq_occur=True, case='sensitive')

    log_enforce('DONE\n')


def IPC_PRIVKEYS(agreedperms='0600',
                 mode='exact',
                 category='all',
                 mustexist=False):
    '''
        all users $HOME/.ssh/ all files containing "PRIVATE KEY-----"
            - permissions 600
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    # for (dr, probs) in fails.iteritems():

    # comment above line to support python 3 syntax replacing iteritems() with items()

    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms,
                           ownerid=prob['rightful_ownerid'])
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))

    log_enforce('DONE\n')

# IZ.1.4.2.1 
def SSAA_FTPUSERS(osrname='/etc/vsftpd/ftpusers', contains="root"):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    if fails == ['Directive MISSING']:  # append the line to the file
        # print ("bb")
        writelines_infile(target=osrname,
                          lines=contains,
                          mode='append')
    else:  # wrong value => replace with the right one
        # or...multiple occurences => replace all
        # print "bb1"
        search_file_replace_line(target=osrname,
                                 regex=contains,
                                 newline=contains,
                                 commentchr='#',
                                 uniq_occur=1)

    log_enforce('DONE\n')

# IZ.1.5.4.2
def NWSET_RLOGIN(osrnames=['/etc/pam.d/rlogin', '/etc/pam.d/rsh'],
                 searchstrings="auth      sufficient  /lib/security/pam_rhosts_auth.so no_hosts_equiv"):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for osrname in fails:
        writelines_infile(target=osrname,
                          lines=searchstrings + '\n',
                          mode='append')

    log_enforce('DONE\n')

# IZ.1.5.4.1
def NWSET_HOSTS_EQUIV(osrname='/etc/hosts.equiv', mustexist=False):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    os.remove(osrname)

    log_enforce('DONE\n')

# IZ.1.2.2

def AUDIT_EXIST_WTMP(osrname='/var/log/wtmp', mustexist=True):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    fd = os.open(osrname, os.O_RDWR | os.CREAT)
    os.write(fd, "")
    os.close(fd)
    log_enforce('DONE\n')

# IZ.1.2.1.4.2
def AUDIT_SYSLOG(osrname='/etc/rsyslog.conf',
                 audits=['*.info;mail.none;authpriv.none;cron.none                /var/log/messages',
                         'authpriv.*                                              /var/log/secure'],
                 by_regex=''):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for audit in fails:
        writelines_infile(target=osrname,
                          lines=audit + '\n',
                          mode='append')

    log_enforce('DONE\n')

# IZ.1.2.5

def AUDIT_EXIST_SECURE(osrname='/var/log/secure', mustexist=True):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    fd = os.open(osrname, os.O_RDWR | os.CREAT)
    os.write(fd, "")
    os.close(fd)
    log_enforce('DONE\n')

# IZ.1.2.3.1

def AUDIT_EXIST_MSG(osrname='/var/log/messages', mustexist=True):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    fd = os.open(osrname, os.O_RDWR | os.CREAT)
    os.write(fd, "")
    os.close(fd)
    log_enforce('DONE\n')


def AUDIT_EXIST_FAILLOG(osrname='/var/log/faillog', mustexist=True):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    fd = os.open(osrname, os.O_RDWR | os.CREAT)
    os.write(fd, "")
    os.close(fd)
    log_enforce('DONE\n')

# IZ.1.2.4.2

def AUDIT_EXIST_TALLYLOG(osrname='/var/log/tallylog', mustexist=True):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    fd = os.open(osrname, os.O_RDWR | os.CREAT)
    os.write(fd, "")
    os.close(fd)
    log_enforce('DONE\n')


# IZ.1.8.14.1/ IZ.1.8.15.1

def OSR_CRON_CMD(osrnames=['/var/spool/cron/root', '/var/spool/cron/tabs/root', '/etc/crontab'], mustexist=True):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "MANUALLY CHECK AND UPDATE ...\n")
    for fail in fails.keys():
        log_enforce(format_nicely(
            checkname) + "Please manually check commands are fully qualified in " + fail + '\n')
    log_enforce('DONE\n')


def OSR_CRON_D_CMD(osrdir='/etc/crond.d'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "MANUALLY CHECK AND UPDATE ...\n")
    for fail in fails.keys():
        log_enforce(format_nicely(
            checkname) + "Please manually check commands are fully qualified in " + fail + '\n')
    log_enforce('DONE\n')


def OSR_INITTAB_CMD(osrname='/etc/inittab'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "MANUALLY CHECK AND UPDATE ...\n")
    for fail in fails.keys():
        log_enforce(format_nicely(
            checkname) + "Please manually check commands are fully qualified in " + fail + '\n')
    log_enforce('DONE\n')


def OSR_XINETD_D_CMD(osrdir='/etc/xinetd.d'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "MANUALLY CHECK AND UPDATE ...\n")
    for fail in fails.keys():
        log_enforce(format_nicely(
            checkname) + "Please manually check commands are fully qualified in " + fail + '\n')
    log_enforce('DONE\n')


def OSR_XINETD_CMD(osrname='/etc/xinetd.conf'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "MANUALLY CHECK AND UPDATE ...\n")
    for fail in fails.keys():
        log_enforce(format_nicely(
            checkname) + "Please manually check commands are fully qualified in " + fail + '\n')
    log_enforce('DONE\n')


# IZ.1.1.4.5
def AUTH_NO_NULL_PASS(osrnames=['/etc/pam.d/system-auth','/etc/pam.d/password-auth'],
                      directives=['auth pam_unix.so nullok',
                                  'password pam_unix.so nullok']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for osrname in osrnames:
        if 'FILE_NOT_FOUND' in fails.keys():
            log_enforce(format_nicely(checkname) +
                        ": File %s not found.\n" % (osrname))

        if 'MISSING_DIRECTIVES' in fails.keys():
            for directive in fails['MISSING_DIRECTIVES']:
                log_enforce(format_nicely(checkname) +
                            ": Directives %s line missing in %.\n" % (directive))
                log_enforce(format_nicely(checkname) + ": Analyze the output of the Audit step above and perform the"
                            "appropriate action to correct any discrepancies found.\n")

        if 'BAD_PARAM_DIRECTIVES' in fails.keys():
            for line in fails['BAD_PARAM_DIRECTIVES']:
                search_key = (line.split(':')[0])
                lines_to_file1 = (line.split(':')[1])
                # wrong value => replace with the right one
                update_line = search_file_replace_line(target=osrname,
                                                       regex=search_key,
                                                       newline=lines_to_file1 + "\n",
                                                       commentchr='#',
                                                       uniq_occur=1)
                if update_line != 1:
                    log_enforce(format_nicely(checkname) +
                                ': line %s not updated' % (lines_to_file1))
                else:
                    log_enforce('line %s is successfully updated\n' %
                                (lines_to_file1))

    log_enforce('\nDONE\n')


# IZ.1.2.1.4.1
def AUDIT_RSYSLOG(agreedvalue='rsyslog'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'Agreed to values not installed' in entry:
            cmd = "yum -y install " + agreedvalue
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(
                    checkname) + ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': Service %s was not insatlled \n' % (agreedvalue))
            else:
                log_enforce('Service %s was installed successfully\n' %
                            (agreedvalue))
                cmd = "systemctl enable " + agreedvalue
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(
                        checkname) + ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(
                        checkname) + ': Service %s was not enabled \n' % (agreedvalue))
                else:
                    log_enforce('Service %s was enabled successfully\n' %
                                (agreedvalue))

        elif 'Agreed to values not enabled' in entry:
            cmd = "systemctl enable " + agreedvalue
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(
                    checkname) + ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service %s was not enabled \n' % (agreedvalue))
            else:
                log_enforce('Service %s was enabled successfully\n' %
                            (agreedvalue))

    log_enforce('\nDONE\n')


# IZ.1.2.1.4.3
def AUDIT_RSYSLOG_SECURE(osrnames=[
    '/etc/rsyslog.conf',
    '/etc/rsyslog.d/'],
        searchstrings='FileCreateMode'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Files %s are not found\n' % entry.split()[0])

        if searchstrings in entry:
            filename = entry.split()[7]
            update_line = search_file_replace_line(
                filename, searchstrings[1:], searchstrings + " 0640\n", commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated\n' % (searchstrings))
            else:
                log_enforce('\n line %s 0640 is successfully updated\n' %
                            (searchstrings))

        if 'Line not found in file' in entry:
            filename = entry.split()[5]
            add_line = writelines_infile(target=filename,
                                         lines=searchstrings + " 0640\n",
                                         mode='append')
            if add_line != 1:
                log_enforce(format_nicely(
                    checkname) + ': line %s not added to file %s\n' % (searchstrings, filename))
            else:
                log_enforce('line %s 0640 is successfully added\n' %
                            (searchstrings))

    log_enforce('\nDONE\n')


# IZ.1.1.13.4
def AUTH_PASS_USE_PAM(osrname='/etc/ssh/sshd_config',
                      searchstrings='UsePAM'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Files %s are not found\n' % (osrname))

        if searchstrings in entry:
            # filename =  entry.split()[7]
            update_line = search_file_replace_line(
                osrname, searchstrings, searchstrings + " yes\n", commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated\n' % (searchstrings))
            else:
                log_enforce('line %s yes is successfully updated\n' %
                            (searchstrings))

        if 'Line not found in file' in entry:
            # filename = entry.split()[5]
            add_line = writelines_infile(target=osrname,
                                         lines=searchstrings + " yes\n",
                                         mode='append')
            if add_line != 1:
                log_enforce(format_nicely(
                    checkname) + ': line %s not added to file %s\n' % (searchstrings, osrname))
            else:
                log_enforce('line %s yes is successfully added\n' %
                            (searchstrings))

    log_enforce('\nDONE\n')


#  AD.1.2.6
def AUDIT_SYSLOG_ROTATE(osrname='/etc/logrotate.d/syslog',
                        searchstrings=['monthly', 'daily',
                                       'hourly', 'weekly', 'yearly'],
                        logrotatevalue='rotate 30',
                        searchline='sharedscripts'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    space_string = "    "
    for entry in fails:
        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Files %s are not found' % (osrname))

        if 'Line not found' in entry:
            lines_to_file = space_string + \
                searchstrings[0] + "\n" + space_string + logrotatevalue + "\n"
            add_lines = insertlines_infile_after_line(target=osrname,
                                                      lines=lines_to_file,
                                                      searchline=searchline)
            if add_lines != 1:
                log_enforce(format_nicely(
                    checkname) + ': line %s not added to file %s\n' % (lines_to_file, osrname))
            else:
                log_enforce('line %s is successfully added\n' %
                            (lines_to_file))

        if 'Rotate Missing' in entry:
            lines_to_file = space_string + logrotatevalue + "\n"
            add_lines = insertlines_infile_after_line(target=osrname,
                                                      lines=lines_to_file,
                                                      searchline=searchstrings[0])
            if add_lines != 1:
                log_enforce(format_nicely(
                    checkname) + ': line %s not added to file %s\n' % (lines_to_file, osrname))
            else:
                log_enforce('line %s is successfully added\n' %
                            (lines_to_file))

        if 'Replace Rotate 30' in entry:
            lines_to_file = space_string + logrotatevalue
            lines_to_search = entry.split()[4] + "\s" + entry.split()[5]

            update_line = search_file_replace_line(
                osrname, lines_to_search, lines_to_file, commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated' % (lines_to_file))
            else:
                log_enforce('line %s is successfully updated\n' %
                            (lines_to_file))

        if 'Monthly and Rotate not found' in entry:
            lines_to_file = space_string + \
                searchstrings[0] + "\n" + space_string + logrotatevalue
            lines_to_search = entry.split()[9]
            update_line = search_file_replace_line(
                osrname, lines_to_search, lines_to_file, commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated' % (lines_to_file))
            else:
                log_enforce('line %s is successfully updated\n' %
                            (lines_to_file))

        if 'Replace Monthly Rotate' in entry:
            lines_to_file1 = space_string + searchstrings[0]
            lines_to_file2 = space_string + logrotatevalue
            lines_to_search1 = entry.split()[4]
            lines_to_search2 = entry.split()[6] + "\s" + entry.split()[7]

            update_line = search_file_replace_line(
                osrname, lines_to_search1, lines_to_file1, commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated' % (lines_to_file1))
            else:
                log_enforce('line %s is successfully updated\n' %
                            (lines_to_file1))

            update_line = search_file_replace_line(
                osrname, lines_to_search2, lines_to_file2, commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated' % (lines_to_file2))
            else:
                log_enforce('line %s is successfully updated\n' %
                            (lines_to_file2))

        if 'Replace Monthly Only' in entry:

            lines_to_file = space_string + searchstrings[0]
            lines_to_search = entry.split()[4]

            update_line = search_file_replace_line(
                osrname, lines_to_search, lines_to_file, commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated' % (lines_to_file))
            else:
                log_enforce('line %s is successfully updated\n' %
                            (lines_to_file))

    cmd = "rpm -q rsyslog"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        log_enforce(format_nicely(checkname) +
                    ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        cmd = "rpm -q syslog-ng"
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            log_enforce(format_nicely(checkname) +
                        ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_ret'] != 0:
            log_enforce(format_nicely(checkname) +
                        ': Service syslogd  and syslog-ng are not insatlled \n')
        else:
            cmd = "systemctl restart rsyslog"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service syslog-ng was not restarted \n')
            else:
                log_enforce('Service syslog-ng was restared successfully\n')
    else:
        cmd = "systemctl restart rsyslog"
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            log_enforce(format_nicely(checkname) +
                        ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_ret'] != 0:
            log_enforce(format_nicely(checkname) +
                        ': Service rsyslog was not restarted \n')
        else:
            log_enforce('Service rsyslog was restared successfully\n')

    log_enforce('\nDONE\n')


# IZ.1.2.7.1
def AUDIT_SYNC_CLOCK():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    print("Filas: ", fails)
    for entry in fails:
        if 'failed in executing ntpd command:' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if "No clock synchronization is active" in entry:
          cmd = "systemctl restart chronyd"
          print("Restarting chronyd service")
          cmd_exec = execute_command(cmd)
          cmd_status =  "systemctl status chronyd"
          cmd_status_exec = execute_command(cmd_status)
          log_enforce(format_nicely(checkname) +': Status of chronyd service after restart: %s \n' % (str(cmd_status_exec['cmd_out'])))
          if cmd_exec['cmd_err']:
              log_enforce(format_nicely(checkname) +
                          ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
          elif cmd_exec['cmd_ret'] != 0:
              log_enforce(format_nicely(checkname) +
                          ': Both ntpd and chronyd services are not active,'
                          ' check and start suitable service \n')

    log_enforce('\nDONE\n')

# Workaround for IZ.1.2.7.1
def AUDIT_SYNC_CLOCK_WORKAROUND():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    log_enforce('\nDONE\n')


# IZ.1.2.7.2
def AUDIT_CHRONY_SERVER(osrname='/etc/chrony.conf',
                        searchstrings=['server', 'pool']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'CHRONYD is not active' in entry:
            log_enforce(format_nicely(checkname) +
                        ': CHRONYD is not active, Ensure it is active for securing it')

        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s are not found' % (osrname))

        if 'Line not found' in entry:
            log_enforce(format_nicely(checkname) +
                        ':File %s does not have either %s or %s specified,'
                        ' minimum required configuration for server missing'
                        % (osrname, searchstrings[0], searchstrings[1]))

    log_enforce('\nDONE\n')


# IZ.1.2.7.3
def AUDIT_CHRONY_NOEXCESSPRIV():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'CHRONYD is not active' in entry:
            log_enforce(format_nicely(checkname) +
                        ': CHRONYD is not active, Ensure it is active for securing it')

        if "No task is running as chrony id" in entry:
            cmd = "systemctl restart chronyd"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': CHRONYD is not restarted, Ensure its running')
            else:
                cmd = "ps -u chrony"
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_out'] == b'' or 'chronyd' not in str(cmd_exec['cmd_out']):
                    log_enforce(format_nicely(checkname) +
                                ':Ensure Chronyd has least privilege configuration, '
                                'as no task is running as chrony id\n')
                else:
                    log_enforce('Chronyd has least privilege configuration'
                                ' required post restart and is running as chrony id\n')

    log_enforce('\nDONE\n')


# IZ.1.2.7.4
def AUDIT_NTPD_SECURE(osrname='/etc/ntp.conf',
                      directives=['restrict -4 default kod nomodify notrap nopeer noquery',
                                  'restrict -6 default kod nomodify notrap nopeer noquery']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'NTPD is not active' in entry:
            log_enforce(format_nicely(checkname) +
                        ': NTPD is not active, Ensure it is active for securing it\n')

        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Files %s are not found\n' % (osrname))

        if 'Line not found' in entry:
            lines_to_file = ' '.join(entry.split()[0:8:1])
            add_line = writelines_infile(target=osrname,
                                         lines=lines_to_file + "\n",
                                         mode='append')
            if add_line != 1:
                log_enforce(format_nicely(
                    checkname) + ': line %s not added to file %s\n' % (lines_to_file, osrname))
            else:
                log_enforce('line %s is successfully added\n' %
                            (lines_to_file))
        if 'key default missing' in entry:
            if '-4' in entry:
                lines_to_file = directives[0]
            if '-6' in entry:
                lines_to_file = directives[1]
            lines_to_search = ' '.join(entry.split()[6:8:1])
            update_line = search_file_replace_line(
                osrname, lines_to_search, lines_to_file, commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated\n' % (lines_to_file))
            else:
                log_enforce('line %s is successfully updated\n' %
                            (lines_to_file))

    log_enforce('\nDONE\n')


# IZ.1.2.7.5
def AUDIT_NTPD_SERVER(osrname='/etc/ntp.conf',
                      searchstrings=['server', 'pool']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'NTPD is not active' in entry:
            log_enforce(format_nicely(checkname) +
                        ': NTPD is not active, Ensure it is active for securing it\n')

        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s are not found\n' % (osrname))

        if 'Line not found' in entry:
            log_enforce(format_nicely(checkname) +
                        ':File %s does not have either %s or %s specified,'
                        ' minimum required configuration for server missing\n'
                        % (osrname, searchstrings[0], searchstrings[1]))

    log_enforce('\nDONE\n')



#IZ.1.1.1.3
def AUTH_SHADOWF3(osrname='/etc/shadow',
                  fieldno=3):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {}  or [{'line 3' : 'entire_line'}] or
    # [{'line n' : 'line content'}]

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for i in fails:
        line = fails[i]
        vals = line.strip().split(':')
        username = vals[0]
        uid = pwd.getpwnam(username).pw_uid
        if(uid >= 1000):
            #os.system('passwd -e '+ username)
            cmd = 'passwd -e ' + username
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Could not expire the password for user %s, please ensure it is expired. \n'%(username))
            elif cmd_exec['cmd_ret'] == 0:
                log_enforce(format_nicely(checkname) + ': Expired password for the following user: %s\n' % (username))

    log_enforce('DONE\n')

# IZ.1.1.2.1
def AUTH_SHADOWF2(osrname='/etc/shadow',
                  fieldno=2):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {}  or [{'line 3' : 'entire_line'}] or
    # [{'line n' : 'line content'}]

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for i in fails:
        line = fails[i]
        vals = line.strip().split(':')
        username = vals[0]

        #Get the user id from username
        uid = pwd.getpwnam(username).pw_uid

        # Checking user accounts only
        if(uid >= 1000):
            cmd = 'chage -E0 ' + username
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Could not lock account for user %s, please ensure it is locked. \n' % (username))
            elif cmd_exec['cmd_ret'] == 0:
                log_enforce(format_nicely(checkname) + ': Locked account for the following user: %s\n' % (username))

    log_enforce('DONE\n')

# IZ.1.1.2.2
def AUTH_PASSWDF2(osrname='/etc/passwd',
                  fieldno=2):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {}  or [{'line 3' : 'entire_line'}] or
    # [{'line n' : 'line content'}]

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for i in fails:
        line = fails[i]
        vals = line.strip().split(':')
        username = vals[0]

        #Get the user id from username
        uid = pwd.getpwnam(username).pw_uid

        #Checking user accounts only
        if(uid >= 1000):
            cmd = 'chage -E0 ' + username
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Could not lock account for user %s, please ensure it is locked. \n' % (username))
            elif cmd_exec['cmd_ret'] == 0:
                log_enforce(format_nicely(checkname) + ': Locked account for the following user: %s\n' % (username))

    log_enforce('DONE\n')

# IZ.1.1.8.3.2
def AUTH_PASSWD_GROUP(osrnames = ['/etc/passwd', '/etc/group'], fieldno=4):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {}  or [{'line 3' : 'entire_line'}] or
    # [{'line n' : 'line content'}]

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "Analyze the output of the Audit step above and perform the appropriate action to correct any discrepancies found.\n")

# IZ.1.1.10.1
def AUTH_PASSWD_NON_LOGIN(osrname='/etc/passwd', fieldno=7):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # dups = check.USERIDS_UID(osrname='/etc/passwd')
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {}  or [{'line 3' : 'entire_line'}] or
    # [{'line n' : 'line content'}]

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for i in fails:
        line = fails[i]
        vals = line.strip().split(':')
        username = vals[0]
        uid = pwd.getpwnam(username).pw_uid
        if (uid < 1000):
            if(username != 'root'):
                cmd = 'usermod -L ' + username
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(checkname) +
                                ': Could not lock account for user %s, please ensure it is locked. \n' % (username))
                elif cmd_exec['cmd_ret'] == 0:
                    log_enforce(format_nicely(checkname) + ': Locked account for the following user: %s\n' % (username))


                cmd = 'usermod -s /sbin/nologin ' + username
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(checkname) +
                                ': Could not set the shell as /sbin/nologin for user %s, please ensure it is set. \n' % (username))
                elif cmd_exec['cmd_ret'] == 0:
                    log_enforce(format_nicely(checkname) + ': Set user shell as /sbin/nologin for the following user:: %s\n' % (username))

    log_enforce('DONE\n')


# IZ.1.5.9.39
def SAMBA_SERVICE():
    '''
        Enforce SAMBA(smd) service is stopped and disabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "smb"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")



# IZ.1.5.9.40
def RSH_CLIENT():
    '''
        Enforce rsh client is not installed
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    package_name = "rsh"
    command = "yum remove -y {}".format(package_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": {} client successfully uninstalled".format(package_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to uninstall package '{}' with error: {}".format(
                        package_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")


# IZ.1.5.9.41
def TALK_CLIENT():
    '''
        Enforce talk client is not installed
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    package_name = "talk"
    command = "yum remove -y {}".format(package_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": {} client successfully uninstalled".format(package_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to uninstall package '{}' with error: {}".format(
                        package_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")


# IZ.1.5.11.1
def RLOGIN_SERVICE():
    '''
        Enforce rlogin service not enabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "rlogin.socket"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")



# IZ.1.5.11.2
def RSH_SERVICE():
    '''
        Enforce rsh service not enabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "rsh.socket"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")



# IZ.1.5.11.3
def REXEC_SERVICE():
    '''
        Enforce rexec service not enabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "rexec.socket"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")

# IZ.1.5.9.34
def RSYNC_SERVICE():
    '''
        Enforce RSYNC(rsyncd) service is stopped and disabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "rsyncd"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")


# IZ.1.5.9.35
def CUPS_SERVICE():
    '''
        Enforce CUPS(cups) service is stopped and disabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "cups"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")



# IZ.1.5.9.36
def DHCP_SERVICE():
    '''
        Enforce DHCP(dhcpd) service is stopped and disabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "dhcpd"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")


# IZ.1.5.9.37
def DNS_SERVICE():
    '''
        Enforce DNS(dhcpd) service is stopped and disabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "named"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")



# IZ.1.5.9.38
def HTTP_SERVICE():
    '''
        Enforce DNS(dhcpd) service is stopped and disabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "httpd"
    command = "systemctl disable {}".format(service_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")


# IZ.1.5.13.1
def NET_COREDUMPS(osrnames=['/etc/security/limits.conf', '/etc/security/limits.d/', '/etc/sysctl.conf'],
                  searchstrings=['* hard core 0', 'fs.suid_dumpable = 0']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Files %s are not found\n' % entry.split()[0])
        if 'Line not found in limits file' in entry:
            new_osrnames = []
            writelines_infile(target=osrnames[0],
                              lines=searchstrings[0] + "\n",
                              mode='append')
            osr_names = list_files_in_dir_with_extension(
                osrnames[1], extension='')
            if osr_names:
                for osr_name in osr_names:
                    new_osrnames.append(osr_name)
                for osr in new_osrnames:
                    if os.path.isfile(osr):
                        search_key = "core"
                        result = lookline_in_file(afile=osr,
                                                  thevalues=search_key,
                                                  commentchr='#', case="sensitive")
                        if result:
                            writelines_infile(target=osr,
                                              lines=searchstrings[0] + "\n",
                                              mode='append')
        if 'Line not found in sysctl file' in entry:
            writelines_infile(target=osrnames[2],
                              lines=searchstrings[1] + "\n",
                              mode='append')

    cmd = "sysctl -w fs.suid_dumpable=0"
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_err']:
        log_enforce(format_nicely(checkname) +
                    ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        log_enforce(format_nicely(checkname) +
                    ': Failed to restrict core dumps')
    log_enforce('\nDONE\n')


# IZ.1.5.13.2
def NET_ASLR(osrname='/etc/sysctl.conf',
             searchstring='kernel.randomize_va_space = 2'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s not found\n' % (osrname))
        else:
            writelines_infile(target=osrname,
                              lines=searchstring + "\n",
                              mode='append')
            log_enforce('line %s is successfully updated,changes will come into effect after reboot\n' %(searchstring))

            cmd = "sysctl -w kernel.randomize_va_space=2"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Failed to enable ASLR')
            else:
                log_enforce('ASLR is enabled successfully')

    log_enforce('\nDONE\n')


# IZ.1.8.3.4
def OSR_BOOTLOADER_BOOT(osrname='/boot',
                        agreedperms='0555',
                        mode='exact',
                        category='all',
                        agreeduser='root',
                        agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                log_enforce(format_nicely(checkname) +
                            ': Directory %s not found\n' % (dr))
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
                log_enforce('Directory %s owner updated successfully\n' %(dr))
            if prob['problem'] == 'groupownership':
                os.chown(dr, -1, name2gid(prob['rightful_group']))
                log_enforce('Directory %s group updated successfully\n' %(dr))
            if prob['problem'] == 'permissions':
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('Directory %s permissions changed successfully\n' %(dr))

    log_enforce('DONE\n')


# IZ.1.8.3.5
def OSR_BOOTLOADER_GRUB(osrnames=['/boot/grub2/grub.cfg', '/boot/grub2/user.cfg'],
                        agreedperms='0600',
                        mode='exact',
                        category='all',
                        agreeduser='root',
                        agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
                log_enforce('File %s owner updated successfully\n' %(dr))
            if prob['problem'] == 'groupownership':
                os.chown(dr, -1, name2gid(prob['rightful_group']))
                log_enforce('File %s group updated successfully\n' %(dr))
            if prob['problem'] == 'permissions':
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('File %s permissions changed successfully\n' %(dr))

    log_enforce('DONE\n')


# IZ.1.5.5
def NET_DISABLE_REXD():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            log_enforce(format_nicely(checkname) +
                        ': rexd do not apply to linux, so needs to be fixed manually\n')

    log_enforce('\nDONE\n')


# IZ.1.5.7
def NET_DISABLE_XWIN():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'xorg-x11* is installed' in entry:
            cmd = "yum -y remove xorg-x11*"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': Service xorg-x11* is still installed \n')
            else:
                log_enforce('Service xorg-x11* is uninstalled successfully\n')

    log_enforce('\nDONE\n')


# IZ.1.5.9.1
def NET_DISABLE_ECHO(directives=['echo-dgram: off', 'echo-stream: off']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'Both directives MISSING' in entry:
            for directive in directives:
                flag = directive.split()[0]
                cmd = "chkconfig " + flag[:-1] + " off"
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(
                        checkname) + ': Adding %s failed \n' % (directive))
                else:
                    log_enforce('%s is added successfully\n' % (directive))

        elif 'Only single directive' in entry:
            flag_present = entry.split()[4][2:]
            for directive in directives:
                if flag_present not in directive:
                    flag_absent = directive.split()[0]
                    directive_absent = directive

            cmd = "chkconfig " + flag_absent[:-1] + " off"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': Adding %s failed \n' % (directive_absent))
            else:
                log_enforce('%s is added successfully\n' % (directive_absent))

    log_enforce('\nDONE\n')


# IZ.1.5.9.2
def NET_DISABLE_CHARGEN(directives=['chargen-dgram: off', 'chargen-stream: off']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'Both directives MISSING' in entry:
            for directive in directives:
                flag = directive.split()[0]
                cmd = "chkconfig " + flag[:-1] + " off"
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(
                        checkname) + ': Adding %s failed \n' % (directive))
                else:
                    log_enforce('%s is added successfully\n' % (directive))

        elif 'Only single directive' in entry:
            flag_present = entry.split()[4][2:]
            for directive in directives:
                if flag_present not in directive:
                    flag_absent = directive.split()[0]
                    directive_absent = directive

            cmd = "chkconfig " + flag_absent[:-1] + " off"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': Adding %s failed \n' % (directive_absent))
            else:
                log_enforce('%s is added successfully\n' % (directive_absent))

    log_enforce('\nDONE\n')


# IZ.1.5.9.3
def NET_RSTATD_DISABLE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable rstatd.service"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service rstatd was not disabled \n')
            else:
                log_enforce('Service rstatd was disabled successfully \n')

    log_enforce('\nDONE\n')


# IZ.1.5.3.3
def NFS_CONFIGURATION_NO_ROOT_SQUASH(osrname="/etc/exports", searchstrings="no_root_squash"):
    '''
        Enforcing NFS Configuration file to have no filesystem exported with 'no_root_squash'
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    matched_filesystems = eval('check.' + checkname)(**args)
    if not matched_filesystems:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    extra_regex = ",{0,1}"
    regex_string = "{}{}".format(extra_regex, searchstrings)

    try:
        search_file_replace_line(osrname, regex_string, "", "#", replace_full_line=False)
    except Exception as e:
        log_enforce(format_nicely(checkname) +
                    ": Failed to remove '{}' from file '{}' with error: {}.".format(searchstrings,
                                                                                    osrname,
                                                                                    e))
        log_enforce("\nFAILED\n")

    log_enforce("\nDONE\n")


# IZ.1.5.9.24.3
def VSFTPD_SERVICE_CONFIGURATION_FOR_ANON_FTP(osrnames=["/etc/vsftpd/vsftpd.conf", "/etc/vsftpd/user_list"],
                                              directives=None):
    '''
        Ensure VSFTPD service is properly configured (when anonymous ftp is enabled) and enforce if required
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, all_results = eval('check.' + checkname)(**args)
    if succeeded:
        return
    else:
        if all_results["error"]:
            log_enforce(format_nicely(checkname) + ": Cannot enforce due to error - {}".format(all_results["error"]))
            log_enforce(format_nicely(checkname) + "\nFAILED\n")

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    try:
        iterate_through = zip(osrnames, directives)

        for osrname, directive in iterate_through:
            result = all_results["file_details"].get(osrname)

            # Write missing lines which are required
            if result["missing_required_lines"]:
                writelines_infile(osrname, lines=[line+"\n" for line in result["missing_required_lines"]])

            # delete disallowed lines
            if result["disallowed_lines"]:
                current_lines = []
                if not result["file_missing"]:
                    with open(osrname, 'r') as fh:
                        current_lines = fh.readlines()

                to_write = []
                for line in current_lines:
                    check_line = line.strip()
                    if check_line.startswith("#"):
                        to_write.append(line)
                    elif check_line not in result["disallowed_lines"]:
                        to_write.append(line)
                    else:
                        continue

                writelines_infile(osrname, lines=to_write, mode="rewrite")

    except Exception as e:
        log_enforce(format_nicely(checkname) +
                    ": Failed to enforce remedies for file '{}' with error: '{}'".format(osrname, e))
        log_enforce("\nFAILED\n")

    log_enforce("\nDONE\n")


# IZ.1.5.9.4
def NET_DISABLE_TFTP(osrname='/etc/xinetd.d/tftp', directives=['tftp: off']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'Directive MISSING' in entry:
            if os.path.isfile(osrname):
                searchstring = "disable"
                result = lookline_in_file(afile=osrname,
                                          thevalues=searchstring,
                                          commentchr='#', case="sensitive")
                if result:
                    lines_to_file = "\tdisable\t\t\t= yes"
                    update_line = search_file_replace_line(
                        osrname, searchstring, lines_to_file, commentchr='#', uniq_occur=1)
                    if update_line != 1:
                        log_enforce(format_nicely(checkname) +
                                    ': line %s not updated\n' % (lines_to_file))
                    else:
                        log_enforce('line %s is successfully updated\n' %
                                    (lines_to_file))

    log_enforce('\nDONE\n')


# IZ.1.5.9.6
def NET_RUSERSD_DISABLE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable rusersd.service"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service rusersd was not disabled \n')
            else:
                log_enforce('Service rusersd was disabled successfully \n')

    log_enforce('\nDONE\n')


# IZ.1.5.9.7
def NET_DISABLE_DISCARD(directives=['discard-dgram: off', 'discard-stream: off']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'Both directives MISSING' in entry:
            for directive in directives:
                flag = directive.split()[0]
                cmd = "chkconfig " + flag[:-1] + " off"
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(
                        checkname) + ': Adding %s failed \n' % (directive))
                else:
                    log_enforce('%s is added successfully\n' % (directive))

        elif 'Only single directive' in entry:
            flag_present = entry.split()[4][2:]
            for directive in directives:
                if flag_present not in directive:
                    flag_absent = directive.split()[0]
                    directive_absent = directive

            cmd = "chkconfig " + flag_absent[:-1] + " off"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': Adding %s failed \n' % (directive_absent))
            else:
                log_enforce('%s is added successfully\n' % (directive_absent))

    log_enforce('\nDONE\n')


# IZ.1.5.9.8
def NET_DISABLE_DAYTIME(directives=['daytime-dgram: off', 'daytime-stream: off']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'Both directives MISSING' in entry:
            for directive in directives:
                flag = directive.split()[0]
                cmd = "chkconfig " + flag[:-1] + " off"
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(
                        checkname) + ': Adding %s failed \n' % (directive))
                else:
                    log_enforce('%s is added successfully\n' % (directive))

        elif 'Only single directive' in entry:
            flag_present = entry.split()[4][2:]
            for directive in directives:
                if flag_present not in directive:
                    flag_absent = directive.split()[0]
                    directive_absent = directive

            cmd = "chkconfig " + flag_absent[:-1] + " off"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': Adding %s failed \n' % (directive_absent))
            else:
                log_enforce('%s is added successfully\n' % (directive_absent))

    log_enforce('\nDONE\n')


# IZ.1.5.9.9
def NET_BOOTPS_DISABLE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable dhcpd"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service dhcpd was not disabled \n')
            else:
                log_enforce('Service dhcpd was disabled successfully \n')

    log_enforce('\nDONE\n')


#IZ.1.5.1.2
def NET_FTP_PERMS(osrnames= ['/var/ftp', '/etc/vsftpd/vsftpd.conf'],
                  directives = ['anonymous_enable=YES', 'anon_root = *']):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the status for vsftpd' in entry:
            log_enforce('Unable to check the status for vsftpd')
        if ' directory owner is not root' in entry:
            uid = pwd.getpwnam("root").pw_uid
            gid = grp.getgrnam("root").gr_gid
            dir =  entry.split(' ')
            home_dir = dir[0]
            os.chown(home_dir, uid, gid)
            log_enforce('Changed the FTP home directory owner and group to root\n')
        if ' directory group has write permission' in entry:
            dir = entry.split(' ')
            home_dir = dir[0]
            mode = oct(os.stat(home_dir)[ST_MODE])[-3:]
            #dir_perm = str(mode)
            temp = int(mode) - 20
            cmd = "chmod " + str(temp) + " " + home_dir
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Removed write access from group users\n')
            else:
                log_enforce('ERROR enforcing NET_FTP_PERMS\n' % (cmd_err))
        if ' directory other users have write permission' in entry:
            dir = entry.split(' ')
            home_dir = dir[0]
            mode = oct(os.stat(home_dir)[ST_MODE])[-3:]
            #dir_perm = str(mode)
            temp = int(mode) - 2
            cmd = "chmod " + str(temp) + " " + home_dir
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Removed write access from other users\n')
            else:
                log_enforce('ERROR enforcing NET_FTP_PERMS\n' % (cmd_err))

    log_enforce('\nDONE\n')


#IZ.1.5.1.3
def NET_FTP_BIN_PERMS(osrnames= ['/var/ftp/bin', '/etc/vsftpd/vsftpd.conf'],
                  directives = ['anonymous_enable=YES', 'anon_root = *'], agreedperms='0111'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the status for vsftpd' in entry:
            log_enforce('Unable to check the status for vsftpd')
        if ' directory owner is not root' in entry:
            uid = pwd.getpwnam("root").pw_uid
            gid = grp.getgrnam("root").gr_gid
            dir = entry.split(' ')
            bin_dir = dir[0]
            os.chown(bin_dir, uid, gid)
            log_enforce('Changed the FTP home directory owner and group to root\n')
        if ' directory group has write permission' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            mode = oct(os.stat(bin_dir)[ST_MODE])[-3:]
            # dir_perm = str(mode)
            temp = int(mode) - 20
            cmd = "chmod " + str(temp) + " " + bin_dir
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Removed write access from group users\n')
            else:
                log_enforce('ERROR enforcing NET_FTP_PERMS\n' % (cmd_err))
        if ' directory other users have write permission' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            mode = oct(os.stat(bin_dir)[ST_MODE])[-3:]
            # dir_perm = str(mode)
            temp = int(mode) - 2
            cmd = "chmod " + str(temp) + " " + bin_dir
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Removed write access from other users\n')
            else:
                log_enforce('ERROR enforcing NET_FTP_PERMS\n' % (cmd_err))

        if 'directory files do not have permissions' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            drs = []
            drs.append(bin_dir)
            # permfailed = false
            files = list_files_in(drs, cond='os.access(%, os.F_OK)')
            if (files):
                for file in files:
                    cmd = "chmod " + str(agreedperms) + " " + file
                    cmd_exec = execute_command(cmd)
                    if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                        log_enforce('Enforced the permissions of %s file to %s\n'%(file, agreedperms))
                    else:
                        log_enforce('ERROR enforcing the permission\n' % (cmd_err))

    log_enforce('\nDONE\n')


# IZ.1.5.9.28
def NET_DISABLE_XINETD():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    service_active = []

    if 'CMD_ERR' in fails.keys():
        log_enforce(format_nicely(checkname) + ': %s \n' % (fails['CMD_ERR']))

    if 'SERVICES_ENABLED' in fails.keys():
        for service in fails['SERVICES_ENABLED']:
            if 'tftp' in service or 'finger' in service:
                if 'tftp' in service:
                    osrname = '/etc/xinetd.d/tftp'
                if 'finger' in service:
                    osrname = '/etc/xinetd.d/finger'
                if os.path.isfile(osrname):
                    searchstring = "disable"
                    result = lookline_in_file(afile=osrname,
                                              thevalues=searchstring,
                                              commentchr='#', case="sensitive")
                    if result:
                        lines_to_file = "\tdisable\t\t\t= yes"
                        update_line = search_file_replace_line(
                            osrname, searchstring, lines_to_file, commentchr='#', uniq_occur=1)
                        if update_line != 1:
                            log_enforce(format_nicely(checkname) +
                                        ': line %s not updated\n' % (lines_to_file))
                            service_active.append(servive)
                        else:
                            log_enforce('line %s is successfully updated\n' %
                                        (lines_to_file))

            else:
                cmd = "chkconfig " + service + " off"
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(checkname) +
                                ': Service %s was not disabled \n' % (service))
                    service_active.append(service)
                else:
                    log_enforce(
                        'Service %s was disabled successfully \n' % (service))

    if len(service_active) == 0 or 'XINETD_ENABLED' in fails.keys():
        cmd = "systemctl disable xinetd"
        cmd_exec = execute_command(cmd)
        if cmd_exec['cmd_err']:
            log_enforce(format_nicely(checkname) +
                        ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
        elif cmd_exec['cmd_ret'] != 0:
            log_enforce(format_nicely(checkname) +
                        ': Service xinet was not disabled \n')
        else:
            log_enforce('Service xinet was disabled successfully \n')

    else:
        log_enforce(format_nicely(
            checkname) + ': Services %s were not disabled, so xinetd was not disabled \n' % (service_active))

    log_enforce('\nDONE\n')


# IZ.1.5.10.2
def AUDIT_NIS_MAPS(osrnames=['/etc/passwd', '/etc/shadow', '/etc/group']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'contains NIS legacy entries' in entry:
            osrname = entry.split()[0]
            log_enforce(format_nicely(checkname) +
                        ': NIS legacy entries present, needs to be removed manually from %s \n' % (osrname))

    log_enforce('\nDONE\n')


# IZ.1.8.3.2.2
def OSR_USR_RESTRICT(osrname='/usr',
                     agreeduser='root',
                     agreedgroup='root'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Files %s are not found\n' % (entry.split()[0]))
        if 'not owned by previledged user' in entry:
            osr = entry.split()[0]
            #os.chown(osr, name2uid(agreeduser), gid2name(agreedgroup))
            shutil.chown(osr, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osr, agreeduser))
        if 'not owned by previledged group' in entry:
            osr = entry.split()[0]
            #os.chown(osr, name2uid(agreeduser), gid2name(agreedgroup))
            shutil.chown(osr, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osr, agreedgroup))

    log_enforce('\nDONE\n')


# IZ.1.8.1.2
def OSR_OWNER_UID():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if fails:
        log_enforce(format_nicely(checkname) + "This techspec has been taken care "\
             "in AD.1.8.3.2.2 OSR_USR_RESTRICT \n")

    log_enforce('\nDONE\n')

# IZ.1.8.1.3
def OSR_OWNER_GID():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if fails:
        log_enforce(format_nicely(checkname) + "This techspec has been taken care "\
             "in AD.1.8.3.2.2 OSR_USR_RESTRICT \n")

    log_enforce('\nDONE\n')


# AD.5.0.3
def PREVILEDGED_UID():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if fails:
        log_enforce(format_nicely(checkname) + "This techspec has been taken care "\
             "in AD.1.8.3.2.2 OSR_USR_RESTRICT \n")

    log_enforce('\nDONE\n')


# AD.5.0.4
def PREVILEDGED_GID():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if fails:
        log_enforce(format_nicely(checkname) + "This techspec has been taken care "\
             "in AD.1.8.3.2.2 OSR_USR_RESTRICT \n")

    log_enforce('\nDONE\n')


# IZ.1.9.1.3
def AUTH_IBMSINIT_SH(osrname='/etc/profile.d/IBMsinit.sh',
                    agreedperms='0755',agreedvalue='true'):
    '''
            /etc/profile.d/IBMsinit.sh:
            - Must include this line:
                if [ $UID -gt 199 ]; then
                  umask 077
                fi
            - If agreedvalue=="true", also include lines:
                TMOUT=1800
                export TMOUT
            - File must exists
            - Must be readable by all users
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    line = "if [ $UID -gt 199 ]; then" + '\n\t' + "umask 077" + '\n' + "fi\n"
    line1 = "TMOUT=1800" + '\n' + "export TMOUT\n"
    create_osr(osr=osrname, res_type='file',perms=agreedperms)
    writelines_infile(target=osrname,
                lines=[line],
                mode='append')
    os.chown(osrname, -1, name2gid('root'))
    if agreedvalue == "true":
      writelines_infile(target=osrname,
                lines=[line1],
                mode='append')

    log_enforce('File %s created successfully\n' % (osrname))
    log_enforce('DONE\n')


# IZ.1.9.1.4
def AUTH_IBMSINIT_CSH(osrname='/etc/profile.d/IBMsinit.csh',
                    agreedperms='0755',agreedvalue='true'):
    '''
            /etc/profile.d/IBMsinit.csh:
            - Must include this line:
                if ($uid > 199) then
                  umask 077
                endif
            - If agreedvalue=="true", also include lines:
                set autologout=30
            - File must exists
            - Must be readable by all users
    '''

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    line = "if ($uid > 199) then" + '\n\t' + "umask 077" + '\n' + "endif\n"
    line1 = "set autologout=30\n"
    create_osr(osr=osrname, res_type='file',perms=agreedperms)
    writelines_infile(target=osrname,
                lines=[line],
                mode='append')
    os.chown(osrname, -1, name2gid('root'))
    if agreedvalue == "true":
      writelines_infile(target=osrname,
                lines=[line1],
                mode='append')

    log_enforce('File %s created successfully\n' % (osrname))
    log_enforce('DONE\n')


# IZ.1.5.9.20.9
def AUDIT_REV_PATH_FILTER(osrnames=['/etc/sysctl.conf', '/etc/sysctl.d/'],
                          directives=["net.ipv4.conf.all.rp_filter = 1",
                                      "net.ipv4.conf.default.rp_filter = 1"]):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    remediation_done = 0

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if 'CMD_ERR' in fails.keys():
        log_enforce(format_nicely(checkname) + ': %s \n' % (fails['CMD_ERR']))
    if 'FILE_NOT_FOUND' in fails.keys():
        log_enforce(format_nicely(checkname) +
                    ": File %s not found.\n" % (fails['FILE_NOT_FOUND']))

    if 'MISSING_DIRECTIVES' in fails.keys():
        for osrnames in fails['MISSING_DIRECTIVES']:
            for osrname in osrnames:
                for directive in directives:
                    search_key = directive
                    result = lookline_in_file(
                        afile=osrname,
                        thevalues=search_key,
                        commentchr='#', case="sensitive")
                    if not result:
                        lines_to_file = directive
                        add_line = writelines_infile(target=osrname,
                                                     lines=lines_to_file + "\n",
                                                     mode='append')
                        if add_line != 1:
                            log_enforce(format_nicely(
                                checkname) + ': line %s not added to file %s\n' % (lines_to_file, osrname))
                        else:
                            log_enforce('line %s is successfully added\n' %
                                        (lines_to_file))

        directives.append('net.ipv4.route.flush = 1')
        for directive in directives:
            directive = ''.join(directive.split())
            cmd = "sysctl -w " + directive
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': setting %s failed \n' % (directive))
            else:
                log_enforce('%s is set successfully\n' % (directive))

    log_enforce('\nDONE\n')


# IZ.1.5.9.21.1
def AUDIT_IPV6_ROUTER_ADV(osrnames=['/etc/sysctl.conf', '/etc/sysctl.d/'],
                          directives=["net.ipv6.conf.all.accept_ra = 0",
                                      "net.ipv6.conf.default.accept_ra = 0"]):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    remediation_done = 0

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if 'CMD_ERR' in fails.keys():
        log_enforce(format_nicely(checkname) + ': %s \n' % (fails['CMD_ERR']))
    if 'FILE_NOT_FOUND' in fails.keys():
        log_enforce(format_nicely(checkname) +
                    ": File %s not found.\n" % (fails['FILE_NOT_FOUND']))

    if 'MISSING_DIRECTIVES' in fails.keys():

        for osrnames in fails['MISSING_DIRECTIVES']:
            for osrname in osrnames:
                for directive in directives:
                    search_key = directive
                    result = lookline_in_file(
                        afile=osrname,
                        thevalues=search_key,
                        commentchr='#', case="sensitive")
                    if not result:
                        lines_to_file = directive
                        add_line = writelines_infile(target=osrname,
                                                     lines=lines_to_file + "\n",
                                                     mode='append')
                        if add_line != 1:
                            log_enforce(format_nicely(
                                checkname) + ': line %s not added to file %s\n' % (lines_to_file, osrname))
                        else:
                            log_enforce('line %s is successfully added\n' %
                                        (lines_to_file))

        directives.append('net.ipv6.route.flush = 1')
        for directive in directives:
            directive = ''.join(directive.split())
            cmd = "sysctl -w " + directive
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': setting %s failed \n' % (directive))
            else:
                log_enforce('%s is set successfully\n' % (directive))

    log_enforce('\nDONE\n')


# Iz.1.5.9.21.2
def AUDIT_ICMP_REDIRECT(osrnames=['/etc/sysctl.conf', '/etc/sysctl.d/'],
                        directives=["net.ipv6.conf.all.accept_redirect = 0",
                                    "net.ipv6.conf.default.accept_redirect = 0"]):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if 'CMD_ERR' in fails.keys():
        log_enforce(format_nicely(checkname) + ': %s \n' % (fails['CMD_ERR']))
    if 'FILE_NOT_FOUND' in fails.keys():
        log_enforce(format_nicely(checkname) +
                    ": File %s not found.\n" % (fails['FILE_NOT_FOUND']))

    if 'FILE_MISSING_DIRECTIVES' in fails.keys():
        osr_names = fails['FILE_MISSING_DIRECTIVES']
        for osrname in osr_names:
            for directive in directives:
                search_key = directive.split()[0]
                result = lookline_in_file(afile=osrname,thevalues=search_key,commentchr='#', case="sensitive")
                if result:
                    search_file_replace_line(target=osrname,regex=directive.split()[0], newline=directive,commentchr='#',uniq_occur=1)
                if not result:
                    add_line = writelines_infile(target=osrname,lines=directive + "\n", mode='append')
                    if add_line != 1:
                         log_enforce(format_nicely(
                            checkname) + ': line %s not added to file %s\n' % (directive, osrname))
                    else:
                        log_enforce('line %s is successfully added\n' % (directive))
	
    if 'MISSING_DIRECTIVES' in fails.keys():

        directives.append('net.ipv6.route.flush = 1')
        for directive in directives:
            directive = ''.join(directive.split())
            cmd = "sysctl -w " + directive.strip()
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': setting %s failed \n' % (directive))
            else:
                log_enforce('%s is set successfully\n' % (directive))

    log_enforce('\nDONE\n')



# IZ.1.5.9.23
def AUDIT_TELNET():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable telnet.socket"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service telnet was not disabled. Please disable it manually \n')
            else:
                log_enforce('Service telnet was disabled successfully \n')

    log_enforce('\nDONE\n')


# AD.1.5.9.24.1.1
def AUDIT_VSFTPD():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) +
                        ': %s\n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable vsftpd"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service vsftpd was not disabled. Please disable it manually \n')
            else:
                log_enforce('Service vsftpd was disabled successfully \n')

    log_enforce('\nDONE\n')


#IZ.1.5.1.4
def NET_FTP_LIB_PERMS(osrnames= ['/var/ftp/lib', '/etc/vsftpd/vsftpd.conf'],
                  directives = ['anonymous_enable=YES', 'anon_root = *'], agreedperms='0555'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the status for vsftpd' in entry:
            log_enforce('Unable to check the status for vsftpd')
        if ' directory owner is not root' in entry:
            uid = pwd.getpwnam("root").pw_uid
            gid = grp.getgrnam("root").gr_gid
            dir = entry.split(' ')
            bin_dir = dir[0]
            os.chown(bin_dir, uid, gid)
            log_enforce('Changed the FTP home directory subdirectory lib owner and group to root\n')
        if ' directory group has write permission' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            mode = oct(os.stat(bin_dir)[ST_MODE])[-3:]
            # dir_perm = str(mode)
            temp = int(mode) - 20
            cmd = "chmod " + str(temp) + " " + bin_dir
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Removed write access from group users\n')
            else:
                log_enforce('ERROR enforcing NET_FTP_LIB_PERMS\n' % (cmd_err))
        if ' directory other users have write permission' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            mode = oct(os.stat(bin_dir)[ST_MODE])[-3:]
            # dir_perm = str(mode)
            temp = int(mode) - 2
            cmd = "chmod " + str(temp) + " " + bin_dir
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Removed write access from other users\n')
            else:
                log_enforce('ERROR enforcing NET_FTP_LIB_PERMS\n' % (cmd_err))

        if 'directory files do not have permissions' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            drs = []
            drs.append(bin_dir)
            # permfailed = false
            files = list_files_in(drs, cond='os.access(%, os.F_OK)')
            if (files):
                for file in files:
                    cmd = "chmod " + str(agreedperms) + " " + file
                    cmd_exec = execute_command(cmd)
                    if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                        log_enforce('Enforced the permissions of %s file to %s\n'%(file, agreedperms))
                    else:
                        log_enforce('ERROR enforcing the permission\n' % (cmd_err))

    log_enforce('\nDONE\n')


#IZ.1.5.1.5
def NET_FTP_ETC_PERMS(osrnames= ['/var/ftp/etc', '/etc/vsftpd/vsftpd.conf'],
                  directives = ['anonymous_enable=YES', 'anon_root = *'], agreedperms='0111'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the status for vsftpd' in entry:
            log_enforce('Unable to check the status for vsftpd')
        if ' directory owner is not root' in entry:
            uid = pwd.getpwnam("root").pw_uid
            gid = grp.getgrnam("root").gr_gid
            dir = entry.split(' ')
            bin_dir = dir[0]
            os.chown(bin_dir, uid, gid)
            log_enforce('Changed the FTP home directory subdirectory etc owner and group to root\n')
        if ' directory group has write permission' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            mode = oct(os.stat(bin_dir)[ST_MODE])[-3:]
            # dir_perm = str(mode)
            temp = int(mode) - 20
            cmd = "chmod " + str(temp) + " " + bin_dir
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Removed write access from group users\n')
            else:
                log_enforce('ERROR enforcing NET_FTP_ETC_PERMS\n' % (cmd_err))
        if ' directory other users have write permission' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            mode = oct(os.stat(bin_dir)[ST_MODE])[-3:]
            # dir_perm = str(mode)
            temp = int(mode) - 2
            cmd = "chmod " + str(temp) + " " + bin_dir
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Removed write access from other users\n')
            else:
                log_enforce('ERROR enforcing NET_FTP_ETC_PERMS\n' % (cmd_err))

        if 'directory files do not have permissions' in entry:
            dir = entry.split(' ')
            bin_dir = dir[0]
            drs = []
            drs.append(bin_dir)
            # permfailed = false
            files = list_files_in(drs, cond='os.access(%, os.F_OK)')
            if (files):
                for file in files:
                    cmd = "chmod " + str(agreedperms) + " " + file
                    cmd_exec = execute_command(cmd)
                    if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                        log_enforce('Enforced the permissions of %s file to %s\n'%(file, agreedperms))
                    else:
                        log_enforce('ERROR enforcing the permission\n' % (cmd_err))

        if 'file does not have the following password entries as null' in entry:
            dir = entry.split(' ')
            etc_passwd = dir[0]
            search_file_replace_field(target=etc_passwd,
                                      fieldno=2,
                                      agreedvalue="",
                                      delim=':', commentchr=None)
            log_enforce('DONE\n')


    log_enforce('\nDONE\n')


#IZ.1.5.9.24.1.1
def SERVICE_STOP_VSFTPD(agreedparams = 'deinstall'):
    '''
        - Ensure vsftpd is de installed or disabled.
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the status for vsftpd' in entry:
            log_enforce('Unable to check the status for vsftpd\n')
        elif 'VSFTPD installed' in entry:
            cmd = 'rpm -e vsftpd'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce("Could not uninstall vsftpd\n")
            if cmd_exec['cmd_ret'] == 0:
                log_enforce("VSFTPD uninstalled successfully\n")
        elif 'VSFTPD enabled' in entry:
            cmd = 'systemctl stop vsftpd'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce("Could not stop vsftpd\n")
            if cmd_exec['cmd_ret'] == 0:
                log_enforce("VSFTPD stopped successfully\n")
            cmd = 'systemctl disable vsftpd'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce("Could not disable vsftpd\n")
            if cmd_exec['cmd_ret'] == 0:
                log_enforce("VSFTPD disabled successfully\n")

    log_enforce('Done\n')


#IZ.1.5.9.25
def SERVICE_STOP_NFS(agreedparams = 'deinstall'):
    '''
        - Ensure nfs is de installed or disabled.
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the status for nfs' in entry:
            log_enforce('Unable to check the status for nfs\n')
        elif 'NFS installed' in entry:
            cmd = 'yum remove nfs* -y'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce("Could not uninstall nfs\n")
            if cmd_exec['cmd_ret'] == 0:
                log_enforce("NFS uninstalled successfully\n")
        elif 'NFS enabled' in entry:
            cmd = 'systemctl stop nfs'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce("Could not stop nfs\n")
            if cmd_exec['cmd_ret'] == 0:
                log_enforce("NFS stopped successfully\n")
            cmd = 'systemctl disable nfs'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce("Could not disable nfs\n")
            if cmd_exec['cmd_ret'] == 0:
                log_enforce("NFS disabled successfully\n")

    log_enforce('Done\n')



# IZ.1.5.9.24.1.2
def  OSR_VSFTPD(osrnames= ['/etc/vsftpd/vsftpd.conf', '/etc/vsftpd/user_list'],  agreedperms='600'):
    '''
        - Ensure VSFTPD configuration files have permissions 600
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        dir = entry.split(' ')
        filename = dir[0]
        if 'file does not have permission' in entry:
            cmd = "chmod " + str(agreedperms) + " " + filename
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Enforced the permissions of %s file to %s\n' % (filename, agreedperms))
            else:
                log_enforce('ERROR enforcing the permission\n' % (cmd_err))


    log_enforce('Done\n')


# IZ.1.5.9.26 / IZ.1.5.9.27
def NET_DISABLE_TIME(directives=['time-dgram: off', 'time-stream: off']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'Both directives MISSING' in entry:
            for directive in directives:
                flag = directive.split()[0]
                cmd = "chkconfig " + flag[:-1] + " off"
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(
                        checkname) + ': Adding %s failed \n' % (directive))
                else:
                    log_enforce('%s is added successfully\n' % (directive))

        elif 'Only single directive' in entry:
            flag_present = entry.split()[4][2:]
            for directive in directives:
                if flag_present not in directive:
                    flag_absent = directive.split()[0]
                    directive_absent = directive

            cmd = "chkconfig " + flag_absent[:-1] + " off"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                    checkname) + ': Adding %s failed \n' % (directive_absent))
            else:
                log_enforce('%s is added successfully\n' % (directive_absent))

    log_enforce('\nDONE\n')


# IZ.1.8.4.2.2
def OSR_ETC_GSHADOW(osrname='/etc/gshadow',
                    agreedperms='0000',
                    agreeduser='root',
                    agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'File MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s is not found\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')


# IZ.1.8.4.2.3
def OSR_ETC_SHADOW1(osrname='/etc/shadow-',
                    agreedperms='0000',
                    agreeduser='root',
                    agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'File MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s is not found\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')


# IZ.1.8.4.2.4
def OSR_ETC_GSHADOW1(osrname='/etc/gshadow-',
                     agreedperms='0000',
                     agreeduser='root',
                     agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'File MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s is not found\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')


# IZ.1.8.4.3.1
def OSR_CRONTAB(osrname='/etc/crontab',
                agreedperms='0600',
                agreeduser='root',
                agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'File MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s is not found\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')


# IZ.1.8.4.3.2
def OSR_CRON_HOURLY(osrname='/etc/cron.hourly',
                    agreedperms='0700',
                    agreeduser='root',
                    agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'dir MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Dir %s not found\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')

# IZ.1.5.9.24.4.1
def VSFTPD_SERVICE_CONFIGURATION_FOR_SECURE_FTP_PURCHASED_CERTIFICATES(
        osrname=["/etc/vsftpd/vsftpd.conf", "/etc/pki/tls/certs/vsftpd.crt", "/etc/pki/tls/private/vsftpd.key"],
        searchstrings=['ssl_enable=YES', 'allow_anon_ssl=YES', 'force_local_data_ssl=YES', 'force_local_logins_ssl=YES',
                       'ssl_sslv2=NO', 'ssl_sslv3=NO', 'ssl_tlsv1=NO', 'ssl_tlsv1_1=NO', 'ssl_tlsv1_2=YES',
                       'rsa_cert_file=/etc/pki/tls/certs/vsftpd.crt',
                       'rsa_private_key_file=/etc/pki/tls/private/vsftpd.key'], agreedvalue="yes", agreedperms='0600',
        mode='max', category='all', mustexist=True, agreeduser='root', directives=None):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    try:
        for (dr, probs) in fails.items():
            for prob in probs:
                if 'File missing' in prob:
                    log_enforce(format_nicely(checkname) +
                                ': File %s is missing\n' % (dr))
                if 'OSR permissions for file are not as expected' in prob:
                    os.chmod(dr, int(agreedperms, 8))
                    log_enforce(format_nicely(
                        checkname) + ': Permissions for file %s is not as expected. Changing permissions to %s\n' % (
                                    dr, agreedperms))

                if 'Not all required lines are present in file' in prob:
                    log_enforce(format_nicely(checkname) + ": File %s doesn't contain required lines\n" % (dr))

    except Exception as e:
        log_enforce(format_nicely(checkname) +
                    ": Failed to enforce remedies for file '{}' with error: '{}'".format(osrname, e))
        log_enforce("\nFAILED\n")

    log_enforce("\nDONE\n")

# IZ.1.5.9.24.4.2
def VSFTPD_SERVICE_CONFIGURATION_FOR_SECURE_FTP_SELFSIGNED_CERTIFICATES(
        osrname=["/etc/vsftpd/vsftpd.conf", "/etc/vsftpd/vsftpd.pem"],
        searchstrings=['ssl_enable=YES', 'allow_anon_ssl=YES', 'force_local_data_ssl=YES', 'force_local_logins_ssl=YES',
                       'ssl_sslv2=NO', 'ssl_sslv3=NO', 'ssl_tlsv1=NO', 'ssl_tlsv1_1=NO', 'ssl_tlsv1_2=YES',
                       'rsa_cert_file=/etc/vsftpd/vsftpd.pem'], agreedvalue="yes", agreedperms='0600', mode='max',
        category='all', mustexist=True, agreeduser='root', directives=None):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    try:
        for (dr, probs) in fails.items():
            for prob in probs:
                if 'File missing' in prob:
                    log_enforce(format_nicely(checkname) +
                                ': File %s is missing\n' % (dr))
                if 'OSR permissions for file are not as expected' in prob:
                    os.chmod(dr, int(agreedperms, 8))
                    log_enforce(format_nicely(
                        checkname) + ': Permissions for file %s is not as expected. Changing permissions to %s\n' % (
                                    dr, agreedperms))

                if 'Not all required lines are present in file' in prob:
                    log_enforce(format_nicely(checkname) + ": File %s doesn't contain required lines\n" % (dr))

    except Exception as e:
        log_enforce(format_nicely(checkname) +
                    ": Failed to enforce remedies for file '{}' with error: '{}'".format(osrname, e))
        log_enforce("\nFAILED\n")

    log_enforce("\nDONE\n")


# IZ.1.5.9.29
def NET_AVAHI_DISABLE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable avahi-daemon"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s. Please disable manually  \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service avahi was not disabled. Please disable manually \n')
            else:
                log_enforce('Service avahi was disabled successfully \n')

    log_enforce('\nDONE\n')


# IZ.1.5.9.30
def NET_LDAP_DISABLE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable slapd"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s. Please disable manually \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service slapd was not disabled. Please disable manually  \n')
            else:
                log_enforce('Service slapd was disabled successfully \n')

    log_enforce('\nDONE\n')


# IZ.1.5.9.31
def NET_IMAP_POP3_DISABLE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable dovecot"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s. Please disable manually \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service dovecot was not disabled. Please disable manually  \n')
            else:
                log_enforce('Service dovecot was disabled successfully \n')

    log_enforce('\nDONE\n')


# IZ.1.5.9.32
def NET_HTTP_PROXY_DISABLE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable squid"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s. Please disable manually \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service squid was not disabled. Please disable manually  \n')
            else:
                log_enforce('Service squid was disabled successfully \n')

    log_enforce('\nDONE\n')


# IZ.1.5.9.33
def NET_TALK_DISABLE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            cmd = "systemctl disable ntalk"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s. Please disable manually \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Service ntalk was not disabled. Please disable manually  \n')
            else:
                log_enforce('Service ntalk was disabled successfully \n')

    log_enforce('\nDONE\n')


# IZ.1.8.4.3.3
def OSR_CRON_DAILY(osrname='/etc/cron.daily',
                  agreedperms='0700',
                  agreeduser='root',
                  agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'dir MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Dir %s are not found. Please do manually\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')


# IZ.1.8.4.3.4
def OSR_CRON_WEEKLY(osrname='/etc/cron.weekly',
                  agreedperms='0700',
                  agreeduser='root',
                  agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'dir MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Dir %s are not found. Please do manually\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')


# IZ.1.8.4.3.5
def OSR_CRON_MONTHLY(osrname='/etc/cron.monthly',
                  agreedperms='0700',
                  agreeduser='root',
                  agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'dir MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Dir %s are not found. Please do manually\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')


# IZ.1.8.4.3.6
def OSR_CRON_D(osrname='/etc/cron.d',
                  agreedperms='0700',
                  agreeduser='root',
                  agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'dir MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Dir %s are not found. Please do manually\n' % (osrname))
        if 'OSR owned not by user' in entry:
            shutil.chown(osrname, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osrname, agreeduser))
        if 'OSR owned not by group' in entry:
            shutil.chown(osrname, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osrname, agreedgroup))
        if 'OSR permissions not as expected' in entry:
            os.chmod(osrname, int(agreedperms, 8))
            log_enforce('Permissions of %s changed to %s\n' %(osrname, agreedperms))

    log_enforce('\nDONE\n')


# IZ.1.8.12.8
def OSR_GPGCHECK(osrnames=['/etc/yum.conf', '/etc/yum.repos.d/*'],
                 directive='gpgcheck=1'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'gpgcheck is not set' in entry:
            osrname = entry.split()[2]
            searchstring = directive.split('=')[0] + "=0"
            update_line = search_file_replace_line(
                osrname, searchstring, directive, commentchr='#', uniq_occur=1)
            if update_line != 1:
                log_enforce(format_nicely(checkname) +
                            ': line %s not updated in file %s. Please do manually\n' % (directive, osrname))
            else:
                log_enforce('line %s is successfully updated\n' % (directive))

    log_enforce('\nDONE\n')


def DISABLE_IPV6():

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    conf_file = "/etc/sysctl.d/ipv6.conf"
    lines = "net.ipv6.conf.all.disable_ipv6 = 1" + '\n' + "net.ipv6.conf.default.disable_ipv6 = 1" + '\n'
    commands = "sysctl -p /etc/sysctl.d/ipv6.conf;cp /boot/initramfs-$(uname -r).img /boot/initramfs-$(uname -r).bak.$(date +%m-%d-%H%M%S).img;dracut -f -v;cp -p /etc/hosts /etc/hosts.disableipv6;sed -i 's/^[[:space:]]*::/#::/' /etc/hosts"

    if not os.path.isfile(conf_file):
        open(conf_file, 'a').close()
    writelines_infile(target=conf_file,lines=[lines],mode='rewrite')
    os.system(commands)

    log_enforce('Successfully disbled IPv6')
    log_enforce('\nDONE\n')

# IZ.1.5.12.4
def NET_DISABLE_SENDMAIL():
    '''
        Enforce sendmail service not enabled
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    service_name = "sendmail"
    command = "chkconfig sendmail off"

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": Successfully disabled service '{}'".format(service_name))
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to disable service, Please disable manually. '{}' with error: {}".format(
                        service_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")
    log_enforce("\nDONE\n")


# IZ.1.2.7.6
def AUDIT_NTPD_NOEXCESSPRIV():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Ntpd or chronyd is not active' in entry:
            log_enforce(format_nicely(checkname) +
                        'Ntpd or chronyd is not active, manually ensure either of it is active')

        if "Ntpd task is not running as ntp id" in entry:
            log_enforce(format_nicely(checkname) +
                        'Manually ensure ntpd has least privilege configuration, ' \
                        'as it is not running with ntp id\n')

    log_enforce('\nDONE\n')

#IZ.1.4.2.2
def AUDIT_ROOT_GID(osrname = '/etc/passwd'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the GID for root user' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Could not check the GID of root user, manually ensure it is 0')

        if "Root GID is not 0" in entry:
            cmd = 'usermod -g 0 root'
            cmd_exec = execute_command(cmd)

            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Changed the root GID to 0\n')
            else:
                log_enforce('ERROR enforcing AUDIT_ROOT_GID, manually ensure that root GID is 0\n' % (cmd_err))

    log_enforce('\nDONE\n')


#AD.1.3.0
def ANTIVIRUS_STATUS():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Trendmicro is not installed' in entry:
            log_enforce(format_nicely(checkname) +
                        'Trendmicro is not installed, manually ensure it is installed and running')

        if "Trendmicro service is not running" in entry:

            log_enforce(format_nicely(checkname) +
                        'Trendmicro service is not running, manually ensure it is running\n')

    log_enforce('\nDONE\n')

# IZ.1.4.3.1.1
def SELINUX_STATUS():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the libselinux installation status' in entry:
            log_enforce(format_nicely(checkname) +
                        'Could not check the libselinux installation status, manually ensure it is installed')

        if "SElinux is not installed" in entry:
            cmd = 'yum install libselinux'
            cmd_exec = execute_command(cmd)

            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Installed SELinux\n')
            else:
                log_enforce('ERROR enforcing the techspec SELinux_STATUS\n' % (cmd_err))

    log_enforce('\nDONE\n')

# IZ.1.4.3.1.2
def SELINUX_CONFIG_MODE(osrname='/etc/selinux/config', agreedvalue='enforcing'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    val = "SELINUX="+agreedvalue+"\n"
    for line in fileinput.input([osrname], inplace=True):
        if line.strip().startswith('SELINUX='):
            line = val
        sys.stdout.write(line)

    log_enforce('The config file has been updated with the SELinux mode provided as an input. These changes would come into effect after the next reboot\n')

    log_enforce('DONE\n')

# IZ.1.4.3.1.4
def SELINUX_TYPE(osrname='/etc/selinux/config', agreedvalue='targeted'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    val = "SELINUXTYPE="+agreedvalue+"\n"
    for line in fileinput.input([osrname], inplace=True):
        if line.strip().startswith('SELINUXTYPE='):
            line = val
        sys.stdout.write(line)

    log_enforce('The config file has been updated with the SELinux mode provided as an input. These changes would come into effect after the next reboot\n')

    log_enforce('DONE\n')

# IZ.1.4.3.3.1
def AUDITD_SERVICE():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    cmd = 'systemctl enable auditd'
    cmd_exec = execute_command(cmd)
    if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
        log_enforce('Enabled the auditd service\n')
    else:
        log_enforce('ERROR enforcing AUDITD_SERVICE, please enable it manually\n' % (cmd_err))


    log_enforce('DONE\n')

#IZ.1.5.3.1
def OSR_NFS(osrname='/etc/exports',
            agreedperms='0644',
            mode='max',
            category='all',
            mustexist=True,
            agreeduser='root'):

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    # e.g: fails = []  or {
    #                       '/home/gigi' : [
    #                          {   'problem': 'ownership',
    #                              'rightful_owner': user_name,
    #                              'wrong_owner': owner_name
    #                          },
    #                          {    'problem': 'permissions',
    #                               'perms': permfailed
    #                           }
    #                        ]
    #                      }

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for (dr, probs) in fails.iteritems():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername=agreeduser)
                log_enforce('Created the file\n')
            if prob['problem'] == 'ownership':
                os.chown(dr, name2uid(prob['rightful_owner']), -1)
                log_enforce('Changed the owner successfully\n')
            if prob['problem'] == 'permissions':
                # os.chmod(dr, int(agreedperms, 8))
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                # print rightperm
                os.chmod(dr, int(rightperm, 8))
                log_enforce('Changed the permissions successfully\n')

    log_enforce('DONE\n')

# IZ.1.5.1.1
def WUFTPD_STATUS():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the wu-ftpd installation status' in entry:
            log_enforce(format_nicely(checkname) +
                        'Could not check the wu-ftpd installation status, manually ensure it is not active')

        if "Wu-ftpd is installed" in entry:
            cmd = 'yum remove wu-ftpd'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Stopped the ftp server\n')
            else:
                log_enforce('ERROR enforcing WUFTPD_STATUS, manually ensure it is not active\n' % (cmd_err))

    log_enforce('\nDONE\n')


# IZ.1.9.1.2
def AUTH_UMASK_BASHRC(target='/etc/bashrc',
                      directives=['if [ $UID -gt 199 ] && [ "`/usr/bin/id -gn`" = "`/usr/bin/id -un`" ]; then',
                                  'for i in /etc/profile.d/*.sh'], commentchr='#'):
    umask_block_content = []
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if 'File missing' in probs:
                log_enforce(format_nicely(checkname) + ": %s File missing \n" % (target))

            if "Invocation of ('/etc/profile.d/IBMsinit.sh') script" in probs:
                log_enforce(format_nicely(
                    checkname) + "Setting umask before invocation of ('/etc/profile.d/IBMsinit.sh') script in %s file.\n" % (
                                target))
                umask_script_line_number = fails['umask_script_line_number']
                profile_script_line_number = fails['profile_script_line_number']
                validline_in_file = fails['validline_in_file']
                # Copy umask code to list and delete same line from file
                for i in range((umask_script_line_number - 1), (umask_script_line_number + 4)):
                    umask_block_content.append(validline_in_file[umask_script_line_number])
                    del validline_in_file[umask_script_line_number]

                    # Copy umask block to file before script invocation block
                for item in umask_block_content:
                    validline_in_file.insert(profile_script_line_number, item)
                    profile_script_line_number = profile_script_line_number + 1

                with open(target, "w") as f:
                    for line in validline_in_file:
                        f.write(line)
    log_enforce('DONE\n')


# IZ.1.8.12.6
def OSR_IBMSINIT_SH(osrname='/etc/profile.d/IBMsinit.sh',
                    agreedperms='0755',
                    mode='exact',
                    category='others'):

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    othersperms = "false"
    print(fails)
    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                log_enforce(format_nicely(checkname) +
                            ': File %s not found,Please create file manually\n' % (dr))
            if prob['problem'] == 'others permissions':
                othersperms = "true"
                crtperm = prob['perms']
                print("Current perms: ", crtperm,"\n Agreed permissions: ", agreedperms)
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('File %s others permissions updated successfully. Oringinal_permission=%s & updated_permissions=%s.\n' %(dr,crtperm,agreedperms))
            if prob['problem'] == 'group permissions':
                category = 'group'
                if othersperms == "true":
                    crtperm = rightperm
                else:
                    crtperm = prob['perms']
                refperm = prob['right_perms']
                print("Current perms: ", crtperm,"\n Agreed permissions: ",refperm)
                rightperm = enforce_perm(refperm=refperm,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('File %s group permissions updated successfully.Oringinal_permission=%s & updated_permissions=%s.\n' %(dr,crtperm,refperm))

    log_enforce('DONE\n')


# IZ.1.8.12.7
def OSR_IBMSINIT_CSH(osrname='/etc/profile.d/IBMsinit.csh',
                     agreedperms='0755',
                     mode='exact',
                     category='others'):

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    othersperms = "false"
    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                log_enforce(format_nicely(checkname) +
                            ': File %s not found,Please create file manually\n' % (dr))
            if prob['problem'] == 'others permissions':
                othersperms = "true"
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('File %s others permissions updated successfully\n' %(dr))
            if prob['problem'] == 'group permissions':
                category = 'group'
                if othersperms == "true":
                    crtperm = rightperm
                else:
                    crtperm = prob['perms']
                refperm = prob['right_perms']
                rightperm = enforce_perm(refperm=refperm,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('File %s group permissions updated successfully\n' %(dr))

    log_enforce('DONE\n')


# AD.1.8.15.3
def OSR_CRONTAB_GROUP(osrname='/etc/crontab',
                      agreedperms='0744',
                      mode='max',
                      category='all'):

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")


    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'permissions':
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('Permissions of %s changed to %s\n' %(dr, rightperm))

    log_enforce('DONE\n')


# AD.1.1.12.0
def AUTH_PASS_NO_EXPIRY(maxage='90'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'password expiry must be set' in entry:

            username = entry.split()[1]
            osrname = '/etc/shadow'
            fieldno = 5
            except_regex = r'^(?!(%s)).*' % username

            if fails:
                update_field = search_file_replace_field(target=osrname,
                                          fieldno=fieldno,
                                          agreedvalue=maxage,
                                          delim=':', commentchr=None,
                                          except_regex=except_regex)
                if update_field != 1:
                    log_enforce(format_nicely(
                        checkname) + ': Password expiry not set for user %s, Please set manully. \n' % (username))
                else:
                    log_enforce('Password expiry set successfully for user %s\n' % (username))
                cmd = "sudo passwd -e " + username
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s, Please do manully. \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(
                                    checkname) + ':expire password failed for user %s, Please do manully.\n' % (username) )
                else:
                    log_enforce('expire password done successfully for user %s\n' % (username))



    log_enforce('\nDONE\n')


#IZ.1.5.9.10
def NET_REMOVE_FINGER():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'Finger is installed on the system' in entry:
            cmd = "yum remove finger -y"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Unable to remove the finger service, please remove the service manually \n')
            else:
                log_enforce('Finger service was removed successfully\n')

    log_enforce('\nDONE\n')

#IZ.1.5.9.11
def NET_DISABLE_SPRAYD():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            log_enforce(format_nicely(checkname) +
                        ': sprayd is present in rpc, please disable manually\n')

    log_enforce('\nDONE\n')

#IZ.1.5.9.12
def NET_DISABLE_PCNFSD():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'need to be disabled' in entry:
            log_enforce(format_nicely(checkname) +
                        ': pcnsfd is present in rpc, please disable manually\n')

    log_enforce('\nDONE\n')

#IZ.1.5.9.14
def NET_DISABLE_RWHOD():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Unable to check the rwhod service status' in entry:
            log_enforce(format_nicely(checkname) +
                        'Could not check the rwhod service status, manually ensure it is disabled')

        if "RWHOD service is enabled" in entry:
            cmd = 'systemctl stop rwhod'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Stopped the Rwhod service\n')
            else:
                log_enforce('ERROR enforcing the techspec NET_DISABLE_RWHOD\n' % (cmd_err))

    log_enforce('\nDONE\n')


#IZ.1.5.9.18.1
def NET_DISABLE_SNMPD():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Error checking the SNMPD service status' in entry:
            log_enforce(format_nicely(checkname) +
                        'Could not check the SNMPD service status, manually ensure it is disabled')

        if "SNMPD service is enabled" in entry:
            cmd = 'systemctl disable snmpd'
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                log_enforce('Disabled the SNMPD service\n')
            else:
                log_enforce('ERROR enforcing the techspec NET_DISABLE_SNMPD, manually ensure it is disabled\n' % (cmd_err))

    log_enforce('\nDONE\n')

# IZ.1.5.1.6
def NET_FTP_OTHER_PERMS(osrnames=['/var/ftp', '/etc/vsftpd/vsftpd.conf'],
                        directives=['anonymous_enable=YES', 'anon_root = *']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if 'Unable to check the status for vsftpd' in probs:
                log_enforce(format_nicely(checkname) + "Unable to check the status for vsftpd. Please check manually \n")
            if ("File missing: %s" % (osrnames[1])) in probs:
                log_enforce(format_nicely(checkname) + "File missing: %s \n" % (osrnames[1]))

        # Enforce directory permissions
        if "dir" == dr:
            for dr in probs:
                mode = oct(os.stat(dr)[ST_MODE])[-3:]
                dir_perm = int(mode) / 10
                # Provide only read /execute access to directories
                agreedperms = (dir_perm * 10) + 5
                cmd = "chmod " + str(agreedperms) + " " + dr
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Enforced the permissions of %s directory to read/execute\n' % (dr))
                else:
                    log_enforce('ERROR enforcing the permission. Please check manually \n' % (cmd_exec['cmd_err']))

        # Enforce file permissions
        if "file" == dr:
            for dr in probs:
                mode = oct(os.stat(dr)[ST_MODE])[-3:]
                dir_perm = int(mode) / 10
                # Provide only read access to file
                agreedperms = (dir_perm * 10) + 4
                cmd = "chmod " + str(agreedperms) + " " + dr
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Enforced the permissions of %s file to read only \n' % (dr))
                else:
                    log_enforce('ERROR enforcing the permission. Please check manually \n' % (cmd_exec['cmd_err']))
    log_enforce('\nDONE\n')

# AD.1.5.1.7
def NET_FTP_DIR_CLASSIFIED_DATA(osrnames=['/var/ftp', '/etc/vsftpd/vsftpd.conf'],
                                directives=['anonymous_enable=YES', 'anon_root = *'],
                                directories_containing_classified_data=[]):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if 'Unable to check the status for vsftpd' in probs:
                log_enforce(format_nicely(checkname) + "Unable to check the status for vsftpd. Please check manually \n")
            if ("File missing: %s" % (osrnames[1])) in probs:
                log_enforce(format_nicely(checkname) + "File missing: %s \n" % (osrnames[1]))

        # Enforce directory permissions
        if "dir" == dr:
            for dr in probs:
                mode = oct(os.stat(dr)[ST_MODE])[-3:]
                # Provide only read /execute access to directories
                agreedperms = "o-r"
                cmd = "chmod " + str(agreedperms) + " " + dr
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Enforced the permissions of %s directory to remove read access\n' % (dr))
                else:
                    log_enforce('ERROR enforcing the permission. Please check manually \n' % (cmd_exec['cmd_err']))

    log_enforce('\nDONE\n')


# IZ.1.1.4.7
def AUTH_PAM_ORDER(osrnames=['/etc/pam.d/password-auth', '/etc/pam.d/system-auth'],
                   directives=['password pam_pwquality.so',
                               'password pam_pwhistory.so',
                               'password pam_unix.so',
                               'password pam_deny.so']):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for osrname in osrnames:
        if 'FILE_NOT_FOUND' in fails.keys():
            log_enforce(format_nicely(checkname) +
                        ": File %s not found.\n" % (osrname))

        if osrname in fails.keys():
            entry = fails[osrname]
            length = len(entry)
            line_to_be_moved = {}
            ordered =  False

            while not ordered:
                for i in range(len(entry)-1):
                    position_i = list(entry.values())[i]
                    position_j = list(entry.values())[i+1]
                    if position_i > position_j:
                        line_to_be_moved[list(entry.keys())[i+1]] = list(entry.keys())[i]
                        entry[list(entry.keys())[i+1]] = list(entry.values())[i] + 1
                positional_array =   list(entry.values())
                if positional_array == sorted(positional_array):
                    ordered = True

            for key, value in line_to_be_moved.items():
                result_for_deletion = lookline_in_file(afile=osrname, thevalues=key, commentchr='#', case="sensitive")
                if result_for_deletion:
                    for line in result_for_deletion:
                        delete_line = deleteline_infile(osrname, line)
                        if delete_line != 1:
                            log_enforce(format_nicely(checkname) +
                                        ': line %s not deleted in file %s\n' % (line, osrname))
                        else:
                            log_enforce('line %s is successfully deleted in file %s\n' % (line, osrname))

                        result_for_insert = lookline_in_file(afile=osrname, thevalues=value, commentchr='#', case="sensitive")
                        if result_for_insert:
                            for ln in result_for_insert:
                                add_lines = insertlines_infile_after_line(target=osrname, lines=line, searchline=ln)
                                if add_lines != 1:
                                    log_enforce(format_nicely(
                                                checkname) + ': line %s not added to file %s\n' % (line, osrname))
                                else:
                                    log_enforce('line %s is successfully added in file %s\n' %(line, osrname))
    log_enforce('\nDONE\n')


# IZ.1.1.13.3

def AUTH_FTP_RESTRICT(osrname='/etc/vsftpd/ftpusers'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s are not found\n' % (entry.split()[0]))
        if 'User MISSING' in entry:
            username = entry.split()[0]
            add_line = writelines_infile(target=osrname,
                                         lines=username + "\n",
                                         mode='append')
            if add_line != 1:
                log_enforce(format_nicely(
                    checkname) + ': line %s not added to file %s\n' % (username, osrname))
            else:
                log_enforce('line %s is successfully added\n' %
                            (username))

    log_enforce('\nDONE\n')


# IZ.1.4.3.1.3
def SYS_SELINUX_DOMAIN(domain_name='httpd_t',
                       agreedvalue='enforcing'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'needs to be in permissive state' in entry:
            cmd = "semanage permissive -a " + domain_name
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Failed to add domain %s to permissive state\n' % (domain_name))
            else:
                log_enforce('Domain %s added to permissive state successfully \n' % (domain_name))
        if 'needs to be in enforcing state' in entry:
            cmd = "semanage permissive -d " + domain_name
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) +
                            ': Failed to add domain %s to enforcing state\n' % (domain_name))
            else:
                log_enforce('Domain %s added to enforcing state successfully \n' % (domain_name))

    log_enforce('\nDONE\n')


# IZ.1.8.14.3
def OSR_CRONROOT_GROUP(osrname='/var/spool/cron/root',
                       agreedperms='0755',
                       mode='max',
                       category='group',
                       mustexist=False):

    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for (dr, probs) in fails.items():
        for prob in probs:
            if prob['problem'] == 'missing':
                create_osr(osr=dr, res_type='file',
                           perms=agreedperms, ownername='root')
                log_enforce('File %s created successfully\n' % (dr))
            if prob['problem'] == 'permissions':
                crtperm = prob['perms']
                rightperm = enforce_perm(refperm=agreedperms,
                                         crtperm=crtperm,
                                         mode=mode,
                                         category=category)
                os.chmod(dr, int(rightperm, 8))
                log_enforce('Enforced the permissions of %s file to %s\n'%(dr, rightperm))

    log_enforce('DONE\n')


# IZ.1.8.13.1.2
def OSR_UID_GID(agreeduser='root',
                agreedgroup='root'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'FS object MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': File %s is not found\n' % (entry.split()[0]))
        if 'not owned by previledged user' in entry:
            osr = entry.split()[0]
            shutil.chown(osr, user = agreeduser)
            log_enforce('Owner of %s changed to user %s\n' %(osr, agreeduser))
        if 'not owned by previledged group' in entry:
            osr = entry.split()[0]
            shutil.chown(osr, group = agreedgroup)
            log_enforce('Owner of %s changed to group %s\n' %(osr, agreedgroup))

    log_enforce('\nDONE\n')


# IZ.1.5.9.20.4)

def NET_IP_FORWARD(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directive = "net.ipv4.ip_forward = 0"):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Error executing command' in entry:
            log_enforce('Error executing the sysctl command, please ensure IP forwarding is disabled\n')
        if 'Error checking the contents of configuration files' in entry:
            log_enforce('Error checking the contents of configuration files, please ensure IP forwarding is disabled\n')
        if 'Directive missing' in entry:
            directives = []
            if directive not in directives:
                directives.append(directive)
            if 'net.ipv4.route.flush=1' not in directives:
                directives.append('net.ipv4.route.flush=1')
            writelines_infile(target=osrnames[0], lines=directive + "\n", mode='append')
            log_enforce('Successfully added the line %s in file %s\n' %(directive, osrnames[0]))
            for directive in directives:
                value = ''.join(directive.split())
                cmd = "sysctl -w " + value
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Successfully set the active kernel parameter\n')
                else:
                    log_enforce('Error enforcing NET_IP_FORWARD %s\n' % (cmd_err))

    log_enforce('\nDONE\n')


# IZ.1.5.9.20.5

def NET_SOURCE_ROUTE(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                    directives = ['net.ipv4.conf.all.accept_source_route = 0','net.ipv4.conf.default.accept_source_route = 0']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Error executing command' in entry:
            log_enforce('Error executing the sysctl command, please ensure source route disabled\n')
        if 'Error checking the contents of configuration files' in entry:
            log_enforce('Error checking the contents of configuration files, please ensure source route  is disabled\n')
        if 'Directive missing' in entry:
            for directive in directives:
                linefound = lookline_in_file(afile=osrnames[0], thevalues=directive)
                if(not linefound and directive != 'net.ipv4.route.flush=1'):
                    writelines_infile(target=osrnames[0], lines=directive + "\n", mode='append')
                    log_enforce('Successfully added the line %s in file %s\n' %(directive, osrnames[0]))
            if 'net.ipv4.route.flush=1' not in directives:
                directives.append('net.ipv4.route.flush=1')
            for directive in directives:
                directive = ''.join(directive.split())
                cmd = "sysctl -w " + directive
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Successfully set the active kernel parameter\n\n')
                else:
                    log_enforce('Error enforcing NET_SOURCE_ROUTE %s\n' % (cmd_err))

    log_enforce('\nDONE\n')


# IZ.1.5.9.20.6

def NET_SECURE_ICMP_REDIRECTS(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directives = ['net.ipv4.conf.all.secure_redirects = 0','net.ipv4.conf.default.secure_redirects = 0']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Error executing command' in entry:
            log_enforce('Error executing the sysctl command, please ensure secure ICMP redirects are not accepted\n')
        if 'Error checking the contents of configuration files' in entry:
            log_enforce('Error checking the contents of configuration files, please ensure secure ICMP redirects are not accepted\n')
        if 'Directive missing' in entry:
            for directive in directives:
                linefound = lookline_in_file(afile=osrnames[0], thevalues=directive)
                if (not linefound and directive != 'net.ipv4.route.flush=1'):
                    writelines_infile(target=osrnames[0], lines=directive + "\n", mode='append')
                    log_enforce('Successfully added the line %s in file %s\n' % (directive, osrnames[0]))
            if 'net.ipv4.route.flush=1' not in directives:
                directives.append('net.ipv4.route.flush=1')
            for directive in directives:
                directive = ''.join(directive.split())
                cmd = "sysctl -w " + directive
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Successfully set the active kernel parameter\n')
                else:
                    log_enforce('Error enforcing NET_SECURE_ICMP_REDIRECTS %s\n' % (cmd_err))

    log_enforce('\nDONE\n')


#IZ.1.5.9.20.7
def NET_LOG_MARTIANS(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directives = ['net.ipv4.conf.all.log_martians = 1','net.ipv4.conf.default.log_martians = 1']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Error executing command' in entry:
            log_enforce('Error executing the sysctl command, please ensure suspicious packets are logged\n')
        if 'Error checking the contents of configuration files' in entry:
            log_enforce(
                'Error checking the contents of configuration files, please ensure suspicious packets are logged\n')
        if 'Directive missing' in entry:
            for directive in directives:
                linefound = lookline_in_file(afile=osrnames[0], thevalues=directive)
                if (not linefound and directive != 'net.ipv4.route.flush=1'):
                    writelines_infile(target=osrnames[0], lines=directive + "\n", mode='append')
                    log_enforce('Successfully added the line %s in file %s\n' % (directive, osrnames[0]))
            if 'net.ipv4.route.flush=1' not in directives:
                directives.append('net.ipv4.route.flush=1')
            for directive in directives:
                directive = ''.join(directive.split())
                cmd = "sysctl -w " + directive
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Successfully set the active kernel parameter\n')
                else:
                    log_enforce('Error enforcing NET_LOG_MARTIANS %s\n' % (cmd_err))

    log_enforce('\nDONE\n')


#IZ.1.5.9.20.8
def NET_ICMP_BOGUS_RESPONSES(osrnames = ['/etc/sysctl.conf', '/etc/sysctl.d/'],
                         directive = "net.ipv4.icmp_ignore_bogus_error_responses = 1"):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Error executing command' in entry:
            log_enforce('Error executing the sysctl command, please ensure bogus ICMP responses are ignored\n')
        if 'Error checking the contents of configuration files' in entry:
            log_enforce('Error checking the contents of configuration files, please ensure bogus ICMP responses are ignored\n')
        if 'Directive missing' in entry:
            linefound = lookline_in_file(afile=osrnames[0], thevalues=directive)
            if (not linefound and directive != 'net.ipv4.route.flush=1'):
                writelines_infile(target=osrnames[0], lines=directive + "\n", mode='append')
                log_enforce('Successfully added the line %s in file %s\n' % (directive, osrnames[0]))
            directives = []
            if directive not in directives:
                directives.append(directive)
            if 'net.ipv4.route.flush=1' not in directives:
                directives.append('net.ipv4.route.flush=1')
            for directive in directives:
                directive = ''.join(directive.split())
                cmd = "sysctl -w " + directive
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Successfully set the active kernel parameter\n')
                else:
                    log_enforce('Error enforcing NET_ICMP_BOGUS_RESPONSES %s\n' % (cmd_err))

    log_enforce('\nDONE\n')

# IZ.2.1.3.0
def PASSWORD_ALGO():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))
        if 'sha512 is not being used for password hashing' in entry:
            cmd = "authconfig --passalgo=sha512 --update"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s \n' % (str(cmd_exec['cmd_err'])))
            else:
                log_enforce("Successfully updated the password hashing as sha512")

    log_enforce('\nDONE\n')


# IZ.1.4.6.3
def AUTO_LOGOFF_SH(osrname = '/etc/profile.d/IBMsinit.sh', directives=['TMOUT=21600', 'export TMOUT']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'directive time is not set as expected in /etc/profile.d/IBMsinit.sh' in entry:
            directive = entry.split(' ')
            search_file_replace_line(target=osrname,
                                     regex=directive[0],
                                     newline=directives[0] + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

        if 'directive is not a part of /etc/profile.d/IBMsinit.sh' in entry:
            missing_directive = entry.split(' ')
            #print missing_directive[0]
            if missing_directive[0] == 'export':
              writelines_infile(target=osrname, lines=directives[1] + "\n", mode='append')
              log_enforce("Added the directive %s successfully ...\n" %directives[1])
            else:
              writelines_infile(target=osrname, lines=directives[0] + "\n", mode='append')
              log_enforce("Added the directive %s successfully ...\n" %directives[0])

    log_enforce('\nDONE\n')

# IZ.1.4.6.4
def AUTO_LOGOFF_CSH(osrname='/etc/profile.d/IBMsinit.csh', directive='autologout=360'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'directive time is not set as expected in /etc/profile.d/IBMsinit.csh' in entry:
            directive1 = entry.split(' ')
            search_file_replace_line(target=osrname,
                                     regex=directive1[0],
                                     newline=directive + "\n",
                                     commentchr='#',
                                     uniq_occur=1)

        if 'directive is not a part of /etc/profile.d/IBMsinit.csh' in entry:
            #missing_directive = entry.split(' ')
            #print missing_directive[0]
            writelines_infile(target=osrname, lines=directive + "\n", mode='append')
            log_enforce("Added the directive %s successfully ...\n" %directive)

    log_enforce('\nDONE\n')


#AD.30.0.1.0
def AUTO_LOGOFF(osrnames = ['/root/.bashrc', '/root/.bash_profile'], directive='TMOUT=900'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'directive time is not set as expected in /root/.bashrc' in entry:
            directive1 = entry.split(' ')
            search_file_replace_line(target=osrnames[0],
                                     regex=directive1[0],
                                     newline=directive + "\n",
                                     commentchr='#',
                                     uniq_occur=1)
        if 'directive time is not set as expected in /root/.bash_profile' in entry:
            directive1 = entry.split(' ')
            search_file_replace_line(target=osrnames[1],
                                     regex=directive1[0],
                                     newline=directive + "\n",
                                     commentchr='#',
                                     uniq_occur=1)
        if 'directive is missing from file /root/.bash_profile' in entry:
            #missing_directive = entry.split(' ')
            #print missing_directive[0]
            writelines_infile(target=osrnames[1], lines=directive + "\n", mode='append')
            log_enforce("Added the directive %s successfully ...\n" %directive)

        if 'directive is missing from both files /root/.bashrc and /root/.bash_profile' in entry:
            #missing_directive = entry.split(' ')
            #print missing_directive[0]
            writelines_infile(target=osrnames[1], lines=directive + "\n", mode='append')
            log_enforce("Added the directive %s successfully ...\n" %directive)
    log_enforce('\nDONE\n')


# IZ.1.5.12.4
def NET_MTA_LOCAL_ONLY(osrname = '/etc/postfix/main.cf',
                       directives = ['tcp 0 0 127.0.0.1:25 0.0.0.0:* LISTEN',
                                     'inet_interfaces = loopback-only']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'MTA is listening on non-loopback address' in entry:
            if os.path.isfile(osrname):
                searchstring = directives[1].split()[0]
                result = lookline_in_file(afile=osrname,
                                          thevalues=searchstring,
                                          commentchr='#', case="sensitive")
                if result:
                    lines_to_file = directives[1]
                    searchstring = directives[1].split()[0]

                    update_line = search_file_replace_line(osrname, searchstring,
                                     lines_to_file, commentchr='#', uniq_occur=1)

                    if update_line != 1:
                        log_enforce(format_nicely(checkname) +
                                    ': line %s not updated to file %s, Please check manully\n' % (lines_to_file, osrname))
                    else:
                        log_enforce('line %s is successfully updated\n' %
                                    (lines_to_file))
                else:
                    add_line = writelines_infile(target=osrname,
                                                 lines=directives[1]+"\n",
                                                 mode='append')
                    if add_line != 1:
                        log_enforce(format_nicely(
                            checkname) + ': line %s not added to file, Please check manully\n' % (directives[1], osrname))
                    else:
                        log_enforce('line %s is successfully added\n' %
                                    (directives[1]))

                cmd = "systemctl restart postfix"
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s, Please check manully \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(checkname) +
                                ': Failed to restart the postfix service, Please do manully.\n' )
                else:
                    log_enforce('Postfix service restarted successfully \n')

    log_enforce('\nDONE\n')


# IZ.2.0.1.1
def GMD_BUSINESS_USE(osrnames = ['/etc/dconf/profile/gdm',
                                 '/etc/dconf/db/gdm.d/01-banner-message'],
                     gdm_directives = ['user-db:user','system-db:gdm','file-db:/usr/share/gdm/greeter-dconf-defaults'],
                     banner_directives = ['[org/gnome/login-screen]',
                                          'banner-message-enable=true',
                                           "banner-message-text='Authorized uses only. All activity may be monitored and reported.'"]):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if 'CMD_ERR' in fails.keys():
        log_enforce(format_nicely(checkname) + ': %s \n' % (fails['CMD_ERR']))
    if 'FILE_NOT_FOUND' in fails.keys():
        for osrname in fails['FILE_NOT_FOUND']:
            print(osrname)
            if osrname == osrnames[0]:
                    filename =  'gdm'
                    filepath = '/etc/dconf/profile'
                    directives = gdm_directives
            elif osrname == osrnames[1]:
                    filename =  '01-banner-message'
                    filepath = '/etc/dconf/db/gdm.d/'
                    directives = banner_directives
            # create missing file
            file_create = create_file(filepath, filename)
            if file_create != 1:
                log_enforce(format_nicely(checkname) +
                            ": File %s creation failes.\n" % (osrname) )
            else:
                log_enforce('File %s created successfully\n' % (osrname))
            # add directive lines to file
            for directive in directives:
                lines_to_file = directive
                add_line = writelines_infile(target=osrname,
                                             lines=lines_to_file + "\n",
                                             mode='append')
                if add_line != 1:
                    log_enforce(format_nicely(
                                checkname) + ': line %s not added to file %s, Please check manully\n' % (lines_to_file, osrname))
                else:
                    log_enforce('line %s is successfully added\n' % (lines_to_file))

    if 'MISSING_DIRECTIVES' in fails.keys():
        for directive in fails['MISSING_DIRECTIVES']:
            for gdm_directive in gdm_directives:
                if directive ==  gdm_directive:
                    osrname = osrnames[0]
            for banner_directive in banner_directives:
                if directive ==  banner_directive:
                    osrname =  osrnames[1]
            lines_to_file = directive
            add_line = writelines_infile(target=osrname,
                                         lines=lines_to_file + "\n",
                                         mode='append')
            if add_line != 1:
                log_enforce(format_nicely(
                            checkname) + ': line %s not added to file %s, Please check manully\n' % (lines_to_file, osrname))
            else:
                log_enforce('line %s is successfully added\n' %(lines_to_file))

    cmd = "dconf update"
    cmd_exec = execute_command(cmd, shell=True)
    if cmd_exec['cmd_err']:
        log_enforce(format_nicely(checkname) +
                    ': Error, failed in executing command: %s, Please check manully \n' % (str(cmd_exec['cmd_err'])))
    elif cmd_exec['cmd_ret'] != 0:
        log_enforce(format_nicely(
                        checkname) + ':dconf update failed, Please check manully \n' )
    else:
        log_enforce('dconf update successful\n')

    log_enforce('\nDONE\n')


# IZ.1.5.1.8
def NET_FTP_DIR_PERMS(osrnames=['/var/ftp', '/etc/vsftpd/vsftpd.conf'],
                      directives=['anonymous_enable=YES', 'anon_root = *']):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if 'Unable to check the status for vsftpd' in probs:
                log_enforce(format_nicely(checkname) + "Unable to check the status for vsftpd \n")
            if ("File missing: %s" % (osrnames[1])) in probs:
                log_enforce(format_nicely(checkname) + "File missing: %s \n" % (osrnames[1]))

        # Enforce directory permissions
        if "dir" == dr:
            for dr in probs:
                mode = oct(os.stat(dr)[ST_MODE])[-3:]
                # Remove read access
                agreedperms = int(mode) - 4
                cmd = "chmod " + str(agreedperms) + " " + dr
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce('Enforced the permissions of %s directory to remove read rights\n' % (dr))
                else:
                    log_enforce('ERROR enforcing the permission. Please check manually \n' % (cmd_exec['cmd_err']))
    log_enforce('\nDONE\n')


# IZ.1.5.2.1
def NET_TFTP_OTHER_PERMS(tftp_enabled=True, osrname='/etc/xinetd.d/tftp', permitted_directory='/tmp/tftp'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for (dr, probs) in fails.items():
        if "violations" == dr:
            if 'Unable to find xinetd service' in probs:
                log_enforce(format_nicely(checkname) + "Unable to find xinetd service \n")
            if "File Missing %s" % (osrname) in probs:
                log_enforce(format_nicely(checkname) + "File Missing %s \n" % (osrname))

            if ("Permitted directory '%s' is not specified with the -s parameter to server_args inside file '%s'" % (
            permitted_directory, osrname)) in probs:
                # Create newline to specify permitted directory  to -s parameter to server_args
                prepare_new_line = fails["linefound"].split(" ")
                newline = prepare_new_line[0:(len(prepare_new_line) - 1)]
                newline.append(permitted_directory)
                newline = (" ").join(newline)
                search_file_replace_line(target=osrname, regex='server_args', newline=newline, commentchr="#",
                                         uniq_occur=1, case='insensitive')
                log_enforce(format_nicely(
                    checkname) + "Enforced permitted directory '%s' to be specified with the -s parameter to server_args inside file '%s'\n" % (
                            permitted_directory, osrname))
    log_enforce('\nDONE\n')


# AD.1.8.18.2
def OSR_INITD_RCD_OTHERS(osrnames=["/etc/rc.d/rc0.d", "/etc/rc.d/rc1.d",
                                   "/etc/rc.d/rc2.d", "/etc/rc.d/rc3.d",
                                   "/etc/rc.d/rc4.d", "/etc/rc.d/rc5.d",
                                   "/etc/rc.d/rc6.d", "/etc/rc.d/rcS.d"],
                         agreedperms='0755',
                         mode='max',
                         category='others'):
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for entry in fails:
        dir = entry.split(' ')
        osr = dir[0]
        crtperm = oct(os.stat(osr).st_mode)[-3:]
        rightperm = enforce_perm(refperm=agreedperms,
                                 crtperm=crtperm,
                                 mode=mode,
                                 category=category)
        os.chmod(osr, int(rightperm, 8))
        log_enforce('File %s permissions changed successfully\n' %(osr))
    log_enforce('DONE\n')


# AD.1.8.18.3
def OSR_INITD_RCD_GROUP(osrnames=["/etc/rc.d/rc0.d", "/etc/rc.d/rc1.d",
                                  "/etc/rc.d/rc2.d", "/etc/rc.d/rc3.d",
                                  "/etc/rc.d/rc4.d", "/etc/rc.d/rc5.d",
                                  "/etc/rc.d/rc6.d", "/etc/rc.d/rcS.d"],
                         agreedperms='0755',
                         mode='max',
                         category='group'):
    frame = inspect.currentframe()
    args, _, _, vals = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, vals[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    for entry in fails:
        dir = entry.split(' ')
        osr = dir[0]
        crtperm = oct(os.stat(osr).st_mode)[-3:]
        rightperm = enforce_perm(refperm=agreedperms,
                                 crtperm=crtperm,
                                 mode=mode,
                                 category=category)
        os.chmod(osr, int(rightperm, 8))
        log_enforce('File %s permissions changed successfully\n' %(osr))
    log_enforce('DONE\n')

# IZ.1.8.22.1
def OPT_DIR_FILES_PERMS(osrname='/opt'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if ("Directory missing: %s" % (osrname)) in probs:
                log_enforce(format_nicely(checkname) + "Directory missing: %s \n" % (osrname))

        # Enforce file permissions
        if "files" == dr:
            for dr in probs:
                agreedperms = oct(os.stat(dr)[ST_MODE])[-3:]
                dir_perm = str(agreedperms)
                # Remove read access from permissions of Other
                cmd = "chmod o-w, o-x " + dr
                cmd = "chmod g-x,o-x,o-w,g-w " + dr
                removed_rights = 'read & write'
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce("Enforced the permissions of '%s' file to remove %s rights.\n" % (dr, removed_rights))

                else:
                    log_enforce("ERROR enforcing the permission: %s. Please check manually.\n" % (cmd_exec['cmd_err']))
    log_enforce('\nDONE\n')

# IZ.1.8.22.2
def VAR_DIR_FILES_PERMS(osrname='/var'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if ("Directory missing: %s" % (osrname)) in probs:
                log_enforce(format_nicely(checkname) + "Directory missing: %s \n" % (osrname))

        # Enforce file permissions
        if "files" == dr:
            for dr in probs:
                agreedperms = oct(os.stat(dr)[ST_MODE])[-3:]
                dir_perm = str(agreedperms)
                if (int(dir_perm[2]) == 7):
                    # Remove read access from permissions of Other
                    cmd = "chmod o-r " + dr
                    removed_rights = 'read'

                else:
                    cmd = "chmod o-x " + dr
                    removed_rights = 'execute'
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce("Enforced the permissions of '%s' file to remove %s rights.\n" % (dr, removed_rights))

                else:
                    log_enforce("ERROR enforcing the permission: %s. Please check manually.\n" % (cmd_exec['cmd_err']))
    log_enforce('\nDONE\n')

# IZ.1.8.22.3
def USRLOCAL_DIR_FILES_PERMS(osrname='/usr/local'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if ("Directory missing: %s" % (osrname)) in probs:
                log_enforce(format_nicely(checkname) + "Directory missing: %s \n" % (osrname))

        # Enforce file permissions
        if "files" == dr:
            for dr in probs:
                agreedperms = oct(os.stat(dr)[ST_MODE])[-3:]
                dir_perm = str(agreedperms)
                if (int(dir_perm[2]) == 7):
                    # Remove read access from permissions of Other
                    cmd = "chmod o-r " + dr
                    removed_rights = 'read'

                else:
                    cmd = "chmod o-x " + dr
                    removed_rights = 'execute'
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce("Enforced the permissions of '%s' file to remove %s rights.\n" % (dr, removed_rights))

                else:
                    log_enforce("ERROR enforcing the permission: %s. Please check manually.\n" % (cmd_exec['cmd_err']))
    log_enforce('\nDONE\n')

# IZ.1.8.22.4
def TMP_DIR_FILES_PERMS(osrname='/tmp'):
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if ("Directory missing: %s" % (osrname)) in probs:
                log_enforce(format_nicely(checkname) + "Directory missing: %s \n" % (osrname))

        # Enforce file permissions
        if "files" == dr:
            for dr in probs:
                agreedperms = oct(os.stat(dr)[ST_MODE])[-3:]
                dir_perm = str(agreedperms)
                if (int(dir_perm[2]) == 7):
                    # Remove read access from permissions of Other
                    cmd = "chmod o-r " + dr
                    removed_rights = 'read'

                else:
                    cmd = "chmod o-x " + dr
                    removed_rights = 'execute'
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                    log_enforce("Enforced the permissions of '%s' file to remove %s rights.\n" % (dr, removed_rights))

                else:
                    log_enforce("ERROR enforcing the permission: %s. Please check manually.\n" % (cmd_exec['cmd_err']))
    log_enforce('\nDONE\n')


# IZ.1.8.23.1
def SET_STICKY_BIT_WORLD_WRITEABLE_DIR():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in fails.items():
        if 'violations' == dr:
            if ("Error, failed in executing command:") in probs:
                log_enforce(format_nicely(checkname) + "%s \n" % (probs))

        # Enforce file permissions
        if "world_writeable_directories" == dr:
            for dr in probs:
                if (os.path.isdir(dr)):
                    agreedperms = oct(os.stat(dr)[ST_MODE])[-3:]
                    cmd = "chmod +t " + dr
                    cmd_exec = execute_command(cmd)
                    if cmd_exec['cmd_ret'] == 0 and not cmd_exec['cmd_err']:
                        log_enforce("Enforced the permissions of '%s' directory to set sticky bit to it. \n" % (dr))
                    else:
                        log_enforce(
                            "ERROR enforcing the permission: %s. Please check manually.\n" % (cmd_exec['cmd_err']))
    log_enforce('\nDONE\n')


# IZ.1.5.9.24.2
def DISABLE_ANON_FTPD(osrname='/etc/vsftpd/vsftpd.conf', directive='anonymous_enable=NO'):
    '''
        If ftpd is installed, disable anonymous ftp in $file /etc/vsftpd/vsftpd.conf.
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    succeeded, fails = eval('check.' + checkname)(**args)
    if succeeded:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    # If directive is present but but value is not expected i.e 'NO' then, update value of directive
    if 'Directive is present' in fails:
        searchstring = directive.split('=')[0] + "=YES"
        update_line = search_file_replace_line(osrname, searchstring, directive, commentchr='#', uniq_occur=1)
        if update_line != 1:
            log_enforce(format_nicely(checkname) +
                        ': line %s not updated in file %s. Please do manually\n' % (directive, osrname))

    # If directive is absent, then write line in file
    if 'Directive is absent' in fails:
        writelines_infile(target=osrname, lines=directive, mode='append')

    log_enforce('Diabled anonymous ftp in %s file \n' % (osrname))
    log_enforce('DONE\n')

#AV.1.2.1.2:AV.1.2.1.3
def RSYS_LOGLEVEL_SET_INFO(osrname='', txt='', message=''):


    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)


    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for entry in fails:
        if 'File dont have *info in messages' in entry:
            writelines_infile(target=osrname,
                            lines=[message],
                            mode='append')
                
        if 'File have wrong message' in entry:
            del fails[0]
            for thisline in fails:
                matchline = thisline.strip()
                goodline = "#" + matchline
                search_file_replace_line(target=osrname, regex=matchline,
                                        newline=goodline, commentchr='#',
                                        uniq_occur=None, case='sensitive')
                writelines_infile(target=osrname,
                                lines=[message],
                                mode='append')
                break
        

    log_enforce('DONE\n')

# IZ.C.1.6.1.5
def  MCS_SERVICE():
    '''
        Ensure the MCS Translation Service (mcstrans) is not installed
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    package_name = "mcstrans"
    command = "yum remove -y {}".format(package_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": {} service successfully uninstalled".format(package_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to uninstall package '{}' with error: {}".format(
                        package_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")

# IZ.1.1.7.3
def  PASSWORD_SYS_IDS():
    '''
        Password must not be assigned for these system IDs
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'Password is set for the ID' in entry:
            username = entry.split()[6]
            cmd = "sudo passwd --lock " + username
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) +
                            ': Error, failed in executing command: %s, Please do manully. \n' % (str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(
                              checkname) + ':failed to lock system ID %s, Please do manully.\n' % (username) )
            else:
                log_enforce('System ID %s disabled successfully \n' % (username))

    log_enforce('\nDONE\n')

# IZ.1.5.10.3
def  NIS_SETTINGS():
    '''
        Network information services plus (nis+) settings
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    package_name = "ypbind"
    command = "yum remove -y {}".format(package_name)

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": {} service successfully uninstalled".format(package_name))
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to uninstall package '{}' with error: {}".format(
                        package_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")

# IZ.2.1.2
def  CHECKSUM_FUNCTION_INSTALL():
    '''
        The 'native' encryption/checksum function utilizing at a minimum sha512 and SHA-1 algorithm must be installed
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    package_name = "coreutils"
    command = "yum install -y {}".format(package_name)
    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": {} service successfully installed".format(package_name))
        log_enforce("\nDONE\n")
    else:
        package1_name = "openssl"
        command1 = "yum install -y {}".format(package1_name)
        result1 = execute_command(command1)

        if result1["cmd_ret"] == 0:
            log_enforce(format_nicely(checkname) +
                        ": {} service successfully installed".format(package1_name))
            log_enforce("\nDONE\n")
        else:
            log_enforce(format_nicely(checkname) +
                    ": Failed to install package '{}' with error: {}".format(
                        package1_name,
                        result['cmd_err']
                    ))
        log_enforce("\nFAILED\n")

# IZ.2.1.4.0
def CRYPTO_POLICIES():
    '''
        System-wide Cryptographic policies
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    command = "update-crypto-policies --set DEFAULT"

    result = execute_command(command)

    if result["cmd_ret"] == 0:
        log_enforce(format_nicely(checkname) +
                    ": {} successfully set the crypto-policies to DEFAULT")
        log_enforce("\nDONE\n")
    else:
        log_enforce(format_nicely(checkname) +
                    ": Failed to set crypto policy to any valid value,please set it manually to (DEFAULT, FUTURE, or FIPS )")
        log_enforce("\nFAILED\n")

# IZ.C.1.1.1.1
def DISABLE_CRAMFS_MOUNT():
    '''
        Ensure mounting of cramfs filesystems is disabled
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    osrname = "/etc/modprobe.d/CIS.conf"
    linetoadd = "install cramfs /bin/true"
    result = []
    if os.path.isfile(osrname):
        result = lookline_in_file(afile=osrname,thevalues=linetoadd,)

    if not result:
        writelines_infile(target=osrname,
                          lines=linetoadd + "\n",
                          mode='append')

    log_enforce('DONE\n')

# IZ.C.1.1.1.2
def DISABLE_FREEVXFS_MOUNT():
    '''
        Ensure mounting of freevxfs filesystems is disabled
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    osrname = "/etc/modprobe.d/CIS.conf"
    linetoadd = "install freevxfs /bin/true"
    result = []
    if os.path.isfile(osrname):
        result = lookline_in_file(afile=osrname,thevalues=linetoadd,)

    if not result:
        writelines_infile(target=osrname,
                          lines=linetoadd + "\n",
                          mode='append')

    log_enforce('DONE\n')

# IZ.C.1.1.1.3
def DISABLE_JFFS2_MOUNT():
    '''
        Ensure mounting of jffs2 filesystems is disabled
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    osrname = "/etc/modprobe.d/CIS.conf"
    linetoadd = "install jffs2 /bin/true"
    result = []
    if os.path.isfile(osrname):
        result = lookline_in_file(afile=osrname,thevalues=linetoadd,)

    if not result:
        writelines_infile(target=osrname,
                          lines=linetoadd + "\n",
                          mode='append')

    log_enforce('DONE\n')

# IZ.C.1.1.1.4
def DISABLE_HFS_MOUNT():
    '''
        Ensure mounting of hfs filesystems is disabled
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    osrname = "/etc/modprobe.d/CIS.conf"
    linetoadd = "install hfs /bin/true"
    result = []
    if os.path.isfile(osrname):
        result = lookline_in_file(afile=osrname,thevalues=linetoadd,)

    if not result:
        writelines_infile(target=osrname,
                          lines=linetoadd + "\n",
                          mode='append')

    log_enforce('DONE\n')

# IZ.C.1.1.1.5
def DISABLE_HFSPLUS_MOUNT():
    '''
        Ensure mounting of hfsplus filesystems is disabled
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    osrname = "/etc/modprobe.d/CIS.conf"
    linetoadd = "install hfsplus /bin/true"
    result = []
    if os.path.isfile(osrname):
        result = lookline_in_file(afile=osrname,thevalues=linetoadd,)

    if not result:
        writelines_infile(target=osrname,
                          lines=linetoadd + "\n",
                          mode='append')

    log_enforce('DONE\n')

# IZ.C.1.1.1.6
def DISABLE_SQUASHFS_MOUNT():
    '''
        Ensure mounting of squashfs filesystems is disabled
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    osrname = "/etc/modprobe.d/CIS.conf"
    linetoadd = "install squashfs /bin/true"
    result = []
    if os.path.isfile(osrname):
        result = lookline_in_file(afile=osrname,thevalues=linetoadd,)

    if not result:
        writelines_infile(target=osrname,
                          lines=linetoadd + "\n",
                          mode='append')

    log_enforce('DONE\n')

# IZ.C.1.1.1.7
def DISABLE_UDF_MOUNT():
    '''
        Ensure mounting of udf filesystems is disabled
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    osrname = "/etc/modprobe.d/CIS.conf"
    linetoadd = "install udf /bin/true"
    result = []
    if os.path.isfile(osrname):
        result = lookline_in_file(afile=osrname,thevalues=linetoadd,)

    if not result:
        writelines_infile(target=osrname,
                          lines=linetoadd + "\n",
                          mode='append')

    log_enforce('DONE\n')

# IZ.1.1.7.2
def RESTRICT_LOGIN_ACCESS():
    '''
        Login access must be restricted to the physical console, or to a method that provides accountability to an individual
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    osrname = "/etc/securetty"
    for entry in fails:
        if 'file is not present' in entry:
            create_osr(osr=osrname,res_type='file',perms='0600')
        if 'pts entry is present' in entry:
            cmd = "sed -i '/pts/d'" + osrname
            execute_command(cmd)
            
    log_enforce('DONE\n')

# IZ.1.2.4.3
def DIR_FAILLOCK_EXISTS():
    '''
        /var/run/faillock directory must exist for all systems using pam_faillock.
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    cmd = "grep faillock /usr/lib/tmpfiles.d/pam.conf"
    cmd_exec = execute_command(cmd)

    if not (os.path.isfile("/etc/tmpfiles.d/pam.conf")):
        if 'd /var/run/faillock 0755 root root -' in str(cmd_exec['cmd_out']):
            cmd1= "systemd-tmpfiles --create"
            cmd_exec = execute_command(cmd1)
        else:
            log_enforce(format_nicely(checkname) +
                    ": /var/run/faillock doesnot exists create it manually")
            log_enforce("\nFAILED\n")
    else:
        result = lookline_in_file(afile="/etc/tmpfiles.d/pam.conf",thevalues="d /var/run/faillock 0755 root root -")
        if not result:
            log_enforce(format_nicely(checkname) +
                    ": /var/run/faillock doesnot exists create it manually2")
            log_enforce("\nFAILED\n")

    log_enforce('DONE\n')

# IZ.C.6.2.11
def FORWARD_FILES():
    '''
        Ensure no users have .forward files in directories located in local file systems.
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    for entry in fails:
        os.remove(entry)

    log_enforce('DONE\n')

# IZ.C.6.2.12
def NETRC_FILES():
    '''
        Ensure no users have .netrc files in directories located in local file systems.
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    for entry in fails:
        os.remove(entry)

    log_enforce('DONE\n')

# IZ.C.6.2.14
def RHOSTS_FILES():
    '''
        Ensure no users have .rhosts files in directories located in local file systems.
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    for entry in fails:
        os.remove(entry)

    log_enforce('DONE\n')

# AD.5.0.5
def FIREWALLD_CONFIG():
    '''
        Ensure Firewalld is configured.
    '''  
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "Firewalld is not configured,please configure manually.....\n")

    log_enforce('\nDONE\n')

# AD.5.0.7
def DELETE_TEMP_FILES():
    '''
        Temporary files can contain sensitive information that can be used by local attackers, deleted at regular intervals
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for entry in fails:
        if 'files older than 90 days are present' in entry:
            cmd = "find /tmp -type f -mtime +90 -delete"
            execute_command(cmd)


    log_enforce('DONE\n')

# IZ.1.1.9.0
def NON_PREVILEDGED_ID_PASSWORD(maxage='365'):
    '''
       Allow non-privileged ID to have a password expiration of 365 days, or more strict
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'password expiry must be set' in entry:

            username = entry.split()[1]
            osrname = '/etc/shadow'
            fieldno = 5
            except_regex = r'^(?!(%s)).*' % username

            if fails:
                update_field = search_file_replace_field(target=osrname,
                                          fieldno=fieldno,
                                          agreedvalue=maxage,
                                          delim=':', commentchr=None,
                                          except_regex=except_regex)
                if update_field != 1:
                    log_enforce(format_nicely(
                        checkname) + ': Password expiry not set for user %s, Please set manully. \n' % (username))
                else:
                    log_enforce('Password expiry set successfully for user %s\n' % (username))
                cmd = "sudo passwd -e " + username
                cmd_exec = execute_command(cmd)
                if cmd_exec['cmd_err']:
                    log_enforce(format_nicely(checkname) +
                                ': Error, failed in executing command: %s, Please do manully. \n' % (str(cmd_exec['cmd_err'])))
                elif cmd_exec['cmd_ret'] != 0:
                    log_enforce(format_nicely(
                                    checkname) + ':expire password failed for user %s, Please do manully.\n' % (username) )
                else:
                    log_enforce('expire password done successfully for user %s\n' % (username))


    log_enforce('\nDONE\n')

# IZ.C.4.1.3
def ENABLE_AUDITING():
    '''
       Ensure auditing for processes that start prior to auditd is enabled
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    inputfile = open('/etc/default/grub', 'r').readlines()
    write_file = open('/etc/default/grub','w')
    for line in inputfile:
        write_file.write(line)
        if 'GRUB_CMDLINE_LINUX' in line:
            new_line = line.replace('GRUB_CMDLINE_LINUX','GRUB_CMDLINE_LINUX="audit=1"')
            write_file.write(new_line + "\n")
    write_file.close()
    cmd = "grub2-mkconfig -o /boot/grub2/grub.cfg"
    cmd_exec = execute_command(cmd)

    log_enforce('\nDONE\n')

# AD.5.0.6
def KERNEL_IP_CONFIG(osrname='/etc/sysctl.conf',
                         directives=["net.ipv4.conf.all.send_redirects = 0","net.ipv4.conf.default.accept_redirects = 0",
                                     "kernel.dmesg_restrict = 1","kernel.kptr_restrict = 2","kernel.sysrq = 0","kernel.yama.ptrace_scope = 1 2 3"]):
    '''
        The kernel and networkparameters of the Linux operating systems to be hardened properly.
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    remediation_done = 0

    fails = eval('check.' + checkname)(**args)
    print("fails",fails)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if 'FILE_NOT_FOUND' in fails.keys():
        log_enforce(format_nicely(checkname) +
                    ": File %s not found.\n" % (fails['FILE_NOT_FOUND']))

    if 'MISSING_DIRECTIVES' in fails.keys():
        for directive in fails['MISSING_DIRECTIVES']:
            lines_to_file = directive
            add_line = writelines_infile(target=osrname,
                                         lines=lines_to_file + "\n",
                                         mode='append')
            if add_line != 1:
                log_enforce(format_nicely(
                            checkname) + ': line %s not added to file %s\n' % (lines_to_file, osrname))
            else:
                log_enforce('line %s is successfully added\n' %
                           (lines_to_file))
    if 'MISSING_Value' in fails.keys():
        for directive in fails['MISSING_Value']:
            search_key = directive.split('=')[0]
            lines_to_file = directive
            search_file_replace_line(target=osrname,
                                     regex=search_key,
                                     newline=lines_to_file + "\n",
                                     commentchr='#',
                                     uniq_occur=1)
            log_enforce('line %s is successfully replaced\n' %
                       (lines_to_file))

        directives.append('net.ipv4.route.flush = 1')

    log_enforce('\nDONE\n')

# AD.5.0.3
def SSH_CONFIG(osrname='/etc/ssh/sshd_config',
                      searchstrings=['AllowAgentForwarding no','AllowTcpForwarding no','ClientAliveCountMax 2','Compression no','LogLevel VERBOSE','MaxSessions 2','TCPKeepAlive no','X11Forwarding no']):
    '''
            In /etc/ssh/sshd_config fix weak SSH Conﬁguration
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    for entry in fails:
        if 'file MISSING' in entry:
            log_enforce(format_nicely(checkname) +
                        ': Files %s are not found\n' % (osrname))
        elif 'not found in file' in entry:
            line = entry.split()[1] + " " + entry.split()[2]
            add_line = writelines_infile(target=osrname,
                                         lines=line + "\n",
                                         mode='append')
            if add_line != 1:
                log_enforce(format_nicely(
                    checkname) + ': line %s not added to file %s\n' % (line, osrname))
            else:
                log_enforce('line %s yes is successfully added\n' %
                            (line))
        else:
            for value in searchstrings:
                val = entry.split()[4]
                search_key = entry.split()[0]
                old_entry = search_key + " " + val
                key = value.split()[0]
                if key in entry:
                    update_line = search_file_replace_line(
                        osrname, old_entry, value , commentchr='#', uniq_occur=1)
                    if update_line != 1:
                        log_enforce(format_nicely(checkname) +
                                    ': line %s not updated\n' % (old_entry))
                    else:
                        log_enforce('line %s  is successfully updated\n' %
                                    (old_entry))

    log_enforce('\nDONE\n')

# AD.5.0.9 & IV.5.0.2
def SU_COMMAND_RESTRICTION(directive,
                       pamfiles=['/etc/pam.d/su']):
    '''
        -----------------------
            REQ_ID:  52_1
        -----------------------

        /etc/pam.d/other:
            - auth required  pam_wheel.so use_uid

    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    for osrname in fails:
        writelines_infile(target=osrname,
                          lines=[directive + '\n'],
                          mode='append')

    log_enforce('DONE\n')

def CURRENT_PERMS_OF_FILES():
    '''
        Test function
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    print(fails)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    log_enforce("\nDone\n")

def AFTER_PERMS_OF_FILES():
    '''
        Test function
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    print(fails)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    log_enforce("\nDone\n")


# IZ.C.1.1.2

def TMP_PARTITION_EXIST(osrname="/etc/systemd/system/local-fs.target.wants/tmp.mount", directive='\tmp'):
    '''
              Ensure separate partition exists for /tmp partition
    ''' 
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING.\n")
    
    if 'Update config file' in value:
      cmd = "systemctl unmask tmp.mount"
      print('Running - systemctl unmask tmp.mount')
      out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
      (cmd_out, cmd_err) = out.communicate()
      cmd_ret = out.returncode
      if cmd_err: 
        log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
      cmd = "systemctl enable tmp.mount"
      print('Running - systemctl enable tmp.mount')
      out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
      (cmd_out, cmd_err) = out.communicate()
      cmd_ret = out.returncode
      output = cmd_out.decode("utf-8").strip("\n")
      print("OUTPUT",output)
      
      cmd = "systemctl restart  tmp.mount"
      print('Running - systemctl restart  tmp.mount')
      out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
      (cmd_out, cmd_err) = out.communicate()
      cmd_ret = out.returncode
      output = cmd_out.decode("utf-8").strip("\n")
    
      if cmd_err: 
        if 'Update config file' in value:log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
    log_enforce("\nDone\n")
    
    
# IZ.C.1.1.3
def TMP_PARTITION_CONFIGURATION_NODEV(osrname="/etc/systemd/system/local-fs.target.wants/tmp.mount", directive="nodev"):
    '''
	      Ensure nodev option set on /tmp partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if fails:
        return
        
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if 'Update config file' in value:
        with open(osrname, 'r') as f:
          lines = []
          new_line = []
          for line in f:
            if 'strictatime' in line:
              if directive not in line:
                split_line = line.split(',')
                split_line.insert(2,directive)
                new_line.append(','.join(split_line))
                print(new_line)
                lines.append(' '.join(new_line))
                log_enforce("Added the directive %s successfully ...\n" %directive)
            else:
              lines.append(line)  
              
        with open(osrname, 'w') as f:
          for line in lines:
            f.write(line)    
        
        cmd = "mount -o remount,nodev /tmp"
        out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        (cmd_out, cmd_err) = out.communicate()
        cmd_ret = out.returncode 
        
        if cmd_err: 
            log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')

    log_enforce("\nDone\n")
    

# IZ.C.1.1.4
def TMP_PARTITION_CONFIGURATION_NOSUID(osrname="/etc/systemd/system/local-fs.target.wants/tmp.mount", directive="nosuid"):
    
    #Ensure nosuid option set on /tmp partition
    
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if fails:
        return
        
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if 'Update config file' in value:
        print("Begning Enforce")  
        with open(osrname, 'r') as f:
          lines = []
          new_line = []
          for line in f:
            if 'strictatime' in line:
              if directive not in line:
                split_line = line.split(',')
                split_line.insert(2,directive)
                new_line.append(','.join(split_line))
                print(new_line)
                lines.append(' '.join(new_line))
                log_enforce("Added the directive %s successfully ...\n" %directive)
            else:
              lines.append(line)  
              
        with open(osrname, 'w') as f:
          for line in lines:
            f.write(line)  
            
        cmd = "mount -o remount,nosuid /tmp"
        out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        (cmd_out, cmd_err) = out.communicate()
        cmd_ret = out.returncode 
        
        if cmd_err: 
            log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')

    log_enforce("\nDone\n")
    
    
# IZ.C.1.1.5
def TMP_PARTITION_CONFIGURATION_NOEXEC(osrname="/etc/systemd/system/local-fs.target.wants/tmp.mount", directive="noexec"):
    
    #Ensure noexec option set on /tmp partition
    
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if fails:
        return
        
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    if 'Update config file' in value:
        print("Begning Enforce")  
        with open(osrname, 'r') as f:
          lines = []
          new_line = []
          for line in f:
            if 'strictatime' in line:
              if directive not in line:
                split_line = line.split(',')
                split_line.insert(2,directive)
                new_line.append(','.join(split_line))
                print(new_line)
                lines.append(' '.join(new_line))
                log_enforce("Added the directive %s successfully ...\n" %directive)
            else:
              lines.append(line)  
              
        with open(osrname, 'w') as f:
          for line in lines:
            f.write(line)  
            
        cmd = "mount -o remount,noexec /tmp"
        out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        (cmd_out, cmd_err) = out.communicate()
        cmd_ret = out.returncode 
        
        if cmd_err: 
            log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')

    log_enforce("\nDone\n")


# IZ.C.1.1.6

def VAR_PARTITION_EXIST(osrname="/etc/fstab", directive='/var'):
    '''
              Ensure separate partition exists for /var partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "Analyze the output of the Audit step above and perform the appropriate action to correct any discrepancies found.\n")
    
    
# IZ.C.1.1.7

def VAR_TMP_PARTITION_EXIST(osrname="/etc/fstab", directive="/var/tmp"):
    '''
              Ensure separate partition exists for /var/tmp partition
    ''' 
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "Analyze the output of the Audit step above and perform the appropriate action to correct any discrepancies found.\n")


# IZ.C.1.1.8

def VAR_TMP_PARTITION_CONFIGURATION_NODEV(osrname="/etc/fstab", directive="nodev"):  
    '''
        Ensure nodev option is set for /var/tmp partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails,values = eval('check.' + checkname)(**args)
    print(fails)
    if fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    with open(osrname, 'r') as f:
      lines = []
      new_line = []
      for line in f:
        if '/var/tmp' in line:
          if directive not in line:
            split_line = line.split()
            def_split = split_line[3].split(',')      
            def_split.insert(1,directive)
            new_line.append(','.join(def_split))
            str_new = " "
            split_line[3]=str_new.join(new_line)
            print(split_line)
            lines.append(' '.join(split_line) + '\n')
            log_enforce("Added the directive %s successfully ...\n" %directive)
          else:
            lines.append(line)
            log_enforce("Directive %s Already Exists...\n" %directive)
        else:
          lines.append(line)

    with open(osrname, 'w') as f:
      for line in lines:
        f.write(line)
        
    cmd = "mount -o remount,nodev /var/tmp"
    print("Running")
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode 
    if cmd_err: 
      log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
    log_enforce("\nDone\n")


# IZ.C.1.1.9

def VAR_TMP_PARTITION_CONFIGURATION_NOSUID(osrname="/etc/fstab", directive='nosuid'):  
    '''
        Ensure nosuid option is set for /var/tmp partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails,values = eval('check.' + checkname)(**args)
    print(fails)
    if fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    with open(osrname, 'r') as f:
      lines = []
      new_line = []
      for line in f:
        if '/var/tmp' in line:
          if directive not in line:
            split_line = line.split()
            def_split = split_line[3].split(',')      
            def_split.insert(1,directive)
            new_line.append(','.join(def_split))
            str_new = " "
            split_line[3]=str_new.join(new_line)
            print(split_line)
            lines.append(' '.join(split_line) + '\n')
            log_enforce("Added the directive %s successfully ...\n" %directive)
          else:
            lines.append(line)
            log_enforce("Directive %s Already Exists...\n" %directive)
        else:
          lines.append(line)

    with open(osrname, 'w') as f:
      for line in lines:
        f.write(line)
        
    cmd = "mount -o remount,nosuid /var/tmp"
    print("Running")
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode 
    if cmd_err: 
      log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
    log_enforce("\nDone\n")
    
    
# IZ.C.1.1.10

def VAR_TMP_PARTITION_CONFIGURATION_NOEXEC(osrname="/etc/fstab", directive='noexec'):  
    '''
        Ensure noexec option is set for /var/tmp partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails,values = eval('check.' + checkname)(**args)
    print(fails)
    if fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    with open(osrname, 'r') as f:
      lines = []
      new_line = []
      for line in f:
        if '/var/tmp' in line:
          if directive not in line:
            split_line = line.split()
            def_split = split_line[3].split(',')      
            def_split.insert(1,directive)
            new_line.append(','.join(def_split))
            str_new = " "
            split_line[3]=str_new.join(new_line)
            print(split_line)
            lines.append(' '.join(split_line) + '\n')
            log_enforce("Added the directive %s successfully ...\n" %directive)
          else:
            lines.append(line)
            log_enforce("Directive %s Already Exists...\n" %directive)
        else:
          lines.append(line)

    with open(osrname, 'w') as f:
      for line in lines:
        f.write(line)
        
    cmd = "mount -o remount,noexec /var/tmp"
    print("Running")
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode 
    if cmd_err: 
      log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
    log_enforce("\nDone\n")


# IZ.C.1.1.13

def HOME_PARTITION_EXIST(osrname='/etc/fstab', directive='/home'):
    '''
	      Ensure separate partition exists for /home
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "Analyze the output of the Audit step above and perform the appropriate action to correct any discrepancies found.\n")

# IZ.C.1.1.14

def HOME_PARTITION_CONFIGURATION_NODEV(osrname="/etc/fstab", directive="nodev"):  
    '''
        Ensure nodev option is set for /home partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails,values = eval('check.' + checkname)(**args)
    print(fails)
    if fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    with open(osrname, 'r') as f:
      lines = []
      new_line = []
      for line in f:
        if '/home' in line:
          if directive not in line:
            split_line = line.split()
            def_split = split_line[3].split(',')      
            def_split.insert(1,directive)
            new_line.append(','.join(def_split))
            str_new = " "
            split_line[3]=str_new.join(new_line)
            print(split_line)
            lines.append(' '.join(split_line) + '\n')
            log_enforce("Added the directive %s successfully ...\n" %directive)
          else:
            lines.append(line)
            log_enforce("Directive %s Already Exists...\n" %directive)
        else:
          lines.append(line)

    with open(osrname, 'w') as f:
      for line in lines:
        f.write(line)
        
    cmd = "mount -o remount,nodev /home"
    print("Running")
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode 
    if cmd_err: 
      log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
    log_enforce("\nDone\n")


# IZ.1.5.10.1
def CHECK_YPPASSWD_DAEMON():
    '''
        - Ensure ypbind, ypserv is not installed
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails = eval('check.' + checkname)(**args)
    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")
    print(fails)
    for entry in fails:
        if 'failed in executing command' in entry:
            log_enforce(format_nicely(checkname) + ': %s \n' % (entry))

        if 'package ypbind is installed' in entry:
            cmd = "yum remove -y ypbind"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) + ': Error, failed in executing command: %s \n' % (
                    str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) + ':Unable to uninstall package ypbind \n')
            else:
                log_enforce('Package ypbind uninstalled successfully\n')

        if 'package ypserv is installed' in entry:
            cmd = "yum remove -y ypserv"
            cmd_exec = execute_command(cmd)
            if cmd_exec['cmd_err']:
                log_enforce(format_nicely(checkname) + ': Error, failed in executing command: %s \n' % (
                    str(cmd_exec['cmd_err'])))
            elif cmd_exec['cmd_ret'] != 0:
                log_enforce(format_nicely(checkname) + ':Unable to uninstall package ypserv \n')
            else:
                log_enforce('Package ypserv uninstalled successfully\n')

    log_enforce('DONE\n')


# IZ.1.4.6.7

def RESTRICT_USER_SELECTION_TO_LOGIN_SHELLS(osrname='/etc/shells',directives=["/bin/sh", "/bin/bash", "/sbin/nologin", "/usr/bin/sh", "/usr/bin/bash", "/usr/sbin/nologin", "/bin/tcsh", "/bin/csh", "/bin/ksh", "/bin/rksh", "/bin/false", "/bin/ksh93", "/usr/bin/ksh", "/usr/bin/rksh", "/usr/bin/ksh93"]):
    '''
       Restrict user selection to login shells which supports time out
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    success, values = eval('check.' + checkname)(**args)

    if success:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")

    for (dr, probs) in values.items():
        if dr != "violations":
            for prob in probs:
                if prob['problem'] == 'shell_not_found':
                    writelines_infile(osrname, lines=prob["shell_name"]+"\n", mode='append')
                    log_enforce('New shell line is added \n')
                    
                if prob['problem'] == 'non_compliant_line_found':
                    deleteline_infile(osrname, prob["shell_name"])
                    log_enforce('Non-compliant line is deleted \n')


# IZ.1.1.13.2

def DENY_INTERACTIVE_LOGIN(maxage='90',osrname='/etc/security/remote_deny'):

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    for entry in fails:
        if 'File not present' in entry:
            create_osr(osr=osrname, res_type='file')
            userid = entry.split()[1]
            print(f"Created file #{osrname} and added id #{id}")
            writelines_infile(target=osrname,
                              lines=userid + "\n",
                              mode='append')
        if 'needs to be added in' in entry:
            userid = entry.split()[1]
            print(f"Added id #{id}")
            writelines_infile(target=osrname,
                              lines=userid + "\n",
                              mode='append')
    
    log_enforce('DONE\n')

    
# IZ.1.1.13.1
        
def ETC_SECURITY_REMOTE(directive, pamfile_1, pamfile_2):


    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    fails = eval('check.' + checkname)(**args)
    if not fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    for entry in fails:
      if '/etc/pam.d/password-auth - missing directive' in entry:
        writelines_infile(target=pamfile_1,
                              lines=directive + "\n",
                              mode='append')
                              
      if '/etc/pam.d/system-auth - missing directive' in entry:
        writelines_infile(target=pamfile_2,
                              lines=directive + "\n",
                              mode='append')
    
    log_enforce('DONE\n')


# IZ.C.1.1.11
def VAR_LOG_PARTITION(osrname='/etc/fstab',
                                    directive="/var/log"):
    '''
	      Ensure separate partition exists for /var/log
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "Analyze the output of the Audit step above and perform the appropriate action to correct any discrepancies found.\n")


# IZ.C.1.1.12
def VAR_LOG_AUDIT_PARTITION(osrname='/etc/fstab',
                                    directive="/var/log/audit"):
    '''
	      Ensure separate partition exists for /var/log/audit
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails, value = eval('check.' + checkname)(**args)

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "Analyze the output of the Audit step above and perform the appropriate action to correct any discrepancies found.\n")
    

# IZ.C.1.1.15
def DEV_SHM_PARTITION_CONFIG_NODEV(osrname="/etc/fstab", directive="nodev"):  
    '''
        Ensure nodev option is set for /dev/shm partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails,values = eval('check.' + checkname)(**args)
    print(fails)
    if fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    with open(osrname, 'r') as f:
      lines = []
      new_line = []
      for line in f:
        if '/dev/shm' in line:
          if directive not in line:
            split_line = line.split()
            def_split = split_line[3].split(',')      
            def_split.insert(1,directive)
            new_line.append(','.join(def_split))
            str_new = " "
            split_line[3]=str_new.join(new_line)
            print(split_line)
            lines.append(' '.join(split_line) + '\n')
            log_enforce("Added the directive %s successfully ...\n" %directive)
          else:
            lines.append(line)
            log_enforce("Directive %s Already Exists...\n" %directive)
        else:
          lines.append(line)

    with open(osrname, 'w') as f:
      for line in lines:
        f.write(line)
        
    cmd = "mount -o remount,nodev /dev/shm"
    # print("Running")
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode 
    if cmd_err: 
      log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
    log_enforce("\nDone\n")
    
    
# IZ.C.1.1.16
def DEV_SHM_PARTITION_CONFIG_NOSUID(osrname="/etc/fstab", directive="nosuid"):  
    '''
        Ensure nosuid option is set for /dev/shm partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails,values = eval('check.' + checkname)(**args)
    print(fails)
    if fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    with open(osrname, 'r') as f:
      lines = []
      new_line = []
      for line in f:
        if '/dev/shm' in line:
          if directive not in line:
            split_line = line.split()
            def_split = split_line[3].split(',')      
            def_split.insert(1,directive)
            new_line.append(','.join(def_split))
            str_new = " "
            split_line[3]=str_new.join(new_line)
            print(split_line)
            lines.append(' '.join(split_line) + '\n')
            log_enforce("Added the directive %s successfully ...\n" %directive)
          else:
            lines.append(line)
            log_enforce("Directive %s Already Exists...\n" %directive)
        else:
          lines.append(line)

    with open(osrname, 'w') as f:
      for line in lines:
        f.write(line)
        
    cmd = "mount -o remount,nosuid /dev/shm"
    # print("Running")
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode 
    if cmd_err: 
      log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
    log_enforce("\nDone\n")
    
    
# IZ.C.1.1.17
def DEV_SHM_PARTITION_CONFIG_NOEXEC(osrname="/etc/fstab", directive="noexec"):  
    '''
        Ensure noexec option is set for /dev/shm partition
    '''
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)
    fails,values = eval('check.' + checkname)(**args)
    print(fails)
    if fails:
        return
    log_enforce(format_nicely(checkname) + "ENFORCING ...\n")
    
    with open(osrname, 'r') as f:
      lines = []
      new_line = []
      for line in f:
        if '/dev/shm' in line:
          if directive not in line:
            split_line = line.split()
            def_split = split_line[3].split(',')      
            def_split.insert(1,directive)
            new_line.append(','.join(def_split))
            str_new = " "
            split_line[3]=str_new.join(new_line)
            print(split_line)
            lines.append(' '.join(split_line) + '\n')
            log_enforce("Added the directive %s successfully ...\n" %directive)
          else:
            lines.append(line)
            log_enforce("Directive %s Already Exists...\n" %directive)
        else:
          lines.append(line)

    with open(osrname, 'w') as f:
      for line in lines:
        f.write(line)
        
    cmd = "mount -o remount,noexec /dev/shm"
    # print("Running")
    out = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    (cmd_out, cmd_err) = out.communicate()
    cmd_ret = out.returncode 
    if cmd_err: 
      log_enforce(format_nicely(checkname) + ': Error, failed in executing command \n')
    
    log_enforce("\nDone\n")


 # IZ.6.2.18
def DUPLICATE_USER_ETC_PASSWD(osrname='/etc/passwd'):
    '''
        Removes the duplicates from /etc/passwd, by keeping only the last entry
        for each User Name
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # call the twin function from the check module, with the same args
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {490: ['line_1', 'line_2', 'line_3'], 0: ['ln_x', 'ln_y']}

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    all_lines = loadfile2dict(thefile=osrname, byfieldno=1)
    # keep_entries = [val[-1] for (key, val) in all_lines.iteritems()]

    # comment above line to support python 3 syntax replacing iteritems() with items()

    keep_entries = [val[-1] for (key, val) in all_lines.items()]

    writelines_infile(target=osrname, lines=keep_entries, mode='rewrite')

    log_enforce('DONE\n')


 # IZ.6.2.19
def DUPLICATE_GROUP_ETC_GROUP(osrname='/etc/group'):
    '''
        Removes the duplicates from /etc/group, by keeping only the last entry
        for each Group Name
    '''

    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    checkname = inspect.getframeinfo(frame)[2]
    args = dict((i, values[i]) for i in args)

    # call the twin function from the check module, with the same args
    fails = eval('check.' + checkname)(**args)
    # e.g: fails = {490: ['line_1', 'line_2', 'line_3'], 0: ['ln_x', 'ln_y']}

    if not fails:
        return

    log_enforce(format_nicely(checkname) + "ENFORCING ...")

    all_lines = loadfile2dict(thefile=osrname, byfieldno=1)
    # keep_entries = [val[-1] for (key, val) in all_lines.iteritems()]

    # comment above line to support python 3 syntax replacing iteritems() with items()

    keep_entries = [val[-1] for (key, val) in all_lines.items()]

    writelines_infile(target=osrname, lines=keep_entries, mode='rewrite')

    log_enforce('DONE\n')
