# frozen_string_literal: true

#! /usr/bin/env python

# Copyright:: Kyndryl 2022

import os
import sys
# import time
import datetime
import optparse
import platform

parser = optparse.OptionParser()
parser.add_option("-c", "--configfile",
                  default=os.path.join(os.path.dirname(os.path.abspath(
                    sys.argv[0])), 'hardening_conf.json'))
parser.add_option("-m", "--mode")
options, args = parser.parse_args()

CONFIGFILE = options.configfile
if not os.path.isfile(CONFIGFILE):
    print("\n\tThe configuration file %s does not exist \n" % (CONFIGFILE))
    exit(1)

RUN_MODE = options.mode  # check, enforce, off
if RUN_MODE and RUN_MODE not in ['check', 'enforce', 'off']:
    print ("\n\tValid values for 'mode': { check, enforce, off }\n")
    exit(2)

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])),
                       'logs_audit')
BKP_DIR = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])),
                       'bkps_audit')

# TSTAMP = '_%s_%s_%s__%s_%s_%s' % time.localtime()[0:6]
TSTAMP = datetime.datetime.now().strftime("_%Y_%m_%d__%H_%M_%S__%f")
LOG_AUDIT = os.path.join(LOG_DIR, 'audit' + TSTAMP + '.log')

MAX_CHECKNAME_LEN = 18
MAX_LEN = 12
BITRANGE = {
        'all':    [0, MAX_LEN],
        'others': [MAX_LEN - 3, MAX_LEN],
        'group':  [MAX_LEN - 6, MAX_LEN - 3],
        'owner':  [MAX_LEN - 9, MAX_LEN - 6]
        }

LIBPATH = ['/lib64', '/lib']
# try:
#     LIBPATH = [os.path.join('/', platform.sys.lib)]  # /lib64
#     # eg: /lib64/security/pam_unix.so
# except:  # Ubuntu, Debian....
#     # eg : /lib/x86_64-linux-gnu/security/pam_deny.so
#     LIBPATH = ['/lib', '/lib32', '/lib64']
