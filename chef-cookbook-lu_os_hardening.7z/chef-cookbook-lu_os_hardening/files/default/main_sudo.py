# frozen_string_literal: true

#! /usr/bin/env python

# Copyright:: Kyndryl 2022

'''
    The automation entry point.
    Loads the config file and calls the corresponding functions from the
    appropriate module: "check" or "enforce"
'''

import check
import enforce
import check_sudo
import enforce_sudo
import os
import sys
import json
from helper_funcs import *

# --------------------- MAIN ---------------------------- #

initdirs()

with open(CONFIGFILE) as fh:
    CHECKLIST = json.load(fh)

fh.close()

for item in CHECKLIST:

    if item['mode'].lower() == 'off':
        continue

    # added this to be able to overwrite on the spot all the individual mode
    # values from the json file.....except off
    if RUN_MODE:
        item['mode'] = RUN_MODE

    if item['mode'].lower() == 'check':
        # from the "check" module, call the func identified by item[name]
        # passing it the params contained by item['params']
        eval('check_sudo.' + item['name'])(**item['params'])
        continue

    if item['mode'].lower() == 'enforce':
        # from the "enforce" module, call the func identified by item[name]
        # passing it the params contained by item['params']
        eval('enforce_sudo.' + item['name'])(**item['params'])
        continue

    # else....invalid option: issue a warning, skip check and move on
    log_enforce(descr='\n' + format_nicely(item['name']) +
                " *** WARNING *** Invalid mode: '%s'" % item['mode'] +
                "\n" + " " * (3 + MAX_CHECKNAME_LEN) +
                " Should be one of the following: " +
                "{ \"off\" | \"check\" | \"enforce\" }. Skipping item...\n")
