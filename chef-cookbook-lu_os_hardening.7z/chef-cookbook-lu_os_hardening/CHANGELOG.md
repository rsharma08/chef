# chef-cookbook-lu_os_hardening CHANGELOG

This file is used to list changes made in each version of the chef-cookbook-lu_os_hardening cookbook.

# 0.1.0

Initial release.

- change 0
- change 1

