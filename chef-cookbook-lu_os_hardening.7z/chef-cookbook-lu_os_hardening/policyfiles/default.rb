# frozen_string_literal: true

# This policyfile is used solely for testing by Test Kithcen or ChefSpec.

# A name that describes what the system you're building with Chef does.
name 'lu_os_hardening_default'

# Where to find external cookbooks:
default_source :chef_server, 'https://chef.onelum.host/organizations/default'

# run_list: chef-client will run these recipes in the order specified.
run_list 'lu_os_hardening::default'

# Specify a custom source for a single cookbook:
cookbook 'lu_os_hardening', path: '..'
