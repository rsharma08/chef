# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Recipe:: prereq
#
# Copyright:: Kyndryl 2022, All Rights Reserved.
#
# <> This recipe configures the operating prerequisites for the product.

# expand_area = (node['lu_os_hardening_linux']['expand_area']).to_s
install_dir = (node['lu_os_hardening_linux']['install_dir']).to_s

# Abort the execution if the os platform is not redhat
#------------------------------------------------------------------------------

ruby_block 'Check if the platform is not redhat' do
  block do
    raise "#{node['platform']} is NOT Supported" unless platform?('redhat')
  end
end

# Create required directories
#-------------------------------------------------------------------------------
[install_dir].each do |dir|
  directory dir do
    recursive true
    action :create
    mode '750'
    owner 'root'
    group 'root'
  end
end

# Source the files to be executed
#-------------------------------------------------------------------------------
node['lu_os_hardening_linux']['archive_names'].each_pair do |_p, v|
  filename = v['filename']

  cookbook_file filename do
    path "#{install_dir}/#{filename}"
    owner 'root'
    group 'root'
    mode '0755'
    action :create_if_missing
  end
end
