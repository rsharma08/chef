# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Recipe:: dnf_update
#
# Copyright:: Kyndryl 2022, All Rights Reserved.
#
# <> This recipe updates a Rhel release using 'dnf update -y --releasever=8.*'.

# local recipe variable
dnf_update_version = node['lu_os_hardening']['dnf_update_version']

# dnf update
bash "dnf update -y --releasever=#{dnf_update_version}" do
  user 'root'
  code <<-DNFUPDATE
		yum-config-manager --disable rhui-rhel-8-for-x86_64-highavailability-rhui-rpms
		yum-config-manager --disable rhui-client-config-server-8-ha
		dnf update -y --releasever=#{dnf_update_version} --disablerepo='*' --enablerepo='rhel-8-appstream-rhui-rpms' --enablerepo='rhel-8-baseos-rhui-rpms' --enablerepo='rhui-client-config-server-8-ha' --exclude=corosync* --exclude=corosynclib* --exclude=pacemaker* --exclude=pcs*
  DNFUPDATE
  action :run
  retries 5
  retry_delay 180
  # not_if { node['platform_version'].include?(dnf_update_version) }
end
