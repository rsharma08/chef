# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Recipe:: cleanup
#
# Copyright:: Kyndryl 2022, All Rights Reserved.
#
# <> This recipe will remove any temporary installation files created as part of the automation.

# Local variables used in this recipe
expand_area = node['lu_os_hardening_linux']['expand_area']

# Delete expand_area directory
#-------------------------------------------------------------------------------
directory expand_area do
  recursive true
  action :delete
end
