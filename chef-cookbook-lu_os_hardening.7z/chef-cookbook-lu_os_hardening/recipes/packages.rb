#
# Cookbook:: lu_os_hardening
# Recipe:: packages
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# do package config for ubuntu
case node['platform_family']
when 'debian'
  include_recipe('lu_os_hardening::apt')
end

# do package config for rhel-family
case node['platform_family']
when 'rhel', 'fedora', 'amazon'
  include_recipe('lu_os_hardening::yum')
end

package 'ntp' do
  action :install
end

# File /etc/ntp is expected not to be executable by other
directory '/etc/ntp' do
  mode '0550'
end
# Ensure aide package is installed and configured
package 'aide' do
  action :install
end

cron 'aide_check' do
  minute '0'
  hour '0'
  command '/usr/sbin/aide --check'
end

file '/etc/security/limits.conf' do
  content '* hard core 0'
  action :create
end

# Ensure chrony is configured
file '/etc/chrony.conf' do
  content 'server pool.ntp.org iburst'
  action :create
end

package 'chrony' do
  action :remove
end

service 'rpcbind' do
  action [:stop, :disable]
end
