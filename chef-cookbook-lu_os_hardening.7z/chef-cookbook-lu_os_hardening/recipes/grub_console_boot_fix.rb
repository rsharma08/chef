# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Recipe:: grub_console_boot_fix
#
# Copyright:: Kyndryl 2022, All Rights Reserved.
#
# <> This recipe configures grub to fix console boot.

# Update grub configuration file : '/etc/default/grub'
ruby_block 'Update grub configuration file : /etc/default/grub' do
  block do
    file = Chef::Util::FileEdit.new('/etc/default/grub')
    file.insert_line_if_no_match(/^GRUB_TERMINAL=/, 'GRUB_TERMINAL="console serial"')
    file.insert_line_if_no_match(/^GRUB_SERIAL_COMMAND=/, 'GRUB_SERIAL_COMMAND="serial --speed=115200"')
    file.write_file
  end
  only_if 'ls /etc/default/grub'
  not_if %(grep 'GRUB_SERIAL_COMMAND="serial --speed=115200"' /etc/default/grub)
end

# Rebuild grub grub2 : grub2-mkconfig
# Subscribe to updation of grub configuration file
bash 'grub2-mkconfig' do
  user 'root'
  code <<-GRUB2
			grub2-mkconfig -o /boot/grub2/grub.cfg
  GRUB2
  action :nothing
  subscribes :run, 'ruby_block[Update grub configuration file : /etc/default/grub]', :immediately
end
