#
# Cookbook:: chef-cookbook-lu_os_hardening
# Recipe:: sticky
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# Define an array of directories on which to set the sticky bit
directories_to_sticky = ['/tmp', '/var/tmp', '/tmp/omnibus/cache'] # Add more directories as needed

# Iterate over the directories and set the sticky bit
directories_to_sticky.each do |dir|
  directory dir do
    mode '1777' # Sets the directory mode to include the sticky bit
    recursive true  # Apply the mode recursively to subdirectories
    action :create  # Create the directory if it doesn't exist
  end
end

# Define a method to set the sticky bit on world-writable directories
def sticky_bit_on_world_writable_directories(directory)
  execute "Set sticky bit on #{directory}" do
    command "chmod +t #{directory}"
    action :run
    only_if { ::File.directory?(directory) && (::File.stat(directory).mode & 0002 != 0) }
  end
end

# List of directories to check and set the sticky bit
world_writable_directories = [
  '/tmp',
  '/var/tmp',
  '/tmp/omnibus/cache',
  # Add more directories as needed
]

# Iterate over the list and set the sticky bit
world_writable_directories.each do |directory|
  sticky_bit_on_world_writable_directories(directory)
end

execute 'chmod' do
  command 'chmod +t /tmp/omnibus/cache'
  action :run
end
