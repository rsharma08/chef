#
# Cookbook:: lu_os_hardening
# Recipe:: default
#
# Copyright:: 2023, The Authors, All Rights Reserved.

include_recipe 'lu_os_hardening::login'
include_recipe 'lu_os_hardening::packages'
include_recipe 'lu_os_hardening::pam'
include_recipe 'lu_os_hardening::sshd'
include_recipe 'lu_os_hardening::sysctl'
include_recipe 'lu_os_hardening::securetty'
include_recipe 'lu_os_hardening::rsyslog'
include_recipe 'lu_os_hardening::mount'
include_recipe 'lu_os_hardening::sticky'
include_recipe 'lu_os_hardening::iptables'
include_recipe 'lu_os_hardening::permission'
include_recipe 'lu_os_hardening::auditd'
