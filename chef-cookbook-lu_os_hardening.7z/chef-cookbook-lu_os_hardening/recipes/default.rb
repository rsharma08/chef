#
# Cookbook:: chef-cookbook-lu_os_hardening
# Recipe:: default
#
# Copyright:: 2023, The Authors, All Rights Reserved.

include_recipe 'chef-cookbook-lu_os_hardening::login'
include_recipe 'chef-cookbook-lu_os_hardening::packages'
include_recipe 'chef-cookbook-lu_os_hardening::pam'
include_recipe 'chef-cookbook-lu_os_hardening::sshd'
include_recipe 'chef-cookbook-lu_os_hardening::sysctl'
include_recipe 'chef-cookbook-lu_os_hardening::auditd'
include_recipe 'chef-cookbook-lu_os_hardening::securetty'
