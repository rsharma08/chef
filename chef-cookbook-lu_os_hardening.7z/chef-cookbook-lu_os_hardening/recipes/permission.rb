#
# Cookbook:: chef-cookbook-lu_os_hardening
# Recipe:: permissions
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# Ensure directories and files permissions are restrictive as per CIS Compliance requirement

directories = ['/var/ftp', '/var/lib/rngd', '/var/lib/chrony', '/var/run/vboxadd']

directories.each do |dir|
  directory dir do
    owner 'root'
    group 'root'
    mode '0750'
    action :create
  end
end

execute 'logfile_permission' do
  command 'sudo setfacl -m u::rw-,g::r--,o::--- /var/log'
  action :run
end

# Define the directory path to apply permission
directory_path = '/var/log'

# Use the `execute` resource to find and change permissions for all files
execute 'change_permissions' do
  command "find #{directory_path} -type f -exec chmod 0640 {} +"
  action :run
end

file '/etc/crontab' do
  mode '0600'
end

%w(/etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly /etc/cron.d).each do |dir|
  directory dir do
    mode '0700'
  end
end

# Create hosts.deny file if doesnt exist
file '/etc/hosts.deny' do
  content 'ALL: ALL'
  action :create
end

# xccdf_org.cisecurity.benchmarks_rule_5.1.8_Ensure_atcron_is_restricted_to_authorized_users: Ensure at/cron is restricted to authorized users
file '/etc/cron.deny' do
  action :delete
end

file '/etc/at.deny' do
  action :delete
end

#  File /etc/at.allow uid is expected to cmp == 0
# File /etc/at.allow is expected not to be readable by other expected File /etc/at.allow not to be readable by other
file '/etc/at.allow' do
  owner 'root'
  # mode '0550'
end

file '/etc/at.allow' do
  owner 'root'
  mode '0700'
end

# File /etc/cron.allow uid is expected to cmp == 0 expected: 0
file '/etc/cron.allow' do
  owner 'root'
  group 'root'
end

# [FAIL]  File /etc/cron.allow is expected not to be readable by other
# expected File /etc/cron.allow not to be readable by other
file '/etc/cron.allow' do
  mode '0700'
end

#  xccdf_org.cisecurity.benchmarks_rule_6.1.10_Ensure_no_world_writable_files_exist: Ensure no world writable files exist
file '/tmp/omnibus/cache/chef-18.2.7-1.el7.x86_64.rpm' do
  mode '0555'
end

file '/tmp/omnibus/cache/chef_18.2.7-1_amd64.deb' do
  mode '0555'
end

bash 'setting_permission' do
  code <<-EOH
        #!/bin/bash
        awk -F: '($1!~/(halt|sync|shutdown|nfsnobody|vagrant|ec2-user)/ &&
        $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/)
        {print $6}' /etc/passwd | while read -r dir; do
         if [ -d "$dir" ]; then
         dirperm=$(stat -L -c "%A" "$dir")
         if [ "$(echo "$dirperm" | cut -c6)" != "-" ] || [ "$(echo "$dirperm" |
        cut -c8)" != "-" ] || [ "$(echo "$dirperm" | cut -c9)" != "-" ] || [ "$(echo
        "$dirperm" | cut -c10)" != "-" ]; then
         chmod g-w,o-rwx "$dir"
         fi
         fi
        done

  EOH
  action :run
end
