# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Recipe:: python3_install
#
# Copyright:: Kyndryl 2022, All Rights Reserved.

# ON RHEL 8
package node['lu_os_hardening_linux']['package'] do
  action :install
end

# ON RHEL 8
package node['lu_os_hardening_linux']['net_tools_package'] do
  action :install
end
