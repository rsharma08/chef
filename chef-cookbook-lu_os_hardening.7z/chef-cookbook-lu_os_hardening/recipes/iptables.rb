#
# Cookbook:: chef-cookbook-lu_os_hardening
# Recipe:: iptables
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# Recipe to configure IPv6 firewall rule with ip6tables

# Define the rule as a variable for better readability
chef_gem 'mixlib-shellout' do
  compile_time false
  action  :install
end

package 'iptables-services' do
  action  :install
end

service 'iptables' do
  action  [:enable, :start]
end

service 'ip6tables' do
  action  [:enable, :start]
end

ipv6_rule_input = '-A INPUT -i lo -j ACCEPT'
# Execute the ip6tables command to add the rule
execute 'add_ipv6_rule' do
  command "ip6tables #{ipv6_rule_input}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo ip6tables -L INPUT -v -n  | grep -- ACCEPT | grep -- lo | wc -l ')
    cmd.run_command
    cmd.stdout.to_i == 0
  end
end

ipv6_rule_output = '-A OUTPUT -o lo -j ACCEPT'
# Execute the ip6tables command to add the rule
execute 'add_ipv6_rule' do
  command "ip6tables #{ipv6_rule_output}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo ip6tables -L OUTPUT -v -n  | grep -- ACCEPT | grep -- lo | wc -l')
    cmd.run_command
    cmd.stdout.to_i == 0
  end
end

ipv6_rule_drop = '-A INPUT -s ::1 -j DROP'
# Execute the ip6tables command to add the rule
execute 'add_ipv6_rule' do
  command "ip6tables #{ipv6_rule_drop}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo ip6tables -L INPUT -v -n  | grep -- DROP | wc -l')
    cmd.run_command
    cmd.stdout.to_i == 0

    # puts "#{cmd.stdout}"
    # puts "#{minimum_find}"
    # $output == $minimum_find
  end
end

ipv4_rule_input = '-A INPUT -i lo -j ACCEPT'
# Execute the iptables command to add the rule
execute 'add_ipv4_rule' do
  command "iptables #{ipv4_rule_input}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo iptables -L INPUT -v -n  | grep -- ACCEPT | grep -- lo | wc -l ')
    cmd.run_command
    cmd.stdout.to_i == 0
  end
end

ipv4_rule_output = '-A OUTPUT -o lo -j ACCEPT'
# Execute the iptables command to add the rule
execute 'add_ipv4_rule' do
  command "iptables #{ipv4_rule_output}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo iptables -L OUTPUT -v -n  | grep -- ACCEPT | grep -- lo | wc -l')
    cmd.run_command
    cmd.stdout.to_i == 0
  end
end

ipv4_rule_drop = '-A INPUT -s 127.0.0.0/8 -j DROP'
# Execute the ip6tables command to add the rule
execute 'add_ipv4_rule' do
  command "iptables #{ipv4_rule_drop}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo iptables -L INPUT -v -n  | grep -- DROP | wc -l')
    cmd.run_command
    cmd.stdout.to_i == 0
    # puts "#{cmd.stdout}"
    # puts "#{minimum_find}"
    # $output == $minimum_find
  end
end

ipv4_rule_udp = '-A INPUT -p udp -m udp --dport 68 -m state --state NEW,ESTABLISHED -j ACCEPT'
# Execute the iptables command to add the rule
execute 'add_ipv4_rule' do
  command "iptables #{ipv4_rule_udp}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo iptables -L INPUT -v -n | grep -- ACCEPT |grep -- udp | wc -l')
    cmd.run_command
    cmd.stdout.to_i == 0
  end
end

ipv4_rule_udp_output = '-A OUTPUT -p udp -m udp --sport 68 -m state --state ESTABLISHED -j ACCEPT'
# Execute the iptables command to add the rule
execute 'add_ipv4_rule' do
  command "iptables #{ipv4_rule_udp_output}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo iptables -L OUTPUT -v -n | grep -- ACCEPT |grep -- udp | wc -l')
    cmd.run_command
    cmd.stdout.to_i == 0
  end
end

ipv4_rule_22_input = '-A INPUT -p tcp -m tcp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT'
# Execute the iptables command to add the rule
execute 'add_ipv4_rule' do
  command "iptables #{ipv4_rule_22_input}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo iptables -L INPUT -v -n | grep -- ACCEPT |grep -- dpt:22 | wc -l')
    cmd.run_command
    cmd.stdout.to_i == 1
  end
end

ipv4_rule_22_output = '-A OUTPUT -p tcp -m tcp --sport 22 -m state --state ESTABLISHED -j ACCEPT'
# Execute the iptables command to add the rule
execute 'add_ipv4_rule' do
  command "iptables #{ipv4_rule_22_output}"
  action :run
  only_if do
    cmd = Mixlib::ShellOut.new('sudo iptables -L OUTPUT -v -n | grep -- ACCEPT |grep -- spt:22 | wc -l')
    cmd.run_command
    cmd.stdout.to_i == 0
  end
end

directory '/var/log/' do
  recursive true
  action  :create
  mode    '0640'
end
