# frozen_string_literal: true
#
# Cookbook:: lu_os_hardening

# Recipe:: update_libcurl_package
# Copyright:: Kyndryl, 2022
# <> Installation recipe:: (update_libcurl_package.rb)
# <> Description:: This recipe resposbible for updating libcurl package

# Upgrade package
package 'libcurl' do
  action :upgrade
end
