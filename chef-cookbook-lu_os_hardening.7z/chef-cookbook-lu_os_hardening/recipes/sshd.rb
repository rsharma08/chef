#
# Cookbook:: chef-cookbook-lu_os_hardening
# Recipe:: sshd
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# Configuring sshd_config as per Controls specified in reference

# updating default content message

['/etc/motd', '/etc/issue', '/etc/issue.net', '/etc/update-motd.d/30-banner'].each do |file|
  file file do
    content 'Authorized users only. All activity may be monitored and reported.'
    action :create
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.19_Ensure_SSH_warning_banner_is_configured: Ensure SSH warning banner is configure
file '/etc/ssh/sshd_config' do
  content 'Banner /etc/issue.net'
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.15_Ensure_that_strong_Key_Exchange_algorithms_a
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.insert_line_if_no_match(/^KexAlgorithms\s.*$/, 'KexAlgorithms curve25519-sha256@libssh.org,diffie-hellman-group-exchange-sha256')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.14_Ensure_only_strong_MAC_algorithms_are_used: Ensure only strong MAC algorithms are used
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.insert_line_if_no_match(/^MACs\s.*$/, 'MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.13_Ensure_only_strong_ciphers_are_used: Ensure only strong ciphers are used
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.insert_line_if_no_match(/^Ciphers\s.*$/, 'Ciphers aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.12_Ensure_SSH_PermitUserEnvironment_is_disabled: Ensure SSH PermitUserEnvironment is disabled
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^PermitUserEnvironment\s.*$/, 'PermitUserEnvironment no')
    file.insert_line_if_no_match(/^PermitUserEnvironment\s.*$/, 'PermitUserEnvironment no')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.11_Ensure_SSH_PermitEmptyPasswords_is_disabled: Ensure SSH PermitEmptyPasswords is disabled
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^PermitEmptyPasswords\s.*$/, 'PermitEmptyPasswords no')
    file.insert_line_if_no_match(/^PermitEmptyPasswords\s.*$/, 'PermitEmptyPasswords no')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.10_Ensure_SSH_root_login_is_disabled: Ensure SSH root login is disabled
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^PermitRootLogin\s.*$/, 'PermitRootLogin no')
    file.insert_line_if_no_match(/^PermitRootLogin\s.*$/, 'PermitRootLogin no')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.9_Ensure_SSH_HostbasedAuthentication_is_disabled: Ensure SSH HostbasedAuthentication is disabled
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^HostbasedAuthentication\s.*$/, 'HostbasedAuthentication no')
    file.insert_line_if_no_match(/^HostbasedAuthentication\s.*$/, 'HostbasedAuthentication no')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.8_Ensure_SSH_IgnoreRhosts_is_enabled: Ensure SSH IgnoreRhosts is enabled
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^IgnoreRhosts\s.*$/, 'IgnoreRhosts yes')
    file.insert_line_if_no_match(/^IgnoreRhosts\s.*$/, 'IgnoreRhosts yes')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.7_Ensure_SSH_MaxAuthTries_is_set_to_4_or_less
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^MaxAuthTries\s.*$/, 'MaxAuthTries 4')
    file.insert_line_if_no_match(/^MaxAuthTries\s.*$/, 'MaxAuthTries 4')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.5_Ensure_SSH_LogLevel_is_appropriate: Ensure SSH LogLevel is appropriate
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^LogLevel\s.*$/, 'LogLevel INFO')
    file.insert_line_if_no_match(/^LogLevel\s.*$/, 'LogLevel INFO')
    file.write_file
  end
end

# xccdf_org.cisecurity.benchmarks_rule_5.2.4_Ensure_SSH_Protocol_is_set_to_2: Ensure SSH Protocol is set to 2
ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^Protocol\s.*$/, 'Protocol 2')
    file.insert_line_if_no_match(/^Protocol\s.*$/, 'Protocol 2')
    file.write_file
  end
end

# Update the SSHD configuration file with the banner
ruby_block 'update_sshd_config_banner' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.insert_line_if_no_match(/^Banner.*$/, 'Banner /etc/issue.net')
    file.write_file
  end
end

ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^LoginGraceTime\s.*$/, 'LoginGraceTime 60')
    file.insert_line_if_no_match(/^LoginGraceTime\s.*$/, 'LoginGraceTime 60')
    file.write_file
  end
end

ruby_block 'update sshd_config' do
  block do
    file = Chef::Util::FileEdit.new('/etc/ssh/sshd_config')
    file.search_file_replace_line(/^ClientAliveInterval\s.*$/, 'ClientAliveInterval 300')
    file.insert_line_if_no_match(/^ClientAliveInterval\s.*$/, 'ClientAliveInterval 300')
    file.search_file_replace_line(/^ClientAliveCountMax\s.*$/, 'ClientAliveCountMax 3')
    file.insert_line_if_no_match(/^ClientAliveCountMax\s.*$/, 'ClientAliveCountMax 3')
    file.write_file
  end
end

# Define the SSH configuration file path
sshd_config_path = '/etc/ssh/sshd_config'

# Define the users you want to allow to SSH
allowed_users = ['ec2-user', 'vagrant']

# Add the allowed users to the SSH configuration file
ruby_block 'update_sshd_config' do
  block do
    sshd_config_content = File.read(sshd_config_path)

    # Check if AllowUsers directive already exists in the SSH config file
    if sshd_config_content.include?('AllowUsers')
      # AllowUsers directive already exists, update it
      sshd_config_content.gsub!(/^AllowUsers (.*)$/, "AllowUsers \\1 #{allowed_users.join(' ')}")
    else
      sshd_config_content << "\nAllowUsers #{allowed_users.join(' ')}"
    end

    # Write the modified content back to the SSH configuration file
    File.write(sshd_config_path, sshd_config_content)
  end
end

%w(hfs hfsplus squashfs udf).each do |mod|
  kernel_module mod do
    action :disable
  end
end

%w(dccp sctp rds tipc).each do |mod|
  kernel_module mod do
    action :disable
  end
end

# Notify SSHD service to restart if the configuration has changed
service 'sshd' do
  action :restart
end
