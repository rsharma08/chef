# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Recipe:: sudo_install
#
# Copyright:: Kyndryl 2022, All Rights Reserved.
#
# <> This recipe performs the product installation.
# Prepare the JSON File.
if platform?('redhat')
  template "#{node['lu_os_hardening_linux']['install_dir']}/#{node['lu_os_hardening_linux']['sudo_configuration_file']}" do
    source 'RHEL_hardening_sudo_conf.json.erb'
    mode '0775'
    variables(
      SUDO_FILE_WORD_WRITABLE_MODE: node['lu_os_hardening_linux']['itss']['SUDO_FILE_WORD_WRITABLE']['mode'],
      SUDO_FILE_WORD_WRITABLE_P1: node['lu_os_hardening_linux']['itss']['SUDO_FILE_WORD_WRITABLE']['params']['osrname'],
      SUDO_ENSURE_LOGGING_MODE: node['lu_os_hardening_linux']['itss']['SUDO_ENSURE_LOGGING']['mode'],
      SUDO_ENSURE_LOGGING_P1: node['lu_os_hardening_linux']['itss']['SUDO_ENSURE_LOGGING']['params']['osrname'],
      SUDO_ENSURE_LOGGING_P2: node['lu_os_hardening_linux']['itss']['SUDO_ENSURE_LOGGING']['params']['directive'],
      SUDO_LOG_RETENTION_TIMEFRAME_MODE: node['lu_os_hardening_linux']['itss']['SUDO_LOG_RETENTION_TIMEFRAME']['mode'],
      SUDO_LOG_RETENTION_TIMEFRAME_P1: node['lu_os_hardening_linux']['itss']['SUDO_LOG_RETENTION_TIMEFRAME']['params']['osrname'],
      SUDO_LOG_RETENTION_TIMEFRAME_P2: node['lu_os_hardening_linux']['itss']['SUDO_LOG_RETENTION_TIMEFRAME']['params']['directive'],
      SUDO_LOG_RETENTION_TIMEFRAME_P3: node['lu_os_hardening_linux']['itss']['SUDO_LOG_RETENTION_TIMEFRAME']['params']['timeframe'],
      SUDO_SPECIFIC_LOGFILE_MODE: node['lu_os_hardening_linux']['itss']['SUDO_SPECIFIC_LOGFILE']['mode'],
      SUDO_SPECIFIC_LOGFILE_P1: node['lu_os_hardening_linux']['itss']['SUDO_SPECIFIC_LOGFILE']['params']['osrname'],
      SUDO_SPECIFIC_LOGFILE_P2: node['lu_os_hardening_linux']['itss']['SUDO_SPECIFIC_LOGFILE']['params']['sudologfilename'],
      OSR_SUDOERS_D_PERMS_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['mode'],
      OSR_SUDOERS_D_PERMS_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['params']['osrname'],
      OSR_SUDOERS_D_PERMS_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['params']['agreedperms'],
      OSR_SUDOERS_D_PERMS_P3: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['params']['mode'],
      OSR_SUDOERS_D_PERMS_P4: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['params']['mustexist'],
      OSR_SUDOERS_D_PERMS_P5: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['params']['agreeduser'],
      OSR_SUDOERS_D_PERMS_P6: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['params']['category'],
      OSR_SUDOERS_FILE_CMD_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['mode'],
      OSR_SUDOERS_FILE_CMD_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_PERMS']['params']['osrname'],
      OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS']['mode'],
      OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS']['params']['osrname'],
      OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS']['params']['category'],
      OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS_P3: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_NESTED_ENV_FILE_PERMS']['params']['agreeduser'],
      OSR_SUDOERS_FILE_PERMS_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_PERMS']['mode'],
      OSR_SUDOERS_FILE_PERMS_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_PERMS']['params']['osrname'],
      OSR_SUDOERS_FILE_PERMS_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_PERMS']['params']['agreedperms'],
      OSR_SUDOERS_FILE_PERMS_P3: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_PERMS']['params']['mode'],
      OSR_SUDOERS_FILE_PERMS_P4: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_PERMS']['params']['mustexist'],
      OSR_SUDOERS_FILE_PERMS_P5: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_PERMS']['params']['agreeduser'],
      OSR_SUDOERS_FILE_NESTED_SUDO_INVOCATION_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_NESTED_SUDO_INVOCATION']['mode'],
      OSR_SUDOERS_FILE_NESTED_SUDO_INVOCATION_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_NESTED_SUDO_INVOCATION']['params']['osrname'],
      OSR_SUDOERS_FILE_NESTED_SUDO_INVOCATION_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_NESTED_SUDO_INVOCATION']['params']['directive'],
      OSR_SUDOERS_D_CMD_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_CMD']['mode'],
      OSR_SUDOERS_D_CMD_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_CMD']['params']['osrname'],
      OSR_SUDOERS_GROUP_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_GROUP']['mode'],
      OSR_SUDOERS_GROUP_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_GROUP']['params']['osrname'],
      OSR_SUDOERS_GROUP_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_GROUP']['params']['agreedperms'],
      OSR_SUDOERS_GROUP_P3: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_GROUP']['params']['mode'],
      OSR_SUDOERS_GROUP_P4: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_GROUP']['params']['category'],
      SUDO_FILE_SUDOEDIT_MODE: node['lu_os_hardening_linux']['itss']['SUDO_FILE_SUDOEDIT']['mode'],
      SUDO_FILE_SUDOEDIT_P1: node['lu_os_hardening_linux']['itss']['SUDO_FILE_SUDOEDIT']['params']['osrname'],
      OSR_SUDOERS_LOGGING_CMD_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_LOGGING_CMD']['mode'],
      OSR_SUDOERS_LOGGING_CMD_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_LOGGING_CMD']['params']['osrname'],
      OSR_SUDOERS_LOGGING_CMD_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_LOGGING_CMD']['params']['directive'],
      OSR_SUDOERS_SHELL_ESCAPE_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_SHELL_ESCAPE']['mode'],
      OSR_SUDOERS_SHELL_ESCAPE_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_SHELL_ESCAPE']['params']['osrname'],
      OSR_SUDOERS_SHELL_ESCAPE_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_SHELL_ESCAPE']['params']['directives'],
      SUDO_SECONDARY_LOGGING_MODE: node['lu_os_hardening_linux']['itss']['SUDO_SECONDARY_LOGGING']['mode'],
      SUDO_SECONDARY_LOGGING_P1: node['lu_os_hardening_linux']['itss']['SUDO_SECONDARY_LOGGING']['params']['osrname'],
      OSR_SUDOERS_D_OWNER_PERMS_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_OWNER_PERMS']['mode'],
      OSR_SUDOERS_D_OWNER_PERMS_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_OWNER_PERMS']['params']['osrname'],
      OSR_SUDOERS_D_OWNER_PERMS_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_OWNER_PERMS']['params']['agreedperms'],
      OSR_SUDOERS_D_OWNER_PERMS_P3: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_OWNER_PERMS']['params']['mode'],
      OSR_SUDOERS_D_OWNER_PERMS_P4: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_OWNER_PERMS']['params']['mustexist'],
      OSR_SUDOERS_D_OWNER_PERMS_P5: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_D_OWNER_PERMS']['params']['agreeduser'],
      OSR_SUDOERS_FILE_LISTED_CMD_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_LISTED_CMD']['mode'],
      OSR_SUDOERS_FILE_LISTED_CMD_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_FILE_LISTED_CMD']['params']['osrname'],
      OSR_SUDOERS_LOGGING_EXTERNAL_SYS_MODE: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_LOGGING_EXTERNAL_SYS']['mode'],
      OSR_SUDOERS_LOGGING_EXTERNAL_SYS_P1: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_LOGGING_EXTERNAL_SYS']['params']['osrname'],
      OSR_SUDOERS_LOGGING_EXTERNAL_SYS_P2: node['lu_os_hardening_linux']['itss']['OSR_SUDOERS_LOGGING_EXTERNAL_SYS']['params']['audits']
    )
  end
end

# execute python file, if the global variable execution_mode is null or empty, use the mode of each attributes, else use global setting for all attributes
execution_mode = node['lu_os_hardening_linux']['execution_mode']
execute "run-os-hardening-script-#{node['lu_os_hardening_linux']['execution_mode']}" do
  cwd node['lu_os_hardening_linux']['install_dir']
  if execution_mode.nil? || execution_mode.empty?
    command "python ./main_sudo.py --configfile #{node['lu_os_hardening_linux']['install_dir']}/#{node['lu_os_hardening_linux']['sudo_configuration_file']}"
  else
    command "python ./main_sudo.py --configfile #{node['lu_os_hardening_linux']['install_dir']}/#{node['lu_os_hardening_linux']['sudo_configuration_file']} --mode #{node['lu_os_hardening_linux']['execution_mode']}"
  end
  user 'root'
  only_if { ::File.exist?("#{node['lu_os_hardening_linux']['install_dir']}/main_sudo.py") }
  not_if { ::File.exist?("#{node['lu_os_hardening_linux']['install_dir']}/disable_hardening_continuos_compliance.txt") }
end

if node['lu_os_hardening_linux']['continuos_compliance'] == 'False'
  execute 'Disable-continuos_compliance' do
    cwd node['lu_os_hardening_linux']['install_dir']
    command 'touch disable_hardening_continuos_compliance.txt'
    user 'root'
    not_if { ::File.exist?("#{node['lu_os_hardening_linux']['install_dir']}/disable_hardening_continuos_compliance.txt") }
  end
end
