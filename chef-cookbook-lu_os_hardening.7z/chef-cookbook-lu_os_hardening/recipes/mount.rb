

mount '/mount/home' do
  options         'nodev'
  action          [:mount, :enable]
end