#
# Cookbook:: chef-cookbook-lu_os_hardening
# Recipe:: mount
#
# Copyright:: 2023, The Authors, All Rights Reserved.
# Ensure '/dev/shm', tmp, home are mounted with required options
# Ensure mounting of cramfs, HFS,hfsplus, squashfs, udf filesystems are mounted

['/var/tmp', '/tmp', '/home'].each do |dir|
  directory dir do
    owner 'root'
    group 'root'
    mode '0755'
    action :create
  end
end

mount '/dev/shm' do
  device 'tmpfs'
  fstype 'tmpfs'
  options 'rw,nosuid,nodev,noexec'
  action [:mount, :enable]
end

# Define the mount point and expected options
mount_point = '/dev/shm'
# expected_options = 'rw,nosuid,nodev,seclabel,noexec'

# Check if the mount point exists and is mounted
if File.exist?(mount_point) && File.readlines('/proc/mounts').grep(/#{Regexp.escape(mount_point)}/).any?
  # Get the current mount options
  current_options = File.readlines('/proc/mounts').grep(/#{Regexp.escape(mount_point)}/).first.split(' ')[3]

  # Check if "noexec" is already included in the options
  if current_options.include?('noexec')
    # It's already set as expected, do nothing
    log "#{mount_point} is already mounted with noexec option."
  else
    # Remount the partition with the "noexec" option
    execute 'remount_dev_shm_with_noexec' do
      command "mount -o remount,noexec #{mount_point}"
      action :run
    end
  end
else
  # The mount point doesn't exist or isn't mounted
  log "#{mount_point} is not mounted."
end

# Define the mount point and expected options
mount_point_tmp = '/tmp/omnibus/cache'

# Check if the mount point exists and is mounted
if File.exist?(mount_point_tmp) && File.readlines('/proc/mounts').grep(/#{Regexp.escape(mount_point_tmp)}/).any?
  # Get the current mount options
  current_options = File.readlines('/proc/mounts').grep(/#{Regexp.escape(mount_point_tmp)}/).first.split(' ')[3]

  # Check if "noexec" is already included in the options
  if current_options.include?('noexec')
    # It's already set as expected, do nothing
    log "#{mount_point_tmp} is already mounted with noexec option."
  else
    # Remount the partition with the "noexec" option
    execute 'remount_dev_tmp_with_noexec' do
      command "mount -o remount,noexec,nosuid #{mount_point_tmp}"
      action :run
    end
  end
else
  # The mount point doesn't exist or isn't mounted
  log "#{mount_point_tmp} is not mounted."
end

# Define the mount point and expected options
mount_point_home = '/home'

# Check if the mount point exists and is mounted
if File.exist?(mount_point_home) && File.readlines('/proc/mounts').grep(/#{Regexp.escape(mount_point_home)}/).any?
  # Get the current mount options
  current_options = File.readlines('/proc/mounts').grep(/#{Regexp.escape(mount_point_home)}/).first.split(' ')[3]

  # Check if "noexec" is already included in the options
  if current_options.include?('noexec')
    # It's already set as expected, do nothing
    log "#{mount_point_home} is already mounted with noexec option."
  else
    # Remount the partition with the "noexec" option
    execute 'remount_dev_shm_with_noexec' do
      command "mount -o remount,noexec #{mount_point_home}"
      action :run
    end
  end
else
  # The mount point doesn't exist or isn't mounted
  log "#{mount_point_home} is not mounted."
end
