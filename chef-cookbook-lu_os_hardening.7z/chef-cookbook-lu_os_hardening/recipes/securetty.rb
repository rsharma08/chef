
template '/etc/securetty' do
  source 'securetty.erb'
  mode '0400'
  owner 'root'
  group 'root'
  variables(
    ttys: node['chef-cookbook-lu_os_hardening']['auth']['root_ttys'].join("\n")
  )
end