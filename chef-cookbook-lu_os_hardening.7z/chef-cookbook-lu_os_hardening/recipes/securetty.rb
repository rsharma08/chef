#
# Cookbook:: lu_os_hardening
# Recipe:: Securetty
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# # See NSA 2.3.1.1 Restrict Root Logins to System Console
# Consume securetty template with ttys secure terminal from attribute file
template '/etc/securetty' do
  source 'securetty.erb'
  mode '0400'
  owner 'root'
  group 'root'
  variables(
    ttys: node['lu_os_hardening']['auth']['root_ttys'].join("\n")
  )
end
