# Define the directory path
directory_path = '/var/log'

# Use the `execute` resource to find and change permissions for all files
execute 'change_permissions' do
  command "find #{directory_path} -type f -exec chmod 0640 {} +"
  action :run
end
