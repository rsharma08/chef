# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Recipe:: gather_evidence
#
# Copyright:: Kyndryl 2022, All Rights Reserved.
#
# <> Evidence gathering recipe (gather_evidence.rb)
# <> This recipe will collect functional product information and store it in an archive.

# Local variables used in this recipe
evidence_path_unix = node['lu_os_hardening_linux']['evidence_path']['unix']

install_dir = node['lu_os_hardening_linux']['install_dir']

# Create Evidence Directory
#-------------------------------------------------------------------------------
directory evidence_path_unix do
  recursive true
  action :create
end

# Run validation script
#-------------------------------------------------------------------------------
execute 'Collect OS Hardening log' do
  command "cp #{install_dir}/logs_audit/*.log #{evidence_path_unix}"
  not_if "test -f #{evidence_path_unix}/audit*.log"
end
