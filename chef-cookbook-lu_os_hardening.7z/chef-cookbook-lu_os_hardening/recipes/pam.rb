#
# Cookbook:: lu_os_hardening
# Recipe:: pam
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# remove ccreds if not necessary
package 'pam-ccreds' do
  package_name node['lu_os_hardening']['packages']['pam_ccreds']
  action :remove
end

case node['platform_family']
  # do pam config for ubuntu
when 'debian'

  passwdqc_path = '/usr/share/pam-configs/passwdqc'
  tally2_path = '/usr/share/pam-configs/tally2'

  # See NSA 2.3.3.1.2
  if node['lu_os_hardening']['auth']['pam']['passwdqc']['enable']

    # remove pam_cracklib, because it does not play nice with passwdqc
    package 'pam-cracklib' do
      package_name node['lu_os_hardening']['packages']['pam_cracklib']
      action :remove
    end

    # get the package for strong password checking
    package 'pam-passwdqc' do
      package_name node['lu_os_hardening']['packages']['pam_passwdqc']
    end

    # configure passwdqc via central module:
    template passwdqc_path do
      source 'pam_passwdqc.erb'
      cookbook node['lu_os_hardening']['auth']['pam']['passwdqc']['template_cookbook']
      mode '0640'
      owner 'root'
      group 'root'
    end

    # deactivate passwdqc
  else

    # delete passwdqc file on ubuntu and debian
    file passwdqc_path do
      action :delete
    end

    # make sure the package is not on the system,
    # if this feature is not wanted
    package 'pam-passwdqc' do
      package_name node['lu_os_hardening']['packages']['pam_passwdqc']
      action :remove
    end
  end

  # configure tally2
  if node['lu_os_hardening']['auth']['retries'] > 0
    # tally2 is needed for pam
    package 'libpam-modules'

    template tally2_path do
      source 'pam_tally2.erb'
      cookbook node['lu_os_hardening']['auth']['pam']['tally2']['template_cookbook']
      mode '0640'
      owner 'root'
      group 'root'
    end
  else

    file tally2_path do
      action :delete
    end
  end

  execute 'update-pam' do
    command '/usr/sbin/pam-auth-update --package'
  end

  # do config for rhel-family
when 'rhel', 'fedora'

  # we do not allow to use authconfig, because it does not use the /etc/sysconfig/authconfig as a basis
  # therefore we edit /etc/pam.d/system-auth-ac/
  # @see http://serverfault.com/questions/292406/puppet-configuration-using-augeas-fails-if-combined-with-notify

  if node['platform_version'].to_f < 7
    # remove pam_cracklib, because it does not play nice with passwdqc in versions less than 7
    package 'pam-cracklib' do
      package_name node['lu_os_hardening']['packages']['pam_cracklib']
      action node['lu_os_hardening']['auth']['pam']['passwdqc']['enable'] ? :remove : :nothing
    end

    package 'pam-passwdqc' do
      package_name node['lu_os_hardening']['packages']['pam_passwdqc']
      action node['lu_os_hardening']['auth']['pam']['passwdqc']['enable'] ? :install : :remove
    end
  else
    # In RH-family distros > 7, 'pam_pwquality' obsoletes both pam_cracklib and pam_passwdqc
    # See https://linux.web.cern.ch/linux/rhel/releasenotes/RELEASE-NOTES-7.0-x86_64/
    package 'pam_pwquality' do
      package_name node['lu_os_hardening']['packages']['pam_pwquality']
    end
  end

  # configure passwdqc and tally via central system-auth confic:
  template '/etc/pam.d/system-auth-ac' do
    source 'rhel_system_auth.erb'
    cookbook node['lu_os_hardening']['auth']['pam']['system-auth']['template_cookbook']
    mode '0640'
    owner 'root'
    group 'root'
  end

  # NSA 2.3.3.5 Upgrade Password Hashing Algorithm to SHA-512
  template '/etc/libuser.conf' do
    source 'rhel_libuser.conf.erb'
    mode '0640'
    owner 'root'
    group 'root'
  end
end

# Ensure lockout for failed password attempts is configured
['/etc/pam.d/system-auth', '/etc/pam.d/password-auth'].each do |file|
  ruby_block "edit #{file}" do
    block do
      fe = Chef::Util::FileEdit.new(file)
      fe.insert_line_if_no_match(/^auth\s+required\s+pam_faillock\.so\s+preauth\s+audit\s+silent\s+deny=5\s+unlock_time=900$/, 'auth required pam_faillock.so preauth audit silent deny=5 unlock_time=900')
      fe.insert_line_if_no_match(/^auth\s+\[default=die\]\s+pam_faillock\.so\s+authfail\s+audit\s+deny=5\s+unlock_time=900$/, 'auth [default=die] pam_faillock.so authfail audit deny=5 unlock_time=900')
      fe.insert_line_if_no_match(/^auth\s+sufficient\s+pam_faillock\.so\s+authsucc\s+audit\s+deny=5\s+unlock_time=900$/, 'auth sufficient pam_faillock.so authsucc audit deny=5 unlock_time=900')
      fe.write_file
    end
  end
end

# Ensure lockout for failed password history control is configured in system auth
ruby_block 'update system-auth' do
  block do
    file = Chef::Util::FileEdit.new('/etc/pam.d/system-auth')
    file.search_file_replace_line(/^password\s+required\s+pam_pwhistory\.so\s+remember=([56789]|[1-9][0-9]+)/, 'password required pam_pwhistory.so use_authtok remember=5 retry=3')
    file.insert_line_if_no_match(/^password\s+required\s+pam_pwhistory\.so\s+remember=([56789]|[1-9][0-9]+)/, 'password required pam_pwhistory.so use_authtok remember=5 retry=3')
    file.write_file
  end
end

# Ensure lockout for failed password history control is configured in password auth
ruby_block 'update password-auth' do
  block do
    file = Chef::Util::FileEdit.new('/etc/pam.d/password-auth')
    file.search_file_replace_line(/^password\s+required\s+pam_pwhistory\.so\s+remember=([56789]|[1-9][0-9]+)/, 'password required pam_pwhistory.so use_authtok remember=5 retry=3')
    file.insert_line_if_no_match(/^password\s+required\s+pam_pwhistory\.so\s+remember=([56789]|[1-9][0-9]+)/, 'password required pam_pwhistory.so use_authtok remember=5 retry=3')
    file.write_file
  end
end

execute 'set max_days for vagrant' do
  command 'chage -M 365 vagrant'
  not_if 'grep "^vagrant:[^:]*:[^:]*:[^:]*:365:" /etc/shadow'
end

execute 'set min_days for vagrant' do
  command 'chage -m 7 vagrant'
  not_if 'grep "^vagrant:[^:]*:[^:]*:7:" /etc/shadow'
end

# Ensure useradd configure with default 30 days Inactive
template '/etc/default/useradd' do
  source 'useradd.erb'
  variables(inactive: 30)
end

# Only require for dev box testing, if Only_if condition met.
execute 'set inactive_days for vagrant' do
  command 'chage -I 30 vagrant'
  not_if 'grep "^vagrant:[^:]*:[^:]*:[^:]*:[^:]*:[^:]*:[^:]*:30:" /etc/shadow'
end

# Only require for dev box testing, if Only_if condition met.
execute 'set shell for vboxadd' do
  command 'usermod -s /sbin/nologin vboxadd'
  only_if 'grep "^vboxadd:" /etc/passwd | grep -v "/sbin/nologin"'
end

# setting up Umask for Bashrc setup
template '/etc/bashrc' do
  source 'bashrc.erb'
  variables(umask: '027')
end

# setting up Umask for user profiles
template '/etc/profile' do
  source 'profile.erb'
  variables(umask: '027')
end

# Configure /etc/pam.d/su as per Template su.erb
template '/etc/pam.d/su' do
  source 'su.erb'
end

# xccdf_org.cisecurity.benchmarks_rule_5.3.1_Ensure_password_creation_requirements_are_configured with minimum length
file '/etc/security/pwquality.conf' do
  content 'minlen = 14'
end
