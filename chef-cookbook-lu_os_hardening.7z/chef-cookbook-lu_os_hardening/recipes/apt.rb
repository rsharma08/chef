# apt-get and aptitude check package signatures by default.
# TODO: could check apt.conf to make sure this hasn't been disabled.

if node['lu_os_hardening']['security']['packages']['clean']
  # remove packages and handle virtual packages correctly.
  # this is the same package list as used for the redhat distro family
  node['lu_os_hardening']['security']['packages']['list'].each do |pkg|
    if !AptPackageExtras.virtual_package?(pkg)
      package pkg do
        action :purge
      end
    else
      AptPackageExtras.get_providing_packages(pkg).each do |provider|
        package provider do
          action :purge
        end
      end
    end
  end
end
