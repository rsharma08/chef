#
# Cookbook:: chef-cookbook-lu_os_hardening
# Recipe:: rsyslog
#
# Copyright:: 2023, The Authors, All Rights Reserved.

# Ensure rsyslog default file permissions and content configured as per CIS compliance requirement

file '/etc/rsyslog.conf' do
  content '$FileCreateMode 0640'
  action :create
end

file '/etc/rsyslog.conf' do
  content '*.* @remote-host:514'
  action :create
end

ruby_block 'update rsyslog.conf' do
  block do
    file = Chef::Util::FileEdit.new('/etc/rsyslog.conf')
    file.search_file_replace_line(/^FileCreateMode\s.*$/, '$FileCreateMode 0640')
    file.insert_line_if_no_match(/^FileCreateMode\s.*$/, '$FileCreateMode 0640')
    file.write_file
  end
end

ruby_block 'update rsyslog.d/*.conf' do
  block do
    file = Chef::Util::FileEdit.new('/etc/rsyslog.d/21-cloudinit.conf')
    file.search_file_replace_line(/^FileCreateMode\s.*$/, '$FileCreateMode 0640')
    file.insert_line_if_no_match(/^FileCreateMode\s.*$/, '$FileCreateMode 0640')
    file.write_file
  end
end

# Ensure rsyslog configure and applied
service 'rsyslog' do
  action :restart
end
