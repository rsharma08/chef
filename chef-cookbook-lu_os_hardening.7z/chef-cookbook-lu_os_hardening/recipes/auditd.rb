# frozen_string_literal: true

#
# Cookbook Name: chef-cookbook-lu_os_hardening
# Recipe: auditd.rb
#
# Copyright 2017, Artem Sidorenko
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

package node['chef-cookbook-lu_os_hardening']['packages']['auditd']

service 'auditd' do
  supports %i[start stop restart reload status]
  if (node['platform_family'] == 'rhel' && node['platform_version'].to_f >= 7) ||
     (node['platform_family'] == 'fedora' && node['platform_version'].to_f >= 27) ||
     (node['platform_family'] == 'amazon' && node['platform_version'].to_f >= 2)
    restart_command 'service auditd restart'
  end
  action [:enable]
end

unless node['chef-cookbook-lu_os_hardening']['auditd']['flush'].match(/^INCREMENTAL|INCREMENTAL_ASYNC$/) ||
       node['chef-cookbook-lu_os_hardening']['auditd']['flush'].empty?
  Chef::Log.fatal('If specifying a value for auditd flush parameter, must be one of INCREMENTAL or INCREMENTAL_ASYNC')
  raise
end

template '/etc/audit/auditd.conf' do
  source 'auditd.conf.erb'
  mode '0400'
  owner 'root'
  group 'root'
  variables(
    flush:               node['chef-cookbook-lu_os_hardening']['auditd']['flush'],
    log_group:           node['chef-cookbook-lu_os_hardening']['auditd']['log_group'],
    priority_boost:      node['chef-cookbook-lu_os_hardening']['auditd']['priority_boost'],
    freq:                node['chef-cookbook-lu_os_hardening']['auditd']['freq'],
    num_logs:            node['chef-cookbook-lu_os_hardening']['auditd']['num_logs'],
    disp_qos:            node['chef-cookbook-lu_os_hardening']['auditd']['disp_qos'],
    dispatcher:          node['chef-cookbook-lu_os_hardening']['auditd']['dispatcher'],
    name_format:         node['chef-cookbook-lu_os_hardening']['auditd']['name_format'],
    max_log_file:        node['chef-cookbook-lu_os_hardening']['auditd']['max_log_file'],
    tcp_listen_queue:    node['chef-cookbook-lu_os_hardening']['auditd']['tcp_listen_queue'],
    tcp_max_per_addr:    node['chef-cookbook-lu_os_hardening']['auditd']['tcp_max_per_addr'],
    tcp_client_max_idle: node['chef-cookbook-lu_os_hardening']['auditd']['tcp_client_max_idle'],
    enable_krb5:         node['chef-cookbook-lu_os_hardening']['auditd']['enable_krb5'],
    krb5_principal:      node['chef-cookbook-lu_os_hardening']['auditd']['krb5_principal']
  )
  notifies :restart, 'service[auditd]'
  action :create
end
