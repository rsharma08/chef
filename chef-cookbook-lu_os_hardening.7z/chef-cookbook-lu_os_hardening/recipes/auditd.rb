# Cookbook Name: lu_os_hardening
# Recipe: auditd.rb
#

package node['lu_os_hardening']['packages']['auditd']

service 'auditd' do
  supports %i[start stop restart reload status]
  if (node['platform_family'] == 'rhel' && node['platform_version'].to_f >= 7) ||
     (node['platform_family'] == 'fedora' && node['platform_version'].to_f >= 27) ||
     (node['platform_family'] == 'amazon' && node['platform_version'].to_f >= 2)
    restart_command 'service auditd restart'
  end
  action [:enable]
end

unless node['lu_os_hardening']['auditd']['flush'].match(/^INCREMENTAL|INCREMENTAL_ASYNC$/) ||
       node['lu_os_hardening']['auditd']['flush'].empty?
  Chef::Log.fatal('If specifying a value for auditd flush parameter, must be one of INCREMENTAL or INCREMENTAL_ASYNC')
  raise
end

template '/etc/audit/auditd.conf' do
  source 'auditd.conf.erb'
  mode '0400'
  owner 'root'
  group 'root'
  variables(
    flush: node['lu_os_hardening']['auditd']['flush'],
    log_group: node['lu_os_hardening']['auditd']['log_group'],
    priority_boost: node['lu_os_hardening']['auditd']['priority_boost'],
    freq: node['lu_os_hardening']['auditd']['freq'],
    num_logs: node['lu_os_hardening']['auditd']['num_logs'],
    disp_qos: node['lu_os_hardening']['auditd']['disp_qos'],
    dispatcher: node['lu_os_hardening']['auditd']['dispatcher'],
    name_format: node['lu_os_hardening']['auditd']['name_format'],
    max_log_file: node['lu_os_hardening']['auditd']['max_log_file'],
    tcp_listen_queue: node['lu_os_hardening']['auditd']['tcp_listen_queue'],
    tcp_max_per_addr: node['lu_os_hardening']['auditd']['tcp_max_per_addr'],
    tcp_client_max_idle: node['lu_os_hardening']['auditd']['tcp_client_max_idle'],
    enable_krb5: node['lu_os_hardening']['auditd']['enable_krb5'],
    krb5_principal: node['lu_os_hardening']['auditd']['krb5_principal']
  )
  notifies :restart, 'service[auditd]'
  action :create
end
