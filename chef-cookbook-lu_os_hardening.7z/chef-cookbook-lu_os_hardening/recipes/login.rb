template '/etc/login.defs' do
  source 'login.defs.erb'
  mode '0444'
  owner 'root'
  group 'root'
  variables(
    additional_user_paths:    node['chef-cookbook-lu_os_hardening']['env']['extra_user_paths'].join(':'), # :/usr/local/games:/usr/games
    umask:                    node['chef-cookbook-lu_os_hardening']['env']['umask'],
    password_max_age:         node['chef-cookbook-lu_os_hardening']['auth']['pw_max_age'],
    password_min_age:         node['chef-cookbook-lu_os_hardening']['auth']['pw_min_age'],
    password_warn_age:        node['chef-cookbook-lu_os_hardening']['auth']['pw_warn_age'],
    login_retries:            node['chef-cookbook-lu_os_hardening']['auth']['retries'],
    login_timeout:            node['chef-cookbook-lu_os_hardening']['auth']['timeout'],
    chfn_restrict:            '', # "rwh"
    allow_login_without_home: node['chef-cookbook-lu_os_hardening']['auth']['allow_homeless'],
    uid_min:                  node['chef-cookbook-lu_os_hardening']['auth']['uid_min'],
    uid_max:                  node['chef-cookbook-lu_os_hardening']['auth']['uid_max'],
    gid_min:                  node['chef-cookbook-lu_os_hardening']['auth']['gid_min'],
    gid_max:                  node['chef-cookbook-lu_os_hardening']['auth']['gid_max'],
    sys_uid_min:              node['chef-cookbook-lu_os_hardening']['auth']['sys_uid_min'],
    sys_uid_max:              node['chef-cookbook-lu_os_hardening']['auth']['sys_uid_max'],
    sys_gid_min:              node['chef-cookbook-lu_os_hardening']['auth']['sys_gid_min'],
    sys_gid_max:              node['chef-cookbook-lu_os_hardening']['auth']['sys_gid_max'],
    mail_dir:                 node['chef-cookbook-lu_os_hardening']['auth']['maildir']
  )
end
