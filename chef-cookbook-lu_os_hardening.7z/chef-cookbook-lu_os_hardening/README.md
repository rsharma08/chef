# chef-cookbook-lu_os_hardening

[1]: metadata.rb

## Overview

Chef cookbook for Applying OS Hardening as per CIS Benchmarking Level 1

## Requirements

Check out [metadata.rb][1] file for the:

- platforms supported;
- chef version required;
- cookbook dependencies.

## Usage

Assign required attributes in the attributes file and include the default recipe in your run list.

## Recipes

### default

Runs default recipe to apply entire cookbook Recipes:
1. Audit Recipe:Apply desired controls on '/etc/audit/auditd.conf' and enable and restart auditd.
2. Mount Recipe: Mount filesystem and setup desired options.
3. Packages: Apply packages as per Yum recipe for ('rhel', 'fedora', 'amazon') and APT recipe for Debian Distro. Remove packages with known issues
4. Pam: Configures `pam` and `pam_limits` module
5. ssshd: For SSHD config customisation as per CIS compliance
6. IPtales: Configure default basic requirement for Iptables INPUT, OUTPUT options.
7. Permissions: Update filesytem permissions for directories and files with requested mode.
8. Sticky: set the sticky bit on world-writable directories
9. Securetty: Restrict Root Logins to System Console
10. rsyslog: rsyslog default file permissions and content configured as per CIS compliance requirement
11. sysctl: Configure login configuration as per defined attributes


## Attributes

Attributes are described in their respective files.

## Local Testing

### Local testing

Please install [chef-workstation], [VirtualBox](https://www.virtualbox.org/) and [Vagrant](https://www.vagrantup.com/).
chef_version '>= 14.0'

Kitchen.yml configured to test amazon Linux 2 vagrant image 'bento/amazonlinux-2'

## Authors

- Author: Raman Sharma (<raman.sharma@luminorgroup.com>)


