#
# Cookbook Name:: lu_os_hardening
# Attributes:: sshd
#

default['lu_os_hardening']['sshd_config']['max_sessions'] = 10
default['lu_os_hardening']['sshd_config']['max_auth_tries'] = 4
default['lu_os_hardening']['sshd_config']['login_grace_time'] = 60
default['lu_os_hardening']['sshd_config']['kex_algorithms'] = 'diffie-hellman-group-exchange-sha256,diffie-hellman-group14-sha256,diffie-hellman-group16-sha512'
default['lu_os_hardening']['sshd_config']['allowed_users'] = ['ec2-user', 'root']
default['lu_os_hardening']['sshd_config']['allowed_groups'] = ['ssh_users']
