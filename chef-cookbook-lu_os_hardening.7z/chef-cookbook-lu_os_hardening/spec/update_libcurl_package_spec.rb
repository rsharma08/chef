# frozen_string_literal: true
#
# Cookbook:: lu_os_hardening
# Spec:: update_libcurl_package
#
# Copyright:: Kyndryl, 2022, All Rights Reserved.

require 'chefspec'

describe 'lu_os_hardening::update_libcurl_package' do
  let(:node) { subject.node }
  let(:attr) { node['lu_os_hardening_linux']['itss'] }
  cached! :subject do
    ChefSpec::SoloRunner.new(platform: 'redhat', version: '8').converge(described_recipe)
  end

  # Expected to update libcurl dnf_package
  describe 'Update libcurl dnf_package' do
    it do
      is_expected.to upgrade_package('libcurl')
    end
  end
end
