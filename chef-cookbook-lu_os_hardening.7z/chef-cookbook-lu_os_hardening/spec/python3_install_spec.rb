# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Spec:: install
#
# Copyright:: 2022, kyndryl, All Rights Reserved.

require 'chefspec'

describe 'lu_os_hardening::python3_install' do
  let(:node) { subject.node }
  let(:attr) { node['lu_os_hardening_linux']['itss'] }
  let(:lu_os_hardening_linux_python_package) { 'python36' }
  let(:lu_os_hardening_linux_nettools_package) { 'net-tools' }

  cached! :subject do
    ChefSpec::SoloRunner.new(platform: 'redhat', version: '8').converge(described_recipe)
  end

  # Expected to install Python36 package
  describe 'Install a Python36 package' do
    it do
      is_expected.to install_package(lu_os_hardening_linux_python_package.to_s)
    end
  end

  # Expected to install Net-tools package
  describe 'Install a Net-tools package' do
    it do
      is_expected.to install_package(lu_os_hardening_linux_nettools_package.to_s)
    end
  end
end
