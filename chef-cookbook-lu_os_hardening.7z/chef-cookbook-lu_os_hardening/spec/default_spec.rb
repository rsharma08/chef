# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Spec:: default
#
# Copyright:: Kyndryl, 2022, All Rights Reserved.

require 'chefspec'

describe 'lu_os_hardening::default' do
  let(:lu_oshardening_linux_expand_area) { '/tmp/rds/expand_area/os_hardening_linux' }
  let(:lu_oshardening_linux_config_file) { 'RHEL_hardening_conf.json' }
  let(:lu_oshardening_linux_install_dir) { '/opt/ibm/os_hardening_linux' }
  let(:lu_oshardening_linux_execution_mode) { 'enforce' }
  let(:lu_oshardening_linux_evidence_path) { '/var/log/chef_mcds/evidence/os_hardening_linux' }
  let(:lu_oshardening_linux_file1) { 'main.py' }
  let(:lu_oshardening_linux_file2) { 'global_consts.py' }
  let(:lu_oshardening_linux_file3) { 'helper_funcs.py' }
  let(:lu_oshardening_linux_file4) { 'check.py' }
  let(:lu_oshardening_linux_file5) { 'enforce.py' }
  let(:lu_oshardening_linux_file6) { 'check_sudo.py' }
  let(:lu_oshardening_linux_file7) { 'enforce_sudo.py' }
  let(:lu_oshardening_linux_file8) { 'main_sudo.py' }
  let(:lu_oshardening_linux_file9) { 'IBMsinit.sh' }
  let(:lu_oshardening_linux_file10) { 'IBMsinit.csh' }
  let(:lu_oshardening_linux_python_package) { 'python36' }
  before do
    stub_command("test -f #{lu_oshardening_linux_evidence_path}/audit*.log").and_return(false)
  end

  cached! :subject do
    allow_any_instance_of(Chef::Recipe).to receive(:aws_secret).and_return('jfrog_art_apikey')
    ChefSpec::SoloRunner.new(platform: 'redhat', version: '8') do |node|
      node.override['lu_os_hardening_linux']['install_dir'] = lu_oshardening_linux_install_dir
      node.override['lu_os_hardening_linux']['evidence_path']['unix'] = lu_oshardening_linux_evidence_path
      node.override['lu_os_hardening_linux']['configuration_file'] = lu_oshardening_linux_config_file
      node.override['lu_os_hardening_linux']['execution_mode'] = lu_oshardening_linux_execution_mode
      node.default['ec2']['region'] = 'eu-central-1'
    end.converge(described_recipe)
  end

  # Expected to include prereq recipe
  it 'includes the `prereq` recipe' do
    is_expected.to include_recipe('lu_os_hardening::prereq')
  end

  # Expected to include install recipe
  it 'includes the `install` recipe' do
    is_expected.to include_recipe('lu_os_hardening::install')
  end

  # Expected to include gather_evidence recipe
  it 'includes the `gather_evidence` recipe' do
    is_expected.to include_recipe('lu_os_hardening::gather_evidence')
  end

  # Expected to include cleanup recipe
  it 'includes the `cleanup` recipe' do
    is_expected.to include_recipe('lu_os_hardening::cleanup')
  end

  # Expected to include python3_install recipe
  it 'includes the `python3_install` recipe' do
    is_expected.to include_recipe('lu_os_hardening::python3_install')
  end
end
