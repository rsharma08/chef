# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Spec:: gather_evidence
#
# Copyright:: 2022, kyndryl, All Rights Reserved.

require 'chefspec'

describe 'lu_os_hardening::gather_evidence' do
  let(:node) { subject.node }
  let(:attr) { node['lu_os_hardening_linux']['itss'] }
  let(:lu_oshardening_linux_evidence_path) { '/var/log/chef_mcds/evidence/os_hardening_linux' }
  let(:lu_oshardening_linux_install_dir) { '/opt/ibm/os_hardening_linux' }
  before do
    stub_command("test -f #{lu_oshardening_linux_evidence_path}/audit*.log").and_return(false)
  end

  cached! :subject do
    allow_any_instance_of(Chef::Recipe).to receive(:aws_secret).and_return('jfrog_art_apikey')
    ChefSpec::SoloRunner.new(platform: 'redhat', version: '8') do |node|
      node.override['lu_os_hardening_linux']['install_dir'] = lu_oshardening_linux_install_dir
      node.override['lu_os_hardening_linux']['evidence_path']['unix'] = lu_oshardening_linux_evidence_path
      node.default['ec2']['region'] = 'eu-central-1'
    end.converge(described_recipe)
  end

  # Expected to create evidence log directory for product installation
  it 'Creates evidence log directory for product installation' do
    is_expected.to create_directory(lu_oshardening_linux_evidence_path).with(
      recursive: true
    )
  end

  # Expected to collect OS Hardening log
  describe 'Run validation script' do
    it do
      allow(File).to receive(:exist?).and_call_original
      allow(File).to receive(:exist?).with(lu_oshardening_linux_evidence_path).and_return(true)
      is_expected.to run_execute('Collect OS Hardening log')
    end
  end
end
