# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Spec:: cleanup
#
# Copyright:: Kyndryl, 2022, All Rights Reserved.

require 'chefspec'

describe 'lu_os_hardening::cleanup' do
  let(:node) { subject.node }
  let(:attr) { node['lu_os_hardening_linux']['itss'] }
  let(:lu_oshardening_linux_expand_area) { '/tmp/rds/expand_area/os_hardening_linux' }

  cached! :subject do
    allow_any_instance_of(Chef::Recipe).to receive(:aws_secret).and_return('jfrog_art_apikey')
    ChefSpec::SoloRunner.new(platform: 'redhat', version: '8').converge(described_recipe)
  end

  # Expected to delete the temporary directory used for the extraction of installation files
  it 'Deletes expand_area directory' do
    is_expected.to delete_directory(lu_oshardening_linux_expand_area).with(
      recursive: true
    )
  end
end
