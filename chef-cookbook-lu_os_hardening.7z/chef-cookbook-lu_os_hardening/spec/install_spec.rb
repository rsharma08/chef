# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Spec:: install
#
# Copyright:: Kyndryl, 2022, All Rights Reserved.

require 'chefspec'

describe 'lu_os_hardening::install' do
  let(:node) { subject.node }
  let(:attr) { node['lu_os_hardening_linux']['itss'] }
  let(:lu_oshardening_linux_config_file) { 'RHEL_hardening_conf.json' }
  let(:lu_oshardening_linux_install_dir) { '/opt/ibm/os_hardening_linux' }
  let(:lu_oshardening_linux_execution_mode) { 'enforce' }

  cached! :subject do
    allow_any_instance_of(Chef::Recipe).to receive(:aws_secret).and_return('jfrog_art_apikey')
    ChefSpec::SoloRunner.new(platform: 'redhat', version: '8') do |node|
      node.override['lu_os_hardening_linux']['configuration_file'] = lu_oshardening_linux_config_file
      node.override['lu_os_hardening_linux']['install_dir'] = lu_oshardening_linux_install_dir
      node.override['lu_os_hardening_linux']['execution_mode'] = lu_oshardening_linux_execution_mode
      node.default['ec2']['region'] = 'eu-central-1'
    end.converge(described_recipe)
  end

  # Expected to prepare the JSON configuration file for OS Hardening
  describe 'Prepare the JSON File' do
    it do
      allow(File).to receive(:exist?).and_call_original
      allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
      is_expected.to create_template("#{lu_oshardening_linux_install_dir}/#{lu_oshardening_linux_config_file}")
    end
  end

  # Expected to execute the python file
  describe 'Execute Python file' do
    it do
      allow(File).to receive(:exist?).and_call_original
      allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
      is_expected.to run_execute("run-os-hardening-script-#{lu_oshardening_linux_execution_mode}")
    end
  end

  # Expected to Disable continuous compliance
  describe 'Disable-continuos_compliance' do
    it do
      allow(File).to receive(:exist?).and_call_original
      allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
      is_expected.to run_execute('Disable-continuos_compliance')
    end
  end
end
