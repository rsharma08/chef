# frozen_string_literal: true

#
# Cookbook:: lu_os_hardening
# Spec:: prereq
#
# Copyright:: Kyndryl, 2022, All Rights Reserved.

require 'chefspec'

describe 'lu_os_hardening::prereq' do
  let(:node) { subject.node }
  let(:attr) { node['lu_os_hardening_linux']['itss'] }
  let(:lu_oshardening_linux_install_dir) { '/opt/ibm/os_hardening_linux' }
  let(:lU_oshardening_linux_file1) { 'main.py' }
  let(:lU_oshardening_linux_file2) { 'global_consts.py' }
  let(:lU_oshardening_linux_file3) { 'helper_funcs.py' }
  let(:lU_oshardening_linux_file4) { 'check.py' }
  let(:lU_oshardening_linux_file5) { 'enforce.py' }
  let(:lU_oshardening_linux_file6) { 'check_sudo.py' }
  let(:lU_oshardening_linux_file7) { 'enforce_sudo.py' }
  let(:lU_oshardening_linux_file8) { 'main_sudo.py' }
  let(:lU_oshardening_linux_file9) { 'IBMsinit.sh' }
  let(:lU_oshardening_linux_file10) { 'IBMsinit.csh' }

  cached! :subject do
    ChefSpec::SoloRunner.new(platform: 'redhat', version: '8') do |node|
      node.override['lu_os_hardening_linux']['install_dir'] = lu_oshardening_linux_install_dir
    end.converge(described_recipe)
  end

  # Expected to check the platform
  it 'Checks the Platform' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to run_ruby_block('Check if the platform is not redhat')
  end

  # Expected to create lu_oshardening_linux_install_base directory
  it 'Creates lu_oshardening_linux_install_base directory' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_directory(lu_oshardening_linux_install_dir).with(
      recursive: true
    )
  end

  # Expected to create OS Hardening linux file1
  it 'Sources the file1 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file1.to_s)
  end

  # Expected to create OS Hardening linux file2
  it 'Sources the file2 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file2.to_s)
  end

  # Expected to create OS Hardening linux file3
  it 'Sources the file3 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file3.to_s)
  end

  # Expected to create OS Hardening linux file4
  it 'Sources the file4 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file4.to_s)
  end

  # Expected to create OS Hardening linux file5
  it 'Sources the file5 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file5.to_s)
  end

  # Expected to create OS Hardening linux file6
  it 'Sources the file6 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file6.to_s)
  end

  # Expected to create OS Hardening linux file7
  it 'Sources the file7 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file7.to_s)
  end

  # Expected to create OS Hardening linux file8
  it 'Sources the file8 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file8.to_s)
  end

  # Expected to create OS Hardening linux file9
  it 'Sources the file9 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file9.to_s)
  end

  # Expected to create OS Hardening linux file10
  it 'Sources the file10 to be executed' do
    allow(File).to receive(:exist?).and_call_original
    allow(File).to receive(:exist?).with(lu_oshardening_linux_install_dir.to_s).and_return(false)
    is_expected.to create_cookbook_file_if_missing(lU_oshardening_linux_file10.to_s)
  end
end
