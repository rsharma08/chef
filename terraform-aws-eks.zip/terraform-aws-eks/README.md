<!-- BEGIN_TF_DOCS -->
# Terraform module for layer: eks

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.0 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | ~> 2.23 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_coreinfra_tags"></a> [coreinfra\_tags](#module\_coreinfra\_tags) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-coreinfra-tags.git | v3.0.5 |
| <a name="module_ecr"></a> [ecr](#module\_ecr) | ./modules/ecr | n/a |
| <a name="module_eks"></a> [eks](#module\_eks) | terraform-aws-modules/eks/aws | 19.15.4 |
| <a name="module_public_nlb"></a> [public\_nlb](#module\_public\_nlb) | terraform-aws-modules/alb/aws | ~> 8.7.0 |
| <a name="module_security_group_eks_private_nlb"></a> [security\_group\_eks\_private\_nlb](#module\_security\_group\_eks\_private\_nlb) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |
| <a name="module_security_group_private_nlb"></a> [security\_group\_private\_nlb](#module\_security\_group\_private\_nlb) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |
| <a name="module_security_group_public_nlb"></a> [security\_group\_public\_nlb](#module\_security\_group\_public\_nlb) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_account_name"></a> [aws\_account\_name](#input\_aws\_account\_name) | User friendly name for AWS account | `string` | n/a | yes |
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | AWS region in which resources will be deployed | `string` | `"eu-central-1"` | no |
| <a name="input_cluster_endpoint_public_access"></a> [cluster\_endpoint\_public\_access](#input\_cluster\_endpoint\_public\_access) | Indicates whether or not the Amazon EKS public API server endpoint is enabled | `bool` | `false` | no |
| <a name="input_create_worker_group_core"></a> [create\_worker\_group\_core](#input\_create\_worker\_group\_core) | Should 'core' worker group be created | `bool` | `true` | no |
| <a name="input_creator"></a> [creator](#input\_creator) | Email address of person deploying this module | `string` | n/a | yes |
| <a name="input_ecr_repositories"></a> [ecr\_repositories](#input\_ecr\_repositories) | List of ECR repositories to be created | `list(string)` | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | Environment type | `string` | n/a | yes |
| <a name="input_git_repo"></a> [git\_repo](#input\_git\_repo) | Link to Terraform module repository | `string` | n/a | yes |
| <a name="input_layer_network"></a> [layer\_network](#input\_layer\_network) | Layer 02-network information | `any` | n/a | yes |
| <a name="input_private_nlb_cidr_hostnum"></a> [private\_nlb\_cidr\_hostnum](#input\_private\_nlb\_cidr\_hostnum) | Host number used to calculate IP address based on private subnet CIDR blocks | `number` | `15` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ecr"></a> [ecr](#output\_ecr) | n/a |
| <a name="output_eks"></a> [eks](#output\_eks) | n/a |
| <a name="output_iam_roles"></a> [iam\_roles](#output\_iam\_roles) | n/a |
| <a name="output_public_nlb"></a> [public\_nlb](#output\_public\_nlb) | n/a |
| <a name="output_security_groups"></a> [security\_groups](#output\_security\_groups) | n/a |
<!-- END_TF_DOCS -->