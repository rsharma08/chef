<!---
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-aws-eks

Terraform module for Terragrunt layer: eks

## LINKS
#### [Additional documentation](./docs/README.md)
#### [CHANGELOG](CHANGELOG.md)

<!--- "./docs/header.md" content ends here.--->

<!--- "./README.md" file content bellow this comment is automticaly generated and replaced by terraform_docs and pre-commit hooks.
To make changes in anything below this comment, modify template file - ".terraform-docs.yaml".
Human managed content (abbove this comment) is automatically pulled in "./README.md" file from "./docs/header.md". --->

## Examples
```hcl
module "this" {
  source = "../"

  aws_account_name    = "devsecops"
  env                 = "tst"
  public_access_cidrs = ["0.0.0.0/0"]
  creator             = "chaimaa.ibnoucheikh@luminorgroup.com"
  git_repo            = "https://git.onelum.host/lds/Foundation/terragrunt-aws-coreinfra/-/tree/master/modules/eks"

  layers = {
    network = data.terraform_remote_state.network.outputs
  }
}
```
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.0 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | ~> 2.23 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_coreinfra_tags"></a> [coreinfra\_tags](#module\_coreinfra\_tags) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-coreinfra-tags.git | v3.0.5 |
| <a name="module_ecr"></a> [ecr](#module\_ecr) | ./modules/ecr | n/a |
| <a name="module_eks"></a> [eks](#module\_eks) | terraform-aws-modules/eks/aws | 19.15.4 |
| <a name="module_public_nlb"></a> [public\_nlb](#module\_public\_nlb) | terraform-aws-modules/alb/aws | ~> 8.7.0 |
| <a name="module_security_group_private_nlb"></a> [security\_group\_private\_nlb](#module\_security\_group\_private\_nlb) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |
| <a name="module_security_group_public_nlb"></a> [security\_group\_public\_nlb](#module\_security\_group\_public\_nlb) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_account_name"></a> [aws\_account\_name](#input\_aws\_account\_name) | User friendly name for AWS account | `string` | n/a | yes |
| <a name="input_cluster_endpoint_public_access"></a> [cluster\_endpoint\_public\_access](#input\_cluster\_endpoint\_public\_access) | Indicates whether or not the Amazon EKS public API server endpoint is enabled | `bool` | `false` | no |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Version of Kubernetes cluster to be deployed. | `string` | `"1.27"` | no |
| <a name="input_creator"></a> [creator](#input\_creator) | Email address of person deploying this module | `string` | n/a | yes |
| <a name="input_ecr_repositories"></a> [ecr\_repositories](#input\_ecr\_repositories) | List of ECR repositories to be created | `list(string)` | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | Environment type | `string` | n/a | yes |
| <a name="input_git_repo"></a> [git\_repo](#input\_git\_repo) | Link to Terraform module repository | `string` | n/a | yes |
| <a name="input_layers"></a> [layers](#input\_layers) | Infrastructure layers information | <pre>object({<br>    network = any<br>  })</pre> | n/a | yes |
| <a name="input_private_nlb_cidr_hostnum"></a> [private\_nlb\_cidr\_hostnum](#input\_private\_nlb\_cidr\_hostnum) | Host number used to calculate IP address based on private subnet CIDR blocks | `number` | `15` | no |
| <a name="input_public_access_cidrs"></a> [public\_access\_cidrs](#input\_public\_access\_cidrs) | List of whitelisted cidrs | `list(string)` | <pre>[<br>  "0.0.0.0/0"<br>]</pre> | no |
| <a name="input_whitelisted_access_cidrs"></a> [whitelisted\_access\_cidrs](#input\_whitelisted\_access\_cidrs) | whitelisted cidrs | `string` | `"0.0.0.0/0"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ecr"></a> [ecr](#output\_ecr) | Output representing the ECR information. |
| <a name="output_eks"></a> [eks](#output\_eks) | Output representing the EKS cluster information. |
| <a name="output_iam_roles"></a> [iam\_roles](#output\_iam\_roles) | Output representing the IAM Roles information. |
| <a name="output_public_nlb"></a> [public\_nlb](#output\_public\_nlb) | Output representing the Network Load balancer information. |
| <a name="output_security_groups"></a> [security\_groups](#output\_security\_groups) | Output representing the Security Group information. |

