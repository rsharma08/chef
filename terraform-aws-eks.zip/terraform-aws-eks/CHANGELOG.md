# CHANGELOG

## Improvements for Future Releases
- add terraform_validate hook to pre-commit
- add terraform_tflint hook to pre-commit


## v0.8.1 (2023-10-03)

## v0.8.0 (2023-09-28)
### Features
- adding diagram to docs directory
- adding changelog and precommit config

### Bug Fixes
- removed empty providers.tf file from module