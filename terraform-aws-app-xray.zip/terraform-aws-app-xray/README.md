<!---
"./docs/header.md" content starts here ...
This content is automaticaly included  from "./docs/header.md" in ."/README.md" file by terraform-docs.
To make changes, DO NOT edit "./README.md", to customize content edit "./docs/header.md". --->

# terraform-aws-app-xray

Repository offering organized and versioned Terraform/Terragrunt configurations designed to deploy and maintain XRAY application which will be used on DevSecOps Platform on AWS

## LINKS
#### [Additional documentation](./docs/README.md)
#### [CHANGELOG](CHANGELOG.md)

<!--- "./docs/header.md" content ends here.--->

<!--- "./README.md" file content bellow this comment is automticaly generated and replaced by terraform_docs and pre-commit hooks.
To make changes in anything below this comment, modify template file - ".terraform-docs.yaml".
Human managed content (abbove this comment) is automatically pulled in "./README.md" file from "./docs/header.md". --->

## Examples
```hcl
module "xray" {
  source = "../"

  aws_account_name = "devsecops"
  env              = "tst"
  creator          = "raman.sharma@luminorgroup.com"
  git_repo         = "https://git.onelum.host/lds/Foundation/terraform-aws-app-xray"
}
```
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.10.0 |
| <a name="provider_helm"></a> [helm](#provider\_helm) | ~> 2.10.1 |
| <a name="provider_http"></a> [http](#provider\_http) | ~> 3.4.0 |
| <a name="provider_kubectl"></a> [kubectl](#provider\_kubectl) | ~> 1.14.0 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | ~> 2.22.0 |
| <a name="provider_random"></a> [random](#provider\_random) | ~> 3.5.1 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_coreinfra_tags"></a> [coreinfra\_tags](#module\_coreinfra\_tags) | git::https://git.onelum.host/lds/terraform-modules/terraform-aws-coreinfra-tags.git | v3.0.5 |
| <a name="module_irsa_xray"></a> [irsa\_xray](#module\_irsa\_xray) | terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks | ~> 5.30 |
| <a name="module_rds_postgres"></a> [rds\_postgres](#module\_rds\_postgres) | terraform-aws-modules/rds/aws | n/a |
| <a name="module_security_group_rds_main"></a> [security\_group\_rds\_main](#module\_security\_group\_rds\_main) | terraform-aws-modules/security-group/aws | ~> 5.1.0 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_account_name"></a> [aws\_account\_name](#input\_aws\_account\_name) | User frendly name for AWS account | `string` | n/a | yes |
| <a name="input_creator"></a> [creator](#input\_creator) | Email address of person deploying this module | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | Environment tst or prd | `string` | `"tst"` | no |
| <a name="input_git_repo"></a> [git\_repo](#input\_git\_repo) | Link to Terraform module repository | `string` | n/a | yes |
| <a name="input_rds_allocated_storage"></a> [rds\_allocated\_storage](#input\_rds\_allocated\_storage) | RDS Allocated Storage | `number` | `10` | no |
| <a name="input_rds_backup_retention_period"></a> [rds\_backup\_retention\_period](#input\_rds\_backup\_retention\_period) | RDS Backup Retention Period | `number` | `1` | no |
| <a name="input_rds_backup_window"></a> [rds\_backup\_window](#input\_rds\_backup\_window) | RDS backup window | `string` | `"03:00-06:00"` | no |
| <a name="input_rds_engine_version"></a> [rds\_engine\_version](#input\_rds\_engine\_version) | RDS postgres engine version | `string` | `"15.4"` | no |
| <a name="input_rds_instance_class"></a> [rds\_instance\_class](#input\_rds\_instance\_class) | RDS Instance Class | `string` | `"db.t4g.small"` | no |
| <a name="input_rds_maintenance_window"></a> [rds\_maintenance\_window](#input\_rds\_maintenance\_window) | RDS Maintenance Window | `string` | `"Mon:00:00-Mon:03:00"` | no |
| <a name="input_rds_max_allocated_storage"></a> [rds\_max\_allocated\_storage](#input\_rds\_max\_allocated\_storage) | RDS Allocated Storage | `number` | `20` | no |
| <a name="input_rds_skip_final_snapshot"></a> [rds\_skip\_final\_snapshot](#input\_rds\_skip\_final\_snapshot) | RDS Skip final snapshot | `bool` | `true` | no |
| <a name="input_xray_version"></a> [xray\_version](#input\_xray\_version) | Xray Helm release version | `string` | `"103.83.8"` | no |

## Outputs

No outputs.

